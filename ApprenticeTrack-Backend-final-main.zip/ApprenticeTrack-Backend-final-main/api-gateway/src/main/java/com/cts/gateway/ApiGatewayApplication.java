package com.cts.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Spring Cloud Gateway edge service for the ApprenticeTrack platform.
 *
 * <p>Provides Eureka-backed service discovery, load-balanced ({@code lb://})
 * routing to the business microservices, and centralized JWT validation via a
 * {@code GlobalFilter}. Auto-registers as a Eureka client.</p>
 */
@SpringBootApplication
public class ApiGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayApplication.class, args);
    }
}