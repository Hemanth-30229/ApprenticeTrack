package com.cts.gateway.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Spring AOP logging for the gateway's controller layer (CLAUDE.md logging rule).
 * Entry/exit and execution time are logged to {@code spring.log}, matching every
 * business service's {@code aspect/LoggingAspect}.
 *
 * <p>Scoped to {@code controller} only: unlike the business services, the gateway
 * has no {@code service} layer — its request-handling logic lives in
 * {@link com.cts.gateway.filter.JwtAuthenticationFilter}, a reactive
 * {@code GlobalFilter} invoked directly by the Netty/WebFlux request pipeline
 * rather than through a Spring-managed bean method call, so a synchronous
 * {@code @Around} advice cannot wrap it meaningfully (it would log "exit" as soon
 * as the reactive chain is assembled, not when the response is actually written).
 * {@link com.cts.gateway.controller.FallbackController} methods are ordinary
 * synchronous handlers, so they log correctly with the same advice used elsewhere.</p>
 */
@Aspect
@Component
public class LoggingAspect {

    private static final Logger log = LoggerFactory.getLogger(LoggingAspect.class);

    @Pointcut("within(com.cts.gateway.controller..*)")
    public void controllerLayer() {}

    @Around("controllerLayer()")
    public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
        String target = joinPoint.getSignature().getDeclaringType().getSimpleName()
                + "." + joinPoint.getSignature().getName();
        long start = System.currentTimeMillis();
        log.info("--> {}", target);
        try {
            Object result = joinPoint.proceed();
            log.info("<-- {} ({} ms)", target, System.currentTimeMillis() - start);
            return result;
        } catch (Throwable ex) {
            log.error("!!! {} threw {}: {}", target, ex.getClass().getSimpleName(), ex.getMessage());
            throw ex;
        }
    }
}
