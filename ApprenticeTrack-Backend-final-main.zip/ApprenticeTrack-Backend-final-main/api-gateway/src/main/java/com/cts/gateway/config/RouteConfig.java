package com.cts.gateway.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Load-balanced gateway routing, wrapped with Resilience4j circuit breakers
 * (MIGRATION_PLAN.md §6, §10).
 *
 * <p>Routes are defined in the Java DSL (rather than YAML) so they are stable
 * across Spring Cloud Gateway property-namespace changes. Each route forwards a
 * path prefix to a Eureka-registered service via {@code lb://}. Path prefixes
 * mirror the monolith controller mappings (see MIGRATION_PLAN.md §7).</p>
 *
 * <p>Every route also carries a {@code circuitBreaker} filter: when the target
 * service is down, slow past the {@code resilience4j.timelimiter} threshold (shared
 * config, {@code application.yml} in config-repo), or the breaker itself is open,
 * the request is forwarded internally to {@link com.cts.gateway.controller.FallbackController}
 * instead of hanging or surfacing a raw connection error to the caller — the same
 * "degrade gracefully" principle MIGRATION_PLAN.md requires of the dashboard, applied
 * at the edge for every downstream service. Circuit breaker instance names are
 * per-route so each service's health is tracked (and can be tuned) independently
 * (visible at {@code /actuator/circuitbreakers}).</p>
 */
@Configuration
public class RouteConfig {

    @Bean
    public RouteLocator gatewayRoutes(RouteLocatorBuilder builder) {
        return builder.routes()
                .route("auth-service", r -> r
                        .path("/api/auth/**", "/api/users/**", "/api/roles/**")
                        .filters(f -> f.circuitBreaker(c -> c
                                .setName("authServiceCB")
                                .setFallbackUri("forward:/fallback/auth-service")))
                        .uri("lb://auth-service"))
                .route("training-service", r -> r
                        .path("/api/trainees/**", "/api/trade-courses/**",
                                "/api/batches/**", "/api/enrollments/**")
                        .filters(f -> f.circuitBreaker(c -> c
                                .setName("trainingServiceCB")
                                .setFallbackUri("forward:/fallback/training-service")))
                        .uri("lb://training-service"))
                .route("assessment-service", r -> r
                        .path("/api/competency-units/**", "/api/competency-results/**",
                                "/api/trade-tests/**", "/api/trade-test-results/**",
                                "/api/test-questions/**", "/api/test-attempts/**",
                                "/api/reassessments/**", "/api/assessors/**",
                                "/api/certificates/**")
                        .filters(f -> f.circuitBreaker(c -> c
                                .setName("assessmentServiceCB")
                                .setFallbackUri("forward:/fallback/assessment-service")))
                        .uri("lb://assessment-service"))
                .route("placement-service", r -> r
                        .path("/api/employers/**", "/api/vacancies/**", "/api/placements/**")
                        .filters(f -> f.circuitBreaker(c -> c
                                .setName("placementServiceCB")
                                .setFallbackUri("forward:/fallback/placement-service")))
                        .uri("lb://placement-service"))
                .route("ojt-stipend-service", r -> r
                        .path("/api/ojt-logs/**", "/api/stipend-disbursements/**",
                                "/api/attendance-summaries/**")
                        .filters(f -> f.circuitBreaker(c -> c
                                .setName("ojtStipendServiceCB")
                                .setFallbackUri("forward:/fallback/ojt-stipend-service")))
                        .uri("lb://ojt-stipend-service"))
                .route("platform-service", r -> r
                        .path("/api/notifications/**", "/api/audit-logs/**", "/api/dashboard/**")
                        .filters(f -> f.circuitBreaker(c -> c
                                .setName("platformServiceCB")
                                .setFallbackUri("forward:/fallback/platform-service")))
                        .uri("lb://platform-service"))

                // ── Aggregated Swagger: proxy each service's OpenAPI doc through the edge ──
                // The gateway serves one Swagger UI (/swagger-ui.html) whose dropdown fetches
                // these paths; each is rewritten to the service's own /v3/api-docs. Kept under
                // the already-public /v3/api-docs/** prefix so the JWT filter lets them through.
                .route("auth-service-docs", r -> r
                        .path("/v3/api-docs/auth-service")
                        .filters(f -> f.setPath("/v3/api-docs"))
                        .uri("lb://auth-service"))
                .route("training-service-docs", r -> r
                        .path("/v3/api-docs/training-service")
                        .filters(f -> f.setPath("/v3/api-docs"))
                        .uri("lb://training-service"))
                .route("assessment-service-docs", r -> r
                        .path("/v3/api-docs/assessment-service")
                        .filters(f -> f.setPath("/v3/api-docs"))
                        .uri("lb://assessment-service"))
                .route("placement-service-docs", r -> r
                        .path("/v3/api-docs/placement-service")
                        .filters(f -> f.setPath("/v3/api-docs"))
                        .uri("lb://placement-service"))
                .route("ojt-stipend-service-docs", r -> r
                        .path("/v3/api-docs/ojt-stipend-service")
                        .filters(f -> f.setPath("/v3/api-docs"))
                        .uri("lb://ojt-stipend-service"))
                .route("platform-service-docs", r -> r
                        .path("/v3/api-docs/platform-service")
                        .filters(f -> f.setPath("/v3/api-docs"))
                        .uri("lb://platform-service"))
                .build();
    }
}