package com.cts.gateway.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.reactive.CorsConfigurationSource;
import org.springframework.web.cors.reactive.UrlBasedCorsConfigurationSource;
import org.springframework.web.cors.reactive.CorsWebFilter;

/**
 * Gateway security.
 *
 * <p>The gateway's real authentication is performed by {@link com.cts.gateway.filter.JwtAuthenticationFilter}
 * (a Spring Cloud Gateway {@code GlobalFilter} that validates JWTs on every non-public path). Spring Security
 * is present on the classpath only for its filter infrastructure, so without an explicit chain its
 * secure-by-default behaviour (authenticate every exchange + CSRF) would reject routed requests — including
 * Swagger and the public auth endpoints — before the gateway filter ever runs.</p>
 *
 * <p>This chain therefore permits all exchanges at the Spring Security layer (delegating authorization to the
 * JWT global filter) and disables the stateful features (CSRF, form login, HTTP Basic) that don't apply to a
 * stateless edge gateway.</p>
 */
@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {

    @Bean
    public SecurityWebFilterChain gatewaySecurity(ServerHttpSecurity http) {
        return http
                .cors(cors -> {})
                .csrf(ServerHttpSecurity.CsrfSpec::disable)
                .httpBasic(ServerHttpSecurity.HttpBasicSpec::disable)
                .formLogin(ServerHttpSecurity.FormLoginSpec::disable)
                .logout(ServerHttpSecurity.LogoutSpec::disable)
                .authorizeExchange(exchange -> exchange.anyExchange().permitAll())
                .build();
    }

    @Bean
    public CorsWebFilter corsWebFilter() {
        CorsConfiguration configuration = new CorsConfiguration();

        configuration.addAllowedOriginPattern("*");
        configuration.addAllowedMethod("*");
        configuration.addAllowedHeader("*");

        UrlBasedCorsConfigurationSource source =
                new UrlBasedCorsConfigurationSource();

        source.registerCorsConfiguration("/**", configuration);

        return new CorsWebFilter((CorsConfigurationSource) source);
    }
}
