package com.cts.gateway.controller;

import java.time.Instant;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Resilience4j circuit-breaker fallback target for every gateway route (MIGRATION_PLAN.md
 * §6, §10 — "Dashboard availability must degrade gracefully"; the same principle applies
 * at the edge for any downstream service). When a route's circuit breaker is open or the
 * call times out, {@code RouteConfig} forwards here instead of letting the caller see a
 * raw connection error or hang.
 *
 * <p>One method per HTTP verb so any route (GET/POST/PUT/PATCH/DELETE) forwards cleanly;
 * the {@code service} path variable identifies which downstream was unavailable, purely
 * for the response body — no dispatch logic depends on it.</p>
 */
@RestController
@RequestMapping("/fallback")
public class FallbackController {

    @GetMapping("/{service}")
    public ResponseEntity<Map<String, Object>> getFallback(@PathVariable String service) {
        return unavailable(service);
    }

    @PostMapping("/{service}")
    public ResponseEntity<Map<String, Object>> postFallback(@PathVariable String service) {
        return unavailable(service);
    }

    @PutMapping("/{service}")
    public ResponseEntity<Map<String, Object>> putFallback(@PathVariable String service) {
        return unavailable(service);
    }

    @PatchMapping("/{service}")
    public ResponseEntity<Map<String, Object>> patchFallback(@PathVariable String service) {
        return unavailable(service);
    }

    @DeleteMapping("/{service}")
    public ResponseEntity<Map<String, Object>> deleteFallback(@PathVariable String service) {
        return unavailable(service);
    }

    private ResponseEntity<Map<String, Object>> unavailable(String service) {
        Map<String, Object> body = Map.of(
                "timestamp", Instant.now().toString(),
                "status", HttpStatus.SERVICE_UNAVAILABLE.value(),
                "error", "Service Unavailable",
                "message", service + " is temporarily unavailable. Please retry shortly.");
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(body);
    }
}
