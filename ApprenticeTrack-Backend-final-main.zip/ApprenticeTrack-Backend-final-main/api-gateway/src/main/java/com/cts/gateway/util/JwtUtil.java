package com.cts.gateway.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;

/**
 * Validates and parses JWTs issued by auth-service.
 *
 * <p>Uses the same shared secret and HMAC signing scheme as the token issuer
 * ({@code Keys.hmacShaKeyFor(secret.getBytes())}) so signatures verify across
 * services.</p>
 */
@Component
public class JwtUtil {

    @Value("${jwt.secret:change-me-in-production-use-a-256-bit-base64-encoded-secret-key}")
    private String jwtSecret;

    private SecretKey signingKey() {
        return Keys.hmacShaKeyFor(jwtSecret.getBytes());
    }

    /**
     * Verifies the token signature/expiry and returns its claims.
     *
     * @throws io.jsonwebtoken.JwtException if the token is invalid or expired
     */
    public Claims parseClaims(String token) {
        return Jwts.parser()
                .verifyWith(signingKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }
}