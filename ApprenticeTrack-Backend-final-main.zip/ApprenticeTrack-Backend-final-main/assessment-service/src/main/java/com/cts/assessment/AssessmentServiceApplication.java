package com.cts.assessment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Assessment-service: competency units/results, trade tests and results,
 * reassessments, assessors, and trade certificates (MIGRATION_PLAN.md §1).
 *
 * <p>Cross-domain reads (trainee/course/batch → training-service, assessor →
 * auth-service) and audit/notification writes (→ platform-service) go through
 * Resilience4j-backed OpenFeign clients rather than shared tables.
 */
@SpringBootApplication
@EnableFeignClients
public class AssessmentServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(AssessmentServiceApplication.class, args);
    }
}