package com.cts.assessment.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Spring AOP logging for service and controller methods (CLAUDE.md logging rule).
 * Entry/exit and execution time are logged to {@code spring.log}.
 */
@Aspect
@Component
public class LoggingAspect {

    private static final Logger log = LoggerFactory.getLogger(LoggingAspect.class);

    @Pointcut("within(com.cts.assessment.service..*)")
    public void serviceLayer() {}

    @Pointcut("within(com.cts.assessment.controller..*)")
    public void controllerLayer() {}

    @Around("serviceLayer() || controllerLayer()")
    public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
        String target = joinPoint.getSignature().getDeclaringType().getSimpleName()
                + "." + joinPoint.getSignature().getName();
        long start = System.currentTimeMillis();
        log.info("--> {}", target);
        try {
            Object result = joinPoint.proceed();
            log.info("<-- {} ({} ms)", target, System.currentTimeMillis() - start);
            return result;
        } catch (Throwable ex) {
            log.error("!!! {} threw {}: {}", target, ex.getClass().getSimpleName(), ex.getMessage());
            throw ex;
        }
    }
}