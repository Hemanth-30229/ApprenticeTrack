package com.cts.assessment.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.assessment.client.dto.UserContract;

/**
 * Feign client to auth-service, the root of trust for users/roles (MIGRATION_PLAN.md §6).
 * Replaces the in-process {@code UserRepository} reads assessment used to validate assessors
 * and resolve assessor/issuer names. Guarded by {@link AuthClientFallback}.
 */
@FeignClient(name = "auth-service", fallback = AuthClientFallback.class)
public interface AuthClient {

    /** Returns the user, or {@code null} if auth-service reports no such user. */
    @GetMapping("/api/users/{userId}")
    UserContract getUser(@PathVariable("userId") Long userId);

    /**
     * Active users holding the Assessor role — replaces
     * {@code UserRepository.findByRoleAndStatus(Assessor, Active)}.
     */
    @GetMapping("/api/users/assessors")
    List<UserContract> getActiveAssessors(@RequestParam(value = "status", defaultValue = "Active") String status);
}