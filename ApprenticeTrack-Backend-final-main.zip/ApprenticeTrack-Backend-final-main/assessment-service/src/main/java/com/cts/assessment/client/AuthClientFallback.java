package com.cts.assessment.client;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cts.assessment.client.dto.UserContract;

/**
 * Degraded-mode fallback for {@link AuthClient}. When auth-service is unreachable, user
 * lookups return {@code null} (callers fail closed) and the assessor list is empty.
 */
@Component
public class AuthClientFallback implements AuthClient {

    private static final Logger log = LoggerFactory.getLogger(AuthClientFallback.class);

    @Override
    public UserContract getUser(Long userId) {
        log.warn("auth-service unavailable; cannot resolve userID={}", userId);
        return null;
    }

    @Override
    public List<UserContract> getActiveAssessors(String status) {
        log.warn("auth-service unavailable; returning no assessors (status={})", status);
        return Collections.emptyList();
    }
}