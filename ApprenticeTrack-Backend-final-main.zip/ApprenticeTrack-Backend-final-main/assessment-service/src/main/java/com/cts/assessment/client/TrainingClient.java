package com.cts.assessment.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.assessment.client.dto.TradeCourseContract;
import com.cts.assessment.client.dto.TraineeContract;
import com.cts.assessment.client.dto.TrainingBatchContract;

/**
 * Feign client to training-service, which owns trainees, courses, batches and enrollments
 * (MIGRATION_PLAN.md §6). Replaces the in-process {@code TradeCourseRepository},
 * {@code TrainingBatchRepository}, {@code TraineeRepository} and {@code CourseEnrollmentRepository}
 * reads/writes the monolith assessment code performed. Guarded by {@link TrainingClientFallback}.
 */
@FeignClient(name = "training-service", fallback = TrainingClientFallback.class)
public interface TrainingClient {

    /** Returns the course, or {@code null} if training-service reports it does not exist. */
    @GetMapping("/api/trade-courses/{courseId}")
    TradeCourseContract getCourse(@PathVariable("courseId") Long courseId);

    @GetMapping("/api/batches/{batchId}")
    TrainingBatchContract getBatch(@PathVariable("batchId") Long batchId);

    @GetMapping("/api/trainees/{traineeId}")
    TraineeContract getTrainee(@PathVariable("traineeId") Long traineeId);

    /** TraineeIDs enrolled in a batch — replaces {@code CourseEnrollmentRepository.findByBatchID}. */
    @GetMapping("/api/enrollments/batch/{batchId}/trainee-ids")
    List<Long> getEnrolledTraineeIds(@PathVariable("batchId") Long batchId);

    /** Whether a trainee is enrolled in a batch — replaces {@code existsByTraineeIDAndBatchID}. */
    @GetMapping("/api/enrollments/exists")
    Boolean isTraineeEnrolledInBatch(@RequestParam("traineeId") Long traineeId,
                                     @RequestParam("batchId") Long batchId);

    /**
     * Cross-service write: marks the trainee's (non-withdrawn) enrollment for the course
     * Completed after they pass a reassessment. Owned by training-service.
     */
    @PutMapping("/api/enrollments/complete")
    void completeEnrollment(@RequestParam("traineeId") Long traineeId,
                            @RequestParam("courseId") Long courseId);
}