package com.cts.assessment.client;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cts.assessment.client.dto.TradeCourseContract;
import com.cts.assessment.client.dto.TraineeContract;
import com.cts.assessment.client.dto.TrainingBatchContract;

/**
 * Degraded-mode fallback for {@link TrainingClient}. When training-service is unreachable,
 * lookups return {@code null}/empty (so callers fail closed with a not-found / not-enrolled
 * error rather than proceeding on unverified data) and the cross-service write is dropped
 * with a warning.
 */
@Component
public class TrainingClientFallback implements TrainingClient {

    private static final Logger log = LoggerFactory.getLogger(TrainingClientFallback.class);

    @Override
    public TradeCourseContract getCourse(Long courseId) {
        log.warn("training-service unavailable; cannot resolve courseID={}", courseId);
        return null;
    }

    @Override
    public TrainingBatchContract getBatch(Long batchId) {
        log.warn("training-service unavailable; cannot resolve batchID={}", batchId);
        return null;
    }

    @Override
    public TraineeContract getTrainee(Long traineeId) {
        log.warn("training-service unavailable; cannot resolve traineeID={}", traineeId);
        return null;
    }

    @Override
    public List<Long> getEnrolledTraineeIds(Long batchId) {
        log.warn("training-service unavailable; returning no enrollments for batchID={}", batchId);
        return Collections.emptyList();
    }

    @Override
    public Boolean isTraineeEnrolledInBatch(Long traineeId, Long batchId) {
        log.warn("training-service unavailable; cannot verify enrollment traineeID={} batchID={}",
                traineeId, batchId);
        return false;
    }

    @Override
    public void completeEnrollment(Long traineeId, Long courseId) {
        log.warn("training-service unavailable; enrollment completion dropped traineeID={} courseID={}",
                traineeId, courseId);
    }
}