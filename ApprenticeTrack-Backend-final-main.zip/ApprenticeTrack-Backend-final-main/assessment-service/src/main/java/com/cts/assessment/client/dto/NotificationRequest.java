package com.cts.assessment.client.dto;

/**
 * Payload sent to platform-service to raise an in-app notification. The monolith's
 * {@code NotificationDispatcher.notifyUser}/{@code notifyTrainee} become a single
 * request whose {@code recipientType} tells platform-service whether {@code recipientID}
 * is a UserID or a TraineeID (platform resolves a trainee to its user).
 */
public class NotificationRequest {

    /** {@code "USER"} or {@code "TRAINEE"}. */
    private String recipientType;
    private Long recipientID;
    private String message;
    /** Notification category, e.g. {@code "Assessment"} or {@code "Certification"}. */
    private String category;

    public NotificationRequest() {}

    public NotificationRequest(String recipientType, Long recipientID, String message, String category) {
        this.recipientType = recipientType;
        this.recipientID = recipientID;
        this.message = message;
        this.category = category;
    }

    public String getRecipientType() { return recipientType; }
    public void setRecipientType(String recipientType) { this.recipientType = recipientType; }

    public Long getRecipientID() { return recipientID; }
    public void setRecipientID(Long recipientID) { this.recipientID = recipientID; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
}