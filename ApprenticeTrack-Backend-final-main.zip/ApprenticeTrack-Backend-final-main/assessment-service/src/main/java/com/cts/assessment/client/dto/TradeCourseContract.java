package com.cts.assessment.client.dto;

/**
 * Lightweight view of a training-service {@code TradeCourse}, carrying only the fields
 * assessment-service needs (name for display, trade code + qualification level for
 * certificate issuance). Not the full entity — services never share entities across
 * a boundary (MIGRATION_PLAN.md §6).
 */
public class TradeCourseContract {

    private Long courseID;
    private String courseName;
    private String tradeCode;
    private String qualificationLevel;

    public TradeCourseContract() {}

    public Long getCourseID() { return courseID; }
    public void setCourseID(Long courseID) { this.courseID = courseID; }

    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }

    public String getTradeCode() { return tradeCode; }
    public void setTradeCode(String tradeCode) { this.tradeCode = tradeCode; }

    public String getQualificationLevel() { return qualificationLevel; }
    public void setQualificationLevel(String qualificationLevel) { this.qualificationLevel = qualificationLevel; }
}