package com.cts.assessment.client.dto;

/** Lightweight view of a training-service {@code Trainee}. */
public class TraineeContract {

    private Long traineeID;
    /** UserID of the platform account linked to this trainee (target for notifications). */
    private Long userID;
    private String name;

    public TraineeContract() {}

    public Long getTraineeID() { return traineeID; }
    public void setTraineeID(Long traineeID) { this.traineeID = traineeID; }

    public Long getUserID() { return userID; }
    public void setUserID(Long userID) { this.userID = userID; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}