package com.cts.assessment.client.dto;

/** Lightweight view of a training-service {@code TrainingBatch}. */
public class TrainingBatchContract {

    private Long batchID;
    private String batchCode;
    private Long courseID;

    public TrainingBatchContract() {}

    public Long getBatchID() { return batchID; }
    public void setBatchID(Long batchID) { this.batchID = batchID; }

    public String getBatchCode() { return batchCode; }
    public void setBatchCode(String batchCode) { this.batchCode = batchCode; }

    public Long getCourseID() { return courseID; }
    public void setCourseID(Long courseID) { this.courseID = courseID; }
}