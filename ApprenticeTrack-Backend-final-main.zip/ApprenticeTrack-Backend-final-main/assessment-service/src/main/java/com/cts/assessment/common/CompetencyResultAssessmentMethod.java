package com.cts.assessment.common;

public enum CompetencyResultAssessmentMethod {
    Practical, Written, Observation, Portfolio
}
