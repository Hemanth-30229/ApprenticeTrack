package com.cts.assessment.common;

public enum CompetencyResultOutcome {
    Competent, NotYetCompetent
}
