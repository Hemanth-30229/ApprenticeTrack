package com.cts.assessment.common;

public enum CompetencyUnitAssessmentMethod {
    Practical, Written, Observation, Portfolio
}
