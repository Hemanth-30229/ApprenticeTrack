package com.cts.assessment.common;

public enum CompetencyUnitStatus {
    Active, Inactive
}
