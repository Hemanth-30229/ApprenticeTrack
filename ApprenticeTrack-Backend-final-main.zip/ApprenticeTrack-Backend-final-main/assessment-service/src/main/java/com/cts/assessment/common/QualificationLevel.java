package com.cts.assessment.common;

/**
 * Qualification level awarded by a trade course. In the monolith this enum lived on
 * {@code TradeCourse} (owned by training-service); assessment-service keeps a local copy
 * because it stamps the level onto issued trade certificates and receives it from
 * training-service via Feign (MIGRATION_PLAN.md §2).
 */
public enum QualificationLevel {
    Level1, Level2, Level3, Level4
}
