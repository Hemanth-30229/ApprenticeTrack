package com.cts.assessment.common;

public enum ReassessmentStatus {
    Scheduled, Completed
}
