package com.cts.assessment.common;

public enum TestAttemptStatus {
    Submitted, Graded
}
