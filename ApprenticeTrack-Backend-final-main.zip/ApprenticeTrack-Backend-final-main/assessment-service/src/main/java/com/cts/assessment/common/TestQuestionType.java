package com.cts.assessment.common;

public enum TestQuestionType {
    MultipleChoice, Coding
}
