package com.cts.assessment.common;

public enum TradeCertificateStatus {
    Issued, Revoked
}
