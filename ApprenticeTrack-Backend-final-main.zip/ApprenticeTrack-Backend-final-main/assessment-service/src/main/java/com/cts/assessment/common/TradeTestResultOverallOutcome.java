package com.cts.assessment.common;

public enum TradeTestResultOverallOutcome {
    Pass, Fail, Absent
}
