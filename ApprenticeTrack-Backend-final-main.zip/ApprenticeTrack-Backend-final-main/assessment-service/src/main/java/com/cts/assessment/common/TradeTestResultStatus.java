package com.cts.assessment.common;

public enum TradeTestResultStatus {
    Draft, Published
}
