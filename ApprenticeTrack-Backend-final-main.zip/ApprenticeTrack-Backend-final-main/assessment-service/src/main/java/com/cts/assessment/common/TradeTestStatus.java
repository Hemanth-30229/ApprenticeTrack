package com.cts.assessment.common;

public enum TradeTestStatus {
    Scheduled, Conducted, ResultsDeclared, Cancelled
}
