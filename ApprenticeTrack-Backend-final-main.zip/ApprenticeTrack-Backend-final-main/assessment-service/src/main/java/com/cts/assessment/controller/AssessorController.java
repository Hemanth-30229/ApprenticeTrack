package com.cts.assessment.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.assessment.dto.AssessorAvailabilityDTO;
import com.cts.assessment.service.AssessorService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@RequestMapping("/api/assessors")
@SecurityRequirement(name = "bearerAuth")
public class AssessorController {

    private final AssessorService assessorService;

    public AssessorController(AssessorService assessorService) {
        this.assessorService = assessorService;
    }

    /** Lists active, qualified assessors available for a course, with workload summary. */
    @GetMapping("/available")
    @PreAuthorize("hasAnyRole('Admin','VocationalAdmin')")
    public ResponseEntity<List<AssessorAvailabilityDTO>> getAvailableAssessors(
            @RequestParam Long courseId) {
        return ResponseEntity.ok(assessorService.getAvailableAssessors(courseId));
    }
}