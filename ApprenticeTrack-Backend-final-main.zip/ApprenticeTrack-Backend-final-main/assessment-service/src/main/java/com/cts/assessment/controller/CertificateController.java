package com.cts.assessment.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.assessment.dto.CertificateGenerateRequestDTO;
import com.cts.assessment.dto.CertificateResponseDTO;
import com.cts.assessment.dto.CertificateRevokeRequestDTO;
import com.cts.assessment.common.QualificationLevel;
import com.cts.assessment.common.TradeCertificateStatus;
import com.cts.assessment.security.AuthUser;
import com.cts.assessment.service.CertificateService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/certificates")
@SecurityRequirement(name = "bearerAuth")
public class CertificateController {

    private final CertificateService certificateService;

    public CertificateController(CertificateService certificateService) {
        this.certificateService = certificateService;
    }

    @PostMapping("/generate")
    public ResponseEntity<CertificateResponseDTO> generate(
            @Valid @RequestBody CertificateGenerateRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(certificateService.generate(requestDTO, user.userID()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CertificateResponseDTO> getCertificate(@PathVariable Long id) {
        return ResponseEntity.ok(certificateService.getById(id));
    }

    @GetMapping
    public ResponseEntity<Page<CertificateResponseDTO>> getCertificates(
            @RequestParam(required = false) Long traineeID,
            @RequestParam(required = false) Long courseID,
            @RequestParam(required = false) QualificationLevel qualificationLevel,
            @RequestParam(required = false) TradeCertificateStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "issuedDate,desc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("asc")
                ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(
                certificateService.getCertificates(traineeID, courseID, qualificationLevel, status, pageable));
    }

    @PutMapping("/{id}/revoke")
    public ResponseEntity<CertificateResponseDTO> revoke(
            @PathVariable Long id,
            @Valid @RequestBody CertificateRevokeRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(
                certificateService.revoke(id, requestDTO.getRevocationReason(), user.userID()));
    }

    @GetMapping("/{id}/download")
    public ResponseEntity<byte[]> download(@PathVariable Long id) {
        byte[] pdf = certificateService.downloadPdf(id);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"certificate-" + id + ".pdf\"")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdf);
    }
}