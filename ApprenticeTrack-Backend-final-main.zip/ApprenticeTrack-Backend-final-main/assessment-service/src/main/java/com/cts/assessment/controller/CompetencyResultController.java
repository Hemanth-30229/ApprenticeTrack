package com.cts.assessment.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.assessment.dto.BulkCompetencyResultRequestDTO;
import com.cts.assessment.dto.BulkCompetencyResultResponseDTO;
import com.cts.assessment.dto.CompetencyResultCreateRequestDTO;
import com.cts.assessment.dto.CompetencyResultResponseDTO;
import com.cts.assessment.common.CompetencyResultOutcome;
import com.cts.assessment.security.AuthUser;
import com.cts.assessment.service.CompetencyResultService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/competency-results")
@SecurityRequirement(name = "bearerAuth")
public class CompetencyResultController {

    private final CompetencyResultService competencyResultService;

    public CompetencyResultController(CompetencyResultService competencyResultService) {
        this.competencyResultService = competencyResultService;
    }

    @PostMapping
    public ResponseEntity<CompetencyResultResponseDTO> createResult(
            @Valid @RequestBody CompetencyResultCreateRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(competencyResultService.createResult(requestDTO, user.userID()));
    }

    @PostMapping("/bulk")
    public ResponseEntity<BulkCompetencyResultResponseDTO> bulkCreate(
            @Valid @RequestBody BulkCompetencyResultRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(competencyResultService.bulkCreate(requestDTO.getResults(), user.userID()));
    }

    @GetMapping
    public ResponseEntity<Page<CompetencyResultResponseDTO>> getResults(
            @RequestParam(required = false) Long testID,
            @RequestParam(required = false) Long traineeID,
            @RequestParam(required = false) Long unitID,
            @RequestParam(required = false) CompetencyResultOutcome outcome,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "assessmentDate,desc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("asc")
                ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(
                competencyResultService.getResults(testID, traineeID, unitID, outcome, pageable));
    }
}