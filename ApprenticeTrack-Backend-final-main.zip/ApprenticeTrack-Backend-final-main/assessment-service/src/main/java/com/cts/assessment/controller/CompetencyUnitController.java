package com.cts.assessment.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.assessment.dto.CompetencyUnitCreateRequestDTO;
import com.cts.assessment.dto.CompetencyUnitResponseDTO;
import com.cts.assessment.dto.CompetencyUnitUpdateRequestDTO;
import com.cts.assessment.common.CompetencyUnitStatus;
import com.cts.assessment.service.CompetencyUnitService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/competency-units")
@SecurityRequirement(name = "bearerAuth")
public class CompetencyUnitController {

    private final CompetencyUnitService competencyUnitService;

    public CompetencyUnitController(CompetencyUnitService competencyUnitService) {
        this.competencyUnitService = competencyUnitService;
    }

    @PostMapping
    public ResponseEntity<CompetencyUnitResponseDTO> createUnit(
            @Valid @RequestBody CompetencyUnitCreateRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(competencyUnitService.createUnit(requestDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CompetencyUnitResponseDTO> getUnit(@PathVariable Long id) {
        return ResponseEntity.ok(competencyUnitService.getUnitById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CompetencyUnitResponseDTO> updateUnit(
            @PathVariable Long id, @Valid @RequestBody CompetencyUnitUpdateRequestDTO requestDTO) {
        return ResponseEntity.ok(competencyUnitService.updateUnit(id, requestDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUnit(@PathVariable Long id) {
        competencyUnitService.deleteUnit(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<Page<CompetencyUnitResponseDTO>> getAllUnits(
            @RequestParam(required = false) Long courseID,
            @RequestParam(required = false) CompetencyUnitStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "unitCode,asc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("desc")
                ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(competencyUnitService.getAllUnits(courseID, status, pageable));
    }
}