package com.cts.assessment.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.assessment.dto.ReassessmentCandidateDTO;
import com.cts.assessment.dto.ReassessmentHistoryDTO;
import com.cts.assessment.dto.ReassessmentResponseDTO;
import com.cts.assessment.dto.ReassessmentScheduleRequestDTO;
import com.cts.assessment.security.AuthUser;
import com.cts.assessment.service.ReassessmentService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/reassessments")
@SecurityRequirement(name = "bearerAuth")
public class ReassessmentController {

    private final ReassessmentService reassessmentService;

    public ReassessmentController(ReassessmentService reassessmentService) {
        this.reassessmentService = reassessmentService;
    }

    @GetMapping
    public ResponseEntity<List<ReassessmentCandidateDTO>> getCandidates(
            @RequestParam(required = false) Long courseId,
            @RequestParam(required = false) Long batchId) {
        return ResponseEntity.ok(reassessmentService.getCandidates(courseId, batchId));
    }

    @PostMapping
    public ResponseEntity<ReassessmentResponseDTO> schedule(
            @Valid @RequestBody ReassessmentScheduleRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(reassessmentService.schedule(requestDTO, user.userID()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReassessmentHistoryDTO> getHistory(@PathVariable Long id) {
        return ResponseEntity.ok(reassessmentService.getHistory(id));
    }

    /** Recalculates the reassessment outcome after competency results are submitted. */
    @PostMapping("/{id}/recalculate")
    public ResponseEntity<ReassessmentResponseDTO> recalculate(
            @PathVariable Long id, @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(reassessmentService.recalculate(id, user.userID()));
    }
}