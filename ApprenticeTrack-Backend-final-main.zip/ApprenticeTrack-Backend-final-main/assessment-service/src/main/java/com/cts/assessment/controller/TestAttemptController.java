package com.cts.assessment.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.assessment.dto.GradeAttemptRequestDTO;
import com.cts.assessment.dto.TestAttemptResponseDTO;
import com.cts.assessment.dto.TestAttemptSubmitRequestDTO;
import com.cts.assessment.service.TestAttemptService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

/**
 * Trainee submissions for an online trade test. Trainees submit their own attempts;
 * assessors/admins list all attempts and record manual marks for coding answers.
 */
@RestController
@RequestMapping("/api")
@SecurityRequirement(name = "bearerAuth")
public class TestAttemptController {

    private final TestAttemptService attemptService;

    public TestAttemptController(TestAttemptService attemptService) {
        this.attemptService = attemptService;
    }

    /** List attempts for a test; pass traineeID to fetch just that trainee's own attempt. */
    @GetMapping("/trade-tests/{testID}/attempts")
    public ResponseEntity<List<TestAttemptResponseDTO>> listAttempts(
            @PathVariable Long testID,
            @RequestParam(required = false) Long traineeID) {
        return ResponseEntity.ok(attemptService.listAttempts(testID, traineeID));
    }

    @PostMapping("/trade-tests/{testID}/attempts")
    @PreAuthorize("hasAnyRole('Trainee','Admin')")
    public ResponseEntity<TestAttemptResponseDTO> submitAttempt(
            @PathVariable Long testID, @Valid @RequestBody TestAttemptSubmitRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(attemptService.submitAttempt(testID, requestDTO));
    }

    @PutMapping("/test-attempts/{attemptID}/grade")
    @PreAuthorize("hasAnyRole('Assessor','Admin','VocationalAdmin')")
    public ResponseEntity<TestAttemptResponseDTO> gradeAttempt(
            @PathVariable Long attemptID, @Valid @RequestBody GradeAttemptRequestDTO requestDTO) {
        return ResponseEntity.ok(attemptService.gradeAttempt(attemptID, requestDTO));
    }
}
