package com.cts.assessment.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.assessment.dto.TestQuestionCreateRequestDTO;
import com.cts.assessment.dto.TestQuestionResponseDTO;
import com.cts.assessment.service.TestQuestionService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

/**
 * Online trade-test question paper. Authoring (create/update/delete) is limited to
 * assessors and admins; reading the paper is open to any authenticated user so
 * trainees can fetch it when writing the test.
 */
@RestController
@RequestMapping("/api")
@SecurityRequirement(name = "bearerAuth")
public class TestQuestionController {

    private static final String AUTHORING = "hasAnyRole('Assessor','Admin','VocationalAdmin')";

    private final TestQuestionService questionService;

    public TestQuestionController(TestQuestionService questionService) {
        this.questionService = questionService;
    }

    @GetMapping("/trade-tests/{testID}/questions")
    public ResponseEntity<List<TestQuestionResponseDTO>> listQuestions(@PathVariable Long testID) {
        return ResponseEntity.ok(questionService.listQuestions(testID));
    }

    @PostMapping("/trade-tests/{testID}/questions")
    @PreAuthorize(AUTHORING)
    public ResponseEntity<TestQuestionResponseDTO> addQuestion(
            @PathVariable Long testID, @Valid @RequestBody TestQuestionCreateRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(questionService.createQuestion(testID, requestDTO));
    }

    @PutMapping("/test-questions/{questionID}")
    @PreAuthorize(AUTHORING)
    public ResponseEntity<TestQuestionResponseDTO> updateQuestion(
            @PathVariable Long questionID, @Valid @RequestBody TestQuestionCreateRequestDTO requestDTO) {
        return ResponseEntity.ok(questionService.updateQuestion(questionID, requestDTO));
    }

    @DeleteMapping("/test-questions/{questionID}")
    @PreAuthorize(AUTHORING)
    public ResponseEntity<Void> deleteQuestion(@PathVariable Long questionID) {
        questionService.deleteQuestion(questionID);
        return ResponseEntity.noContent().build();
    }
}
