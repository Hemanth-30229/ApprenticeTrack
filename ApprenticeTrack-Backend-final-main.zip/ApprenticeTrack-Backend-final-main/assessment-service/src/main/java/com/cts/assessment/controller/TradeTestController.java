package com.cts.assessment.controller;

import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.assessment.dto.AssignAssessorRequestDTO;
import com.cts.assessment.dto.TradeTestCreateRequestDTO;
import com.cts.assessment.dto.TradeTestResponseDTO;
import com.cts.assessment.dto.TradeTestStatusUpdateRequestDTO;
import com.cts.assessment.dto.TradeTestUpdateRequestDTO;
import com.cts.assessment.common.TradeTestStatus;
import com.cts.assessment.service.TradeTestService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/trade-tests")
@SecurityRequirement(name = "bearerAuth")
public class TradeTestController {

    private final TradeTestService tradeTestService;

    public TradeTestController(TradeTestService tradeTestService) {
        this.tradeTestService = tradeTestService;
    }

    @PostMapping
    public ResponseEntity<TradeTestResponseDTO> createTradeTest(
            @Valid @RequestBody TradeTestCreateRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(tradeTestService.createTradeTest(requestDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<TradeTestResponseDTO> getTradeTest(@PathVariable Long id) {
        return ResponseEntity.ok(tradeTestService.getTradeTestById(id));
    }

    @GetMapping
    public ResponseEntity<Page<TradeTestResponseDTO>> getAllTradeTests(
            @RequestParam(required = false) Long courseID,
            @RequestParam(required = false) Long batchID,
            @RequestParam(required = false) Long assessorID,
            @RequestParam(required = false) TradeTestStatus status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "testDate,desc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("asc")
                ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(
                tradeTestService.getAllTradeTests(courseID, batchID, assessorID, status,
                        fromDate, toDate, pageable));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TradeTestResponseDTO> updateTradeTest(
            @PathVariable Long id, @Valid @RequestBody TradeTestUpdateRequestDTO requestDTO) {
        return ResponseEntity.ok(tradeTestService.updateTradeTest(id, requestDTO));
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<TradeTestResponseDTO> updateStatus(
            @PathVariable Long id, @Valid @RequestBody TradeTestStatusUpdateRequestDTO requestDTO) {
        return ResponseEntity.ok(tradeTestService.updateStatus(id, requestDTO.getStatus()));
    }

    /** Assign or reassign an assessor to a trade test. Restricted to Vocational Admin. */
    @PostMapping("/{testId}/assign-assessor")
    @PreAuthorize("hasAnyRole('Admin','VocationalAdmin')")
    public ResponseEntity<TradeTestResponseDTO> assignAssessor(
            @PathVariable Long testId, @Valid @RequestBody AssignAssessorRequestDTO requestDTO) {
        return ResponseEntity.ok(tradeTestService.assignAssessor(testId, requestDTO.getAssessorID()));
    }
}