package com.cts.assessment.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.assessment.dto.BulkPublishRequestDTO;
import com.cts.assessment.dto.BulkPublishResponseDTO;
import com.cts.assessment.dto.ComputeResultsRequestDTO;
import com.cts.assessment.dto.TradeTestResultEntryRequestDTO;
import com.cts.assessment.dto.TradeTestResultResponseDTO;
import com.cts.assessment.common.TradeTestResultOverallOutcome;
import com.cts.assessment.common.TradeTestResultStatus;
import com.cts.assessment.security.AuthUser;
import com.cts.assessment.service.TradeTestResultService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/trade-test-results")
@SecurityRequirement(name = "bearerAuth")
public class TradeTestResultController {

    private final TradeTestResultService tradeTestResultService;

    public TradeTestResultController(TradeTestResultService tradeTestResultService) {
        this.tradeTestResultService = tradeTestResultService;
    }

    @PostMapping("/compute")
    public ResponseEntity<List<TradeTestResultResponseDTO>> compute(
            @Valid @RequestBody ComputeResultsRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(tradeTestResultService.compute(requestDTO.getTestID(), user.userID()));
    }

    /** Direct per-trainee result entry (assessor enters a mark per trainee; outcome derived). */
    @PostMapping("/enter")
    public ResponseEntity<List<TradeTestResultResponseDTO>> enter(
            @Valid @RequestBody TradeTestResultEntryRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(tradeTestResultService.enterResults(requestDTO, user.userID()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<TradeTestResultResponseDTO> getResult(@PathVariable Long id) {
        return ResponseEntity.ok(tradeTestResultService.getById(id));
    }

    @GetMapping
    public ResponseEntity<Page<TradeTestResultResponseDTO>> getResults(
            @RequestParam(required = false) Long testID,
            @RequestParam(required = false) Long traineeID,
            @RequestParam(required = false) TradeTestResultOverallOutcome overallOutcome,
            @RequestParam(required = false) Boolean reassessmentRequired,
            @RequestParam(required = false) TradeTestResultStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "finalResultID,desc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("asc")
                ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(
                tradeTestResultService.getResults(testID, traineeID, overallOutcome,
                        reassessmentRequired, status, pageable));
    }

    @PutMapping("/{id}/publish")
    public ResponseEntity<TradeTestResultResponseDTO> publish(
            @PathVariable Long id, @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(tradeTestResultService.publish(id, user.userID()));
    }

    @PutMapping("/bulk-publish")
    public ResponseEntity<BulkPublishResponseDTO> bulkPublish(
            @Valid @RequestBody BulkPublishRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(
                tradeTestResultService.bulkPublish(requestDTO.getFinalResultIDs(), user.userID()));
    }
}