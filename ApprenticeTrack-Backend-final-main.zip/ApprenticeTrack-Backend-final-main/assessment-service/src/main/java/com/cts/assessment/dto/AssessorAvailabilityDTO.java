package com.cts.assessment.dto;

/**
 * A qualified, active assessor available for assignment to a course's tests,
 * with a workload summary (count of currently scheduled tests). The assessor's
 * profile (name, email, status) is fetched from auth-service via Feign, so
 * {@code status} is carried as a plain string rather than the auth-owned enum.
 */
public class AssessorAvailabilityDTO {
    private Long assessorID;
    private String name;
    private String email;
    private String status;
    private long scheduledTestCount;

    public AssessorAvailabilityDTO() {}
    public Long getAssessorID() { return assessorID; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getStatus() { return status; }
    public long getScheduledTestCount() { return scheduledTestCount; }
    public void setAssessorID(Long v) { this.assessorID = v; }
    public void setName(String v) { this.name = v; }
    public void setEmail(String v) { this.email = v; }
    public void setStatus(String v) { this.status = v; }
    public void setScheduledTestCount(long v) { this.scheduledTestCount = v; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long assessorID;
        private String name;
        private String email;
        private String status;
        private long scheduledTestCount;
        public Builder assessorID(Long v) { this.assessorID = v; return this; }
        public Builder name(String v) { this.name = v; return this; }
        public Builder email(String v) { this.email = v; return this; }
        public Builder status(String v) { this.status = v; return this; }
        public Builder scheduledTestCount(long v) { this.scheduledTestCount = v; return this; }
        public AssessorAvailabilityDTO build() {
            AssessorAvailabilityDTO d = new AssessorAvailabilityDTO();
            d.assessorID = assessorID; d.name = name; d.email = email;
            d.status = status; d.scheduledTestCount = scheduledTestCount;
            return d;
        }
    }
}