package com.cts.assessment.dto;

import jakarta.validation.constraints.NotNull;

public class AssignAssessorRequestDTO {
    @NotNull(message = "Assessor ID is required")
    private Long assessorID;

    public AssignAssessorRequestDTO() {}
    public Long getAssessorID() { return assessorID; }
    public void setAssessorID(Long v) { this.assessorID = v; }
}
