package com.cts.assessment.dto;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;

public class BulkCompetencyResultRequestDTO {

    @NotEmpty(message = "At least one result is required")
    @Valid
    private List<CompetencyResultCreateRequestDTO> results;

    public BulkCompetencyResultRequestDTO() {}

    public List<CompetencyResultCreateRequestDTO> getResults() { return results; }
    public void setResults(List<CompetencyResultCreateRequestDTO> results) { this.results = results; }
}
