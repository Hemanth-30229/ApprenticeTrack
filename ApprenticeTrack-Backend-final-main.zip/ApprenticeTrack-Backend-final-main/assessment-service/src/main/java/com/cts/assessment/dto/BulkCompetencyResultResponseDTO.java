package com.cts.assessment.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * Result of a bulk competency-result entry: which entries were created and
 * which were rejected (by request index, with a reason).
 */
public class BulkCompetencyResultResponseDTO {

    private int totalRequested;
    private List<CompetencyResultResponseDTO> created = new ArrayList<>();
    private List<FailedEntry> failed = new ArrayList<>();

    public int getTotalRequested() { return totalRequested; }
    public List<CompetencyResultResponseDTO> getCreated() { return created; }
    public List<FailedEntry> getFailed() { return failed; }

    public void setTotalRequested(int totalRequested) { this.totalRequested = totalRequested; }
    public void setCreated(List<CompetencyResultResponseDTO> created) { this.created = created; }
    public void setFailed(List<FailedEntry> failed) { this.failed = failed; }

    public void addCreated(CompetencyResultResponseDTO result) { this.created.add(result); }
    public void addFailed(int index, String reason) { this.failed.add(new FailedEntry(index, reason)); }

    public static class FailedEntry {
        private int index;
        private String reason;

        public FailedEntry() {}
        public FailedEntry(int index, String reason) { this.index = index; this.reason = reason; }

        public int getIndex() { return index; }
        public String getReason() { return reason; }
        public void setIndex(int index) { this.index = index; }
        public void setReason(String reason) { this.reason = reason; }
    }
}
