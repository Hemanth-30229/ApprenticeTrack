package com.cts.assessment.dto;

import java.util.List;

import jakarta.validation.constraints.NotEmpty;

public class BulkPublishRequestDTO {

    @NotEmpty(message = "At least one FinalResultID is required")
    private List<Long> finalResultIDs;

    public BulkPublishRequestDTO() {}

    public List<Long> getFinalResultIDs() { return finalResultIDs; }
    public void setFinalResultIDs(List<Long> finalResultIDs) { this.finalResultIDs = finalResultIDs; }
}
