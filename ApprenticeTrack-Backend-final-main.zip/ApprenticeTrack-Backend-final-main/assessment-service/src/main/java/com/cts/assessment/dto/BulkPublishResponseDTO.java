package com.cts.assessment.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * Result of a bulk publish: which results were published and which were
 * skipped (with a reason), so a partial batch reports per-item outcomes.
 */
public class BulkPublishResponseDTO {

    private int totalRequested;
    private List<Long> published = new ArrayList<>();
    private List<FailedPublish> failed = new ArrayList<>();

    public int getTotalRequested() { return totalRequested; }
    public List<Long> getPublished() { return published; }
    public List<FailedPublish> getFailed() { return failed; }

    public void setTotalRequested(int totalRequested) { this.totalRequested = totalRequested; }
    public void setPublished(List<Long> published) { this.published = published; }
    public void setFailed(List<FailedPublish> failed) { this.failed = failed; }

    public void addPublished(Long finalResultID) { this.published.add(finalResultID); }
    public void addFailed(Long finalResultID, String reason) { this.failed.add(new FailedPublish(finalResultID, reason)); }

    public static class FailedPublish {
        private Long finalResultID;
        private String reason;

        public FailedPublish() {}
        public FailedPublish(Long finalResultID, String reason) { this.finalResultID = finalResultID; this.reason = reason; }

        public Long getFinalResultID() { return finalResultID; }
        public String getReason() { return reason; }
        public void setFinalResultID(Long finalResultID) { this.finalResultID = finalResultID; }
        public void setReason(String reason) { this.reason = reason; }
    }
}
