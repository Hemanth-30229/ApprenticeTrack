package com.cts.assessment.dto;

import jakarta.validation.constraints.NotNull;

public class CertificateGenerateRequestDTO {

    @NotNull(message = "TraineeID is required")
    private Long traineeID;

    @NotNull(message = "CourseID is required")
    private Long courseID;

    public CertificateGenerateRequestDTO() {}

    public Long getTraineeID() { return traineeID; }
    public Long getCourseID() { return courseID; }

    public void setTraineeID(Long traineeID) { this.traineeID = traineeID; }
    public void setCourseID(Long courseID) { this.courseID = courseID; }
}
