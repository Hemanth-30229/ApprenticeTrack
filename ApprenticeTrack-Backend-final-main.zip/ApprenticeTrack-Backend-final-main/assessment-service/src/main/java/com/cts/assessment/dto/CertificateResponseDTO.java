package com.cts.assessment.dto;

import java.time.LocalDate;

import com.cts.assessment.common.QualificationLevel;
import com.cts.assessment.common.TradeCertificateStatus;

public class CertificateResponseDTO {

    private Long certificateID, traineeID, courseID, issuedByID;
    private String traineeName, courseName, issuedByName, certificateNumber, revocationReason;
    private LocalDate issuedDate;
    private QualificationLevel qualificationLevel;
    private TradeCertificateStatus status;

    public CertificateResponseDTO() {}

    public Long getCertificateID() { return certificateID; }
    public Long getTraineeID() { return traineeID; }
    public Long getCourseID() { return courseID; }
    public Long getIssuedByID() { return issuedByID; }
    public String getTraineeName() { return traineeName; }
    public String getCourseName() { return courseName; }
    public String getIssuedByName() { return issuedByName; }
    public String getCertificateNumber() { return certificateNumber; }
    public String getRevocationReason() { return revocationReason; }
    public LocalDate getIssuedDate() { return issuedDate; }
    public QualificationLevel getQualificationLevel() { return qualificationLevel; }
    public TradeCertificateStatus getStatus() { return status; }

    public void setCertificateID(Long v) { this.certificateID = v; }
    public void setTraineeID(Long v) { this.traineeID = v; }
    public void setCourseID(Long v) { this.courseID = v; }
    public void setIssuedByID(Long v) { this.issuedByID = v; }
    public void setTraineeName(String v) { this.traineeName = v; }
    public void setCourseName(String v) { this.courseName = v; }
    public void setIssuedByName(String v) { this.issuedByName = v; }
    public void setCertificateNumber(String v) { this.certificateNumber = v; }
    public void setRevocationReason(String v) { this.revocationReason = v; }
    public void setIssuedDate(LocalDate v) { this.issuedDate = v; }
    public void setQualificationLevel(QualificationLevel v) { this.qualificationLevel = v; }
    public void setStatus(TradeCertificateStatus v) { this.status = v; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long certificateID, traineeID, courseID, issuedByID;
        private String traineeName, courseName, issuedByName, certificateNumber, revocationReason;
        private LocalDate issuedDate;
        private QualificationLevel qualificationLevel;
        private TradeCertificateStatus status;

        public Builder certificateID(Long v) { this.certificateID = v; return this; }
        public Builder traineeID(Long v) { this.traineeID = v; return this; }
        public Builder courseID(Long v) { this.courseID = v; return this; }
        public Builder issuedByID(Long v) { this.issuedByID = v; return this; }
        public Builder traineeName(String v) { this.traineeName = v; return this; }
        public Builder courseName(String v) { this.courseName = v; return this; }
        public Builder issuedByName(String v) { this.issuedByName = v; return this; }
        public Builder certificateNumber(String v) { this.certificateNumber = v; return this; }
        public Builder revocationReason(String v) { this.revocationReason = v; return this; }
        public Builder issuedDate(LocalDate v) { this.issuedDate = v; return this; }
        public Builder qualificationLevel(QualificationLevel v) { this.qualificationLevel = v; return this; }
        public Builder status(TradeCertificateStatus v) { this.status = v; return this; }

        public CertificateResponseDTO build() {
            CertificateResponseDTO d = new CertificateResponseDTO();
            d.certificateID = certificateID; d.traineeID = traineeID; d.courseID = courseID;
            d.issuedByID = issuedByID; d.traineeName = traineeName; d.courseName = courseName;
            d.issuedByName = issuedByName; d.certificateNumber = certificateNumber;
            d.revocationReason = revocationReason; d.issuedDate = issuedDate;
            d.qualificationLevel = qualificationLevel; d.status = status;
            return d;
        }
    }
}
