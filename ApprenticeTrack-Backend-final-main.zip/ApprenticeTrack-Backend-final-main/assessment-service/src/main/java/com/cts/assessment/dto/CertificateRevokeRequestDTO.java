package com.cts.assessment.dto;

import jakarta.validation.constraints.NotBlank;

public class CertificateRevokeRequestDTO {

    @NotBlank(message = "Revocation reason is required")
    private String revocationReason;

    public CertificateRevokeRequestDTO() {}

    public String getRevocationReason() { return revocationReason; }
    public void setRevocationReason(String revocationReason) { this.revocationReason = revocationReason; }
}
