package com.cts.assessment.dto;

import com.cts.assessment.common.CompetencyResultAssessmentMethod;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;

public class CompetencyResultCreateRequestDTO {

    @NotNull(message = "TestID is required")
    private Long testID;

    @NotNull(message = "TraineeID is required")
    private Long traineeID;

    @NotNull(message = "UnitID is required")
    private Long unitID;

    @NotNull(message = "Assessment method is required")
    private CompetencyResultAssessmentMethod assessmentMethod;

    @NotNull(message = "Marks obtained is required")
    @PositiveOrZero(message = "Marks obtained must be zero or positive")
    private Double marksObtained;

    @NotNull(message = "Max marks is required")
    @Positive(message = "Max marks must be positive")
    private Double maxMarks;

    public CompetencyResultCreateRequestDTO() {}

    public Long getTestID() { return testID; }
    public Long getTraineeID() { return traineeID; }
    public Long getUnitID() { return unitID; }
    public CompetencyResultAssessmentMethod getAssessmentMethod() { return assessmentMethod; }
    public Double getMarksObtained() { return marksObtained; }
    public Double getMaxMarks() { return maxMarks; }

    public void setTestID(Long testID) { this.testID = testID; }
    public void setTraineeID(Long traineeID) { this.traineeID = traineeID; }
    public void setUnitID(Long unitID) { this.unitID = unitID; }
    public void setAssessmentMethod(CompetencyResultAssessmentMethod assessmentMethod) { this.assessmentMethod = assessmentMethod; }
    public void setMarksObtained(Double marksObtained) { this.marksObtained = marksObtained; }
    public void setMaxMarks(Double maxMarks) { this.maxMarks = maxMarks; }
}
