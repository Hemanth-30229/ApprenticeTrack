package com.cts.assessment.dto;

import java.time.LocalDate;

import com.cts.assessment.common.CompetencyResultAssessmentMethod;
import com.cts.assessment.common.CompetencyResultOutcome;

public class CompetencyResultResponseDTO {

    private Long resultID, testID, traineeID, unitID, assessedByID;
    private CompetencyResultAssessmentMethod assessmentMethod;
    private Double marksObtained, maxMarks;
    private CompetencyResultOutcome outcome;
    private LocalDate assessmentDate;

    public CompetencyResultResponseDTO() {}

    public Long getResultID() { return resultID; }
    public Long getTestID() { return testID; }
    public Long getTraineeID() { return traineeID; }
    public Long getUnitID() { return unitID; }
    public Long getAssessedByID() { return assessedByID; }
    public CompetencyResultAssessmentMethod getAssessmentMethod() { return assessmentMethod; }
    public Double getMarksObtained() { return marksObtained; }
    public Double getMaxMarks() { return maxMarks; }
    public CompetencyResultOutcome getOutcome() { return outcome; }
    public LocalDate getAssessmentDate() { return assessmentDate; }

    public void setResultID(Long v) { this.resultID = v; }
    public void setTestID(Long v) { this.testID = v; }
    public void setTraineeID(Long v) { this.traineeID = v; }
    public void setUnitID(Long v) { this.unitID = v; }
    public void setAssessedByID(Long v) { this.assessedByID = v; }
    public void setAssessmentMethod(CompetencyResultAssessmentMethod v) { this.assessmentMethod = v; }
    public void setMarksObtained(Double v) { this.marksObtained = v; }
    public void setMaxMarks(Double v) { this.maxMarks = v; }
    public void setOutcome(CompetencyResultOutcome v) { this.outcome = v; }
    public void setAssessmentDate(LocalDate v) { this.assessmentDate = v; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long resultID, testID, traineeID, unitID, assessedByID;
        private CompetencyResultAssessmentMethod assessmentMethod;
        private Double marksObtained, maxMarks;
        private CompetencyResultOutcome outcome;
        private LocalDate assessmentDate;

        public Builder resultID(Long v) { this.resultID = v; return this; }
        public Builder testID(Long v) { this.testID = v; return this; }
        public Builder traineeID(Long v) { this.traineeID = v; return this; }
        public Builder unitID(Long v) { this.unitID = v; return this; }
        public Builder assessedByID(Long v) { this.assessedByID = v; return this; }
        public Builder assessmentMethod(CompetencyResultAssessmentMethod v) { this.assessmentMethod = v; return this; }
        public Builder marksObtained(Double v) { this.marksObtained = v; return this; }
        public Builder maxMarks(Double v) { this.maxMarks = v; return this; }
        public Builder outcome(CompetencyResultOutcome v) { this.outcome = v; return this; }
        public Builder assessmentDate(LocalDate v) { this.assessmentDate = v; return this; }

        public CompetencyResultResponseDTO build() {
            CompetencyResultResponseDTO d = new CompetencyResultResponseDTO();
            d.resultID = resultID; d.testID = testID; d.traineeID = traineeID;
            d.unitID = unitID; d.assessedByID = assessedByID; d.assessmentMethod = assessmentMethod;
            d.marksObtained = marksObtained; d.maxMarks = maxMarks; d.outcome = outcome;
            d.assessmentDate = assessmentDate;
            return d;
        }
    }
}
