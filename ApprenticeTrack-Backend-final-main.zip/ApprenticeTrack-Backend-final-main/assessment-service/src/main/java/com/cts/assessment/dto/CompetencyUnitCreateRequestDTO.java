package com.cts.assessment.dto;

import com.cts.assessment.common.CompetencyUnitAssessmentMethod;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class CompetencyUnitCreateRequestDTO {
    @NotNull(message = "Course ID is required") private Long courseID;
    @NotBlank(message = "Unit name is required") private String unitName;
    @NotBlank(message = "Unit code is required") private String unitCode;
    private String performanceCriteria;
    private String evidenceRequired;
    @NotNull(message = "Assessment method is required") private CompetencyUnitAssessmentMethod assessmentMethod;

    public CompetencyUnitCreateRequestDTO() {}
    public Long getCourseID() { return courseID; }
    public String getUnitName() { return unitName; }
    public String getUnitCode() { return unitCode; }
    public String getPerformanceCriteria() { return performanceCriteria; }
    public String getEvidenceRequired() { return evidenceRequired; }
    public CompetencyUnitAssessmentMethod getAssessmentMethod() { return assessmentMethod; }
    public void setCourseID(Long v) { this.courseID = v; }
    public void setUnitName(String v) { this.unitName = v; }
    public void setUnitCode(String v) { this.unitCode = v; }
    public void setPerformanceCriteria(String v) { this.performanceCriteria = v; }
    public void setEvidenceRequired(String v) { this.evidenceRequired = v; }
    public void setAssessmentMethod(CompetencyUnitAssessmentMethod v) { this.assessmentMethod = v; }
}
