package com.cts.assessment.dto;

import com.cts.assessment.common.CompetencyUnitAssessmentMethod;
import com.cts.assessment.common.CompetencyUnitStatus;

public class CompetencyUnitResponseDTO {
    private Long unitID;
    private Long courseID;
    private String unitName;
    private String unitCode;
    private String performanceCriteria;
    private String evidenceRequired;
    private CompetencyUnitAssessmentMethod assessmentMethod;
    private CompetencyUnitStatus status;

    public CompetencyUnitResponseDTO() {}
    public Long getUnitID() { return unitID; }
    public Long getCourseID() { return courseID; }
    public String getUnitName() { return unitName; }
    public String getUnitCode() { return unitCode; }
    public String getPerformanceCriteria() { return performanceCriteria; }
    public String getEvidenceRequired() { return evidenceRequired; }
    public CompetencyUnitAssessmentMethod getAssessmentMethod() { return assessmentMethod; }
    public CompetencyUnitStatus getStatus() { return status; }
    public void setUnitID(Long v) { this.unitID = v; }
    public void setCourseID(Long v) { this.courseID = v; }
    public void setUnitName(String v) { this.unitName = v; }
    public void setUnitCode(String v) { this.unitCode = v; }
    public void setPerformanceCriteria(String v) { this.performanceCriteria = v; }
    public void setEvidenceRequired(String v) { this.evidenceRequired = v; }
    public void setAssessmentMethod(CompetencyUnitAssessmentMethod v) { this.assessmentMethod = v; }
    public void setStatus(CompetencyUnitStatus v) { this.status = v; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long unitID;
        private Long courseID;
        private String unitName;
        private String unitCode;
        private String performanceCriteria;
        private String evidenceRequired;
        private CompetencyUnitAssessmentMethod assessmentMethod;
        private CompetencyUnitStatus status;
        public Builder unitID(Long v) { this.unitID = v; return this; }
        public Builder courseID(Long v) { this.courseID = v; return this; }
        public Builder unitName(String v) { this.unitName = v; return this; }
        public Builder unitCode(String v) { this.unitCode = v; return this; }
        public Builder performanceCriteria(String v) { this.performanceCriteria = v; return this; }
        public Builder evidenceRequired(String v) { this.evidenceRequired = v; return this; }
        public Builder assessmentMethod(CompetencyUnitAssessmentMethod v) { this.assessmentMethod = v; return this; }
        public Builder status(CompetencyUnitStatus v) { this.status = v; return this; }
        public CompetencyUnitResponseDTO build() {
            CompetencyUnitResponseDTO d = new CompetencyUnitResponseDTO();
            d.unitID = unitID; d.courseID = courseID; d.unitName = unitName; d.unitCode = unitCode;
            d.performanceCriteria = performanceCriteria; d.evidenceRequired = evidenceRequired;
            d.assessmentMethod = assessmentMethod; d.status = status;
            return d;
        }
    }
}
