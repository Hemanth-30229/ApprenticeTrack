package com.cts.assessment.dto;

import jakarta.validation.constraints.NotNull;

public class ComputeResultsRequestDTO {

    @NotNull(message = "TestID is required")
    private Long testID;

    public ComputeResultsRequestDTO() {}

    public Long getTestID() { return testID; }
    public void setTestID(Long testID) { this.testID = testID; }
}
