package com.cts.assessment.dto;

import java.util.List;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GradeAttemptRequestDTO {

    @NotNull(message = "Grades are required")
    private List<QuestionGradeDTO> grades;
}
