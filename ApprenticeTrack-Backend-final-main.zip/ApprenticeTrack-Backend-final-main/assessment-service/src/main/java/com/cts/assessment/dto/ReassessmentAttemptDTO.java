package com.cts.assessment.dto;

import java.time.LocalDate;
import java.util.List;

import com.cts.assessment.common.TradeTestResultOverallOutcome;

/** One attempt (original or reassessment) within a trainee's reassessment history. */
public class ReassessmentAttemptDTO {
    private Integer attemptNumber;
    private Long testID;
    private LocalDate testDate;
    private TradeTestResultOverallOutcome outcome;
    private List<CompetencyResultResponseDTO> unitScores;

    public ReassessmentAttemptDTO() {}
    public Integer getAttemptNumber() { return attemptNumber; }
    public Long getTestID() { return testID; }
    public LocalDate getTestDate() { return testDate; }
    public TradeTestResultOverallOutcome getOutcome() { return outcome; }
    public List<CompetencyResultResponseDTO> getUnitScores() { return unitScores; }
    public void setAttemptNumber(Integer v) { this.attemptNumber = v; }
    public void setTestID(Long v) { this.testID = v; }
    public void setTestDate(LocalDate v) { this.testDate = v; }
    public void setOutcome(TradeTestResultOverallOutcome v) { this.outcome = v; }
    public void setUnitScores(List<CompetencyResultResponseDTO> v) { this.unitScores = v; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Integer attemptNumber;
        private Long testID;
        private LocalDate testDate;
        private TradeTestResultOverallOutcome outcome;
        private List<CompetencyResultResponseDTO> unitScores;
        public Builder attemptNumber(Integer v) { this.attemptNumber = v; return this; }
        public Builder testID(Long v) { this.testID = v; return this; }
        public Builder testDate(LocalDate v) { this.testDate = v; return this; }
        public Builder outcome(TradeTestResultOverallOutcome v) { this.outcome = v; return this; }
        public Builder unitScores(List<CompetencyResultResponseDTO> v) { this.unitScores = v; return this; }
        public ReassessmentAttemptDTO build() {
            ReassessmentAttemptDTO d = new ReassessmentAttemptDTO();
            d.attemptNumber = attemptNumber; d.testID = testID; d.testDate = testDate;
            d.outcome = outcome; d.unitScores = unitScores;
            return d;
        }
    }
}
