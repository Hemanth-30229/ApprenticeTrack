package com.cts.assessment.dto;

import java.time.LocalDate;

import com.cts.assessment.common.TradeTestResultOverallOutcome;

/**
 * A trainee flagged for reassessment (ReassessmentRequired = true), with original test
 * details and the number of reassessment attempts made so far.
 */
public class ReassessmentCandidateDTO {
    private Long traineeID;
    private String traineeName;
    private Long originalTestID;
    private Long courseID;
    private Long batchID;
    private LocalDate originalTestDate;
    private TradeTestResultOverallOutcome overallOutcome;
    private long reassessmentCount;

    public ReassessmentCandidateDTO() {}
    public Long getTraineeID() { return traineeID; }
    public String getTraineeName() { return traineeName; }
    public Long getOriginalTestID() { return originalTestID; }
    public Long getCourseID() { return courseID; }
    public Long getBatchID() { return batchID; }
    public LocalDate getOriginalTestDate() { return originalTestDate; }
    public TradeTestResultOverallOutcome getOverallOutcome() { return overallOutcome; }
    public long getReassessmentCount() { return reassessmentCount; }
    public void setTraineeID(Long v) { this.traineeID = v; }
    public void setTraineeName(String v) { this.traineeName = v; }
    public void setOriginalTestID(Long v) { this.originalTestID = v; }
    public void setCourseID(Long v) { this.courseID = v; }
    public void setBatchID(Long v) { this.batchID = v; }
    public void setOriginalTestDate(LocalDate v) { this.originalTestDate = v; }
    public void setOverallOutcome(TradeTestResultOverallOutcome v) { this.overallOutcome = v; }
    public void setReassessmentCount(long v) { this.reassessmentCount = v; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long traineeID, originalTestID, courseID, batchID;
        private String traineeName;
        private LocalDate originalTestDate;
        private TradeTestResultOverallOutcome overallOutcome;
        private long reassessmentCount;
        public Builder traineeID(Long v) { this.traineeID = v; return this; }
        public Builder traineeName(String v) { this.traineeName = v; return this; }
        public Builder originalTestID(Long v) { this.originalTestID = v; return this; }
        public Builder courseID(Long v) { this.courseID = v; return this; }
        public Builder batchID(Long v) { this.batchID = v; return this; }
        public Builder originalTestDate(LocalDate v) { this.originalTestDate = v; return this; }
        public Builder overallOutcome(TradeTestResultOverallOutcome v) { this.overallOutcome = v; return this; }
        public Builder reassessmentCount(long v) { this.reassessmentCount = v; return this; }
        public ReassessmentCandidateDTO build() {
            ReassessmentCandidateDTO d = new ReassessmentCandidateDTO();
            d.traineeID = traineeID; d.traineeName = traineeName; d.originalTestID = originalTestID;
            d.courseID = courseID; d.batchID = batchID; d.originalTestDate = originalTestDate;
            d.overallOutcome = overallOutcome; d.reassessmentCount = reassessmentCount;
            return d;
        }
    }
}
