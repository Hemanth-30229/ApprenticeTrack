package com.cts.assessment.dto;

import java.util.List;

/** Full reassessment history for a trainee + original-test combination. */
public class ReassessmentHistoryDTO {
    private Long traineeID;
    private String traineeName;
    private Long originalTestID;
    private long totalAttempts;
    private List<ReassessmentAttemptDTO> attempts;

    public ReassessmentHistoryDTO() {}
    public Long getTraineeID() { return traineeID; }
    public String getTraineeName() { return traineeName; }
    public Long getOriginalTestID() { return originalTestID; }
    public long getTotalAttempts() { return totalAttempts; }
    public List<ReassessmentAttemptDTO> getAttempts() { return attempts; }
    public void setTraineeID(Long v) { this.traineeID = v; }
    public void setTraineeName(String v) { this.traineeName = v; }
    public void setOriginalTestID(Long v) { this.originalTestID = v; }
    public void setTotalAttempts(long v) { this.totalAttempts = v; }
    public void setAttempts(List<ReassessmentAttemptDTO> v) { this.attempts = v; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long traineeID, originalTestID;
        private String traineeName;
        private long totalAttempts;
        private List<ReassessmentAttemptDTO> attempts;
        public Builder traineeID(Long v) { this.traineeID = v; return this; }
        public Builder traineeName(String v) { this.traineeName = v; return this; }
        public Builder originalTestID(Long v) { this.originalTestID = v; return this; }
        public Builder totalAttempts(long v) { this.totalAttempts = v; return this; }
        public Builder attempts(List<ReassessmentAttemptDTO> v) { this.attempts = v; return this; }
        public ReassessmentHistoryDTO build() {
            ReassessmentHistoryDTO d = new ReassessmentHistoryDTO();
            d.traineeID = traineeID; d.traineeName = traineeName; d.originalTestID = originalTestID;
            d.totalAttempts = totalAttempts; d.attempts = attempts;
            return d;
        }
    }
}
