package com.cts.assessment.dto;

import java.time.LocalDate;

import com.cts.assessment.common.TradeTestResultOverallOutcome;

public class ReassessmentResponseDTO {
    private Long reassessmentID;
    private Long traineeID;
    private Long originalTestID;
    private Long newTestID;
    private Long assessorID;
    private Long venueID;
    private LocalDate scheduledDate;
    private Integer attemptNumber;
    private TradeTestResultOverallOutcome outcome;

    public ReassessmentResponseDTO() {}
    public Long getReassessmentID() { return reassessmentID; }
    public Long getTraineeID() { return traineeID; }
    public Long getOriginalTestID() { return originalTestID; }
    public Long getNewTestID() { return newTestID; }
    public Long getAssessorID() { return assessorID; }
    public Long getVenueID() { return venueID; }
    public LocalDate getScheduledDate() { return scheduledDate; }
    public Integer getAttemptNumber() { return attemptNumber; }
    public TradeTestResultOverallOutcome getOutcome() { return outcome; }
    public void setReassessmentID(Long v) { this.reassessmentID = v; }
    public void setTraineeID(Long v) { this.traineeID = v; }
    public void setOriginalTestID(Long v) { this.originalTestID = v; }
    public void setNewTestID(Long v) { this.newTestID = v; }
    public void setAssessorID(Long v) { this.assessorID = v; }
    public void setVenueID(Long v) { this.venueID = v; }
    public void setScheduledDate(LocalDate v) { this.scheduledDate = v; }
    public void setAttemptNumber(Integer v) { this.attemptNumber = v; }
    public void setOutcome(TradeTestResultOverallOutcome v) { this.outcome = v; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long reassessmentID, traineeID, originalTestID, newTestID, assessorID, venueID;
        private LocalDate scheduledDate;
        private Integer attemptNumber;
        private TradeTestResultOverallOutcome outcome;
        public Builder reassessmentID(Long v) { this.reassessmentID = v; return this; }
        public Builder traineeID(Long v) { this.traineeID = v; return this; }
        public Builder originalTestID(Long v) { this.originalTestID = v; return this; }
        public Builder newTestID(Long v) { this.newTestID = v; return this; }
        public Builder assessorID(Long v) { this.assessorID = v; return this; }
        public Builder venueID(Long v) { this.venueID = v; return this; }
        public Builder scheduledDate(LocalDate v) { this.scheduledDate = v; return this; }
        public Builder attemptNumber(Integer v) { this.attemptNumber = v; return this; }
        public Builder outcome(TradeTestResultOverallOutcome v) { this.outcome = v; return this; }
        public ReassessmentResponseDTO build() {
            ReassessmentResponseDTO d = new ReassessmentResponseDTO();
            d.reassessmentID = reassessmentID; d.traineeID = traineeID;
            d.originalTestID = originalTestID; d.newTestID = newTestID;
            d.assessorID = assessorID; d.venueID = venueID; d.scheduledDate = scheduledDate;
            d.attemptNumber = attemptNumber; d.outcome = outcome;
            return d;
        }
    }
}
