package com.cts.assessment.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.NotNull;

public class ReassessmentScheduleRequestDTO {
    @NotNull(message = "Trainee ID is required") private Long traineeID;
    @NotNull(message = "Original test ID is required") private Long originalTestID;
    @NotNull(message = "New test date is required") private LocalDate newTestDate;
    @NotNull(message = "Assessor ID is required") private Long assessorID;
    @NotNull(message = "Venue ID is required") private Long venueID;

    public ReassessmentScheduleRequestDTO() {}
    public Long getTraineeID() { return traineeID; }
    public Long getOriginalTestID() { return originalTestID; }
    public LocalDate getNewTestDate() { return newTestDate; }
    public Long getAssessorID() { return assessorID; }
    public Long getVenueID() { return venueID; }
    public void setTraineeID(Long v) { this.traineeID = v; }
    public void setOriginalTestID(Long v) { this.originalTestID = v; }
    public void setNewTestDate(LocalDate v) { this.newTestDate = v; }
    public void setAssessorID(Long v) { this.assessorID = v; }
    public void setVenueID(Long v) { this.venueID = v; }
}
