package com.cts.assessment.dto;

import com.cts.assessment.common.TestQuestionType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TestAnswerResponseDTO {
    private Long questionID;
    private TestQuestionType questionType;
    private Integer marks;
    private Integer selectedOptionIndex;
    private Integer correctOptionIndex;
    private Boolean isCorrect;
    private String codeAnswer;
    private Integer marksAwarded;
}
