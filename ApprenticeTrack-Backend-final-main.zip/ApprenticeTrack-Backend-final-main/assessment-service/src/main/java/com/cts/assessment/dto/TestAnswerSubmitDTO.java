package com.cts.assessment.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TestAnswerSubmitDTO {
    private Long questionID;
    private Integer selectedOptionIndex;
    private String codeAnswer;
}
