package com.cts.assessment.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.cts.assessment.common.TestAttemptStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TestAttemptResponseDTO {
    private Long attemptID;
    private Long testID;
    private Long traineeID;
    private String traineeName;
    private TestAttemptStatus status;
    private Integer autoScore;
    private Integer autoMaxScore;
    private Integer totalScore;
    private Integer maxScore;
    private LocalDateTime submittedAt;
    private List<TestAnswerResponseDTO> answers;
}
