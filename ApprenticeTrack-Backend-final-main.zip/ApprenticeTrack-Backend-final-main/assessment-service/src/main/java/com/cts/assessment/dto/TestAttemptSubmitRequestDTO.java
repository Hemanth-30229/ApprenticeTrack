package com.cts.assessment.dto;

import java.util.List;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TestAttemptSubmitRequestDTO {

    @NotNull(message = "TraineeID is required")
    private Long traineeID;

    private String traineeName;

    private List<TestAnswerSubmitDTO> answers;
}
