package com.cts.assessment.dto;

import java.util.List;

import com.cts.assessment.common.TestQuestionType;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TestQuestionCreateRequestDTO {

    @NotNull(message = "Question type is required")
    private TestQuestionType questionType;

    @NotBlank(message = "Question text is required")
    private String questionText;

    @NotNull(message = "Marks is required")
    @Min(value = 1, message = "Marks must be at least 1")
    private Integer marks;

    // MultipleChoice
    private List<TestQuestionOptionDTO> options;
    private Integer correctOptionIndex;

    // Coding
    private String language;
    private String starterCode;
}
