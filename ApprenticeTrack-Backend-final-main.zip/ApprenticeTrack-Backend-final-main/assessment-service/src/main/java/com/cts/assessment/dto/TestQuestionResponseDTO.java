package com.cts.assessment.dto;

import java.util.List;

import com.cts.assessment.common.TestQuestionType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TestQuestionResponseDTO {
    private Long questionID;
    private Long testID;
    private TestQuestionType questionType;
    private String questionText;
    private Integer marks;
    private Integer sequence;
    private List<TestQuestionOptionDTO> options;
    private Integer correctOptionIndex;
    private String language;
    private String starterCode;
}
