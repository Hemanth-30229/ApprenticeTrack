package com.cts.assessment.dto;

import java.time.LocalDate;

import com.cts.assessment.common.TradeTestStatus;

public class TradeTestResponseDTO {

    private Long testID, courseID, batchID, assessorID, venueID;
    private String courseName, batchCode, assessorName;
    private LocalDate testDate;
    private TradeTestStatus status;

    public TradeTestResponseDTO() {}

    public Long getTestID() { return testID; }
    public Long getCourseID() { return courseID; }
    public Long getBatchID() { return batchID; }
    public Long getAssessorID() { return assessorID; }
    public Long getVenueID() { return venueID; }
    public String getCourseName() { return courseName; }
    public String getBatchCode() { return batchCode; }
    public String getAssessorName() { return assessorName; }
    public LocalDate getTestDate() { return testDate; }
    public TradeTestStatus getStatus() { return status; }

    public void setTestID(Long v) { this.testID = v; }
    public void setCourseID(Long v) { this.courseID = v; }
    public void setBatchID(Long v) { this.batchID = v; }
    public void setAssessorID(Long v) { this.assessorID = v; }
    public void setVenueID(Long v) { this.venueID = v; }
    public void setCourseName(String v) { this.courseName = v; }
    public void setBatchCode(String v) { this.batchCode = v; }
    public void setAssessorName(String v) { this.assessorName = v; }
    public void setTestDate(LocalDate v) { this.testDate = v; }
    public void setStatus(TradeTestStatus v) { this.status = v; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long testID, courseID, batchID, assessorID, venueID;
        private String courseName, batchCode, assessorName;
        private LocalDate testDate;
        private TradeTestStatus status;

        public Builder testID(Long v) { this.testID = v; return this; }
        public Builder courseID(Long v) { this.courseID = v; return this; }
        public Builder batchID(Long v) { this.batchID = v; return this; }
        public Builder assessorID(Long v) { this.assessorID = v; return this; }
        public Builder venueID(Long v) { this.venueID = v; return this; }
        public Builder courseName(String v) { this.courseName = v; return this; }
        public Builder batchCode(String v) { this.batchCode = v; return this; }
        public Builder assessorName(String v) { this.assessorName = v; return this; }
        public Builder testDate(LocalDate v) { this.testDate = v; return this; }
        public Builder status(TradeTestStatus v) { this.status = v; return this; }

        public TradeTestResponseDTO build() {
            TradeTestResponseDTO d = new TradeTestResponseDTO();
            d.testID = testID; d.courseID = courseID; d.batchID = batchID;
            d.assessorID = assessorID; d.venueID = venueID; d.courseName = courseName;
            d.batchCode = batchCode; d.assessorName = assessorName;
            d.testDate = testDate; d.status = status;
            return d;
        }
    }
}
