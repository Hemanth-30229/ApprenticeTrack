package com.cts.assessment.dto;

import java.util.List;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

/**
 * Direct per-trainee trade-test result entry (replaces the competency-unit grid).
 * The assessor supplies a mark per trainee; the service derives Pass/Fail/Absent
 * from the pass threshold (default 60%). A null mark means the trainee was Absent.
 */
public class TradeTestResultEntryRequestDTO {

    @NotNull(message = "testID is required")
    private Long testID;

    @NotEmpty(message = "At least one trainee result is required")
    private List<TraineeResult> results;

    public Long getTestID() { return testID; }
    public void setTestID(Long v) { this.testID = v; }
    public List<TraineeResult> getResults() { return results; }
    public void setResults(List<TraineeResult> v) { this.results = v; }

    public static class TraineeResult {
        @NotNull(message = "traineeID is required")
        private Long traineeID;
        /** Null = Absent. */
        private Integer marksObtained;
        /** Optional; defaults to 100 when omitted. */
        private Integer maxMarks;

        public Long getTraineeID() { return traineeID; }
        public void setTraineeID(Long v) { this.traineeID = v; }
        public Integer getMarksObtained() { return marksObtained; }
        public void setMarksObtained(Integer v) { this.marksObtained = v; }
        public Integer getMaxMarks() { return maxMarks; }
        public void setMaxMarks(Integer v) { this.maxMarks = v; }
    }
}
