package com.cts.assessment.dto;

import java.time.LocalDate;
import java.util.List;

import com.cts.assessment.common.TradeTestResultOverallOutcome;
import com.cts.assessment.common.TradeTestResultStatus;

public class TradeTestResultResponseDTO {

    private Long finalResultID, testID, traineeID, courseID;
    private String traineeName, courseName;
    private TradeTestResultOverallOutcome overallOutcome;
    private Integer marksObtained;
    private Integer maxMarks;
    private Boolean reassessmentRequired;
    private LocalDate publishedDate;
    private TradeTestResultStatus status;
    /** Unit-wise CompetencyResult breakdown; populated by the detail endpoint. */
    private List<CompetencyResultResponseDTO> unitWiseBreakdown;

    public TradeTestResultResponseDTO() {}

    public Long getFinalResultID() { return finalResultID; }
    public Long getTestID() { return testID; }
    public Long getTraineeID() { return traineeID; }
    public Long getCourseID() { return courseID; }
    public String getTraineeName() { return traineeName; }
    public String getCourseName() { return courseName; }
    public TradeTestResultOverallOutcome getOverallOutcome() { return overallOutcome; }
    public Integer getMarksObtained() { return marksObtained; }
    public Integer getMaxMarks() { return maxMarks; }
    public Boolean getReassessmentRequired() { return reassessmentRequired; }
    public LocalDate getPublishedDate() { return publishedDate; }
    public TradeTestResultStatus getStatus() { return status; }
    public List<CompetencyResultResponseDTO> getUnitWiseBreakdown() { return unitWiseBreakdown; }

    public void setFinalResultID(Long v) { this.finalResultID = v; }
    public void setTestID(Long v) { this.testID = v; }
    public void setTraineeID(Long v) { this.traineeID = v; }
    public void setCourseID(Long v) { this.courseID = v; }
    public void setTraineeName(String v) { this.traineeName = v; }
    public void setCourseName(String v) { this.courseName = v; }
    public void setOverallOutcome(TradeTestResultOverallOutcome v) { this.overallOutcome = v; }
    public void setMarksObtained(Integer v) { this.marksObtained = v; }
    public void setMaxMarks(Integer v) { this.maxMarks = v; }
    public void setReassessmentRequired(Boolean v) { this.reassessmentRequired = v; }
    public void setPublishedDate(LocalDate v) { this.publishedDate = v; }
    public void setStatus(TradeTestResultStatus v) { this.status = v; }
    public void setUnitWiseBreakdown(List<CompetencyResultResponseDTO> v) { this.unitWiseBreakdown = v; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long finalResultID, testID, traineeID, courseID;
        private String traineeName, courseName;
        private TradeTestResultOverallOutcome overallOutcome;
        private Integer marksObtained;
        private Integer maxMarks;
        private Boolean reassessmentRequired;
        private LocalDate publishedDate;
        private TradeTestResultStatus status;
        private List<CompetencyResultResponseDTO> unitWiseBreakdown;

        public Builder finalResultID(Long v) { this.finalResultID = v; return this; }
        public Builder testID(Long v) { this.testID = v; return this; }
        public Builder traineeID(Long v) { this.traineeID = v; return this; }
        public Builder courseID(Long v) { this.courseID = v; return this; }
        public Builder traineeName(String v) { this.traineeName = v; return this; }
        public Builder courseName(String v) { this.courseName = v; return this; }
        public Builder overallOutcome(TradeTestResultOverallOutcome v) { this.overallOutcome = v; return this; }
        public Builder marksObtained(Integer v) { this.marksObtained = v; return this; }
        public Builder maxMarks(Integer v) { this.maxMarks = v; return this; }
        public Builder reassessmentRequired(Boolean v) { this.reassessmentRequired = v; return this; }
        public Builder publishedDate(LocalDate v) { this.publishedDate = v; return this; }
        public Builder status(TradeTestResultStatus v) { this.status = v; return this; }
        public Builder unitWiseBreakdown(List<CompetencyResultResponseDTO> v) { this.unitWiseBreakdown = v; return this; }

        public TradeTestResultResponseDTO build() {
            TradeTestResultResponseDTO d = new TradeTestResultResponseDTO();
            d.finalResultID = finalResultID; d.testID = testID; d.traineeID = traineeID;
            d.courseID = courseID; d.traineeName = traineeName; d.courseName = courseName;
            d.overallOutcome = overallOutcome; d.marksObtained = marksObtained; d.maxMarks = maxMarks;
            d.reassessmentRequired = reassessmentRequired;
            d.publishedDate = publishedDate; d.status = status; d.unitWiseBreakdown = unitWiseBreakdown;
            return d;
        }
    }
}
