package com.cts.assessment.dto;

import com.cts.assessment.common.TradeTestStatus;

import jakarta.validation.constraints.NotNull;

public class TradeTestStatusUpdateRequestDTO {

    @NotNull(message = "Status is required")
    private TradeTestStatus status;

    public TradeTestStatusUpdateRequestDTO() {}

    public TradeTestStatus getStatus() { return status; }
    public void setStatus(TradeTestStatus status) { this.status = status; }
}
