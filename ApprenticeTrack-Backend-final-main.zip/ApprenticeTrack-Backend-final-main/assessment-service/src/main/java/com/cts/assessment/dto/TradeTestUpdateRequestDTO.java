package com.cts.assessment.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;

public class TradeTestUpdateRequestDTO {

    @NotNull(message = "AssessorID is required")
    private Long assessorID;

    @NotNull(message = "Test date is required")
    @Future(message = "Test date must be a future date")
    private LocalDate testDate;

    @NotNull(message = "VenueID is required")
    private Long venueID;

    public TradeTestUpdateRequestDTO() {}

    public Long getAssessorID() { return assessorID; }
    public LocalDate getTestDate() { return testDate; }
    public Long getVenueID() { return venueID; }

    public void setAssessorID(Long assessorID) { this.assessorID = assessorID; }
    public void setTestDate(LocalDate testDate) { this.testDate = testDate; }
    public void setVenueID(Long venueID) { this.venueID = venueID; }
}
