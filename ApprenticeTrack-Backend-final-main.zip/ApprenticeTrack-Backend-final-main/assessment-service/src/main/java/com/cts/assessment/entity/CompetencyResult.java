package com.cts.assessment.entity;

import java.time.LocalDate;

import com.cts.assessment.common.CompetencyResultAssessmentMethod;
import com.cts.assessment.common.CompetencyResultOutcome;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "competency_results")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CompetencyResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long resultID;

    @Column(nullable = false)
    private Long testID;

    @Column(nullable = false)
    private Long traineeID;

    @Column(nullable = false)
    private Long unitID;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CompetencyResultAssessmentMethod assessmentMethod;

    @Column(nullable = false)
    private Double marksObtained;

    @Column(nullable = false)
    private Double maxMarks;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CompetencyResultOutcome outcome;

    @Column(nullable = false)
    private Long assessedByID;

    @Column(nullable = false)
    private LocalDate assessmentDate;
}