package com.cts.assessment.entity;

import com.cts.assessment.common.CompetencyUnitAssessmentMethod;
import com.cts.assessment.common.CompetencyUnitStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Competency unit belonging to a trade course, including performance criteria,
 * evidence requirements, and the assessment method used to judge competency.
 * {@code courseID} is a reference ID owned by training-service.
 */
@Entity
@Table(name = "competency_units")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CompetencyUnit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long unitID;

    @Column(nullable = false)
    private Long courseID;

    @Column(nullable = false)
    private String unitName;

    @Column(nullable = false)
    private String unitCode;

    @Column(length = 2000)
    private String performanceCriteria;

    @Column(length = 2000)
    private String evidenceRequired;

    @Enumerated(EnumType.STRING)
    private CompetencyUnitAssessmentMethod assessmentMethod;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private CompetencyUnitStatus status = CompetencyUnitStatus.Active;
}