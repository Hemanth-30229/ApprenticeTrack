package com.cts.assessment.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.cts.assessment.common.TradeTestResultOverallOutcome;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A scheduled reassessment attempt for a trainee who failed a trade test.
 * Each reassessment is backed by a new {@link TradeTest} ({@code newTestID}) that is
 * linked to the original via {@code TradeTest.parentTestID}.
 */
@Entity
@Table(name = "reassessments")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Reassessment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reassessmentID;

    @Column(nullable = false)
    private Long traineeID;

    /** The original (first) trade test the trainee failed. */
    @Column(nullable = false)
    private Long originalTestID;

    /** The newly created trade test for this reassessment attempt. */
    @Column(nullable = false)
    private Long newTestID;

    @Column(nullable = false)
    private Long assessorID;

    @Column(nullable = false)
    private Long venueID;

    @Column(nullable = false)
    private LocalDate scheduledDate;

    @Column(nullable = false)
    private Integer attemptNumber;

    /** Outcome once reassessment results are recalculated; null while pending. */
    @Enumerated(EnumType.STRING)
    private TradeTestResultOverallOutcome outcome;

    @Column(nullable = false)
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();
}