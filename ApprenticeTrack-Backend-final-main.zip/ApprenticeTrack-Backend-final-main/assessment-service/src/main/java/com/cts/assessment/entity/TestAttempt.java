package com.cts.assessment.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.cts.assessment.common.TestAttemptStatus;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A trainee's single submission for a trade test's online question paper.
 * MCQ answers are auto-scored at submit (autoScore/autoMaxScore); coding answers
 * are graded later, at which point totalScore is finalized and status -> Graded.
 */
@Entity
@Table(name = "test_attempts")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TestAttempt {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long attemptID;

    @Column(nullable = false)
    private Long testID;

    @Column(nullable = false)
    private Long traineeID;

    private String traineeName;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TestAttemptStatus status;

    private Integer autoScore;
    private Integer autoMaxScore;
    private Integer totalScore;
    private Integer maxScore;

    @Column(nullable = false)
    private LocalDateTime submittedAt;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "attemptID")
    @Builder.Default
    private List<TestAttemptAnswer> answers = new ArrayList<>();
}
