package com.cts.assessment.entity;

import com.cts.assessment.common.TestQuestionType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * One trainee answer within a {@link TestAttempt}. MCQ answers store the chosen
 * option index + auto-computed correctness; Coding answers store the submitted
 * code and receive marksAwarded during manual grading.
 */
@Entity
@Table(name = "test_attempt_answers")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TestAttemptAnswer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long answerID;

    @Column(nullable = false)
    private Long questionID;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TestQuestionType questionType;

    @Column(nullable = false)
    private Integer marks;

    // MCQ
    private Integer selectedOptionIndex;
    private Integer correctOptionIndex;
    private Boolean isCorrect;

    // Coding
    @Column(columnDefinition = "TEXT")
    private String codeAnswer;

    /** Auto-set for MCQ at submit; set by the assessor for Coding during grading. */
    private Integer marksAwarded;
}
