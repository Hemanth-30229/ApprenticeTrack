package com.cts.assessment.entity;

import java.util.ArrayList;
import java.util.List;

import com.cts.assessment.common.TestQuestionType;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OrderColumn;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A single question in a trade test's online question paper. MultipleChoice
 * questions carry an ordered option list plus the index of the correct option
 * (auto-graded); Coding questions carry a language + optional starter code and
 * are graded manually by the assessor.
 */
@Entity
@Table(name = "test_questions")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TestQuestion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long questionID;

    @Column(nullable = false)
    private Long testID;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TestQuestionType questionType;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String questionText;

    @Column(nullable = false)
    private Integer marks;

    /** 1-based display order within the test. */
    @Column(nullable = false)
    private Integer sequence;

    // ── MultipleChoice ──
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "test_question_options", joinColumns = @JoinColumn(name = "questionID"))
    @OrderColumn(name = "option_index")
    @Column(name = "option_text", length = 1000)
    @Builder.Default
    private List<String> options = new ArrayList<>();

    /** Index into {@link #options} of the correct answer (null for Coding). */
    private Integer correctOptionIndex;

    // ── Coding ──
    private String language;

    @Column(columnDefinition = "TEXT")
    private String starterCode;
}
