package com.cts.assessment.entity;

import java.time.LocalDate;

import com.cts.assessment.common.QualificationLevel;
import com.cts.assessment.common.TradeCertificateStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "trade_certificates")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TradeCertificate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long certificateID;

    @Column(nullable = false)
    private Long traineeID;

    @Column(nullable = false)
    private Long courseID;

    @Column(nullable = false, unique = true)
    private String certificateNumber;

    @Column(nullable = false)
    private LocalDate issuedDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private QualificationLevel qualificationLevel;

    @Column(nullable = false)
    private Long issuedByID;

    @Column(length = 500)
    private String revocationReason;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private TradeCertificateStatus status = TradeCertificateStatus.Issued;
}