package com.cts.assessment.entity;

import java.time.LocalDate;

import com.cts.assessment.common.TradeTestStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "trade_tests")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TradeTest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long testID;

    @Column(nullable = false)
    private Long courseID;

    @Column(nullable = false)
    private Long batchID;

    @Column(nullable = false)
    private Long assessorID;

    @Column(nullable = false)
    private LocalDate testDate;

    @Column(nullable = false)
    private Long venueID;

    /** Links a reassessment test back to the original test it re-evaluates (null for originals). */
    private Long parentTestID;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private TradeTestStatus status = TradeTestStatus.Scheduled;
}