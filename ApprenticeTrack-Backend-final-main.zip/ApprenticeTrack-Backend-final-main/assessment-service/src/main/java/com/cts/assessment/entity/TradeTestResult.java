package com.cts.assessment.entity;

import java.time.LocalDate;

import com.cts.assessment.common.TradeTestResultOverallOutcome;
import com.cts.assessment.common.TradeTestResultStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "trade_test_results")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TradeTestResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long finalResultID;

    @Column(nullable = false)
    private Long testID;

    @Column(nullable = false)
    private Long traineeID;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TradeTestResultOverallOutcome overallOutcome;

    /** Marks the assessor entered directly (out of maxMarks). Null = Absent. */
    private Integer marksObtained;

    /** Denominator for the mark; defaults to 100. */
    private Integer maxMarks;

    @Column(nullable = false)
    @Builder.Default
    private Boolean reassessmentRequired = false;

    private LocalDate publishedDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private TradeTestResultStatus status = TradeTestResultStatus.Draft;
}