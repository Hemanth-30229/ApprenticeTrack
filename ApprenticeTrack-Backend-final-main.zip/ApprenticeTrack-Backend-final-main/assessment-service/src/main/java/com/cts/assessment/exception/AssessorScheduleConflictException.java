package com.cts.assessment.exception;

public class AssessorScheduleConflictException extends RuntimeException {
    public AssessorScheduleConflictException(String message) {
        super(message);
    }
}
