package com.cts.assessment.exception;

/**
 * Thrown when the specified batch does not belong to the specified course.
 * Mapped to 400 Bad Request.
 */
public class BatchCourseMismatchException extends RuntimeException {
    public BatchCourseMismatchException(String message) {
        super(message);
    }
}
