package com.cts.assessment.exception;

/**
 * Thrown when revoking a certificate that is not in "Issued" status.
 * Mapped to 400 Bad Request.
 */
public class CertificateNotRevocableException extends RuntimeException {
    public CertificateNotRevocableException(String message) {
        super(message);
    }
}
