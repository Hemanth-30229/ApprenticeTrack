package com.cts.assessment.exception;

public class CompetencyUnitInUseException extends RuntimeException {
    public CompetencyUnitInUseException(String message) {
        super(message);
    }
}
