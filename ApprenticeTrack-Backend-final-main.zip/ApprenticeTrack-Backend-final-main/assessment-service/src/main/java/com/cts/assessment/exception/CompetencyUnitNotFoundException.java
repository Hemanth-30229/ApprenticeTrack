package com.cts.assessment.exception;

public class CompetencyUnitNotFoundException extends RuntimeException {
    public CompetencyUnitNotFoundException(String message) {
        super(message);
    }
}
