package com.cts.assessment.exception;

public class DuplicateCertificateException extends RuntimeException {
    public DuplicateCertificateException(String message) {
        super(message);
    }
}
