package com.cts.assessment.exception;

public class DuplicateCompetencyResultException extends RuntimeException {
    public DuplicateCompetencyResultException(String message) {
        super(message);
    }
}
