package com.cts.assessment.exception;

public class DuplicateTestAttemptException extends RuntimeException {
    public DuplicateTestAttemptException(String message) {
        super(message);
    }
}
