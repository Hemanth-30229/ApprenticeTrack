package com.cts.assessment.exception;

public class DuplicateTradeTestException extends RuntimeException {
    public DuplicateTradeTestException(String message) {
        super(message);
    }
}
