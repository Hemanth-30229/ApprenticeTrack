package com.cts.assessment.exception;

public class DuplicateUnitCodeException extends RuntimeException {
    public DuplicateUnitCodeException(String message) {
        super(message);
    }
}
