package com.cts.assessment.exception;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Centralized exception handling for assessment-service. Scoped to the exceptions this
 * service raises (competency units/results, trade tests/results, reassessments, assessors,
 * certificates) plus the cross-domain validation failures it reports when a Feign lookup
 * (trainee/course/batch/assessor) comes back empty. Response shape and status codes match
 * the monolith's for client compatibility.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    // 400 - Validation errors (field-level)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationErrors(MethodArgumentNotValidException ex) {
        Map<String, String> fieldErrors = new HashMap<>();
        ex.getBindingResult().getFieldErrors()
                .forEach(err -> fieldErrors.put(err.getField(), err.getDefaultMessage()));

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("status", HttpStatus.BAD_REQUEST.value());
        body.put("error", "Validation Failed");
        body.put("fieldErrors", fieldErrors);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }

    // 400 - Malformed / unreadable request body (e.g. invalid enum value)
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, Object>> handleUnreadableBody(HttpMessageNotReadableException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", "Malformed or invalid request body");
    }

    // 400 - Competency result validation failures
    @ExceptionHandler(TestNotConductedException.class)
    public ResponseEntity<Map<String, Object>> handleTestNotConducted(TestNotConductedException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    @ExceptionHandler(TraineeNotEnrolledException.class)
    public ResponseEntity<Map<String, Object>> handleTraineeNotEnrolled(TraineeNotEnrolledException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    @ExceptionHandler(UnitCourseMismatchException.class)
    public ResponseEntity<Map<String, Object>> handleUnitCourseMismatch(UnitCourseMismatchException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    @ExceptionHandler(InvalidMarksException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidMarks(InvalidMarksException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 400 - Invalid online-test question definition (e.g. MCQ without a valid correct option)
    @ExceptionHandler(InvalidTestQuestionException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidTestQuestion(InvalidTestQuestionException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 400 - Batch does not belong to the specified course
    @ExceptionHandler(BatchCourseMismatchException.class)
    public ResponseEntity<Map<String, Object>> handleBatchCourseMismatch(BatchCourseMismatchException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 400 - Referenced user is not a (valid) Assessor
    @ExceptionHandler(InvalidAssessorException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidAssessor(InvalidAssessorException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 400 - Invalid trade test status transition
    @ExceptionHandler(InvalidTradeTestStatusTransitionException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidTradeTestTransition(InvalidTradeTestStatusTransitionException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 400 - Publishing a non-Draft trade-test result
    @ExceptionHandler(ResultAlreadyPublishedException.class)
    public ResponseEntity<Map<String, Object>> handleResultAlreadyPublished(ResultAlreadyPublishedException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 400 - No passing published result for certificate generation
    @ExceptionHandler(NoPassingResultException.class)
    public ResponseEntity<Map<String, Object>> handleNoPassingResult(NoPassingResultException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 400 - Certificate not revocable (not in Issued status)
    @ExceptionHandler(CertificateNotRevocableException.class)
    public ResponseEntity<Map<String, Object>> handleCertificateNotRevocable(CertificateNotRevocableException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 400 - Trainee not eligible for reassessment
    @ExceptionHandler(ReassessmentNotEligibleException.class)
    public ResponseEntity<Map<String, Object>> handleReassessmentNotEligible(ReassessmentNotEligibleException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 400 - Reassessment date violates cooling period
    @ExceptionHandler(InvalidReassessmentDateException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidReassessmentDate(InvalidReassessmentDateException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 400 - Maximum reassessment attempts exceeded
    @ExceptionHandler(MaxReassessmentAttemptsException.class)
    public ResponseEntity<Map<String, Object>> handleMaxReassessmentAttempts(MaxReassessmentAttemptsException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 404 - Not found
    @ExceptionHandler(CompetencyUnitNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleCompetencyUnitNotFound(CompetencyUnitNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(TradeTestNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleTradeTestNotFound(TradeTestNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(TestQuestionNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleTestQuestionNotFound(TestQuestionNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(TestAttemptNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleTestAttemptNotFound(TestAttemptNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(TradeTestResultNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleTradeTestResultNotFound(TradeTestResultNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(ReassessmentNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleReassessmentNotFound(ReassessmentNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(CertificateNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleCertificateNotFound(CertificateNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(CourseNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleCourseNotFound(CourseNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(BatchNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleBatchNotFound(BatchNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(TraineeNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleTraineeNotFound(TraineeNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleUserNotFound(UserNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    // 403 - Spring Security authorization failure (@PreAuthorize / URL rules)
    @ExceptionHandler(org.springframework.security.access.AccessDeniedException.class)
    public ResponseEntity<Map<String, Object>> handleAccessDenied(
            org.springframework.security.access.AccessDeniedException ex) {
        return error(HttpStatus.FORBIDDEN, "Forbidden",
                "Access denied: you do not have permission to perform this action.");
    }

    // 409 - Conflicts
    @ExceptionHandler(DuplicateUnitCodeException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicateUnitCode(DuplicateUnitCodeException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(CompetencyUnitInUseException.class)
    public ResponseEntity<Map<String, Object>> handleCompetencyUnitInUse(CompetencyUnitInUseException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(DuplicateCompetencyResultException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicateCompetencyResult(DuplicateCompetencyResultException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(DuplicateTradeTestException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicateTradeTest(DuplicateTradeTestException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(DuplicateTestAttemptException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicateTestAttempt(DuplicateTestAttemptException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(TradeTestNotEditableException.class)
    public ResponseEntity<Map<String, Object>> handleTradeTestNotEditable(TradeTestNotEditableException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(AssessorScheduleConflictException.class)
    public ResponseEntity<Map<String, Object>> handleAssessorScheduleConflict(AssessorScheduleConflictException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(DuplicateCertificateException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicateCertificate(DuplicateCertificateException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    // 500 - Generic fallback
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGenericException(Exception ex) {
        return error(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error", ex.getMessage());
    }

    // ── helper ────────────────────────────────────────────────────────────────

    private ResponseEntity<Map<String, Object>> error(HttpStatus status, String error, String message) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("status", status.value());
        body.put("error", error);
        body.put("message", message);
        return ResponseEntity.status(status).body(body);
    }
}