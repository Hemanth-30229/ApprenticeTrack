package com.cts.assessment.exception;

/**
 * Thrown when the referenced AssessorID does not belong to a user with
 * Role = "Assessor". Mapped to 400 Bad Request.
 */
public class InvalidAssessorException extends RuntimeException {
    public InvalidAssessorException(String message) {
        super(message);
    }
}
