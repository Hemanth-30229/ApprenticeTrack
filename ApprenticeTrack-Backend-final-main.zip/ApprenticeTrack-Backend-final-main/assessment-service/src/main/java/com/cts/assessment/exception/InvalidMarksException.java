package com.cts.assessment.exception;

/**
 * Thrown when MarksObtained is outside the inclusive range [0, MaxMarks].
 * Mapped to 400 Bad Request.
 */
public class InvalidMarksException extends RuntimeException {
    public InvalidMarksException(String message) {
        super(message);
    }
}
