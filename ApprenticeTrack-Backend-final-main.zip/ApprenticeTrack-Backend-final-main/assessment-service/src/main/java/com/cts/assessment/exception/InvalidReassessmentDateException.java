package com.cts.assessment.exception;

public class InvalidReassessmentDateException extends RuntimeException {
    public InvalidReassessmentDateException(String message) {
        super(message);
    }
}
