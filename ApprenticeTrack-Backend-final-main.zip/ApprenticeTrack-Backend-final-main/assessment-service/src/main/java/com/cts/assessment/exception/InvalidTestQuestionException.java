package com.cts.assessment.exception;

public class InvalidTestQuestionException extends RuntimeException {
    public InvalidTestQuestionException(String message) {
        super(message);
    }
}
