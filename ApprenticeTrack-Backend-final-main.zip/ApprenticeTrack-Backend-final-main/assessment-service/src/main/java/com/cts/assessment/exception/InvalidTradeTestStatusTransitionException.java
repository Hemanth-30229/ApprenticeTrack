package com.cts.assessment.exception;

/**
 * Thrown when a trade test status change violates the allowed lifecycle
 * (Scheduled → Conducted → ResultsDeclared, or Scheduled → Cancelled).
 * Mapped to 400 Bad Request.
 */
public class InvalidTradeTestStatusTransitionException extends RuntimeException {
    public InvalidTradeTestStatusTransitionException(String message) {
        super(message);
    }
}
