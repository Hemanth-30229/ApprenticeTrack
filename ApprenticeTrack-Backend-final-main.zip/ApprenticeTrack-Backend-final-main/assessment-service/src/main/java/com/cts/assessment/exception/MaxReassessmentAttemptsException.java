package com.cts.assessment.exception;

public class MaxReassessmentAttemptsException extends RuntimeException {
    public MaxReassessmentAttemptsException(String message) {
        super(message);
    }
}
