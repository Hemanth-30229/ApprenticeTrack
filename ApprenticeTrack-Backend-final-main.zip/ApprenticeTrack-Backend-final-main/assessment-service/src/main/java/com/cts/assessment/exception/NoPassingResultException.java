package com.cts.assessment.exception;

/**
 * Thrown when a trainee has no published TradeTestResult with OverallOutcome =
 * "Pass" for the specified course. Mapped to 400 Bad Request.
 */
public class NoPassingResultException extends RuntimeException {
    public NoPassingResultException(String message) {
        super(message);
    }
}
