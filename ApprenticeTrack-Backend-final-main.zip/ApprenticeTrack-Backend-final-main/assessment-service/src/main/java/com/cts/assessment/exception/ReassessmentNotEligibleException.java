package com.cts.assessment.exception;

public class ReassessmentNotEligibleException extends RuntimeException {
    public ReassessmentNotEligibleException(String message) {
        super(message);
    }
}
