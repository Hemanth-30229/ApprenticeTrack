package com.cts.assessment.exception;

public class ReassessmentNotFoundException extends RuntimeException {
    public ReassessmentNotFoundException(String message) {
        super(message);
    }
}
