package com.cts.assessment.exception;

/**
 * Thrown when publishing a trade-test result that is not in "Draft" status.
 * Mapped to 400 Bad Request.
 */
public class ResultAlreadyPublishedException extends RuntimeException {
    public ResultAlreadyPublishedException(String message) {
        super(message);
    }
}
