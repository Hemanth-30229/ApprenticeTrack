package com.cts.assessment.exception;

public class TestAttemptNotFoundException extends RuntimeException {
    public TestAttemptNotFoundException(String message) {
        super(message);
    }
}
