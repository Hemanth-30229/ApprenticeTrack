package com.cts.assessment.exception;

/**
 * Thrown when a competency result targets a test that is not in "Conducted"
 * status. Mapped to 400 Bad Request.
 */
public class TestNotConductedException extends RuntimeException {
    public TestNotConductedException(String message) {
        super(message);
    }
}
