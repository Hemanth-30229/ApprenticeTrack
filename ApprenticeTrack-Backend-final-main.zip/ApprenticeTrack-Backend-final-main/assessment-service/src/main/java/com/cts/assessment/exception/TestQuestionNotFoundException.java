package com.cts.assessment.exception;

public class TestQuestionNotFoundException extends RuntimeException {
    public TestQuestionNotFoundException(String message) {
        super(message);
    }
}
