package com.cts.assessment.exception;

/**
 * Thrown when a trade test is edited while not in "Scheduled" status.
 * Mapped to 409 Conflict.
 */
public class TradeTestNotEditableException extends RuntimeException {
    public TradeTestNotEditableException(String message) {
        super(message);
    }
}
