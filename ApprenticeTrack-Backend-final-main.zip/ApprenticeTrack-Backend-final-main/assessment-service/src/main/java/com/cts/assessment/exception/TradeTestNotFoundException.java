package com.cts.assessment.exception;

public class TradeTestNotFoundException extends RuntimeException {
    public TradeTestNotFoundException(String message) {
        super(message);
    }
}
