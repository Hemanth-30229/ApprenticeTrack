package com.cts.assessment.exception;

public class TradeTestResultNotFoundException extends RuntimeException {
    public TradeTestResultNotFoundException(String message) {
        super(message);
    }
}
