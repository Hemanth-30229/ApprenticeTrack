package com.cts.assessment.exception;

/**
 * Thrown when a trainee is not enrolled in the batch linked to the test.
 * Mapped to 400 Bad Request.
 */
public class TraineeNotEnrolledException extends RuntimeException {
    public TraineeNotEnrolledException(String message) {
        super(message);
    }
}
