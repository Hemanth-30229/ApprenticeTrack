package com.cts.assessment.exception;

/**
 * Thrown when a competency unit does not belong to the course linked to the test.
 * Mapped to 400 Bad Request.
 */
public class UnitCourseMismatchException extends RuntimeException {
    public UnitCourseMismatchException(String message) {
        super(message);
    }
}
