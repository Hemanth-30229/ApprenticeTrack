package com.cts.assessment.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.assessment.entity.CompetencyResult;
import com.cts.assessment.common.CompetencyResultOutcome;

@Repository
public interface CompetencyResultRepository extends JpaRepository<CompetencyResult, Long> {

    boolean existsByTestIDAndTraineeIDAndUnitID(Long testID, Long traineeID, Long unitID);

    boolean existsByUnitID(Long unitID);

    List<CompetencyResult> findByTestIDAndTraineeID(Long testID, Long traineeID);

    long countByOutcome(CompetencyResultOutcome outcome);

    /**
     * Paginated filtering by TestID, TraineeID, UnitID, and Outcome.
     * All params optional — null means no filter applied.
     */
    @Query("SELECT r FROM CompetencyResult r WHERE " +
           "(:testID IS NULL OR r.testID = :testID) AND " +
           "(:traineeID IS NULL OR r.traineeID = :traineeID) AND " +
           "(:unitID IS NULL OR r.unitID = :unitID) AND " +
           "(:outcome IS NULL OR r.outcome = :outcome)")
    Page<CompetencyResult> findAllWithFilters(
            @Param("testID") Long testID,
            @Param("traineeID") Long traineeID,
            @Param("unitID") Long unitID,
            @Param("outcome") CompetencyResultOutcome outcome,
            Pageable pageable);
}