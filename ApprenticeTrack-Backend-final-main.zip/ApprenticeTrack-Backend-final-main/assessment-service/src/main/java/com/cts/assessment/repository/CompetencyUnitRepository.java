package com.cts.assessment.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.assessment.entity.CompetencyUnit;
import com.cts.assessment.common.CompetencyUnitStatus;

@Repository
public interface CompetencyUnitRepository extends JpaRepository<CompetencyUnit, Long> {

    boolean existsByCourseIDAndUnitCodeIgnoreCase(Long courseID, String unitCode);

    List<CompetencyUnit> findByCourseID(Long courseID);

    /**
     * Paginated list with optional courseID and status filters.
     */
    @Query("SELECT u FROM CompetencyUnit u WHERE " +
           "(:courseID IS NULL OR u.courseID = :courseID) AND " +
           "(:status IS NULL OR u.status = :status)")
    Page<CompetencyUnit> findAllWithFilters(
            @Param("courseID") Long courseID,
            @Param("status") CompetencyUnitStatus status,
            Pageable pageable);
}