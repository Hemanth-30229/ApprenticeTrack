package com.cts.assessment.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.assessment.entity.Reassessment;

@Repository
public interface ReassessmentRepository extends JpaRepository<Reassessment, Long> {

    List<Reassessment> findByTraineeIDAndOriginalTestIDOrderByAttemptNumberAsc(
            Long traineeID, Long originalTestID);

    long countByTraineeIDAndOriginalTestID(Long traineeID, Long originalTestID);

    /**
     * True when a reassessment is already scheduled and still pending (its result has not
     * yet been graded, i.e. {@code outcome} is null). Used to drop a trainee from the
     * reassessment-candidate list once a reassessment has been scheduled — they only
     * reappear if that reassessment is itself graded Fail/Absent.
     */
    boolean existsByTraineeIDAndOriginalTestIDAndOutcomeIsNull(Long traineeID, Long originalTestID);

    Optional<Reassessment> findByNewTestID(Long newTestID);
}