package com.cts.assessment.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.assessment.entity.TestAttempt;

@Repository
public interface TestAttemptRepository extends JpaRepository<TestAttempt, Long> {

    List<TestAttempt> findByTestIDOrderBySubmittedAtDesc(Long testID);

    List<TestAttempt> findByTestIDAndTraineeID(Long testID, Long traineeID);

    Optional<TestAttempt> findFirstByTestIDAndTraineeID(Long testID, Long traineeID);
}
