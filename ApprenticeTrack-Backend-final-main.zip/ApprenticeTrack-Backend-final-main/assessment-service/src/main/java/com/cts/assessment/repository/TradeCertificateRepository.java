package com.cts.assessment.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.assessment.common.QualificationLevel;
import com.cts.assessment.common.TradeCertificateStatus;
import com.cts.assessment.entity.TradeCertificate;

@Repository
public interface TradeCertificateRepository extends JpaRepository<TradeCertificate, Long> {

    boolean existsByTraineeIDAndCourseID(Long traineeID, Long courseID);

    long countByCourseID(Long courseID);

    /**
     * Paginated filtering by TraineeID, CourseID, QualificationLevel, and Status.
     * All params optional — null means no filter applied.
     */
    @Query("SELECT c FROM TradeCertificate c WHERE " +
           "(:traineeID IS NULL OR c.traineeID = :traineeID) AND " +
           "(:courseID IS NULL OR c.courseID = :courseID) AND " +
           "(:qualificationLevel IS NULL OR c.qualificationLevel = :qualificationLevel) AND " +
           "(:status IS NULL OR c.status = :status)")
    Page<TradeCertificate> findAllWithFilters(
            @Param("traineeID") Long traineeID,
            @Param("courseID") Long courseID,
            @Param("qualificationLevel") QualificationLevel qualificationLevel,
            @Param("status") TradeCertificateStatus status,
            Pageable pageable);
}