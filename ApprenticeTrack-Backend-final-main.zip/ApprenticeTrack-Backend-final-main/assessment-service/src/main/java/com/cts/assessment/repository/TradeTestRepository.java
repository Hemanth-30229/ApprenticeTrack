package com.cts.assessment.repository;

import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.assessment.entity.TradeTest;
import com.cts.assessment.common.TradeTestStatus;

@Repository
public interface TradeTestRepository extends JpaRepository<TradeTest, Long> {

    boolean existsByCourseIDAndBatchIDAndTestDate(Long courseID, Long batchID, LocalDate testDate);

    /** Workload: number of tests assigned to an assessor in a given status. */
    long countByAssessorIDAndStatus(Long assessorID, TradeTestStatus status);

    /**
     * Detects a scheduling conflict: another non-cancelled test assigned to the same
     * assessor on the same date, excluding the test being (re)assigned.
     */
    @Query("SELECT COUNT(t) FROM TradeTest t WHERE t.assessorID = :assessorID " +
           "AND t.testDate = :testDate AND t.status <> :cancelledStatus " +
           "AND (:excludeTestID IS NULL OR t.testID <> :excludeTestID)")
    long countScheduleConflicts(@Param("assessorID") Long assessorID,
                                @Param("testDate") LocalDate testDate,
                                @Param("cancelledStatus") TradeTestStatus cancelledStatus,
                                @Param("excludeTestID") Long excludeTestID);

    /**
     * Paginated filtering by CourseID, BatchID, AssessorID, Status, and TestDate range.
     * All params optional — null means no filter applied.
     */
    @Query("SELECT t FROM TradeTest t WHERE " +
           "(:courseID IS NULL OR t.courseID = :courseID) AND " +
           "(:batchID IS NULL OR t.batchID = :batchID) AND " +
           "(:assessorID IS NULL OR t.assessorID = :assessorID) AND " +
           "(:status IS NULL OR t.status = :status) AND " +
           "(:fromDate IS NULL OR t.testDate >= :fromDate) AND " +
           "(:toDate IS NULL OR t.testDate <= :toDate)")
    Page<TradeTest> findAllWithFilters(
            @Param("courseID") Long courseID,
            @Param("batchID") Long batchID,
            @Param("assessorID") Long assessorID,
            @Param("status") TradeTestStatus status,
            @Param("fromDate") LocalDate fromDate,
            @Param("toDate") LocalDate toDate,
            Pageable pageable);
}