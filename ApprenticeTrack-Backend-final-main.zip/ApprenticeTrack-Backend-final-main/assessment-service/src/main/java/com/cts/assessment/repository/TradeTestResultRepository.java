package com.cts.assessment.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.assessment.entity.TradeTestResult;
import com.cts.assessment.common.TradeTestResultOverallOutcome;
import com.cts.assessment.common.TradeTestResultStatus;

@Repository
public interface TradeTestResultRepository extends JpaRepository<TradeTestResult, Long> {

    Optional<TradeTestResult> findByTestIDAndTraineeID(Long testID, Long traineeID);

    List<TradeTestResult> findByTraineeIDAndOverallOutcomeAndStatus(
            Long traineeID, TradeTestResultOverallOutcome overallOutcome, TradeTestResultStatus status);

    List<TradeTestResult> findByReassessmentRequiredTrue();

    /**
     * Paginated filtering by TestID, TraineeID, OverallOutcome, ReassessmentRequired, and Status.
     * All params optional — null means no filter applied.
     */
    @Query("SELECT r FROM TradeTestResult r WHERE " +
           "(:testID IS NULL OR r.testID = :testID) AND " +
           "(:traineeID IS NULL OR r.traineeID = :traineeID) AND " +
           "(:overallOutcome IS NULL OR r.overallOutcome = :overallOutcome) AND " +
           "(:reassessmentRequired IS NULL OR r.reassessmentRequired = :reassessmentRequired) AND " +
           "(:status IS NULL OR r.status = :status)")
    Page<TradeTestResult> findAllWithFilters(
            @Param("testID") Long testID,
            @Param("traineeID") Long traineeID,
            @Param("overallOutcome") TradeTestResultOverallOutcome overallOutcome,
            @Param("reassessmentRequired") Boolean reassessmentRequired,
            @Param("status") TradeTestResultStatus status,
            Pageable pageable);
}