package com.cts.assessment.security;

/**
 * Authenticated principal reconstructed from the JWT issued by auth-service.
 * assessment-service does not own the user table, so the caller's identity comes
 * entirely from the trusted token claims (MIGRATION_PLAN.md §10 auth propagation).
 */
public record AuthUser(Long userID, String email, String role) {
}