package com.cts.assessment.service;

import java.util.List;

import com.cts.assessment.dto.AssessorAvailabilityDTO;

public interface AssessorService {

    /** Lists active, qualified assessors available for a course, with workload summary. */
    List<AssessorAvailabilityDTO> getAvailableAssessors(Long courseID);
}