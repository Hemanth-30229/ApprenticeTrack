package com.cts.assessment.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.assessment.client.AuthClient;
import com.cts.assessment.client.TrainingClient;
import com.cts.assessment.client.dto.UserContract;
import com.cts.assessment.common.TradeTestStatus;
import com.cts.assessment.dto.AssessorAvailabilityDTO;
import com.cts.assessment.exception.CourseNotFoundException;
import com.cts.assessment.repository.TradeTestRepository;

@Service
public class AssessorServiceImpl implements AssessorService {

    private static final String STATUS_ACTIVE = "Active";

    private final AuthClient authClient;
    private final TrainingClient trainingClient;
    private final TradeTestRepository tradeTestRepository;

    public AssessorServiceImpl(AuthClient authClient,
                               TrainingClient trainingClient,
                               TradeTestRepository tradeTestRepository) {
        this.authClient = authClient;
        this.trainingClient = trainingClient;
        this.tradeTestRepository = tradeTestRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<AssessorAvailabilityDTO> getAvailableAssessors(Long courseID) {
        if (trainingClient.getCourse(courseID) == null) {
            throw new CourseNotFoundException("Trade course not found with ID: " + courseID);
        }
        // Qualification is modelled as an active Assessor. (There is no course-specific
        // assessor-qualification mapping in the domain; all active assessors qualify.)
        return authClient.getActiveAssessors(STATUS_ACTIVE).stream()
                .map(this::toAvailabilityDTO)
                .collect(Collectors.toList());
    }

    private AssessorAvailabilityDTO toAvailabilityDTO(UserContract assessor) {
        long workload = tradeTestRepository.countByAssessorIDAndStatus(
                assessor.getUserID(), TradeTestStatus.Scheduled);
        return AssessorAvailabilityDTO.builder()
                .assessorID(assessor.getUserID())
                .name(assessor.getName())
                .email(assessor.getEmail())
                .status(assessor.getStatus())
                .scheduledTestCount(workload)
                .build();
    }
}