package com.cts.assessment.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.assessment.dto.CertificateGenerateRequestDTO;
import com.cts.assessment.dto.CertificateResponseDTO;
import com.cts.assessment.common.QualificationLevel;
import com.cts.assessment.common.TradeCertificateStatus;

public interface CertificateService {

    CertificateResponseDTO generate(CertificateGenerateRequestDTO dto, Long actorUserID);

    CertificateResponseDTO getById(Long certificateID);

    Page<CertificateResponseDTO> getCertificates(Long traineeID, Long courseID,
                                                 QualificationLevel qualificationLevel, TradeCertificateStatus status,
                                                 Pageable pageable);

    CertificateResponseDTO revoke(Long certificateID, String revocationReason, Long actorUserID);

    byte[] downloadPdf(Long certificateID);
}