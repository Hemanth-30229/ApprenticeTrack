package com.cts.assessment.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.assessment.client.AuthClient;
import com.cts.assessment.client.PlatformClient;
import com.cts.assessment.client.TrainingClient;
import com.cts.assessment.client.dto.AuditLogRequest;
import com.cts.assessment.client.dto.NotificationRequest;
import com.cts.assessment.client.dto.TradeCourseContract;
import com.cts.assessment.client.dto.TraineeContract;
import com.cts.assessment.client.dto.UserContract;
import com.cts.assessment.dto.CertificateGenerateRequestDTO;
import com.cts.assessment.dto.CertificateResponseDTO;
import com.cts.assessment.common.QualificationLevel;
import com.cts.assessment.common.TradeCertificateStatus;
import com.cts.assessment.common.TradeTestResultOverallOutcome;
import com.cts.assessment.common.TradeTestResultStatus;
import com.cts.assessment.entity.TradeCertificate;
import com.cts.assessment.entity.TradeTestResult;
import com.cts.assessment.exception.CertificateNotFoundException;
import com.cts.assessment.exception.CertificateNotRevocableException;
import com.cts.assessment.exception.CourseNotFoundException;
import com.cts.assessment.exception.DuplicateCertificateException;
import com.cts.assessment.exception.NoPassingResultException;
import com.cts.assessment.exception.TraineeNotFoundException;
import com.cts.assessment.repository.TradeCertificateRepository;
import com.cts.assessment.repository.TradeTestRepository;
import com.cts.assessment.repository.TradeTestResultRepository;

@Service
public class CertificateServiceImpl implements CertificateService {

    private static final String MODULE = "Certification";
    private static final String CATEGORY_CERTIFICATION = "Certification";

    private final TradeCertificateRepository certificateRepository;
    private final TradeTestResultRepository resultRepository;
    private final TradeTestRepository tradeTestRepository;
    private final TrainingClient trainingClient;
    private final AuthClient authClient;
    private final PlatformClient platformClient;

    public CertificateServiceImpl(TradeCertificateRepository certificateRepository,
                                  TradeTestResultRepository resultRepository,
                                  TradeTestRepository tradeTestRepository,
                                  TrainingClient trainingClient,
                                  AuthClient authClient,
                                  PlatformClient platformClient) {
        this.certificateRepository = certificateRepository;
        this.resultRepository = resultRepository;
        this.tradeTestRepository = tradeTestRepository;
        this.trainingClient = trainingClient;
        this.authClient = authClient;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional
    public CertificateResponseDTO generate(CertificateGenerateRequestDTO dto, Long actorUserID) {
        TraineeContract trainee = findTrainee(dto.getTraineeID());
        TradeCourseContract course = findCourse(dto.getCourseID());

        requirePassingResult(dto.getTraineeID(), dto.getCourseID());

        if (certificateRepository.existsByTraineeIDAndCourseID(dto.getTraineeID(), dto.getCourseID())) {
            throw new DuplicateCertificateException(
                    "A certificate already exists for TraineeID=" + dto.getTraineeID()
                    + ", CourseID=" + dto.getCourseID());
        }

        String certificateNumber = generateCertificateNumber(course);

        TradeCertificate certificate = TradeCertificate.builder()
                .traineeID(dto.getTraineeID())
                .courseID(dto.getCourseID())
                .certificateNumber(certificateNumber)
                .issuedDate(LocalDate.now())
                .qualificationLevel(QualificationLevel.valueOf(course.getQualificationLevel()))
                .issuedByID(actorUserID)
                .status(TradeCertificateStatus.Issued)
                .build();
        TradeCertificate saved = certificateRepository.save(certificate);

        audit(actorUserID, "CertificateGenerated: " + saved.getCertificateNumber()
                + ", TraineeID=" + saved.getTraineeID() + ", CourseID=" + saved.getCourseID()
                + " [CertificateID=" + saved.getCertificateID() + "]");

        platformClient.notify(new NotificationRequest("TRAINEE", saved.getTraineeID(),
                "Your trade certificate " + saved.getCertificateNumber() + " for "
                + course.getCourseName() + " has been issued.",
                CATEGORY_CERTIFICATION));

        return toResponseDTO(saved, trainee.getName(), course.getCourseName(), resolveUserName(actorUserID));
    }

    @Override
    @Transactional(readOnly = true)
    public CertificateResponseDTO getById(Long certificateID) {
        return toResponseDTO(findCertificate(certificateID));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<CertificateResponseDTO> getCertificates(Long traineeID, Long courseID,
                                                        QualificationLevel qualificationLevel, TradeCertificateStatus status,
                                                        Pageable pageable) {
        return certificateRepository
                .findAllWithFilters(traineeID, courseID, qualificationLevel, status, pageable)
                .map(this::toResponseDTO);
    }

    @Override
    @Transactional
    public CertificateResponseDTO revoke(Long certificateID, String revocationReason, Long actorUserID) {
        TradeCertificate certificate = findCertificate(certificateID);

        if (certificate.getStatus() != TradeCertificateStatus.Issued) {
            throw new CertificateNotRevocableException(
                    "Only Issued certificates can be revoked. Current status: "
                    + certificate.getStatus() + ". CertificateID: " + certificateID);
        }
        certificate.setStatus(TradeCertificateStatus.Revoked);
        certificate.setRevocationReason(revocationReason);
        certificateRepository.save(certificate);

        audit(actorUserID, "CertificateRevoked: " + certificate.getCertificateNumber()
                + ", reason=" + revocationReason + " [CertificateID=" + certificateID + "]");

        return toResponseDTO(certificate);
    }

    @Override
    @Transactional(readOnly = true)
    public byte[] downloadPdf(Long certificateID) {
        TradeCertificate c = findCertificate(certificateID);
        String traineeName = resolveTraineeName(c.getTraineeID());
        String courseName = resolveCourseName(c.getCourseID());
        String issuedByName = resolveUserName(c.getIssuedByID());

        List<String> lines = List.of(
                "TRADE CERTIFICATE",
                "",
                "Certificate Number : " + c.getCertificateNumber(),
                "Awarded To         : " + safe(traineeName),
                "Course             : " + safe(courseName),
                "Qualification Level: " + c.getQualificationLevel(),
                "Issued Date        : " + c.getIssuedDate(),
                "Issuing Authority  : " + safe(issuedByName),
                "Status             : " + c.getStatus());
        return SimplePdfWriter.singlePage(lines);
    }

    // ── Business rules ───────────────────────────────────────────────────────
    private void requirePassingResult(Long traineeID, Long courseID) {
        List<TradeTestResult> passes = resultRepository.findByTraineeIDAndOverallOutcomeAndStatus(
                traineeID, TradeTestResultOverallOutcome.Pass, TradeTestResultStatus.Published);
        boolean hasForCourse = passes.stream().anyMatch(r ->
                tradeTestRepository.findById(r.getTestID())
                        .map(t -> t.getCourseID().equals(courseID))
                        .orElse(false));
        if (!hasForCourse) {
            throw new NoPassingResultException(
                    "Trainee " + traineeID + " has no published passing trade-test result for course "
                    + courseID);
        }
    }

    private String generateCertificateNumber(TradeCourseContract course) {
        long sequence = certificateRepository.countByCourseID(course.getCourseID()) + 1;
        int year = LocalDate.now().getYear();
        return String.format("CERT-%s-%d-%04d", course.getTradeCode(), year, sequence);
    }

    // ── Lookups & mapping ────────────────────────────────────────────────────
    private TraineeContract findTrainee(Long traineeID) {
        TraineeContract trainee = trainingClient.getTrainee(traineeID);
        if (trainee == null) {
            throw new TraineeNotFoundException("Trainee not found with ID: " + traineeID);
        }
        return trainee;
    }

    private TradeCourseContract findCourse(Long courseID) {
        TradeCourseContract course = trainingClient.getCourse(courseID);
        if (course == null) {
            throw new CourseNotFoundException("Course not found with ID: " + courseID);
        }
        return course;
    }

    private TradeCertificate findCertificate(Long certificateID) {
        return certificateRepository.findById(certificateID)
                .orElseThrow(() -> new CertificateNotFoundException(
                        "Certificate not found with ID: " + certificateID));
    }

    private String resolveTraineeName(Long traineeID) {
        TraineeContract trainee = trainingClient.getTrainee(traineeID);
        return trainee == null ? null : trainee.getName();
    }

    private String resolveCourseName(Long courseID) {
        TradeCourseContract course = trainingClient.getCourse(courseID);
        return course == null ? null : course.getCourseName();
    }

    private String resolveUserName(Long userID) {
        UserContract user = authClient.getUser(userID);
        return user == null ? null : user.getName();
    }

    private void audit(Long userID, String action) {
        platformClient.recordAudit(new AuditLogRequest(userID, action, MODULE, null));
    }

    private String safe(String s) {
        return s == null ? "" : s;
    }

    private CertificateResponseDTO toResponseDTO(TradeCertificate c) {
        return toResponseDTO(c,
                resolveTraineeName(c.getTraineeID()),
                resolveCourseName(c.getCourseID()),
                resolveUserName(c.getIssuedByID()));
    }

    private CertificateResponseDTO toResponseDTO(TradeCertificate c, String traineeName,
                                                 String courseName, String issuedByName) {
        return CertificateResponseDTO.builder()
                .certificateID(c.getCertificateID())
                .traineeID(c.getTraineeID())
                .traineeName(traineeName)
                .courseID(c.getCourseID())
                .courseName(courseName)
                .certificateNumber(c.getCertificateNumber())
                .issuedDate(c.getIssuedDate())
                .qualificationLevel(c.getQualificationLevel())
                .issuedByID(c.getIssuedByID())
                .issuedByName(issuedByName)
                .revocationReason(c.getRevocationReason())
                .status(c.getStatus())
                .build();
    }
}