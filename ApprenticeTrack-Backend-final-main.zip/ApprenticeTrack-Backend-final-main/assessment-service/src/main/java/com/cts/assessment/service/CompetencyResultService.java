package com.cts.assessment.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.assessment.dto.BulkCompetencyResultResponseDTO;
import com.cts.assessment.dto.CompetencyResultCreateRequestDTO;
import com.cts.assessment.dto.CompetencyResultResponseDTO;
import com.cts.assessment.common.CompetencyResultOutcome;

public interface CompetencyResultService {

    CompetencyResultResponseDTO createResult(CompetencyResultCreateRequestDTO dto, Long assessorUserID);

    BulkCompetencyResultResponseDTO bulkCreate(List<CompetencyResultCreateRequestDTO> results, Long assessorUserID);

    Page<CompetencyResultResponseDTO> getResults(Long testID, Long traineeID, Long unitID,
                                                 CompetencyResultOutcome outcome, Pageable pageable);
}