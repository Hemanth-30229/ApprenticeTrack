package com.cts.assessment.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.assessment.client.PlatformClient;
import com.cts.assessment.client.TrainingClient;
import com.cts.assessment.client.dto.AuditLogRequest;
import com.cts.assessment.common.CompetencyResultOutcome;
import com.cts.assessment.common.TradeTestStatus;
import com.cts.assessment.dto.BulkCompetencyResultResponseDTO;
import com.cts.assessment.dto.CompetencyResultCreateRequestDTO;
import com.cts.assessment.dto.CompetencyResultResponseDTO;
import com.cts.assessment.entity.CompetencyResult;
import com.cts.assessment.entity.CompetencyUnit;
import com.cts.assessment.entity.TradeTest;
import com.cts.assessment.exception.CompetencyUnitNotFoundException;
import com.cts.assessment.exception.DuplicateCompetencyResultException;
import com.cts.assessment.exception.InvalidMarksException;
import com.cts.assessment.exception.TestNotConductedException;
import com.cts.assessment.exception.TradeTestNotFoundException;
import com.cts.assessment.exception.TraineeNotEnrolledException;
import com.cts.assessment.exception.UnitCourseMismatchException;
import com.cts.assessment.repository.CompetencyResultRepository;
import com.cts.assessment.repository.CompetencyUnitRepository;
import com.cts.assessment.repository.TradeTestRepository;

@Service
public class CompetencyResultServiceImpl implements CompetencyResultService {

    private static final String MODULE = "Assessment";

    private final CompetencyResultRepository resultRepository;
    private final TradeTestRepository tradeTestRepository;
    private final CompetencyUnitRepository unitRepository;
    private final TrainingClient trainingClient;
    private final PlatformClient platformClient;

    @Value("${assessment.pass-threshold-percent:60}")
    private double passThresholdPercent;

    public CompetencyResultServiceImpl(CompetencyResultRepository resultRepository,
                                       TradeTestRepository tradeTestRepository,
                                       CompetencyUnitRepository unitRepository,
                                       TrainingClient trainingClient,
                                       PlatformClient platformClient) {
        this.resultRepository = resultRepository;
        this.tradeTestRepository = tradeTestRepository;
        this.unitRepository = unitRepository;
        this.trainingClient = trainingClient;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional
    public CompetencyResultResponseDTO createResult(CompetencyResultCreateRequestDTO dto, Long assessorUserID) {
        CompetencyResult saved = doCreate(dto, assessorUserID);
        return toResponseDTO(saved);
    }

    @Override
    @Transactional
    public BulkCompetencyResultResponseDTO bulkCreate(List<CompetencyResultCreateRequestDTO> results,
                                                      Long assessorUserID) {
        BulkCompetencyResultResponseDTO response = new BulkCompetencyResultResponseDTO();
        response.setTotalRequested(results.size());

        for (int i = 0; i < results.size(); i++) {
            try {
                CompetencyResult saved = doCreate(results.get(i), assessorUserID);
                response.addCreated(toResponseDTO(saved));
            } catch (RuntimeException ex) {
                response.addFailed(i, ex.getMessage());
            }
        }
        return response;
    }

    @Override
    @Transactional(readOnly = true)
    public Page<CompetencyResultResponseDTO> getResults(Long testID, Long traineeID, Long unitID,
                                                        CompetencyResultOutcome outcome, Pageable pageable) {
        return resultRepository.findAllWithFilters(testID, traineeID, unitID, outcome, pageable)
                .map(this::toResponseDTO);
    }

    // ── Core ─────────────────────────────────────────────────────────────────
    private CompetencyResult doCreate(CompetencyResultCreateRequestDTO dto, Long assessorUserID) {
        TradeTest test = tradeTestRepository.findById(dto.getTestID())
                .orElseThrow(() -> new TradeTestNotFoundException("Trade test not found with ID: " + dto.getTestID()));
        if (test.getStatus() != TradeTestStatus.Conducted) {
            throw new TestNotConductedException(
                    "Results can only be entered for tests in 'Conducted' status. Current status: "
                    + test.getStatus() + ". TestID: " + dto.getTestID());
        }

        // Enrollment ownership lives in training-service; verify via Feign.
        if (!Boolean.TRUE.equals(trainingClient.isTraineeEnrolledInBatch(dto.getTraineeID(), test.getBatchID()))) {
            throw new TraineeNotEnrolledException(
                    "Trainee " + dto.getTraineeID() + " is not enrolled in batch " + test.getBatchID()
                    + " linked to the test.");
        }

        CompetencyUnit unit = unitRepository.findById(dto.getUnitID())
                .orElseThrow(() -> new CompetencyUnitNotFoundException(
                        "Competency unit not found with ID: " + dto.getUnitID()));
        if (!unit.getCourseID().equals(test.getCourseID())) {
            throw new UnitCourseMismatchException(
                    "Unit " + dto.getUnitID() + " does not belong to course " + test.getCourseID()
                    + " linked to the test.");
        }

        if (dto.getMarksObtained() > dto.getMaxMarks()) {
            throw new InvalidMarksException(
                    "MarksObtained (" + dto.getMarksObtained() + ") must be between 0 and MaxMarks ("
                    + dto.getMaxMarks() + ") inclusive.");
        }

        if (resultRepository.existsByTestIDAndTraineeIDAndUnitID(
                dto.getTestID(), dto.getTraineeID(), dto.getUnitID())) {
            throw new DuplicateCompetencyResultException(
                    "A result already exists for TestID=" + dto.getTestID()
                    + ", TraineeID=" + dto.getTraineeID() + ", UnitID=" + dto.getUnitID());
        }

        CompetencyResultOutcome outcome = computeOutcome(dto.getMarksObtained(), dto.getMaxMarks());

        CompetencyResult result = CompetencyResult.builder()
                .testID(dto.getTestID())
                .traineeID(dto.getTraineeID())
                .unitID(dto.getUnitID())
                .assessmentMethod(dto.getAssessmentMethod())
                .marksObtained(dto.getMarksObtained())
                .maxMarks(dto.getMaxMarks())
                .outcome(outcome)
                .assessedByID(assessorUserID)
                .assessmentDate(LocalDate.now())
                .build();
        CompetencyResult saved = resultRepository.save(result);

        platformClient.recordAudit(new AuditLogRequest(assessorUserID, "CompetencyResultEntered", MODULE,
                "Assessment result submitted. ResultID=" + saved.getResultID()
                + ", TestID=" + saved.getTestID() + ", TraineeID=" + saved.getTraineeID()
                + ", UnitID=" + saved.getUnitID() + ", Outcome=" + saved.getOutcome()));

        return saved;
    }

    private CompetencyResultOutcome computeOutcome(double marksObtained, double maxMarks) {
        double passMark = maxMarks * passThresholdPercent / 100.0;
        return marksObtained >= passMark ? CompetencyResultOutcome.Competent : CompetencyResultOutcome.NotYetCompetent;
    }

    // ── Mapping ──────────────────────────────────────────────────────────────
    private CompetencyResultResponseDTO toResponseDTO(CompetencyResult r) {
        return CompetencyResultResponseDTO.builder()
                .resultID(r.getResultID())
                .testID(r.getTestID())
                .traineeID(r.getTraineeID())
                .unitID(r.getUnitID())
                .assessmentMethod(r.getAssessmentMethod())
                .marksObtained(r.getMarksObtained())
                .maxMarks(r.getMaxMarks())
                .outcome(r.getOutcome())
                .assessedByID(r.getAssessedByID())
                .assessmentDate(r.getAssessmentDate())
                .build();
    }
}