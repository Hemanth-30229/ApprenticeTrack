package com.cts.assessment.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.assessment.dto.CompetencyUnitCreateRequestDTO;
import com.cts.assessment.dto.CompetencyUnitResponseDTO;
import com.cts.assessment.dto.CompetencyUnitUpdateRequestDTO;
import com.cts.assessment.common.CompetencyUnitStatus;

public interface CompetencyUnitService {

    CompetencyUnitResponseDTO createUnit(CompetencyUnitCreateRequestDTO requestDTO);

    CompetencyUnitResponseDTO getUnitById(Long unitID);

    CompetencyUnitResponseDTO updateUnit(Long unitID, CompetencyUnitUpdateRequestDTO requestDTO);

    void deleteUnit(Long unitID);

    Page<CompetencyUnitResponseDTO> getAllUnits(Long courseID, CompetencyUnitStatus status, Pageable pageable);

    List<CompetencyUnitResponseDTO> getUnitsByCourse(Long courseID);
}