package com.cts.assessment.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.assessment.client.PlatformClient;
import com.cts.assessment.client.TrainingClient;
import com.cts.assessment.client.dto.AuditLogRequest;
import com.cts.assessment.dto.CompetencyUnitCreateRequestDTO;
import com.cts.assessment.dto.CompetencyUnitResponseDTO;
import com.cts.assessment.dto.CompetencyUnitUpdateRequestDTO;
import com.cts.assessment.common.CompetencyUnitStatus;
import com.cts.assessment.entity.CompetencyUnit;
import com.cts.assessment.exception.CompetencyUnitInUseException;
import com.cts.assessment.exception.CompetencyUnitNotFoundException;
import com.cts.assessment.exception.CourseNotFoundException;
import com.cts.assessment.exception.DuplicateUnitCodeException;
import com.cts.assessment.repository.CompetencyResultRepository;
import com.cts.assessment.repository.CompetencyUnitRepository;

@Service
public class CompetencyUnitServiceImpl implements CompetencyUnitService {

    private static final String MODULE = "CompetencyUnit";

    private final CompetencyUnitRepository unitRepository;
    private final CompetencyResultRepository resultRepository;
    private final TrainingClient trainingClient;
    private final PlatformClient platformClient;

    public CompetencyUnitServiceImpl(CompetencyUnitRepository unitRepository,
                                     CompetencyResultRepository resultRepository,
                                     TrainingClient trainingClient,
                                     PlatformClient platformClient) {
        this.unitRepository = unitRepository;
        this.resultRepository = resultRepository;
        this.trainingClient = trainingClient;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional
    public CompetencyUnitResponseDTO createUnit(CompetencyUnitCreateRequestDTO dto) {
        ensureCourseExists(dto.getCourseID());
        if (unitRepository.existsByCourseIDAndUnitCodeIgnoreCase(dto.getCourseID(), dto.getUnitCode())) {
            throw new DuplicateUnitCodeException(
                    "Unit code '" + dto.getUnitCode() + "' already exists in course " + dto.getCourseID());
        }
        CompetencyUnit unit = CompetencyUnit.builder()
                .courseID(dto.getCourseID())
                .unitName(dto.getUnitName())
                .unitCode(dto.getUnitCode())
                .performanceCriteria(dto.getPerformanceCriteria())
                .evidenceRequired(dto.getEvidenceRequired())
                .assessmentMethod(dto.getAssessmentMethod())
                .status(CompetencyUnitStatus.Active)
                .build();
        CompetencyUnit saved = unitRepository.save(unit);
        audit("CompetencyUnitCreated: " + saved.getUnitCode() + " [CourseID=" + saved.getCourseID() + "]");
        return toResponseDTO(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public CompetencyUnitResponseDTO getUnitById(Long unitID) {
        return toResponseDTO(findUnit(unitID));
    }

    @Override
    @Transactional
    public CompetencyUnitResponseDTO updateUnit(Long unitID, CompetencyUnitUpdateRequestDTO dto) {
        CompetencyUnit unit = findUnit(unitID);
        if (!unit.getUnitCode().equalsIgnoreCase(dto.getUnitCode())
                && unitRepository.existsByCourseIDAndUnitCodeIgnoreCase(unit.getCourseID(), dto.getUnitCode())) {
            throw new DuplicateUnitCodeException(
                    "Unit code '" + dto.getUnitCode() + "' already exists in course " + unit.getCourseID());
        }
        unit.setUnitName(dto.getUnitName());
        unit.setUnitCode(dto.getUnitCode());
        unit.setPerformanceCriteria(dto.getPerformanceCriteria());
        unit.setEvidenceRequired(dto.getEvidenceRequired());
        unit.setAssessmentMethod(dto.getAssessmentMethod());
        unit.setStatus(dto.getStatus());
        CompetencyUnit updated = unitRepository.save(unit);
        audit("CompetencyUnitUpdated: " + updated.getUnitCode());
        return toResponseDTO(updated);
    }

    @Override
    @Transactional
    public void deleteUnit(Long unitID) {
        CompetencyUnit unit = findUnit(unitID);
        if (resultRepository.existsByUnitID(unitID)) {
            throw new CompetencyUnitInUseException(
                    "Competency unit '" + unit.getUnitCode()
                    + "' cannot be deleted while linked to assessment results.");
        }
        unitRepository.delete(unit);
        audit("CompetencyUnitDeleted: " + unit.getUnitCode());
    }

    @Override
    @Transactional(readOnly = true)
    public Page<CompetencyUnitResponseDTO> getAllUnits(Long courseID, CompetencyUnitStatus status, Pageable pageable) {
        return unitRepository.findAllWithFilters(courseID, status, pageable)
                .map(this::toResponseDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CompetencyUnitResponseDTO> getUnitsByCourse(Long courseID) {
        ensureCourseExists(courseID);
        return unitRepository.findByCourseID(courseID).stream()
                .map(this::toResponseDTO).collect(Collectors.toList());
    }

    // ── Helpers ─────────────────────────────────────────────────────────────

    /** Course ownership lives in training-service; verify via Feign instead of a local FK. */
    private void ensureCourseExists(Long courseID) {
        if (trainingClient.getCourse(courseID) == null) {
            throw new CourseNotFoundException("Trade course not found with ID: " + courseID);
        }
    }

    private CompetencyUnit findUnit(Long unitID) {
        return unitRepository.findById(unitID)
                .orElseThrow(() -> new CompetencyUnitNotFoundException(
                        "Competency unit not found with ID: " + unitID));
    }

    private void audit(String action) {
        // Master-data changes are system-attributed (userID=0), matching the monolith.
        platformClient.recordAudit(new AuditLogRequest(0L, action, MODULE, null));
    }

    private CompetencyUnitResponseDTO toResponseDTO(CompetencyUnit u) {
        return CompetencyUnitResponseDTO.builder()
                .unitID(u.getUnitID())
                .courseID(u.getCourseID())
                .unitName(u.getUnitName())
                .unitCode(u.getUnitCode())
                .performanceCriteria(u.getPerformanceCriteria())
                .evidenceRequired(u.getEvidenceRequired())
                .assessmentMethod(u.getAssessmentMethod())
                .status(u.getStatus())
                .build();
    }
}