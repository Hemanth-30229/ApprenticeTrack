package com.cts.assessment.service;

import java.util.List;

import com.cts.assessment.dto.ReassessmentCandidateDTO;
import com.cts.assessment.dto.ReassessmentHistoryDTO;
import com.cts.assessment.dto.ReassessmentResponseDTO;
import com.cts.assessment.dto.ReassessmentScheduleRequestDTO;

public interface ReassessmentService {

    /** Trainees flagged for reassessment, optionally filtered by course and batch. */
    List<ReassessmentCandidateDTO> getCandidates(Long courseID, Long batchID);

    /** Schedules a reassessment attempt, creating a new linked trade test. */
    ReassessmentResponseDTO schedule(ReassessmentScheduleRequestDTO requestDTO, Long actorUserID);

    /** Full reassessment history for the trainee-test combination of a reassessment. */
    ReassessmentHistoryDTO getHistory(Long reassessmentID);

    /**
     * Recalculates the reassessment test's outcome from its submitted competency results,
     * updating ReassessmentRequired and, on a pass, the trainee's course enrollment.
     */
    ReassessmentResponseDTO recalculate(Long reassessmentID, Long actorUserID);
}