package com.cts.assessment.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.assessment.client.PlatformClient;
import com.cts.assessment.client.TrainingClient;
import com.cts.assessment.client.dto.AuditLogRequest;
import com.cts.assessment.client.dto.NotificationRequest;
import com.cts.assessment.client.dto.TraineeContract;
import com.cts.assessment.dto.CompetencyResultResponseDTO;
import com.cts.assessment.dto.ReassessmentAttemptDTO;
import com.cts.assessment.dto.ReassessmentCandidateDTO;
import com.cts.assessment.dto.ReassessmentHistoryDTO;
import com.cts.assessment.dto.ReassessmentResponseDTO;
import com.cts.assessment.dto.ReassessmentScheduleRequestDTO;
import com.cts.assessment.common.CompetencyResultOutcome;
import com.cts.assessment.common.TradeTestResultOverallOutcome;
import com.cts.assessment.common.TradeTestResultStatus;
import com.cts.assessment.common.TradeTestStatus;
import com.cts.assessment.entity.CompetencyResult;
import com.cts.assessment.entity.Reassessment;
import com.cts.assessment.entity.TradeTest;
import com.cts.assessment.entity.TradeTestResult;
import com.cts.assessment.exception.InvalidReassessmentDateException;
import com.cts.assessment.exception.MaxReassessmentAttemptsException;
import com.cts.assessment.exception.ReassessmentNotEligibleException;
import com.cts.assessment.exception.ReassessmentNotFoundException;
import com.cts.assessment.exception.TradeTestNotFoundException;
import com.cts.assessment.repository.CompetencyResultRepository;
import com.cts.assessment.repository.ReassessmentRepository;
import com.cts.assessment.repository.TradeTestRepository;
import com.cts.assessment.repository.TradeTestResultRepository;

@Service
public class ReassessmentServiceImpl implements ReassessmentService {

    private static final String MODULE = "Assessment";
    private static final String CATEGORY_ASSESSMENT = "Assessment";
    private static final int MAX_ATTEMPTS = 3;
    private static final int COOLING_PERIOD_DAYS = 7;

    private final ReassessmentRepository reassessmentRepository;
    private final TradeTestRepository tradeTestRepository;
    private final TradeTestResultRepository resultRepository;
    private final CompetencyResultRepository competencyResultRepository;
    private final TrainingClient trainingClient;
    private final PlatformClient platformClient;

    public ReassessmentServiceImpl(ReassessmentRepository reassessmentRepository,
                                   TradeTestRepository tradeTestRepository,
                                   TradeTestResultRepository resultRepository,
                                   CompetencyResultRepository competencyResultRepository,
                                   TrainingClient trainingClient,
                                   PlatformClient platformClient) {
        this.reassessmentRepository = reassessmentRepository;
        this.tradeTestRepository = tradeTestRepository;
        this.resultRepository = resultRepository;
        this.competencyResultRepository = competencyResultRepository;
        this.trainingClient = trainingClient;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReassessmentCandidateDTO> getCandidates(Long courseID, Long batchID) {
        List<ReassessmentCandidateDTO> candidates = new ArrayList<>();
        for (TradeTestResult result : resultRepository.findByReassessmentRequiredTrue()) {
            TradeTest test = tradeTestRepository.findById(result.getTestID()).orElse(null);
            if (test == null) {
                continue;
            }
            if (courseID != null && !courseID.equals(test.getCourseID())) {
                continue;
            }
            if (batchID != null && !batchID.equals(test.getBatchID())) {
                continue;
            }
            Long originalTestID = test.getParentTestID() != null ? test.getParentTestID() : test.getTestID();
            // Drop the trainee once a reassessment is already scheduled and still pending
            // (outcome not yet graded). They reappear only if that reassessment is itself
            // graded Fail/Absent, or drop off permanently on a Pass (which clears the flag).
            if (reassessmentRepository
                    .existsByTraineeIDAndOriginalTestIDAndOutcomeIsNull(result.getTraineeID(), originalTestID)) {
                continue;
            }
            long count = reassessmentRepository
                    .countByTraineeIDAndOriginalTestID(result.getTraineeID(), originalTestID);
            candidates.add(ReassessmentCandidateDTO.builder()
                    .traineeID(result.getTraineeID())
                    .traineeName(resolveTraineeName(result.getTraineeID()))
                    .originalTestID(originalTestID)
                    .courseID(test.getCourseID())
                    .batchID(test.getBatchID())
                    .originalTestDate(resolveTestDate(originalTestID))
                    .overallOutcome(result.getOverallOutcome())
                    .reassessmentCount(count)
                    .build());
        }
        return candidates;
    }

    @Override
    @Transactional
    public ReassessmentResponseDTO schedule(ReassessmentScheduleRequestDTO dto, Long actorUserID) {
        TradeTest originalTest = findTest(dto.getOriginalTestID());

        // Eligibility: a Fail result flagged for reassessment must exist for the trainee.
        TradeTestResult result = resultRepository
                .findByTestIDAndTraineeID(dto.getOriginalTestID(), dto.getTraineeID())
                .orElseThrow(() -> new ReassessmentNotEligibleException(
                        "Trainee " + dto.getTraineeID() + " has no result for test " + dto.getOriginalTestID()
                        + " and is not eligible for reassessment."));
        // Eligible outcomes: a failed trainee, or one who was absent for the original test.
        boolean eligibleOutcome = result.getOverallOutcome() == TradeTestResultOverallOutcome.Fail
                || result.getOverallOutcome() == TradeTestResultOverallOutcome.Absent;
        if (!eligibleOutcome || !Boolean.TRUE.equals(result.getReassessmentRequired())) {
            throw new ReassessmentNotEligibleException(
                    "Trainee " + dto.getTraineeID() + " is not eligible for reassessment on test "
                    + dto.getOriginalTestID() + " (outcome=" + result.getOverallOutcome()
                    + ", reassessmentRequired=" + result.getReassessmentRequired() + ").");
        }

        // Cooling period: new date must be >= 7 days after the original test date.
        LocalDate earliest = originalTest.getTestDate().plusDays(COOLING_PERIOD_DAYS);
        if (dto.getNewTestDate().isBefore(earliest)) {
            throw new InvalidReassessmentDateException(
                    "New test date must be at least " + COOLING_PERIOD_DAYS
                    + " days after the original test date (" + originalTest.getTestDate()
                    + "). Earliest allowed: " + earliest + ".");
        }

        // Maximum 3 attempts per trainee per trade test.
        long attempts = reassessmentRepository
                .countByTraineeIDAndOriginalTestID(dto.getTraineeID(), dto.getOriginalTestID());
        if (attempts >= MAX_ATTEMPTS) {
            throw new MaxReassessmentAttemptsException("Maximum reassessment attempts exceeded");
        }

        // Create the new trade test linked to the original via parentTestID.
        TradeTest newTest = tradeTestRepository.save(TradeTest.builder()
                .courseID(originalTest.getCourseID())
                .batchID(originalTest.getBatchID())
                .assessorID(dto.getAssessorID())
                .testDate(dto.getNewTestDate())
                .venueID(dto.getVenueID())
                .parentTestID(dto.getOriginalTestID())
                .status(TradeTestStatus.Scheduled)
                .build());

        Reassessment reassessment = reassessmentRepository.save(Reassessment.builder()
                .traineeID(dto.getTraineeID())
                .originalTestID(dto.getOriginalTestID())
                .newTestID(newTest.getTestID())
                .assessorID(dto.getAssessorID())
                .venueID(dto.getVenueID())
                .scheduledDate(dto.getNewTestDate())
                .attemptNumber((int) attempts + 1)
                .build());

        audit(actorUserID, "ReassessmentScheduled: TraineeID=" + dto.getTraineeID()
                + ", OriginalTestID=" + dto.getOriginalTestID() + ", NewTestID=" + newTest.getTestID()
                + ", Attempt=" + reassessment.getAttemptNumber());

        notifyTrainee(dto.getTraineeID(),
                "A reassessment (attempt " + reassessment.getAttemptNumber() + ") has been scheduled for "
                + dto.getNewTestDate() + ".");
        notifyUser(dto.getAssessorID(),
                "You have been assigned to reassessment test #" + newTest.getTestID()
                + " on " + dto.getNewTestDate() + ".");

        return toResponseDTO(reassessment);
    }

    @Override
    @Transactional(readOnly = true)
    public ReassessmentHistoryDTO getHistory(Long reassessmentID) {
        Reassessment reassessment = findReassessment(reassessmentID);
        Long traineeID = reassessment.getTraineeID();
        Long originalTestID = reassessment.getOriginalTestID();

        List<ReassessmentAttemptDTO> attempts = new ArrayList<>();
        // Attempt 0 = the original test.
        attempts.add(buildAttempt(0, originalTestID, traineeID));
        // Subsequent reassessment attempts in order.
        for (Reassessment r : reassessmentRepository
                .findByTraineeIDAndOriginalTestIDOrderByAttemptNumberAsc(traineeID, originalTestID)) {
            attempts.add(buildAttempt(r.getAttemptNumber(), r.getNewTestID(), traineeID));
        }

        long total = reassessmentRepository.countByTraineeIDAndOriginalTestID(traineeID, originalTestID);
        return ReassessmentHistoryDTO.builder()
                .traineeID(traineeID)
                .traineeName(resolveTraineeName(traineeID))
                .originalTestID(originalTestID)
                .totalAttempts(total)
                .attempts(attempts)
                .build();
    }

    @Override
    @Transactional
    public ReassessmentResponseDTO recalculate(Long reassessmentID, Long actorUserID) {
        Reassessment reassessment = findReassessment(reassessmentID);
        TradeTest newTest = findTest(reassessment.getNewTestID());
        Long traineeID = reassessment.getTraineeID();

        TradeTestResultOverallOutcome outcome = computeOutcome(reassessment.getNewTestID(), traineeID);

        // Upsert the reassessment test's result.
        TradeTestResult newResult = resultRepository
                .findByTestIDAndTraineeID(reassessment.getNewTestID(), traineeID)
                .orElseGet(() -> TradeTestResult.builder()
                        .testID(reassessment.getNewTestID())
                        .traineeID(traineeID)
                        .status(TradeTestResultStatus.Draft)
                        .build());
        newResult.setOverallOutcome(outcome);
        // Still failed or absent on the reassessment -> another attempt is required.
        newResult.setReassessmentRequired(outcome == TradeTestResultOverallOutcome.Fail
                || outcome == TradeTestResultOverallOutcome.Absent);
        resultRepository.save(newResult);

        reassessment.setOutcome(outcome);
        reassessmentRepository.save(reassessment);

        if (outcome == TradeTestResultOverallOutcome.Pass) {
            // Clear reassessment flag on the original result so the trainee drops off the list.
            resultRepository.findByTestIDAndTraineeID(reassessment.getOriginalTestID(), traineeID)
                    .ifPresent(original -> {
                        original.setReassessmentRequired(false);
                        resultRepository.save(original);
                    });
            // Enrollment completion is owned by training-service (cross-service write via Feign).
            trainingClient.completeEnrollment(traineeID, newTest.getCourseID());
        }

        audit(actorUserID, "ReassessmentRecalculated: ReassessmentID=" + reassessmentID
                + ", NewTestID=" + reassessment.getNewTestID() + ", Outcome=" + outcome);

        notifyTrainee(traineeID,
                "Your reassessment result has been recorded. Outcome: " + outcome + ".");

        return toResponseDTO(reassessment);
    }

    // ── Helpers ─────────────────────────────────────────────────────────────

    private TradeTestResultOverallOutcome computeOutcome(Long testID, Long traineeID) {
        // Results are now entered directly per trainee (POST /api/trade-test-results/enter),
        // so the reassessment test's outcome is simply the outcome recorded on its result.
        // No result entered yet => the trainee did not attend => Absent.
        return resultRepository.findByTestIDAndTraineeID(testID, traineeID)
                .map(TradeTestResult::getOverallOutcome)
                .orElse(TradeTestResultOverallOutcome.Absent);
    }

    private ReassessmentAttemptDTO buildAttempt(int attemptNumber, Long testID, Long traineeID) {
        LocalDate testDate = resolveTestDate(testID);
        TradeTestResultOverallOutcome outcome = resultRepository.findByTestIDAndTraineeID(testID, traineeID)
                .map(TradeTestResult::getOverallOutcome).orElse(null);
        List<CompetencyResultResponseDTO> scores =
                competencyResultRepository.findByTestIDAndTraineeID(testID, traineeID).stream()
                        .map(this::toCompetencyDTO).collect(Collectors.toList());
        return ReassessmentAttemptDTO.builder()
                .attemptNumber(attemptNumber)
                .testID(testID)
                .testDate(testDate)
                .outcome(outcome)
                .unitScores(scores)
                .build();
    }

    private TradeTest findTest(Long testID) {
        return tradeTestRepository.findById(testID)
                .orElseThrow(() -> new TradeTestNotFoundException("Trade test not found with ID: " + testID));
    }

    private Reassessment findReassessment(Long id) {
        return reassessmentRepository.findById(id)
                .orElseThrow(() -> new ReassessmentNotFoundException("Reassessment not found with ID: " + id));
    }

    private String resolveTraineeName(Long traineeID) {
        TraineeContract trainee = trainingClient.getTrainee(traineeID);
        return trainee == null ? null : trainee.getName();
    }

    private LocalDate resolveTestDate(Long testID) {
        return tradeTestRepository.findById(testID).map(TradeTest::getTestDate).orElse(null);
    }

    private void audit(Long userID, String action) {
        platformClient.recordAudit(new AuditLogRequest(userID, action, MODULE, null));
    }

    private void notifyUser(Long userID, String message) {
        platformClient.notify(new NotificationRequest("USER", userID, message, CATEGORY_ASSESSMENT));
    }

    /**
     * Notify a trainee. The trainee is resolved to its linked user here — on the
     * authenticated request thread — and sent a direct USER notification. Sending a
     * "TRAINEE" notification instead made platform-service resolve the traineeID via
     * getTrainee on an async worker thread, where the call was failing and the
     * trainee's notification was being silently dropped.
     */
    private void notifyTrainee(Long traineeID, String message) {
        TraineeContract trainee = trainingClient.getTrainee(traineeID);
        if (trainee == null || trainee.getUserID() == null) {
            return;
        }
        notifyUser(trainee.getUserID(), message);
    }

    private ReassessmentResponseDTO toResponseDTO(Reassessment r) {
        return ReassessmentResponseDTO.builder()
                .reassessmentID(r.getReassessmentID())
                .traineeID(r.getTraineeID())
                .originalTestID(r.getOriginalTestID())
                .newTestID(r.getNewTestID())
                .assessorID(r.getAssessorID())
                .venueID(r.getVenueID())
                .scheduledDate(r.getScheduledDate())
                .attemptNumber(r.getAttemptNumber())
                .outcome(r.getOutcome())
                .build();
    }

    private CompetencyResultResponseDTO toCompetencyDTO(CompetencyResult r) {
        return CompetencyResultResponseDTO.builder()
                .resultID(r.getResultID())
                .testID(r.getTestID())
                .traineeID(r.getTraineeID())
                .unitID(r.getUnitID())
                .assessmentMethod(r.getAssessmentMethod())
                .marksObtained(r.getMarksObtained())
                .maxMarks(r.getMaxMarks())
                .outcome(r.getOutcome())
                .assessedByID(r.getAssessedByID())
                .assessmentDate(r.getAssessmentDate())
                .build();
    }
}