package com.cts.assessment.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Minimal, dependency-free PDF writer. Emits a single-page PDF (Helvetica) that
 * renders the supplied lines top-to-bottom. Sufficient for a plain certificate
 * document; not a general-purpose PDF library.
 */
final class SimplePdfWriter {

    private SimplePdfWriter() {}

    static byte[] singlePage(List<String> lines) {
        StringBuilder content = new StringBuilder();
        content.append("BT\n/F1 16 Tf\n72 720 Td\n18 TL\n");
        for (String raw : lines) {
            content.append('(').append(escape(raw)).append(") Tj\nT*\n");
        }
        content.append("ET");
        byte[] stream = content.toString().getBytes(StandardCharsets.ISO_8859_1);

        List<String> objects = new ArrayList<>();
        objects.add("<< /Type /Catalog /Pages 2 0 R >>");
        objects.add("<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
        objects.add("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
                + "/Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>");
        objects.add("<< /Length " + stream.length + " >>\nstream\n"
                + new String(stream, StandardCharsets.ISO_8859_1) + "\nendstream");
        objects.add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        List<Integer> offsets = new ArrayList<>();
        try {
            byte[] header = "%PDF-1.4\n".getBytes(StandardCharsets.ISO_8859_1);
            out.write(header);
            int offset = header.length;

            for (int i = 0; i < objects.size(); i++) {
                offsets.add(offset);
                String obj = (i + 1) + " 0 obj\n" + objects.get(i) + "\nendobj\n";
                byte[] bytes = obj.getBytes(StandardCharsets.ISO_8859_1);
                out.write(bytes);
                offset += bytes.length;
            }

            int xrefStart = offset;
            StringBuilder xref = new StringBuilder();
            xref.append("xref\n0 ").append(objects.size() + 1).append('\n');
            xref.append("0000000000 65535 f \n");
            for (Integer off : offsets) {
                xref.append(String.format("%010d 00000 n \n", off));
            }
            xref.append("trailer\n<< /Size ").append(objects.size() + 1)
                .append(" /Root 1 0 R >>\nstartxref\n").append(xrefStart).append("\n%%EOF");
            out.write(xref.toString().getBytes(StandardCharsets.ISO_8859_1));
        } catch (IOException e) {
            throw new IllegalStateException("Failed to build PDF", e);
        }
        return out.toByteArray();
    }

    private static String escape(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)");
    }
}