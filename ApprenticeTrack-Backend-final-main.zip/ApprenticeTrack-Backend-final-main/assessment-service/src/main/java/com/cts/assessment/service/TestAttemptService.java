package com.cts.assessment.service;

import java.util.List;

import com.cts.assessment.dto.GradeAttemptRequestDTO;
import com.cts.assessment.dto.TestAttemptResponseDTO;
import com.cts.assessment.dto.TestAttemptSubmitRequestDTO;

public interface TestAttemptService {

    /** All attempts for a test, or just one trainee's when traineeID is provided. */
    List<TestAttemptResponseDTO> listAttempts(Long testID, Long traineeID);

    TestAttemptResponseDTO submitAttempt(Long testID, TestAttemptSubmitRequestDTO dto);

    TestAttemptResponseDTO gradeAttempt(Long attemptID, GradeAttemptRequestDTO dto);
}
