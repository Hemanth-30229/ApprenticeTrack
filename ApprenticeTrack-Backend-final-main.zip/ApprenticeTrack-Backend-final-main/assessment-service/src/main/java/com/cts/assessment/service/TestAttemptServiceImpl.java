package com.cts.assessment.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.assessment.client.PlatformClient;
import com.cts.assessment.client.dto.AuditLogRequest;
import com.cts.assessment.common.TestAttemptStatus;
import com.cts.assessment.common.TestQuestionType;
import com.cts.assessment.dto.GradeAttemptRequestDTO;
import com.cts.assessment.dto.QuestionGradeDTO;
import com.cts.assessment.dto.TestAnswerResponseDTO;
import com.cts.assessment.dto.TestAnswerSubmitDTO;
import com.cts.assessment.dto.TestAttemptResponseDTO;
import com.cts.assessment.dto.TestAttemptSubmitRequestDTO;
import com.cts.assessment.entity.TestAttempt;
import com.cts.assessment.entity.TestAttemptAnswer;
import com.cts.assessment.entity.TestQuestion;
import com.cts.assessment.exception.DuplicateTestAttemptException;
import com.cts.assessment.exception.InvalidMarksException;
import com.cts.assessment.exception.TestAttemptNotFoundException;
import com.cts.assessment.exception.TradeTestNotFoundException;
import com.cts.assessment.repository.TestAttemptRepository;
import com.cts.assessment.repository.TestQuestionRepository;
import com.cts.assessment.repository.TradeTestRepository;

@Service
public class TestAttemptServiceImpl implements TestAttemptService {

    private static final String MODULE = "TestAttempt";

    private final TestAttemptRepository attemptRepository;
    private final TestQuestionRepository questionRepository;
    private final TradeTestRepository tradeTestRepository;
    private final PlatformClient platformClient;

    public TestAttemptServiceImpl(TestAttemptRepository attemptRepository,
                                  TestQuestionRepository questionRepository,
                                  TradeTestRepository tradeTestRepository,
                                  PlatformClient platformClient) {
        this.attemptRepository = attemptRepository;
        this.questionRepository = questionRepository;
        this.tradeTestRepository = tradeTestRepository;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional(readOnly = true)
    public List<TestAttemptResponseDTO> listAttempts(Long testID, Long traineeID) {
        requireTest(testID);
        List<TestAttempt> attempts = traineeID != null
                ? attemptRepository.findByTestIDAndTraineeID(testID, traineeID)
                : attemptRepository.findByTestIDOrderBySubmittedAtDesc(testID);
        return attempts.stream().map(this::toResponseDTO).toList();
    }

    @Override
    @Transactional
    public TestAttemptResponseDTO submitAttempt(Long testID, TestAttemptSubmitRequestDTO dto) {
        requireTest(testID);

        if (attemptRepository.findFirstByTestIDAndTraineeID(testID, dto.getTraineeID()).isPresent()) {
            throw new DuplicateTestAttemptException(
                    "Trainee " + dto.getTraineeID() + " has already submitted this test.");
        }

        List<TestQuestion> questions = questionRepository.findByTestIDOrderBySequenceAsc(testID);

        // Index the trainee's submitted answers by question for quick lookup.
        Map<Long, TestAnswerSubmitDTO> submitted = new HashMap<>();
        if (dto.getAnswers() != null) {
            dto.getAnswers().forEach(a -> submitted.put(a.getQuestionID(), a));
        }

        int autoScore = 0;
        int autoMaxScore = 0;
        int maxScore = 0;
        boolean hasCoding = false;

        TestAttempt attempt = TestAttempt.builder()
                .testID(testID)
                .traineeID(dto.getTraineeID())
                .traineeName(dto.getTraineeName())
                .submittedAt(LocalDateTime.now())
                .build();

        for (TestQuestion q : questions) {
            int marks = q.getMarks() == null ? 0 : q.getMarks();
            maxScore += marks;
            TestAnswerSubmitDTO ans = submitted.get(q.getQuestionID());

            TestAttemptAnswer.TestAttemptAnswerBuilder ab = TestAttemptAnswer.builder()
                    .questionID(q.getQuestionID())
                    .questionType(q.getQuestionType())
                    .marks(marks);

            if (q.getQuestionType() == TestQuestionType.MultipleChoice) {
                autoMaxScore += marks;
                Integer selected = ans == null ? null : ans.getSelectedOptionIndex();
                boolean correct = selected != null && selected.equals(q.getCorrectOptionIndex());
                if (correct) autoScore += marks;
                ab.selectedOptionIndex(selected)
                  .correctOptionIndex(q.getCorrectOptionIndex())
                  .isCorrect(correct)
                  .marksAwarded(correct ? marks : 0);
            } else {
                hasCoding = true;
                ab.codeAnswer(ans == null ? null : ans.getCodeAnswer())
                  .marksAwarded(null); // pending manual review
            }
            attempt.getAnswers().add(ab.build());
        }

        attempt.setAutoScore(autoScore);
        attempt.setAutoMaxScore(autoMaxScore);
        attempt.setMaxScore(maxScore);
        // Fully auto-gradeable (no coding) -> finalize immediately.
        attempt.setStatus(hasCoding ? TestAttemptStatus.Submitted : TestAttemptStatus.Graded);
        attempt.setTotalScore(hasCoding ? null : autoScore);

        TestAttempt saved = attemptRepository.save(attempt);
        audit(dto.getTraineeID(), "TestAttemptSubmitted: TestID=" + testID
                + " [AttemptID=" + saved.getAttemptID() + "]");
        return toResponseDTO(saved);
    }

    @Override
    @Transactional
    public TestAttemptResponseDTO gradeAttempt(Long attemptID, GradeAttemptRequestDTO dto) {
        TestAttempt attempt = attemptRepository.findById(attemptID)
                .orElseThrow(() -> new TestAttemptNotFoundException("Attempt not found with ID: " + attemptID));

        Map<Long, Integer> gradeByQuestion = new HashMap<>();
        if (dto.getGrades() != null) {
            for (QuestionGradeDTO g : dto.getGrades()) {
                gradeByQuestion.put(g.getQuestionID(), g.getMarksAwarded());
            }
        }

        for (TestAttemptAnswer answer : attempt.getAnswers()) {
            if (answer.getQuestionType() != TestQuestionType.Coding) continue;
            Integer awarded = gradeByQuestion.get(answer.getQuestionID());
            if (awarded == null) continue;
            int max = answer.getMarks() == null ? 0 : answer.getMarks();
            if (awarded < 0 || awarded > max) {
                throw new InvalidMarksException(
                        "Marks awarded (" + awarded + ") for question " + answer.getQuestionID()
                        + " must be between 0 and " + max + ".");
            }
            answer.setMarksAwarded(awarded);
        }

        int total = attempt.getAnswers().stream()
                .mapToInt(a -> a.getMarksAwarded() == null ? 0 : a.getMarksAwarded())
                .sum();
        attempt.setTotalScore(total);
        attempt.setStatus(TestAttemptStatus.Graded);

        TestAttempt saved = attemptRepository.save(attempt);
        audit(attempt.getTraineeID(), "TestAttemptGraded: [AttemptID=" + saved.getAttemptID() + "]");
        return toResponseDTO(saved);
    }

    // ── helpers ──
    private void requireTest(Long testID) {
        if (!tradeTestRepository.existsById(testID)) {
            throw new TradeTestNotFoundException("Trade test not found with ID: " + testID);
        }
    }

    private void audit(Long userID, String action) {
        platformClient.recordAudit(new AuditLogRequest(userID, action, MODULE, null));
    }

    private TestAttemptResponseDTO toResponseDTO(TestAttempt a) {
        List<TestAnswerResponseDTO> answers = a.getAnswers().stream()
                .map(ans -> TestAnswerResponseDTO.builder()
                        .questionID(ans.getQuestionID())
                        .questionType(ans.getQuestionType())
                        .marks(ans.getMarks())
                        .selectedOptionIndex(ans.getSelectedOptionIndex())
                        .correctOptionIndex(ans.getCorrectOptionIndex())
                        .isCorrect(ans.getIsCorrect())
                        .codeAnswer(ans.getCodeAnswer())
                        .marksAwarded(ans.getMarksAwarded())
                        .build())
                .toList();
        return TestAttemptResponseDTO.builder()
                .attemptID(a.getAttemptID())
                .testID(a.getTestID())
                .traineeID(a.getTraineeID())
                .traineeName(a.getTraineeName())
                .status(a.getStatus())
                .autoScore(a.getAutoScore())
                .autoMaxScore(a.getAutoMaxScore())
                .totalScore(a.getTotalScore())
                .maxScore(a.getMaxScore())
                .submittedAt(a.getSubmittedAt())
                .answers(answers)
                .build();
    }
}
