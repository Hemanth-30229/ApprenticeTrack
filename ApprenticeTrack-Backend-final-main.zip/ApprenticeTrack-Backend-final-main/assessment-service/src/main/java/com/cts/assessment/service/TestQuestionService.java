package com.cts.assessment.service;

import java.util.List;

import com.cts.assessment.dto.TestQuestionCreateRequestDTO;
import com.cts.assessment.dto.TestQuestionResponseDTO;

public interface TestQuestionService {

    List<TestQuestionResponseDTO> listQuestions(Long testID);

    TestQuestionResponseDTO createQuestion(Long testID, TestQuestionCreateRequestDTO dto);

    TestQuestionResponseDTO updateQuestion(Long questionID, TestQuestionCreateRequestDTO dto);

    void deleteQuestion(Long questionID);
}
