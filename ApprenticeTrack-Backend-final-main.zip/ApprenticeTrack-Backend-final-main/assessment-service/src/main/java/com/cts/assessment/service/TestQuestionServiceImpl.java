package com.cts.assessment.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.assessment.client.PlatformClient;
import com.cts.assessment.client.dto.AuditLogRequest;
import com.cts.assessment.common.TestQuestionType;
import com.cts.assessment.dto.TestQuestionCreateRequestDTO;
import com.cts.assessment.dto.TestQuestionOptionDTO;
import com.cts.assessment.dto.TestQuestionResponseDTO;
import com.cts.assessment.entity.TestQuestion;
import com.cts.assessment.exception.InvalidTestQuestionException;
import com.cts.assessment.exception.TestQuestionNotFoundException;
import com.cts.assessment.exception.TradeTestNotFoundException;
import com.cts.assessment.repository.TestQuestionRepository;
import com.cts.assessment.repository.TradeTestRepository;

@Service
public class TestQuestionServiceImpl implements TestQuestionService {

    private static final String MODULE = "TestQuestion";

    private final TestQuestionRepository questionRepository;
    private final TradeTestRepository tradeTestRepository;
    private final PlatformClient platformClient;

    public TestQuestionServiceImpl(TestQuestionRepository questionRepository,
                                   TradeTestRepository tradeTestRepository,
                                   PlatformClient platformClient) {
        this.questionRepository = questionRepository;
        this.tradeTestRepository = tradeTestRepository;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional(readOnly = true)
    public List<TestQuestionResponseDTO> listQuestions(Long testID) {
        requireTest(testID);
        return questionRepository.findByTestIDOrderBySequenceAsc(testID).stream()
                .map(this::toResponseDTO)
                .toList();
    }

    @Override
    @Transactional
    public TestQuestionResponseDTO createQuestion(Long testID, TestQuestionCreateRequestDTO dto) {
        requireTest(testID);
        validate(dto);

        int sequence = (int) questionRepository.countByTestID(testID) + 1;

        TestQuestion question = TestQuestion.builder()
                .testID(testID)
                .questionType(dto.getQuestionType())
                .questionText(dto.getQuestionText().trim())
                .marks(dto.getMarks())
                .sequence(sequence)
                .options(optionTexts(dto))
                .correctOptionIndex(dto.getQuestionType() == TestQuestionType.MultipleChoice
                        ? dto.getCorrectOptionIndex() : null)
                .language(dto.getQuestionType() == TestQuestionType.Coding ? dto.getLanguage() : null)
                .starterCode(dto.getQuestionType() == TestQuestionType.Coding ? dto.getStarterCode() : null)
                .build();

        TestQuestion saved = questionRepository.save(question);
        audit("TestQuestionAdded: TestID=" + testID + " [QuestionID=" + saved.getQuestionID() + "]");
        return toResponseDTO(saved);
    }

    @Override
    @Transactional
    public TestQuestionResponseDTO updateQuestion(Long questionID, TestQuestionCreateRequestDTO dto) {
        TestQuestion question = questionRepository.findById(questionID)
                .orElseThrow(() -> new TestQuestionNotFoundException("Question not found with ID: " + questionID));

        // Question type is immutable once created; validate against the existing type.
        TestQuestionType type = question.getQuestionType();
        validateForType(type, dto);

        question.setQuestionText(dto.getQuestionText().trim());
        question.setMarks(dto.getMarks());
        if (type == TestQuestionType.MultipleChoice) {
            question.setOptions(optionTexts(dto));
            question.setCorrectOptionIndex(dto.getCorrectOptionIndex());
        } else {
            question.setLanguage(dto.getLanguage());
            question.setStarterCode(dto.getStarterCode());
        }

        TestQuestion saved = questionRepository.save(question);
        audit("TestQuestionUpdated: [QuestionID=" + saved.getQuestionID() + "]");
        return toResponseDTO(saved);
    }

    @Override
    @Transactional
    public void deleteQuestion(Long questionID) {
        TestQuestion question = questionRepository.findById(questionID)
                .orElseThrow(() -> new TestQuestionNotFoundException("Question not found with ID: " + questionID));
        questionRepository.delete(question);
        audit("TestQuestionRemoved: [QuestionID=" + questionID + "]");
    }

    // ── helpers ──
    private void requireTest(Long testID) {
        if (!tradeTestRepository.existsById(testID)) {
            throw new TradeTestNotFoundException("Trade test not found with ID: " + testID);
        }
    }

    private void validate(TestQuestionCreateRequestDTO dto) {
        validateForType(dto.getQuestionType(), dto);
    }

    private void validateForType(TestQuestionType type, TestQuestionCreateRequestDTO dto) {
        if (type == TestQuestionType.MultipleChoice) {
            List<TestQuestionOptionDTO> opts = dto.getOptions();
            long filled = opts == null ? 0
                    : opts.stream().filter(o -> o != null && o.getOptionText() != null
                            && !o.getOptionText().isBlank()).count();
            if (filled < 2) {
                throw new InvalidTestQuestionException("A multiple-choice question needs at least two options.");
            }
            Integer idx = dto.getCorrectOptionIndex();
            if (idx == null || idx < 0 || idx >= opts.size()
                    || opts.get(idx) == null || opts.get(idx).getOptionText() == null
                    || opts.get(idx).getOptionText().isBlank()) {
                throw new InvalidTestQuestionException("Mark a non-empty option as the correct answer.");
            }
        }
    }

    private List<String> optionTexts(TestQuestionCreateRequestDTO dto) {
        if (dto.getQuestionType() != TestQuestionType.MultipleChoice || dto.getOptions() == null) {
            return new ArrayList<>();
        }
        List<String> texts = new ArrayList<>();
        dto.getOptions().forEach(o -> texts.add(o == null ? "" : o.getOptionText()));
        return texts;
    }

    private void audit(String action) {
        platformClient.recordAudit(new AuditLogRequest(null, action, MODULE, null));
    }

    private TestQuestionResponseDTO toResponseDTO(TestQuestion q) {
        List<TestQuestionOptionDTO> options = new ArrayList<>();
        if (q.getOptions() != null) {
            q.getOptions().forEach(text -> options.add(new TestQuestionOptionDTO(text)));
        }
        return TestQuestionResponseDTO.builder()
                .questionID(q.getQuestionID())
                .testID(q.getTestID())
                .questionType(q.getQuestionType())
                .questionText(q.getQuestionText())
                .marks(q.getMarks())
                .sequence(q.getSequence())
                .options(options)
                .correctOptionIndex(q.getCorrectOptionIndex())
                .language(q.getLanguage())
                .starterCode(q.getStarterCode())
                .build();
    }
}
