package com.cts.assessment.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.assessment.dto.BulkPublishResponseDTO;
import com.cts.assessment.dto.TradeTestResultEntryRequestDTO;
import com.cts.assessment.dto.TradeTestResultResponseDTO;
import com.cts.assessment.common.TradeTestResultOverallOutcome;
import com.cts.assessment.common.TradeTestResultStatus;

public interface TradeTestResultService {

    List<TradeTestResultResponseDTO> compute(Long testID, Long actorUserID);

    /** Direct per-trainee result entry: assessor supplies marks, outcome derived at the pass threshold. */
    List<TradeTestResultResponseDTO> enterResults(TradeTestResultEntryRequestDTO request, Long actorUserID);

    TradeTestResultResponseDTO getById(Long finalResultID);

    Page<TradeTestResultResponseDTO> getResults(Long testID, Long traineeID, TradeTestResultOverallOutcome overallOutcome,
                                                Boolean reassessmentRequired, TradeTestResultStatus status, Pageable pageable);

    TradeTestResultResponseDTO publish(Long finalResultID, Long actorUserID);

    BulkPublishResponseDTO bulkPublish(List<Long> finalResultIDs, Long actorUserID);
}