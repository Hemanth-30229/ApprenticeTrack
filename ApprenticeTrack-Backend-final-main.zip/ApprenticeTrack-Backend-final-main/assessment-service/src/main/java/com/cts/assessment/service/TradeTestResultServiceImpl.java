package com.cts.assessment.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.assessment.client.PlatformClient;
import com.cts.assessment.client.TrainingClient;
import com.cts.assessment.client.dto.AuditLogRequest;
import com.cts.assessment.client.dto.NotificationRequest;
import com.cts.assessment.client.dto.TradeCourseContract;
import com.cts.assessment.client.dto.TraineeContract;
import com.cts.assessment.dto.BulkPublishResponseDTO;
import com.cts.assessment.dto.CompetencyResultResponseDTO;
import com.cts.assessment.dto.TradeTestResultEntryRequestDTO;
import com.cts.assessment.dto.TradeTestResultResponseDTO;
import com.cts.assessment.common.CompetencyResultOutcome;
import com.cts.assessment.common.TradeTestResultOverallOutcome;
import com.cts.assessment.common.TradeTestResultStatus;
import com.cts.assessment.common.TradeTestStatus;
import com.cts.assessment.entity.CompetencyResult;
import com.cts.assessment.entity.TradeTest;
import com.cts.assessment.entity.TradeTestResult;
import com.cts.assessment.exception.ResultAlreadyPublishedException;
import com.cts.assessment.exception.TradeTestNotFoundException;
import com.cts.assessment.exception.TradeTestResultNotFoundException;
import com.cts.assessment.repository.CompetencyResultRepository;
import com.cts.assessment.repository.TradeTestRepository;
import com.cts.assessment.repository.TradeTestResultRepository;

@Service
public class TradeTestResultServiceImpl implements TradeTestResultService {

    private static final String MODULE = "ResultPublish";
    private static final String CATEGORY_ASSESSMENT = "Assessment";

    private final TradeTestResultRepository resultRepository;
    private final TradeTestRepository tradeTestRepository;
    private final CompetencyResultRepository competencyResultRepository;
    private final TrainingClient trainingClient;
    private final PlatformClient platformClient;

    /** Minimum percentage to Pass; shared with competency grading. Default 60. */
    @Value("${assessment.pass-threshold-percent:60}")
    private double passThresholdPercent;

    public TradeTestResultServiceImpl(TradeTestResultRepository resultRepository,
                                      TradeTestRepository tradeTestRepository,
                                      CompetencyResultRepository competencyResultRepository,
                                      TrainingClient trainingClient,
                                      PlatformClient platformClient) {
        this.resultRepository = resultRepository;
        this.tradeTestRepository = tradeTestRepository;
        this.competencyResultRepository = competencyResultRepository;
        this.trainingClient = trainingClient;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional
    public List<TradeTestResultResponseDTO> compute(Long testID, Long actorUserID) {
        TradeTest test = findTest(testID);

        // Enrolled trainees for the test's batch come from training-service.
        List<Long> traineeIDs = trainingClient.getEnrolledTraineeIds(test.getBatchID()).stream()
                .distinct()
                .collect(Collectors.toList());

        List<TradeTestResult> computed = traineeIDs.stream()
                .map(traineeID -> computeForTrainee(testID, traineeID))
                .filter(r -> r != null)
                .collect(Collectors.toList());

        platformClient.recordAudit(new AuditLogRequest(actorUserID,
                "TradeTestResultsComputed: TestID=" + testID + ", records=" + computed.size(),
                MODULE, null));

        return computed.stream().map(this::toResponseDTO).collect(Collectors.toList());
    }

    private TradeTestResult computeForTrainee(Long testID, Long traineeID) {
        List<CompetencyResult> unitResults = competencyResultRepository.findByTestIDAndTraineeID(testID, traineeID);

        TradeTestResultOverallOutcome outcome;
        if (unitResults.isEmpty()) {
            outcome = TradeTestResultOverallOutcome.Absent;
        } else if (unitResults.stream().allMatch(r -> r.getOutcome() == CompetencyResultOutcome.Competent)) {
            outcome = TradeTestResultOverallOutcome.Pass;
        } else {
            outcome = TradeTestResultOverallOutcome.Fail;
        }
        // Both failed and absent trainees require a reassessment.
        boolean reassessment = outcome == TradeTestResultOverallOutcome.Fail
                || outcome == TradeTestResultOverallOutcome.Absent;

        TradeTestResult result = resultRepository.findByTestIDAndTraineeID(testID, traineeID).orElse(null);
        if (result != null && result.getStatus() == TradeTestResultStatus.Published) {
            // Never overwrite an already-published result; return it unchanged.
            return result;
        }
        if (result == null) {
            result = TradeTestResult.builder()
                    .testID(testID)
                    .traineeID(traineeID)
                    .status(TradeTestResultStatus.Draft)
                    .build();
        }
        result.setOverallOutcome(outcome);
        result.setReassessmentRequired(reassessment);
        return resultRepository.save(result);
    }

    @Override
    @Transactional
    public List<TradeTestResultResponseDTO> enterResults(TradeTestResultEntryRequestDTO request, Long actorUserID) {
        Long testID = request.getTestID();
        findTest(testID); // validate the test exists

        List<TradeTestResult> saved = new ArrayList<>();
        for (TradeTestResultEntryRequestDTO.TraineeResult item : request.getResults()) {
            TradeTestResult r = upsertEnteredResult(testID, item.getTraineeID(),
                    item.getMarksObtained(), item.getMaxMarks());
            if (r != null) saved.add(r);
        }

        platformClient.recordAudit(new AuditLogRequest(actorUserID,
                "TradeTestResultsEntered: TestID=" + testID + ", records=" + saved.size(),
                MODULE, null));

        return saved.stream().map(this::toResponseDTO).collect(Collectors.toList());
    }

    /** Upsert a Draft result from a directly-entered mark. Null marks = Absent. Published rows are never overwritten. */
    private TradeTestResult upsertEnteredResult(Long testID, Long traineeID, Integer marks, Integer maxMarksIn) {
        int max = (maxMarksIn == null || maxMarksIn <= 0) ? 100 : maxMarksIn;
        TradeTestResultOverallOutcome outcome;
        if (marks == null) {
            outcome = TradeTestResultOverallOutcome.Absent;
        } else {
            double pct = (marks * 100.0) / max;
            outcome = pct >= passThresholdPercent
                    ? TradeTestResultOverallOutcome.Pass
                    : TradeTestResultOverallOutcome.Fail;
        }
        boolean reassessment = outcome == TradeTestResultOverallOutcome.Fail
                || outcome == TradeTestResultOverallOutcome.Absent;

        TradeTestResult result = resultRepository.findByTestIDAndTraineeID(testID, traineeID).orElse(null);
        if (result != null && result.getStatus() == TradeTestResultStatus.Published) {
            return result; // never overwrite a published result
        }
        if (result == null) {
            result = TradeTestResult.builder()
                    .testID(testID)
                    .traineeID(traineeID)
                    .status(TradeTestResultStatus.Draft)
                    .build();
        }
        result.setMarksObtained(marks);
        result.setMaxMarks(marks == null ? null : max);
        result.setOverallOutcome(outcome);
        result.setReassessmentRequired(reassessment);
        return resultRepository.save(result);
    }

    @Override
    @Transactional(readOnly = true)
    public TradeTestResultResponseDTO getById(Long finalResultID) {
        TradeTestResult result = findResult(finalResultID);
        TradeTestResultResponseDTO dto = toResponseDTO(result);

        List<CompetencyResultResponseDTO> breakdown =
                competencyResultRepository.findByTestIDAndTraineeID(result.getTestID(), result.getTraineeID())
                        .stream().map(this::toCompetencyDTO).collect(Collectors.toList());
        dto.setUnitWiseBreakdown(breakdown);
        return dto;
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TradeTestResultResponseDTO> getResults(Long testID, Long traineeID, TradeTestResultOverallOutcome overallOutcome,
                                                       Boolean reassessmentRequired, TradeTestResultStatus status, Pageable pageable) {
        return resultRepository
                .findAllWithFilters(testID, traineeID, overallOutcome, reassessmentRequired, status, pageable)
                .map(this::toResponseDTO);
    }

    @Override
    @Transactional
    public TradeTestResultResponseDTO publish(Long finalResultID, Long actorUserID) {
        TradeTestResult result = findResult(finalResultID);
        doPublish(result, actorUserID);
        return toResponseDTO(result);
    }

    @Override
    @Transactional
    public BulkPublishResponseDTO bulkPublish(List<Long> finalResultIDs, Long actorUserID) {
        BulkPublishResponseDTO response = new BulkPublishResponseDTO();
        response.setTotalRequested(finalResultIDs.size());

        for (Long id : finalResultIDs) {
            try {
                TradeTestResult result = findResult(id);
                doPublish(result, actorUserID);
                response.addPublished(id);
            } catch (RuntimeException ex) {
                response.addFailed(id, ex.getMessage());
            }
        }
        return response;
    }

    private void doPublish(TradeTestResult result, Long actorUserID) {
        if (result.getStatus() != TradeTestResultStatus.Draft) {
            throw new ResultAlreadyPublishedException(
                    "Only results in 'Draft' status can be published. Current status: "
                    + result.getStatus() + ". FinalResultID: " + result.getFinalResultID());
        }

        result.setStatus(TradeTestResultStatus.Published);
        result.setPublishedDate(LocalDate.now());
        resultRepository.save(result);

        // Declare results on the parent trade test.
        tradeTestRepository.findById(result.getTestID()).ifPresent(test -> {
            test.setStatus(TradeTestStatus.ResultsDeclared);
            tradeTestRepository.save(test);
        });

        platformClient.recordAudit(new AuditLogRequest(actorUserID,
                "TradeTestResultPublished: FinalResultID=" + result.getFinalResultID()
                        + ", TestID=" + result.getTestID() + ", TraineeID=" + result.getTraineeID()
                        + ", Outcome=" + result.getOverallOutcome(),
                MODULE, null));

        platformClient.notify(new NotificationRequest("TRAINEE", result.getTraineeID(),
                "Your trade test result has been published. Outcome: " + result.getOverallOutcome()
                + (Boolean.TRUE.equals(result.getReassessmentRequired()) ? " (reassessment required)." : "."),
                CATEGORY_ASSESSMENT));
    }

    // ── Lookups & mapping ────────────────────────────────────────────────────
    private TradeTest findTest(Long testID) {
        return tradeTestRepository.findById(testID)
                .orElseThrow(() -> new TradeTestNotFoundException("Trade test not found with ID: " + testID));
    }

    private TradeTestResult findResult(Long finalResultID) {
        return resultRepository.findById(finalResultID)
                .orElseThrow(() -> new TradeTestResultNotFoundException(
                        "Trade test result not found with ID: " + finalResultID));
    }

    private TradeTestResultResponseDTO toResponseDTO(TradeTestResult r) {
        Long courseID = tradeTestRepository.findById(r.getTestID())
                .map(TradeTest::getCourseID).orElse(null);
        String courseName = null;
        if (courseID != null) {
            TradeCourseContract course = trainingClient.getCourse(courseID);
            courseName = course == null ? null : course.getCourseName();
        }
        TraineeContract trainee = trainingClient.getTrainee(r.getTraineeID());
        String traineeName = trainee == null ? null : trainee.getName();

        return TradeTestResultResponseDTO.builder()
                .finalResultID(r.getFinalResultID())
                .testID(r.getTestID())
                .traineeID(r.getTraineeID())
                .traineeName(traineeName)
                .courseID(courseID)
                .courseName(courseName)
                .overallOutcome(r.getOverallOutcome())
                .marksObtained(r.getMarksObtained())
                .maxMarks(r.getMaxMarks())
                .reassessmentRequired(r.getReassessmentRequired())
                .publishedDate(r.getPublishedDate())
                .status(r.getStatus())
                .build();
    }

    private CompetencyResultResponseDTO toCompetencyDTO(CompetencyResult r) {
        return CompetencyResultResponseDTO.builder()
                .resultID(r.getResultID())
                .testID(r.getTestID())
                .traineeID(r.getTraineeID())
                .unitID(r.getUnitID())
                .assessmentMethod(r.getAssessmentMethod())
                .marksObtained(r.getMarksObtained())
                .maxMarks(r.getMaxMarks())
                .outcome(r.getOutcome())
                .assessedByID(r.getAssessedByID())
                .assessmentDate(r.getAssessmentDate())
                .build();
    }
}