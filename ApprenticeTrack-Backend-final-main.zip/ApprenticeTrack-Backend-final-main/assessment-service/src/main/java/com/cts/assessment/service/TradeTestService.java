package com.cts.assessment.service;

import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.assessment.dto.TradeTestCreateRequestDTO;
import com.cts.assessment.dto.TradeTestResponseDTO;
import com.cts.assessment.dto.TradeTestUpdateRequestDTO;
import com.cts.assessment.common.TradeTestStatus;

public interface TradeTestService {

    TradeTestResponseDTO createTradeTest(TradeTestCreateRequestDTO dto);

    TradeTestResponseDTO getTradeTestById(Long testID);

    Page<TradeTestResponseDTO> getAllTradeTests(Long courseID, Long batchID, Long assessorID,
                                                TradeTestStatus status, LocalDate fromDate, LocalDate toDate,
                                                Pageable pageable);

    TradeTestResponseDTO updateTradeTest(Long testID, TradeTestUpdateRequestDTO dto);

    TradeTestResponseDTO updateStatus(Long testID, TradeTestStatus newStatus);

    /** Assigns or reassigns an assessor to a scheduled trade test. */
    TradeTestResponseDTO assignAssessor(Long testID, Long assessorID);
}