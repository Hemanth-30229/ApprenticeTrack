package com.cts.assessment.service;

import java.time.LocalDate;
import java.util.EnumMap;
import java.util.Map;
import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.assessment.client.AuthClient;
import com.cts.assessment.client.PlatformClient;
import com.cts.assessment.client.TrainingClient;
import com.cts.assessment.client.dto.AuditLogRequest;
import com.cts.assessment.client.dto.NotificationRequest;
import com.cts.assessment.client.dto.TradeCourseContract;
import com.cts.assessment.client.dto.TraineeContract;
import com.cts.assessment.client.dto.TrainingBatchContract;
import com.cts.assessment.client.dto.UserContract;
import com.cts.assessment.dto.TradeTestCreateRequestDTO;
import com.cts.assessment.dto.TradeTestResponseDTO;
import com.cts.assessment.dto.TradeTestUpdateRequestDTO;
import com.cts.assessment.common.TradeTestStatus;
import com.cts.assessment.entity.TradeTest;
import com.cts.assessment.exception.AssessorScheduleConflictException;
import com.cts.assessment.exception.BatchCourseMismatchException;
import com.cts.assessment.exception.BatchNotFoundException;
import com.cts.assessment.exception.CourseNotFoundException;
import com.cts.assessment.exception.DuplicateTradeTestException;
import com.cts.assessment.exception.InvalidAssessorException;
import com.cts.assessment.exception.InvalidTradeTestStatusTransitionException;
import com.cts.assessment.exception.TradeTestNotEditableException;
import com.cts.assessment.exception.TradeTestNotFoundException;
import com.cts.assessment.exception.UserNotFoundException;
import com.cts.assessment.repository.TradeTestRepository;

@Service
public class TradeTestServiceImpl implements TradeTestService {

    private static final String MODULE = "TradeTest";
    private static final String ROLE_ASSESSOR = "Assessor";
    private static final String STATUS_ACTIVE = "Active";
    private static final String CATEGORY_ASSESSMENT = "Assessment";

    /** Allowed status transitions. */
    private static final Map<TradeTestStatus, Set<TradeTestStatus>> ALLOWED_TRANSITIONS = new EnumMap<>(TradeTestStatus.class);
    static {
        ALLOWED_TRANSITIONS.put(TradeTestStatus.Scheduled, Set.of(TradeTestStatus.Conducted, TradeTestStatus.Cancelled));
        ALLOWED_TRANSITIONS.put(TradeTestStatus.Conducted, Set.of(TradeTestStatus.ResultsDeclared));
        ALLOWED_TRANSITIONS.put(TradeTestStatus.ResultsDeclared, Set.of());
        ALLOWED_TRANSITIONS.put(TradeTestStatus.Cancelled, Set.of());
    }

    private final TradeTestRepository tradeTestRepository;
    private final TrainingClient trainingClient;
    private final AuthClient authClient;
    private final PlatformClient platformClient;

    public TradeTestServiceImpl(TradeTestRepository tradeTestRepository,
                                TrainingClient trainingClient,
                                AuthClient authClient,
                                PlatformClient platformClient) {
        this.tradeTestRepository = tradeTestRepository;
        this.trainingClient = trainingClient;
        this.authClient = authClient;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional
    public TradeTestResponseDTO createTradeTest(TradeTestCreateRequestDTO dto) {
        TradeCourseContract course = findCourse(dto.getCourseID());
        TrainingBatchContract batch = findBatch(dto.getBatchID());
        requireBatchBelongsToCourse(batch, dto.getCourseID());
        UserContract assessor = requireAssessor(dto.getAssessorID());

        if (tradeTestRepository.existsByCourseIDAndBatchIDAndTestDate(
                dto.getCourseID(), dto.getBatchID(), dto.getTestDate())) {
            throw new DuplicateTradeTestException(
                    "A trade test already exists for CourseID=" + dto.getCourseID()
                    + ", BatchID=" + dto.getBatchID() + ", TestDate=" + dto.getTestDate());
        }

        TradeTest test = TradeTest.builder()
                .courseID(dto.getCourseID())
                .batchID(dto.getBatchID())
                .assessorID(dto.getAssessorID())
                .testDate(dto.getTestDate())
                .venueID(dto.getVenueID())
                .status(TradeTestStatus.Scheduled)
                .build();
        TradeTest saved = tradeTestRepository.save(test);

        audit(saved.getAssessorID(),
                "TradeTestScheduled: CourseID=" + saved.getCourseID() + ", BatchID=" + saved.getBatchID()
                + ", TestDate=" + saved.getTestDate() + " [TestID=" + saved.getTestID() + "]");

        notifyUser(assessor.getUserID(),
                "You have been assigned to trade test #" + saved.getTestID() + " for "
                + course.getCourseName() + " on " + saved.getTestDate() + ".");

        // Notify the trainees the test is actually scheduled for. Resolve each trainee
        // to its linked user here — on the authenticated request thread — and send a
        // direct USER notification. (Sending a "TRAINEE" notification made platform-service
        // resolve the traineeID via getTrainee on an async worker thread, where the call
        // was failing and the trainee's notification was being silently dropped.)
        for (Long traineeID : trainingClient.getEnrolledTraineeIds(saved.getBatchID())) {
            TraineeContract trainee = trainingClient.getTrainee(traineeID);
            if (trainee == null || trainee.getUserID() == null) {
                continue;
            }
            notifyUser(trainee.getUserID(),
                    "A trade test (#" + saved.getTestID() + ") for " + course.getCourseName()
                    + " has been scheduled on " + saved.getTestDate() + ".");
        }

        return toResponseDTO(saved, course.getCourseName(), batch.getBatchCode(), assessor.getName());
    }

    @Override
    @Transactional(readOnly = true)
    public TradeTestResponseDTO getTradeTestById(Long testID) {
        TradeTest test = findTest(testID);
        return toResponseDTO(test,
                resolveCourseName(test.getCourseID()),
                resolveBatchCode(test.getBatchID()),
                resolveAssessorName(test.getAssessorID()));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TradeTestResponseDTO> getAllTradeTests(Long courseID, Long batchID, Long assessorID,
                                                       TradeTestStatus status, LocalDate fromDate, LocalDate toDate,
                                                       Pageable pageable) {
        return tradeTestRepository
                .findAllWithFilters(courseID, batchID, assessorID, status, fromDate, toDate, pageable)
                .map(t -> toResponseDTO(t,
                        resolveCourseName(t.getCourseID()),
                        resolveBatchCode(t.getBatchID()),
                        resolveAssessorName(t.getAssessorID())));
    }

    @Override
    @Transactional
    public TradeTestResponseDTO updateTradeTest(Long testID, TradeTestUpdateRequestDTO dto) {
        TradeTest test = findTest(testID);
        if (test.getStatus() != TradeTestStatus.Scheduled) {
            throw new TradeTestNotEditableException(
                    "Only tests in 'Scheduled' status can be updated. Current status: "
                    + test.getStatus() + ". TestID: " + testID);
        }
        UserContract assessor = requireAssessor(dto.getAssessorID());

        test.setAssessorID(dto.getAssessorID());
        test.setTestDate(dto.getTestDate());
        test.setVenueID(dto.getVenueID());
        TradeTest updated = tradeTestRepository.save(test);

        audit(updated.getAssessorID(), "TradeTestUpdated: [TestID=" + updated.getTestID() + "]");

        return toResponseDTO(updated,
                resolveCourseName(updated.getCourseID()),
                resolveBatchCode(updated.getBatchID()),
                assessor.getName());
    }

    @Override
    @Transactional
    public TradeTestResponseDTO updateStatus(Long testID, TradeTestStatus newStatus) {
        TradeTest test = findTest(testID);
        TradeTestStatus current = test.getStatus();

        if (!ALLOWED_TRANSITIONS.getOrDefault(current, Set.of()).contains(newStatus)) {
            throw new InvalidTradeTestStatusTransitionException(
                    "Invalid status transition: " + current + " → " + newStatus
                    + ". TestID: " + testID);
        }

        test.setStatus(newStatus);
        TradeTest updated = tradeTestRepository.save(test);

        audit(updated.getAssessorID(),
                "TradeTestStatusChanged: " + current + " → " + newStatus
                + " [TestID=" + updated.getTestID() + "]");

        return toResponseDTO(updated,
                resolveCourseName(updated.getCourseID()),
                resolveBatchCode(updated.getBatchID()),
                resolveAssessorName(updated.getAssessorID()));
    }

    @Override
    @Transactional
    public TradeTestResponseDTO assignAssessor(Long testID, Long assessorID) {
        TradeTest test = findTest(testID);
        if (test.getStatus() != TradeTestStatus.Scheduled) {
            throw new TradeTestNotEditableException(
                    "Assessors can only be (re)assigned to tests in 'Scheduled' status. Current status: "
                    + test.getStatus() + ". TestID: " + testID);
        }
        UserContract assessor = requireActiveAssessor(assessorID);
        requireNoScheduleConflict(assessorID, test.getTestDate(), testID);

        test.setAssessorID(assessorID);
        TradeTest updated = tradeTestRepository.save(test);

        audit(assessorID, "TradeTestAssessorAssigned: AssessorID=" + assessorID
                + " [TestID=" + updated.getTestID() + "]");

        notifyUser(assessor.getUserID(),
                "You have been assigned as assessor for trade test #" + updated.getTestID()
                + " on " + updated.getTestDate() + ".");

        return toResponseDTO(updated,
                resolveCourseName(updated.getCourseID()),
                resolveBatchCode(updated.getBatchID()),
                assessor.getName());
    }

    // ── Business rules ───────────────────────────────────────────────────────
    private void requireBatchBelongsToCourse(TrainingBatchContract batch, Long courseID) {
        if (!courseID.equals(batch.getCourseID())) {
            throw new BatchCourseMismatchException(
                    "Batch " + batch.getBatchID() + " does not belong to course " + courseID);
        }
    }

    private UserContract requireAssessor(Long assessorID) {
        UserContract user = authClient.getUser(assessorID);
        if (user == null) {
            throw new UserNotFoundException("User not found with ID: " + assessorID);
        }
        if (!ROLE_ASSESSOR.equals(user.getRole())) {
            throw new InvalidAssessorException(
                    "User " + assessorID + " is not an Assessor (role: " + user.getRole() + ")");
        }
        return user;
    }

    /** Assessor must exist, hold the Assessor role, and be Active (qualified for assignment). */
    private UserContract requireActiveAssessor(Long assessorID) {
        UserContract assessor = requireAssessor(assessorID);
        if (!STATUS_ACTIVE.equals(assessor.getStatus())) {
            throw new InvalidAssessorException(
                    "Assessor " + assessorID + " is not active (status: " + assessor.getStatus() + ")");
        }
        return assessor;
    }

    private void requireNoScheduleConflict(Long assessorID, LocalDate testDate, Long excludeTestID) {
        long conflicts = tradeTestRepository.countScheduleConflicts(
                assessorID, testDate, TradeTestStatus.Cancelled, excludeTestID);
        if (conflicts > 0) {
            throw new AssessorScheduleConflictException(
                    "Assessor " + assessorID + " is already assigned to another test on " + testDate + ".");
        }
    }

    // ── Lookups & mapping ────────────────────────────────────────────────────
    private TradeCourseContract findCourse(Long courseID) {
        TradeCourseContract course = trainingClient.getCourse(courseID);
        if (course == null) {
            throw new CourseNotFoundException("Course not found with ID: " + courseID);
        }
        return course;
    }

    private TrainingBatchContract findBatch(Long batchID) {
        TrainingBatchContract batch = trainingClient.getBatch(batchID);
        if (batch == null) {
            throw new BatchNotFoundException("Batch not found with ID: " + batchID);
        }
        return batch;
    }

    private TradeTest findTest(Long testID) {
        return tradeTestRepository.findById(testID)
                .orElseThrow(() -> new TradeTestNotFoundException("Trade test not found with ID: " + testID));
    }

    private String resolveCourseName(Long courseID) {
        TradeCourseContract course = trainingClient.getCourse(courseID);
        return course == null ? null : course.getCourseName();
    }

    private String resolveBatchCode(Long batchID) {
        TrainingBatchContract batch = trainingClient.getBatch(batchID);
        return batch == null ? null : batch.getBatchCode();
    }

    private String resolveAssessorName(Long assessorID) {
        UserContract user = authClient.getUser(assessorID);
        return user == null ? null : user.getName();
    }

    private void audit(Long userID, String action) {
        platformClient.recordAudit(new AuditLogRequest(userID, action, MODULE, null));
    }

    private void notifyUser(Long userID, String message) {
        platformClient.notify(new NotificationRequest("USER", userID, message, CATEGORY_ASSESSMENT));
    }

    private TradeTestResponseDTO toResponseDTO(TradeTest t, String courseName,
                                               String batchCode, String assessorName) {
        return TradeTestResponseDTO.builder()
                .testID(t.getTestID())
                .courseID(t.getCourseID())
                .courseName(courseName)
                .batchID(t.getBatchID())
                .batchCode(batchCode)
                .assessorID(t.getAssessorID())
                .assessorName(assessorName)
                .testDate(t.getTestDate())
                .venueID(t.getVenueID())
                .status(t.getStatus())
                .build();
    }
}