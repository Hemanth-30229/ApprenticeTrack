package com.cts.auth.client;

import com.cts.auth.client.dto.AuditLogRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Feign client to platform-service, which owns audit logging and email/notification
 * dispatch (MIGRATION_PLAN.md §6). Calls are best-effort: the Resilience4j-backed
 * {@link PlatformClientFallback} keeps auth flows working when platform-service is down.
 */
@FeignClient(name = "platform-service", fallback = PlatformClientFallback.class)
public interface PlatformClient {

    /** Records an audit-log entry (was a direct {@code AuditLogRepository.save} in the monolith). */
    @PostMapping("/api/audit-logs")
    void recordAudit(@RequestBody AuditLogRequest request);
}