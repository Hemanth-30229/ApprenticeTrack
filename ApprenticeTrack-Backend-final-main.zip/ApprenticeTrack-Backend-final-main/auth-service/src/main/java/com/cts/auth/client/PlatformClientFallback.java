package com.cts.auth.client;

import com.cts.auth.client.dto.AuditLogRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Degraded-mode fallback for {@link PlatformClient}. Audit and email are non-critical
 * to the auth transaction, so when platform-service is unreachable the failure is
 * logged and swallowed rather than failing login / password reset.
 */
@Component
public class PlatformClientFallback implements PlatformClient {

    private static final Logger log = LoggerFactory.getLogger(PlatformClientFallback.class);

    @Override
    public void recordAudit(AuditLogRequest request) {
        log.warn("platform-service unavailable; audit entry dropped: userID={} action={} module={}",
                request.getUserID(), request.getAction(), request.getModule());
    }
}