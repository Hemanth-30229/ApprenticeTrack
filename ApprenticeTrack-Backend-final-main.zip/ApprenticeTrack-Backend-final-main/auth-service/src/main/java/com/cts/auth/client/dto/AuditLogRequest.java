package com.cts.auth.client.dto;

/**
 * Payload sent to platform-service to record an audit-log entry.
 * Mirrors the fields the monolith wrote directly to the {@code audit_log} table.
 */
public class AuditLogRequest {

    private Long userID;
    private String action;
    private String module;

    public AuditLogRequest() {}

    public AuditLogRequest(Long userID, String action, String module) {
        this.userID = userID;
        this.action = action;
        this.module = module;
    }

    public Long getUserID() { return userID; }
    public void setUserID(Long userID) { this.userID = userID; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getModule() { return module; }
    public void setModule(String module) { this.module = module; }
}