package com.cts.auth.common;

public enum RoleStatus {
    Active, Inactive
}
