package com.cts.auth.common;

public enum UserRole {
    Trainee, Employer, Assessor, PlacementOfficer, StipendAdmin, Admin
}
