package com.cts.auth.common;

public enum UserStatus {
    Active, Inactive, Graduated
}
