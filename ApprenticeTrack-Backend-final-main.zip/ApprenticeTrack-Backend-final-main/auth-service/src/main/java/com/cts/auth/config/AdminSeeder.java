package com.cts.auth.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.cts.auth.common.UserRole;
import com.cts.auth.common.UserStatus;
import com.cts.auth.entity.User;
import com.cts.auth.repository.UserRepository;

/**
 * Bootstraps the first {@code Admin} account on startup so the platform is usable
 * before any user exists. Without this, no JWT can ever be obtained: login needs a
 * user, and {@code POST /api/users} is Admin-only (chicken-and-egg).
 *
 * <p>Idempotent: seeds only when the configured email is absent, so restarts and
 * persistent databases are safe. Disable in real environments by setting
 * {@code auth.seed.admin.enabled=false}; always override the default password.
 */
@Component
public class AdminSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(AdminSeeder.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${auth.seed.admin.enabled:true}")
    private boolean enabled;

    @Value("${auth.seed.admin.name:System Admin}")
    private String name;

    @Value("${auth.seed.admin.email:admin@cts.com}")
    private String email;

    @Value("${auth.seed.admin.password:Admin@123}")
    private String password;

    @Value("${auth.seed.admin.phone:9876543210}")
    private String phone;

    @Value("${auth.seed.admin.institute-id:1}")
    private Long instituteID;

    public AdminSeeder(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (!enabled) {
            return;
        }
        if (userRepository.existsByEmail(email)) {
            log.info("Admin seeder: user '{}' already exists, skipping.", email);
            return;
        }

        User admin = User.builder()
                .name(name)
                .role(UserRole.Admin)
                .email(email)
                .password(passwordEncoder.encode(password))
                .phone(phone)
                .instituteID(instituteID)
                .status(UserStatus.Active)
                .build();

        userRepository.save(admin);
        log.info("Admin seeder: created default Admin '{}'. CHANGE THE PASSWORD.", email);
    }
}
