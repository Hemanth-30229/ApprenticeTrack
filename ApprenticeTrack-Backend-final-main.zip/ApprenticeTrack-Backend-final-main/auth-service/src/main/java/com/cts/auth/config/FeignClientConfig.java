package com.cts.auth.config;

import java.util.concurrent.TimeUnit;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import feign.Retryer;
import feign.RequestInterceptor;
import jakarta.servlet.http.HttpServletRequest;

/**
 * Resilience4j service-to-service communication config (MIGRATION_PLAN.md §6, §10):
 *
 * <ul>
 *   <li>{@code authForwardingInterceptor} propagates the caller's {@code Authorization}
 *       (JWT) header on outbound Feign calls so platform-service can re-validate the
 *       token and enforce its own role checks.</li>
 *   <li>{@code feignRetryer} retries a transient connectivity failure (e.g. a dropped
 *       connection or connect timeout) up to 3 times, 500ms apart, before the call is
 *       counted as a failure by the Resilience4j circuit breaker and the
 *       {@code @FeignClient} fallback engages — matching the
 *       {@code resilience4j.retry.configs.default} values in the shared config. Feign's
 *       retryer only retries {@link feign.RetryableException}s (connection-level
 *       failures), never a normal 4xx/5xx application response, so business errors are
 *       never retried.</li>
 * </ul>
 *
 * Applied globally to every {@code @FeignClient} in this service.
 */
@Configuration
public class FeignClientConfig {

    @Bean
    RequestInterceptor authForwardingInterceptor() {
        return template -> {
            ServletRequestAttributes attrs =
                    (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attrs != null) {
                HttpServletRequest request = attrs.getRequest();
                String authHeader = request.getHeader("Authorization");
                if (authHeader != null && !authHeader.isBlank()) {
                    template.header("Authorization", authHeader);
                }
            }
        };
    }

    @Bean
    Retryer feignRetryer() {
        return new Retryer.Default(
                TimeUnit.MILLISECONDS.toMillis(500),
                TimeUnit.MILLISECONDS.toMillis(500),
                3);
    }
}
