package com.cts.auth.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.auth.dto.AdminResetPasswordRequestDTO;
import com.cts.auth.dto.ChangePasswordRequestDTO;
import com.cts.auth.dto.UserRegistrationRequestDTO;
import com.cts.auth.dto.UserRegistrationResponseDTO;
import com.cts.auth.dto.UserSummaryResponseDTO;
import com.cts.auth.service.UserService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/users")
@SecurityRequirement(name = "bearerAuth")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**
     * Creates a user. Restricted to administrators: the request supplies the account
     * role, so exposing this anonymously would permit privilege escalation. Seed the
     * first Admin out-of-band (SQL) to bootstrap.
     */
    @PostMapping
    @PreAuthorize("hasRole('Admin')")
    public ResponseEntity<UserRegistrationResponseDTO> registerUser(
            @Valid @RequestBody UserRegistrationRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(userService.registerUser(requestDTO));
    }

    /**
     * Paginated, optionally filtered user directory for the Admin console.
     * Restricted to administrators (identity data). Filters: role, status, and a
     * free-text search over name/email.
     */
    @GetMapping
    @PreAuthorize("hasRole('Admin')")
    public ResponseEntity<Page<UserSummaryResponseDTO>> listUsers(
            @RequestParam(required = false) String role,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "userID,asc") String sort) {
        String[] parts = sort.split(",");
        Sort.Direction dir = (parts.length > 1 && parts[1].equalsIgnoreCase("desc"))
                ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, parts[0]));
        return ResponseEntity.ok(userService.listUsers(role, status, search, pageable));
    }

    /**
     * Cross-service read used by other services' {@code AuthClient} (e.g.
     * assessment-service/ojt-stipend-service resolving an assessor's or
     * supervisor's name). Auth-service is the root of trust for identity
     * (MIGRATION_PLAN.md §6), so every other service treats this as authoritative.
     */
    @GetMapping("/{userId}")
    public ResponseEntity<UserSummaryResponseDTO> getUser(@PathVariable Long userId) {
        return ResponseEntity.ok(userService.getUserById(userId));
    }

    /**
     * Cross-service read used by assessment-service's {@code AuthClient} to list
     * active assessors for assignment (replaces the monolith's in-process
     * {@code UserRepository.findByRoleAndStatus(Assessor, Active)}).
     */
    @GetMapping("/assessors")
    public ResponseEntity<List<UserSummaryResponseDTO>> getActiveAssessors(
            @RequestParam(defaultValue = "Active") String status) {
        return ResponseEntity.ok(userService.getUsersByRoleAndStatus("Assessor", status));
    }

    /**
     * Self-service account deletion: the signed-in user removes their own account.
     * The caller's identity comes from the authenticated principal (email), set by
     * the JWT filter — so no path variable is trusted here. Mapped before /{userId}
     * so "me" is matched literally.
     */
    @DeleteMapping("/me")
    public ResponseEntity<Void> deleteOwnAccount(Authentication authentication) {
        userService.deleteOwnAccount(authentication.getName());
        return ResponseEntity.noContent().build();
    }

    /** Admin action: permanently delete any user account. */
    @DeleteMapping("/{userId}")
    @PreAuthorize("hasRole('Admin')")
    public ResponseEntity<Void> deleteUser(@PathVariable Long userId) {
        userService.deleteUser(userId);
        return ResponseEntity.noContent().build();
    }

    /**
     * Self-service password change for the signed-in user. Used for the forced
     * first-login reset (and any voluntary change). The caller's identity comes from
     * the authenticated principal (email) set by the JWT filter; the request must
     * include the current password to authorize the change.
     */
    @PostMapping("/me/change-password")
    public ResponseEntity<Void> changePassword(
            @Valid @RequestBody ChangePasswordRequestDTO requestDTO,
            Authentication authentication) {
        userService.changePassword(authentication.getName(), requestDTO);
        return ResponseEntity.noContent().build();
    }

    /**
     * Admin action: set a new (temporary) password on any user's account. The user
     * is then forced to change it on their next login (the {@code mustChangePassword}
     * flag is set) and their existing sessions are invalidated. No current password
     * is required — this is the admin-driven replacement for the removed self-service
     * email reset flow.
     */
    @PostMapping("/{userId}/reset-password")
    @PreAuthorize("hasRole('Admin')")
    public ResponseEntity<Void> resetUserPassword(
            @PathVariable Long userId,
            @Valid @RequestBody AdminResetPasswordRequestDTO requestDTO) {
        userService.resetPasswordByAdmin(userId, requestDTO);
        return ResponseEntity.noContent().build();
    }
}