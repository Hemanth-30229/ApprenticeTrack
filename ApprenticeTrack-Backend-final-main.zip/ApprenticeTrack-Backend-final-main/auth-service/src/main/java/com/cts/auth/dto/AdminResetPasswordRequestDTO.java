package com.cts.auth.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * Admin-driven password reset for another user's account. The target user is
 * identified by the path variable, not by this body. The admin supplies a
 * temporary password which the user is then forced to change on next login
 * (the {@code mustChangePassword} flag is set), so no current password is required.
 */
public class AdminResetPasswordRequestDTO {

    @NotBlank(message = "New password is required")
    private String newPassword;

    @NotBlank(message = "Password confirmation is required")
    private String confirmPassword;

    public AdminResetPasswordRequestDTO() {}

    public String getNewPassword() { return newPassword; }
    public String getConfirmPassword() { return confirmPassword; }

    public void setNewPassword(String v) { this.newPassword = v; }
    public void setConfirmPassword(String v) { this.confirmPassword = v; }
}
