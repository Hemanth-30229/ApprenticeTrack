package com.cts.auth.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * Authenticated password change (used for the forced first-login reset and any
 * self-service password change). The user is identified by their JWT, not by this
 * body; they must supply their current password to authorize the change.
 */
public class ChangePasswordRequestDTO {

    @NotBlank(message = "Current password is required")
    private String currentPassword;

    @NotBlank(message = "New password is required")
    private String newPassword;

    @NotBlank(message = "Password confirmation is required")
    private String confirmPassword;

    public ChangePasswordRequestDTO() {}

    public String getCurrentPassword() { return currentPassword; }
    public String getNewPassword() { return newPassword; }
    public String getConfirmPassword() { return confirmPassword; }

    public void setCurrentPassword(String v) { this.currentPassword = v; }
    public void setNewPassword(String v) { this.newPassword = v; }
    public void setConfirmPassword(String v) { this.confirmPassword = v; }
}
