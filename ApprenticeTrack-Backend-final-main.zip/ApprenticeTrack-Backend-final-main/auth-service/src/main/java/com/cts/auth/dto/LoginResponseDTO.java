package com.cts.auth.dto;

import com.cts.auth.common.UserRole;

public class LoginResponseDTO {

    private Long userID;
    private String name;
    private UserRole role;
    private Long instituteID;
    private String accessToken;
    private long expiresInSeconds;
    private String tokenType;
    /** True when the user must change their password before proceeding (first login). */
    private boolean mustChangePassword;

    public LoginResponseDTO() {}

    public Long getUserID() { return userID; }
    public String getName() { return name; }
    public UserRole getRole() { return role; }
    public Long getInstituteID() { return instituteID; }
    public String getAccessToken() { return accessToken; }
    public long getExpiresInSeconds() { return expiresInSeconds; }
    public String getTokenType() { return tokenType; }
    public boolean isMustChangePassword() { return mustChangePassword; }

    public void setUserID(Long v) { this.userID = v; }
    public void setName(String v) { this.name = v; }
    public void setRole(UserRole v) { this.role = v; }
    public void setInstituteID(Long v) { this.instituteID = v; }
    public void setAccessToken(String v) { this.accessToken = v; }
    public void setExpiresInSeconds(long v) { this.expiresInSeconds = v; }
    public void setTokenType(String v) { this.tokenType = v; }
    public void setMustChangePassword(boolean v) { this.mustChangePassword = v; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long userID, instituteID; private String name, accessToken, tokenType;
        private UserRole role; private long expiresInSeconds;
        private boolean mustChangePassword;

        public Builder userID(Long v) { this.userID = v; return this; }
        public Builder name(String v) { this.name = v; return this; }
        public Builder role(UserRole v) { this.role = v; return this; }
        public Builder instituteID(Long v) { this.instituteID = v; return this; }
        public Builder accessToken(String v) { this.accessToken = v; return this; }
        public Builder expiresInSeconds(long v) { this.expiresInSeconds = v; return this; }
        public Builder tokenType(String v) { this.tokenType = v; return this; }
        public Builder mustChangePassword(boolean v) { this.mustChangePassword = v; return this; }

        public LoginResponseDTO build() {
            LoginResponseDTO d = new LoginResponseDTO();
            d.userID = userID; d.name = name; d.role = role; d.instituteID = instituteID;
            d.accessToken = accessToken;
            d.expiresInSeconds = expiresInSeconds; d.tokenType = tokenType;
            d.mustChangePassword = mustChangePassword;
            return d;
        }
    }
}