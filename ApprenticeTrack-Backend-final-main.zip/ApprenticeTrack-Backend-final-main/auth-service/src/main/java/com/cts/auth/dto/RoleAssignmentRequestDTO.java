package com.cts.auth.dto;

import jakarta.validation.constraints.NotNull;

/**
 * Request body for assigning ({@code POST /api/roles/assign}) or
 * revoking ({@code DELETE /api/roles/revoke}) a role for a user.
 */
public class RoleAssignmentRequestDTO {
    @NotNull(message = "User ID is required")
    private Long userID;
    @NotNull(message = "Role ID is required")
    private Long roleID;

    public RoleAssignmentRequestDTO() {}
    public Long getUserID() { return userID; }
    public Long getRoleID() { return roleID; }
    public void setUserID(Long v) { this.userID = v; }
    public void setRoleID(Long v) { this.roleID = v; }
}
