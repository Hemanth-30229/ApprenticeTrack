package com.cts.auth.dto;

import java.util.ArrayList;
import java.util.List;

import com.cts.auth.common.RoleStatus;

public class RoleResponseDTO {
    private Long roleID;
    private String roleName;
    private List<String> permissions = new ArrayList<>();
    private String description;
    private RoleStatus status;

    public RoleResponseDTO() {}
    public Long getRoleID() { return roleID; }
    public String getRoleName() { return roleName; }
    public List<String> getPermissions() { return permissions; }
    public String getDescription() { return description; }
    public RoleStatus getStatus() { return status; }
    public void setRoleID(Long v) { this.roleID = v; }
    public void setRoleName(String v) { this.roleName = v; }
    public void setPermissions(List<String> v) { this.permissions = v; }
    public void setDescription(String v) { this.description = v; }
    public void setStatus(RoleStatus v) { this.status = v; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long roleID;
        private String roleName;
        private List<String> permissions = new ArrayList<>();
        private String description;
        private RoleStatus status;
        public Builder roleID(Long v) { this.roleID = v; return this; }
        public Builder roleName(String v) { this.roleName = v; return this; }
        public Builder permissions(List<String> v) {
            this.permissions = v != null ? v : new ArrayList<>(); return this;
        }
        public Builder description(String v) { this.description = v; return this; }
        public Builder status(RoleStatus v) { this.status = v; return this; }
        public RoleResponseDTO build() {
            RoleResponseDTO d = new RoleResponseDTO();
            d.roleID = roleID; d.roleName = roleName; d.permissions = permissions;
            d.description = description; d.status = status; return d;
        }
    }
}
