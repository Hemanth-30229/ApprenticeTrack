package com.cts.auth.dto;

import com.cts.auth.common.RoleStatus;

import jakarta.validation.constraints.NotNull;

public class RoleStatusUpdateRequestDTO {
    @NotNull(message = "Status is required")
    private RoleStatus status;

    public RoleStatusUpdateRequestDTO() {}
    public RoleStatus getStatus() { return status; }
    public void setStatus(RoleStatus v) { this.status = v; }
}
