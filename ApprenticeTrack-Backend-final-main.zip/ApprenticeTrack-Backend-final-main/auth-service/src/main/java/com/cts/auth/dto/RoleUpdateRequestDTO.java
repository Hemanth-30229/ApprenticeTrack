package com.cts.auth.dto;

import java.util.ArrayList;
import java.util.List;

import jakarta.validation.constraints.NotBlank;

public class RoleUpdateRequestDTO {
    @NotBlank(message = "Role name is required")
    private String roleName;
    private List<String> permissions = new ArrayList<>();
    private String description;

    public RoleUpdateRequestDTO() {}
    public String getRoleName() { return roleName; }
    public List<String> getPermissions() { return permissions; }
    public String getDescription() { return description; }
    public void setRoleName(String v) { this.roleName = v; }
    public void setPermissions(List<String> v) { this.permissions = v; }
    public void setDescription(String v) { this.description = v; }
}
