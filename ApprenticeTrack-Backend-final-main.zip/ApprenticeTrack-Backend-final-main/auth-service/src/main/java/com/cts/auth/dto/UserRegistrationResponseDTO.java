package com.cts.auth.dto;

import com.cts.auth.common.UserRole;
import com.cts.auth.common.UserStatus;

public class UserRegistrationResponseDTO {

    private Long userID;
    private String name;
    private UserRole role;
    private String email;
    private String phone;
    private Long instituteID;
    private UserStatus status;

    public UserRegistrationResponseDTO() {}

    public Long getUserID() { return userID; }
    public String getName() { return name; }
    public UserRole getRole() { return role; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public Long getInstituteID() { return instituteID; }
    public UserStatus getStatus() { return status; }

    public void setUserID(Long userID) { this.userID = userID; }
    public void setName(String name) { this.name = name; }
    public void setRole(UserRole role) { this.role = role; }
    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setInstituteID(Long instituteID) { this.instituteID = instituteID; }
    public void setStatus(UserStatus status) { this.status = status; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long userID; private String name, email, phone;
        private UserRole role; private Long instituteID; private UserStatus status;

        public Builder userID(Long v) { this.userID = v; return this; }
        public Builder name(String v) { this.name = v; return this; }
        public Builder role(UserRole v) { this.role = v; return this; }
        public Builder email(String v) { this.email = v; return this; }
        public Builder phone(String v) { this.phone = v; return this; }
        public Builder instituteID(Long v) { this.instituteID = v; return this; }
        public Builder status(UserStatus v) { this.status = v; return this; }

        public UserRegistrationResponseDTO build() {
            UserRegistrationResponseDTO d = new UserRegistrationResponseDTO();
            d.userID = userID; d.name = name; d.role = role; d.email = email;
            d.phone = phone; d.instituteID = instituteID; d.status = status;
            return d;
        }
    }
}