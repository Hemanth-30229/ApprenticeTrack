package com.cts.auth.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * Roles currently assigned to a user together with the effective (resolved) permissions.
 */
public class UserRolesResponseDTO {
    private Long userID;
    private List<RoleResponseDTO> roles = new ArrayList<>();
    private List<String> effectivePermissions = new ArrayList<>();

    public UserRolesResponseDTO() {}
    public Long getUserID() { return userID; }
    public List<RoleResponseDTO> getRoles() { return roles; }
    public List<String> getEffectivePermissions() { return effectivePermissions; }
    public void setUserID(Long v) { this.userID = v; }
    public void setRoles(List<RoleResponseDTO> v) { this.roles = v; }
    public void setEffectivePermissions(List<String> v) { this.effectivePermissions = v; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long userID;
        private List<RoleResponseDTO> roles = new ArrayList<>();
        private List<String> effectivePermissions = new ArrayList<>();
        public Builder userID(Long v) { this.userID = v; return this; }
        public Builder roles(List<RoleResponseDTO> v) {
            this.roles = v != null ? v : new ArrayList<>(); return this;
        }
        public Builder effectivePermissions(List<String> v) {
            this.effectivePermissions = v != null ? v : new ArrayList<>(); return this;
        }
        public UserRolesResponseDTO build() {
            UserRolesResponseDTO d = new UserRolesResponseDTO();
            d.userID = userID; d.roles = roles; d.effectivePermissions = effectivePermissions;
            return d;
        }
    }
}
