package com.cts.auth.dto;

import com.cts.auth.common.UserRole;
import com.cts.auth.common.UserStatus;

/**
 * Lightweight user view returned by the cross-service read endpoints
 * ({@code GET /api/users/{id}}, {@code GET /api/users/assessors}) that other
 * services' {@code AuthClient} calls — e.g. assessment-service and
 * ojt-stipend-service resolving a userID to a name, or assessment-service
 * listing active assessors (MIGRATION_PLAN.md §6). Distinct from
 * {@link UserRegistrationResponseDTO} since that one is scoped to the
 * registration response.
 */
public class UserSummaryResponseDTO {

    private Long userID;
    private String name;
    private String email;
    private UserRole role;
    private UserStatus status;

    public UserSummaryResponseDTO() {}

    public Long getUserID() { return userID; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public UserRole getRole() { return role; }
    public UserStatus getStatus() { return status; }

    public void setUserID(Long userID) { this.userID = userID; }
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setRole(UserRole role) { this.role = role; }
    public void setStatus(UserStatus status) { this.status = status; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long userID;
        private String name;
        private String email;
        private UserRole role;
        private UserStatus status;

        public Builder userID(Long v) { this.userID = v; return this; }
        public Builder name(String v) { this.name = v; return this; }
        public Builder email(String v) { this.email = v; return this; }
        public Builder role(UserRole v) { this.role = v; return this; }
        public Builder status(UserStatus v) { this.status = v; return this; }

        public UserSummaryResponseDTO build() {
            UserSummaryResponseDTO d = new UserSummaryResponseDTO();
            d.userID = userID; d.name = name; d.email = email;
            d.role = role; d.status = status;
            return d;
        }
    }
}
