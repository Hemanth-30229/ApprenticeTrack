package com.cts.auth.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "login_attempts")
public class LoginAttempt {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private int failedCount;

    @Column(nullable = false)
    private LocalDateTime windowStart;

    @Column
    private LocalDateTime lockedUntil;

    public LoginAttempt() {}

    // â”€â”€ Getters â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public Long getId() { return id; }
    public String getEmail() { return email; }
    public int getFailedCount() { return failedCount; }
    public LocalDateTime getWindowStart() { return windowStart; }
    public LocalDateTime getLockedUntil() { return lockedUntil; }

    // â”€â”€ Setters â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public void setId(Long id) { this.id = id; }
    public void setEmail(String email) { this.email = email; }
    public void setFailedCount(int failedCount) { this.failedCount = failedCount; }
    public void setWindowStart(LocalDateTime windowStart) { this.windowStart = windowStart; }
    public void setLockedUntil(LocalDateTime lockedUntil) { this.lockedUntil = lockedUntil; }

    // â”€â”€ Builder â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String email;
        private int failedCount = 0;
        private LocalDateTime windowStart;
        private LocalDateTime lockedUntil;

        public Builder email(String v) { this.email = v; return this; }
        public Builder failedCount(int v) { this.failedCount = v; return this; }
        public Builder windowStart(LocalDateTime v) { this.windowStart = v; return this; }
        public Builder lockedUntil(LocalDateTime v) { this.lockedUntil = v; return this; }

        public LoginAttempt build() {
            LoginAttempt la = new LoginAttempt();
            la.email = this.email; la.failedCount = this.failedCount;
            la.windowStart = this.windowStart; la.lockedUntil = this.lockedUntil;
            return la;
        }
    }
}