package com.cts.auth.entity;

import java.util.ArrayList;
import java.util.List;

import com.cts.auth.common.RoleStatus;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;

/**
 * Role definition for role-based access control.
 * Well-known role names are declared as constants; VOCATIONAL_ADMIN inherits all permissions.
 */
@Entity
@Table(name = "roles")
public class Role {

    // â”€â”€ Well-known role names â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public static final String TRAINEE = "Trainee";
    public static final String EMPLOYER = "Employer";
    public static final String ASSESSOR = "Assessor";
    public static final String PLACEMENT_OFFICER = "PlacementOfficer";
    public static final String STIPEND_ADMIN = "StipendAdmin";
    public static final String VOCATIONAL_ADMIN = "VocationalAdmin";

    /** Wildcard permission granted to VocationalAdmin (inherits all permissions). */
    public static final String ALL_PERMISSIONS = "*";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long roleID;

    @NotBlank(message = "Role name is required")
    @Column(name = "role_name", nullable = false, unique = true)
    private String roleName;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "role_permissions", joinColumns = @JoinColumn(name = "role_id"))
    @Column(name = "permission")
    private List<String> permissions = new ArrayList<>();

    @Column(length = 500)
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private RoleStatus status = RoleStatus.Active;

    public Role() {}

    /** True if this role inherits all permissions (role hierarchy top). */
    public boolean isSuperRole() {
        return VOCATIONAL_ADMIN.equalsIgnoreCase(roleName)
                || (permissions != null && permissions.contains(ALL_PERMISSIONS));
    }

    // â”€â”€ Getters â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public Long getRoleID() { return roleID; }
    public String getRoleName() { return roleName; }
    public List<String> getPermissions() { return permissions; }
    public String getDescription() { return description; }
    public RoleStatus getStatus() { return status; }

    // â”€â”€ Setters â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public void setRoleID(Long roleID) { this.roleID = roleID; }
    public void setRoleName(String roleName) { this.roleName = roleName; }
    public void setPermissions(List<String> permissions) { this.permissions = permissions; }
    public void setDescription(String description) { this.description = description; }
    public void setStatus(RoleStatus status) { this.status = status; }

    // â”€â”€ Builder â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long roleID;
        private String roleName;
        private List<String> permissions = new ArrayList<>();
        private String description;
        private RoleStatus status = RoleStatus.Active;

        public Builder roleID(Long v) { this.roleID = v; return this; }
        public Builder roleName(String v) { this.roleName = v; return this; }
        public Builder permissions(List<String> v) {
            this.permissions = v != null ? v : new ArrayList<>(); return this;
        }
        public Builder description(String v) { this.description = v; return this; }
        public Builder status(RoleStatus v) { this.status = v; return this; }

        public Role build() {
            Role r = new Role();
            r.roleID = this.roleID; r.roleName = this.roleName;
            r.permissions = this.permissions; r.description = this.description;
            r.status = this.status;
            return r;
        }
    }
}
