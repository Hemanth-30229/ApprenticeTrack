package com.cts.auth.entity;

import com.cts.auth.common.UserRole;
import com.cts.auth.common.UserStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userID;

    @NotBlank(message = "Name is required")
    @Column(nullable = false)
    private String name;

    @NotNull(message = "Role is required")
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private UserRole role;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    @NotBlank(message = "Phone is required")
    @Pattern(regexp = "^[6-9]\\d{9}$", message = "Phone must be a valid 10-digit Indian mobile number")
    @Column(nullable = false)
    private String phone;

    @NotNull(message = "InstituteID is required")
    @Column(nullable = false)
    private Long instituteID;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private UserStatus status = UserStatus.Active;

    /**
     * Access tokens issued before this instant are rejected. Bumped on password reset to
     * invalidate all existing JWT sessions. Null means no cut-off (all tokens accepted).
     */
    @Column(name = "tokens_valid_after")
    private java.time.Instant tokensValidAfter;

    /**
     * When true, the user is forced to change their password before using the app.
     * Set on admin-created accounts (the admin supplies a temporary password) and
     * cleared after the user completes their first password change. Defaults to false
     * so existing accounts and the seeded admin are unaffected.
     */
    @Column(name = "must_change_password", nullable = false)
    private boolean mustChangePassword = false;

    public User() {}

    public User(Long userID, String name, UserRole role, String email, String password,
                String phone, Long instituteID, UserStatus status) {
        this.userID = userID;
        this.name = name;
        this.role = role;
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.instituteID = instituteID;
        this.status = status;
    }

    // â”€â”€ Getters â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public Long getUserID() { return userID; }
    public String getName() { return name; }
    public UserRole getRole() { return role; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public String getPhone() { return phone; }
    public Long getInstituteID() { return instituteID; }
    public UserStatus getStatus() { return status; }
    public java.time.Instant getTokensValidAfter() { return tokensValidAfter; }
    public boolean isMustChangePassword() { return mustChangePassword; }

    // â”€â”€ Setters â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public void setUserID(Long userID) { this.userID = userID; }
    public void setName(String name) { this.name = name; }
    public void setRole(UserRole role) { this.role = role; }
    public void setEmail(String email) { this.email = email; }
    public void setPassword(String password) { this.password = password; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setInstituteID(Long instituteID) { this.instituteID = instituteID; }
    public void setStatus(UserStatus status) { this.status = status; }
    public void setTokensValidAfter(java.time.Instant tokensValidAfter) { this.tokensValidAfter = tokensValidAfter; }
    public void setMustChangePassword(boolean mustChangePassword) { this.mustChangePassword = mustChangePassword; }

    // â”€â”€ Builder â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long userID;
        private String name;
        private UserRole role;
        private String email;
        private String password;
        private String phone;
        private Long instituteID;
        private UserStatus status = UserStatus.Active;
        private boolean mustChangePassword = false;

        public Builder userID(Long userID) { this.userID = userID; return this; }
        public Builder name(String name) { this.name = name; return this; }
        public Builder role(UserRole role) { this.role = role; return this; }
        public Builder email(String email) { this.email = email; return this; }
        public Builder password(String password) { this.password = password; return this; }
        public Builder phone(String phone) { this.phone = phone; return this; }
        public Builder instituteID(Long instituteID) { this.instituteID = instituteID; return this; }
        public Builder status(UserStatus status) { this.status = status; return this; }
        public Builder mustChangePassword(boolean mustChangePassword) { this.mustChangePassword = mustChangePassword; return this; }

        public User build() {
            User u = new User();
            u.userID = this.userID; u.name = this.name; u.role = this.role;
            u.email = this.email; u.password = this.password; u.phone = this.phone;
            u.instituteID = this.instituteID; u.status = this.status;
            u.mustChangePassword = this.mustChangePassword;
            return u;
        }
    }
}