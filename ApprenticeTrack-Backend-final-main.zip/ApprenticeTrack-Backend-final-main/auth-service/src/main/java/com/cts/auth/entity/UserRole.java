package com.cts.auth.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Assignment of a {@link Role} to a user. A user may hold multiple roles.
 */
@Entity
@Table(name = "user_roles",
    uniqueConstraints = @UniqueConstraint(name = "uq_user_role",
        columnNames = {"user_id", "role_id"}))
public class UserRole {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userRoleID;

    @Column(name = "user_id", nullable = false)
    private Long userID;

    @Column(name = "role_id", nullable = false)
    private Long roleID;

    @Column(nullable = false)
    private LocalDateTime assignedAt = LocalDateTime.now();

    public UserRole() {}

    // â”€â”€ Getters â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public Long getUserRoleID() { return userRoleID; }
    public Long getUserID() { return userID; }
    public Long getRoleID() { return roleID; }
    public LocalDateTime getAssignedAt() { return assignedAt; }

    // â”€â”€ Setters â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public void setUserRoleID(Long userRoleID) { this.userRoleID = userRoleID; }
    public void setUserID(Long userID) { this.userID = userID; }
    public void setRoleID(Long roleID) { this.roleID = roleID; }
    public void setAssignedAt(LocalDateTime assignedAt) { this.assignedAt = assignedAt; }

    // â”€â”€ Builder â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long userRoleID;
        private Long userID;
        private Long roleID;
        private LocalDateTime assignedAt = LocalDateTime.now();

        public Builder userRoleID(Long v) { this.userRoleID = v; return this; }
        public Builder userID(Long v) { this.userID = v; return this; }
        public Builder roleID(Long v) { this.roleID = v; return this; }
        public Builder assignedAt(LocalDateTime v) { this.assignedAt = v; return this; }

        public UserRole build() {
            UserRole ur = new UserRole();
            ur.userRoleID = this.userRoleID; ur.userID = this.userID;
            ur.roleID = this.roleID; ur.assignedAt = this.assignedAt;
            return ur;
        }
    }
}
