package com.cts.auth.exception;

public class DuplicateRoleAssignmentException extends RuntimeException {
    public DuplicateRoleAssignmentException(String message) {
        super(message);
    }
}
