package com.cts.auth.exception;

/**
 * Raised when deleting a user would remove the last active administrator,
 * which would leave the system with no one able to manage accounts.
 */
public class LastAdminException extends RuntimeException {
    public LastAdminException(String message) {
        super(message);
    }
}
