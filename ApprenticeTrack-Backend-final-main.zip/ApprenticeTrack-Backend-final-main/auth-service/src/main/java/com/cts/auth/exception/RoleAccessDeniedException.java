package com.cts.auth.exception;

/**
 * Thrown when an authenticated user lacks the permission required for an action.
 * Mapped to 403 Forbidden.
 */
public class RoleAccessDeniedException extends RuntimeException {
    public RoleAccessDeniedException(String message) {
        super(message);
    }
}
