package com.cts.auth.exception;

public class RoleAssignmentNotFoundException extends RuntimeException {
    public RoleAssignmentNotFoundException(String message) {
        super(message);
    }
}
