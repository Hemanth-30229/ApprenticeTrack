package com.cts.auth.exception;

public class RoleInactiveException extends RuntimeException {
    public RoleInactiveException(String message) {
        super(message);
    }
}
