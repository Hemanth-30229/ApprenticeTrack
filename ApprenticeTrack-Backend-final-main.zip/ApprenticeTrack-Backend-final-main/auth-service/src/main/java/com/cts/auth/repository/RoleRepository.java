package com.cts.auth.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.auth.common.RoleStatus;
import com.cts.auth.entity.Role;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {

    boolean existsByRoleNameIgnoreCase(String roleName);

    Optional<Role> findByRoleNameIgnoreCase(String roleName);

    List<Role> findByRoleIDIn(List<Long> roleIDs);

    /**
     * Paginated list with optional status and name filters.
     */
    @Query("SELECT r FROM Role r WHERE " +
           "(:status IS NULL OR r.status = :status) AND " +
           "(:roleName IS NULL OR LOWER(r.roleName) LIKE LOWER(CONCAT('%', :roleName, '%')))")
    Page<Role> findAllWithFilters(
            @Param("status") RoleStatus status,
            @Param("roleName") String roleName,
            Pageable pageable);
}
