package com.cts.auth.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.auth.entity.UserRole;

@Repository
public interface UserRoleRepository extends JpaRepository<UserRole, Long> {

    boolean existsByUserIDAndRoleID(Long userID, Long roleID);

    Optional<UserRole> findByUserIDAndRoleID(Long userID, Long roleID);

    List<UserRole> findByUserID(Long userID);

    long countByRoleID(Long roleID);
}
