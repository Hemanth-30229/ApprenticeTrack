package com.cts.auth.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.cts.auth.entity.User;
import com.cts.auth.repository.UserRepository;
import com.cts.auth.service.RoleService;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Enriches the authenticated principal with the fine-grained permissions resolved from the
 * RBAC tables (each becomes a {@code PERM_*} authority), honouring the role hierarchy where
 * VocationalAdmin inherits all permissions ({@code PERM_*} wildcard authority).
 *
 * <p>Runs after {@link JwtAuthFilter} so that {@code @PreAuthorize("hasAuthority('PERM_X')")}
 * checks on protected endpoints are backed by live role/permission data rather than only the
 * coarse role claim in the JWT. It never blocks a request itself â€” authorization decisions are
 * made by Spring Security, which returns 403 via {@link RestAccessDeniedHandler}.
 */
@Component
public class RolePermissionFilter extends OncePerRequestFilter {

    private final UserRepository userRepository;
    private final RoleService roleService;

    public RolePermissionFilter(UserRepository userRepository, RoleService roleService) {
        this.userRepository = userRepository;
        this.roleService = roleService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (auth != null && auth.isAuthenticated() && auth.getPrincipal() instanceof String email) {
            Optional<User> user = userRepository.findByEmail(email);
            if (user.isPresent()) {
                List<GrantedAuthority> authorities = new ArrayList<>(auth.getAuthorities());
                for (String permission : roleService.getEffectivePermissions(user.get().getUserID())) {
                    authorities.add(new SimpleGrantedAuthority("PERM_" + permission));
                }

                UsernamePasswordAuthenticationToken enriched =
                        new UsernamePasswordAuthenticationToken(
                                auth.getPrincipal(), auth.getCredentials(), authorities);
                enriched.setDetails(auth.getDetails());
                SecurityContextHolder.getContext().setAuthentication(enriched);
            }
        }

        filterChain.doFilter(request, response);
    }
}
