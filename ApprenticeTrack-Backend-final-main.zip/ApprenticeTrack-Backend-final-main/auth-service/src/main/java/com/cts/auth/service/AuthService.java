package com.cts.auth.service;

import com.cts.auth.dto.LoginRequestDTO;
import com.cts.auth.dto.LoginResponseDTO;

public interface AuthService {

    LoginResponseDTO login(LoginRequestDTO requestDTO);
}
