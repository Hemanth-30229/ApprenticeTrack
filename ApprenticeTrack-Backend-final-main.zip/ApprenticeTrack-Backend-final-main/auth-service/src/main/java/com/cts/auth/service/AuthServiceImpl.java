package com.cts.auth.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.auth.common.UserStatus;
import com.cts.auth.dto.LoginRequestDTO;
import com.cts.auth.dto.LoginResponseDTO;
import com.cts.auth.exception.InvalidCredentialsException;
import com.cts.auth.exception.UserInactiveException;
import com.cts.auth.entity.User;
import com.cts.auth.repository.RefreshTokenRepository;
import com.cts.auth.repository.UserRepository;
import com.cts.auth.security.JwtUtil;
import com.cts.auth.client.PlatformClient;
import com.cts.auth.client.dto.AuditLogRequest;

@Service
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final PlatformClient platformClient;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final LoginRateLimiterService rateLimiterService;

    public AuthServiceImpl(UserRepository userRepository,
                           PlatformClient platformClient,
                           RefreshTokenRepository refreshTokenRepository,
                           PasswordEncoder passwordEncoder,
                           JwtUtil jwtUtil,
                           LoginRateLimiterService rateLimiterService) {
        this.userRepository = userRepository;
        this.platformClient = platformClient;
        this.refreshTokenRepository = refreshTokenRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
        this.rateLimiterService = rateLimiterService;
    }

    @Override
    @Transactional
    public LoginResponseDTO login(LoginRequestDTO dto) {

        rateLimiterService.checkRateLimit(dto.getEmail());

        User user = userRepository.findByEmail(dto.getEmail())
                .orElseThrow(() -> {
                    recordFailedAudit(null, dto.getEmail());
                    rateLimiterService.recordFailure(dto.getEmail());
                    return new InvalidCredentialsException("Invalid email or password");
                });

        if (!passwordEncoder.matches(dto.getPassword(), user.getPassword())) {
            recordFailedAudit(user.getUserID(), dto.getEmail());
            rateLimiterService.recordFailure(dto.getEmail());
            throw new InvalidCredentialsException("Invalid email or password");
        }

        if (user.getStatus() == UserStatus.Inactive) {
            recordFailedAudit(user.getUserID(), dto.getEmail());
            throw new UserInactiveException("Your account is inactive. Please contact the administrator.");
        }

        rateLimiterService.recordSuccess(dto.getEmail());

        String accessToken = jwtUtil.generateAccessToken(user);

        refreshTokenRepository.deleteByUser(user);

        platformClient.recordAudit(new AuditLogRequest(user.getUserID(), "LoginSuccess", "Identity"));

        return LoginResponseDTO.builder()
                .userID(user.getUserID())
                .name(user.getName())
                .role(user.getRole())
                .instituteID(user.getInstituteID())
                .accessToken(accessToken)
                .expiresInSeconds(jwtUtil.getExpirationSeconds())
                .tokenType("Bearer")
                .mustChangePassword(user.isMustChangePassword())
                .build();
    }

    private void recordFailedAudit(Long userID, String email) {
        platformClient.recordAudit(
                new AuditLogRequest(userID != null ? userID : 0L, "LoginFailed", "Identity"));
    }
}