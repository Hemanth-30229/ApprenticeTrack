package com.cts.auth.service;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.auth.exception.AccountLockedException;
import com.cts.auth.entity.LoginAttempt;
import com.cts.auth.repository.LoginAttemptRepository;

@Service
public class LoginRateLimiterService {

    private static final int MAX_FAILED_ATTEMPTS = 5;
    private static final int WINDOW_MINUTES = 15;

    private final LoginAttemptRepository loginAttemptRepository;

    public LoginRateLimiterService(LoginAttemptRepository loginAttemptRepository) {
        this.loginAttemptRepository = loginAttemptRepository;
    }

    @Transactional
    public void checkRateLimit(String email) {
        loginAttemptRepository.findByEmail(email).ifPresent(attempt -> {
            if (attempt.getLockedUntil() != null &&
                    LocalDateTime.now().isBefore(attempt.getLockedUntil())) {
                throw new AccountLockedException(
                        "Too many failed attempts. Account locked until " + attempt.getLockedUntil());
            }
        });
    }

    @Transactional
    public void recordFailure(String email) {
        LocalDateTime now = LocalDateTime.now();
        LoginAttempt attempt = loginAttemptRepository.findByEmail(email)
                .orElse(LoginAttempt.builder()
                        .email(email)
                        .failedCount(0)
                        .windowStart(now)
                        .build());

        if (attempt.getWindowStart().plusMinutes(WINDOW_MINUTES).isBefore(now)) {
            attempt.setFailedCount(0);
            attempt.setWindowStart(now);
            attempt.setLockedUntil(null);
        }

        attempt.setFailedCount(attempt.getFailedCount() + 1);

        if (attempt.getFailedCount() >= MAX_FAILED_ATTEMPTS) {
            attempt.setLockedUntil(now.plusMinutes(WINDOW_MINUTES));
        }

        loginAttemptRepository.save(attempt);
    }

    @Transactional
    public void recordSuccess(String email) {
        loginAttemptRepository.findByEmail(email).ifPresent(attempt -> {
            attempt.setFailedCount(0);
            attempt.setLockedUntil(null);
            loginAttemptRepository.save(attempt);
        });
    }
}