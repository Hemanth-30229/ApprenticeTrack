package com.cts.auth.service;

import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.auth.dto.RoleAssignmentRequestDTO;
import com.cts.auth.dto.RoleCreateRequestDTO;
import com.cts.auth.dto.RoleResponseDTO;
import com.cts.auth.dto.RoleStatusUpdateRequestDTO;
import com.cts.auth.dto.RoleUpdateRequestDTO;
import com.cts.auth.dto.UserRolesResponseDTO;
import com.cts.auth.common.RoleStatus;

public interface RoleService {

    // â”€â”€ CRUD â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    RoleResponseDTO createRole(RoleCreateRequestDTO requestDTO);

    RoleResponseDTO getRoleById(Long roleID);

    RoleResponseDTO updateRole(Long roleID, RoleUpdateRequestDTO requestDTO);

    RoleResponseDTO updateStatus(Long roleID, RoleStatusUpdateRequestDTO requestDTO);

    void deleteRole(Long roleID);

    Page<RoleResponseDTO> getAllRoles(RoleStatus status, String roleName, Pageable pageable);

    // â”€â”€ Assignment â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    UserRolesResponseDTO assignRole(RoleAssignmentRequestDTO requestDTO);

    void revokeRole(RoleAssignmentRequestDTO requestDTO);

    UserRolesResponseDTO getUserRoles(Long userID);

    // â”€â”€ Permission enforcement â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    Set<String> getEffectivePermissions(Long userID);

    boolean hasPermission(Long userID, String permission);

    void checkPermission(Long userID, String permission);
}
