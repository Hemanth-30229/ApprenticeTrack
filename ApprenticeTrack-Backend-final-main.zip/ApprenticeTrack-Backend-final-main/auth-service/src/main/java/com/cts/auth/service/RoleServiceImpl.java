package com.cts.auth.service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.auth.dto.RoleAssignmentRequestDTO;
import com.cts.auth.dto.RoleCreateRequestDTO;
import com.cts.auth.dto.RoleResponseDTO;
import com.cts.auth.dto.RoleStatusUpdateRequestDTO;
import com.cts.auth.dto.RoleUpdateRequestDTO;
import com.cts.auth.dto.UserRolesResponseDTO;
import com.cts.auth.exception.DuplicateRoleAssignmentException;
import com.cts.auth.exception.DuplicateRoleException;
import com.cts.auth.exception.RoleAccessDeniedException;
import com.cts.auth.exception.RoleAssignmentNotFoundException;
import com.cts.auth.exception.RoleInUseException;
import com.cts.auth.exception.RoleInactiveException;
import com.cts.auth.exception.RoleNotFoundException;
import com.cts.auth.exception.UserNotFoundException;
import com.cts.auth.common.RoleStatus;
import com.cts.auth.entity.Role;
import com.cts.auth.entity.UserRole;
import com.cts.auth.repository.RoleRepository;
import com.cts.auth.repository.UserRepository;
import com.cts.auth.repository.UserRoleRepository;
import com.cts.auth.client.PlatformClient;
import com.cts.auth.client.dto.AuditLogRequest;

@Service
public class RoleServiceImpl implements RoleService {

    private static final String MODULE = "RoleManagement";

    private final RoleRepository roleRepository;
    private final UserRoleRepository userRoleRepository;
    private final UserRepository userRepository;
    private final PlatformClient platformClient;

    public RoleServiceImpl(RoleRepository roleRepository,
                           UserRoleRepository userRoleRepository,
                           UserRepository userRepository,
                           PlatformClient platformClient) {
        this.roleRepository = roleRepository;
        this.userRoleRepository = userRoleRepository;
        this.userRepository = userRepository;
        this.platformClient = platformClient;
    }

    // â”€â”€ CRUD â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    @Override
    @Transactional
    public RoleResponseDTO createRole(RoleCreateRequestDTO dto) {
        if (roleRepository.existsByRoleNameIgnoreCase(dto.getRoleName())) {
            throw new DuplicateRoleException("Role '" + dto.getRoleName() + "' already exists");
        }
        Role role = Role.builder()
                .roleName(dto.getRoleName())
                .permissions(normalize(dto.getPermissions()))
                .description(dto.getDescription())
                .status(RoleStatus.Active)
                .build();
        Role saved = roleRepository.save(role);
        audit("RoleCreated: " + saved.getRoleName());
        return toResponseDTO(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public RoleResponseDTO getRoleById(Long roleID) {
        return toResponseDTO(findRole(roleID));
    }

    @Override
    @Transactional
    public RoleResponseDTO updateRole(Long roleID, RoleUpdateRequestDTO dto) {
        Role role = findRole(roleID);
        if (!role.getRoleName().equalsIgnoreCase(dto.getRoleName())
                && roleRepository.existsByRoleNameIgnoreCase(dto.getRoleName())) {
            throw new DuplicateRoleException("Role '" + dto.getRoleName() + "' already exists");
        }
        role.setRoleName(dto.getRoleName());
        role.setPermissions(normalize(dto.getPermissions()));
        role.setDescription(dto.getDescription());
        Role updated = roleRepository.save(role);
        audit("RoleUpdated: " + updated.getRoleName());
        return toResponseDTO(updated);
    }

    @Override
    @Transactional
    public RoleResponseDTO updateStatus(Long roleID, RoleStatusUpdateRequestDTO dto) {
        Role role = findRole(roleID);
        RoleStatus current = role.getStatus();
        RoleStatus target = dto.getStatus();
        if (current == target) {
            throw new RoleInactiveException("Role is already in '" + current + "' status.");
        }
        role.setStatus(target);
        Role updated = roleRepository.save(role);
        audit("RoleStatusChanged: " + role.getRoleName() + " " + current + " -> " + target);
        return toResponseDTO(updated);
    }

    @Override
    @Transactional
    public void deleteRole(Long roleID) {
        Role role = findRole(roleID);
        if (userRoleRepository.countByRoleID(roleID) > 0) {
            throw new RoleInUseException(
                    "Role '" + role.getRoleName() + "' cannot be deleted while assigned to users.");
        }
        roleRepository.delete(role);
        audit("RoleDeleted: " + role.getRoleName());
    }

    @Override
    @Transactional(readOnly = true)
    public Page<RoleResponseDTO> getAllRoles(RoleStatus status, String roleName, Pageable pageable) {
        return roleRepository.findAllWithFilters(status, roleName, pageable)
                .map(this::toResponseDTO);
    }

    // â”€â”€ Assignment â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    @Override
    @Transactional
    public UserRolesResponseDTO assignRole(RoleAssignmentRequestDTO dto) {
        ensureUserExists(dto.getUserID());
        Role role = findRole(dto.getRoleID());
        if (role.getStatus() != RoleStatus.Active) {
            throw new RoleInactiveException(
                    "Role '" + role.getRoleName() + "' is inactive and cannot be assigned.");
        }
        if (userRoleRepository.existsByUserIDAndRoleID(dto.getUserID(), dto.getRoleID())) {
            throw new DuplicateRoleAssignmentException(
                    "User " + dto.getUserID() + " already has role '" + role.getRoleName() + "'");
        }
        userRoleRepository.save(UserRole.builder()
                .userID(dto.getUserID()).roleID(dto.getRoleID()).build());
        audit("RoleAssigned: role=" + role.getRoleName() + " user=" + dto.getUserID());
        return getUserRoles(dto.getUserID());
    }

    @Override
    @Transactional
    public void revokeRole(RoleAssignmentRequestDTO dto) {
        ensureUserExists(dto.getUserID());
        UserRole assignment = userRoleRepository
                .findByUserIDAndRoleID(dto.getUserID(), dto.getRoleID())
                .orElseThrow(() -> new RoleAssignmentNotFoundException(
                        "User " + dto.getUserID() + " does not have role " + dto.getRoleID()));
        userRoleRepository.delete(assignment);
        audit("RoleRevoked: role=" + dto.getRoleID() + " user=" + dto.getUserID());
    }

    @Override
    @Transactional(readOnly = true)
    public UserRolesResponseDTO getUserRoles(Long userID) {
        ensureUserExists(userID);
        List<Role> roles = assignedRoles(userID);
        List<RoleResponseDTO> roleDTOs = roles.stream()
                .map(this::toResponseDTO).collect(Collectors.toList());
        Set<String> effective = resolveEffectivePermissions(roles);
        return UserRolesResponseDTO.builder()
                .userID(userID)
                .roles(roleDTOs)
                .effectivePermissions(new ArrayList<>(effective))
                .build();
    }

    // â”€â”€ Permission enforcement â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    @Override
    @Transactional(readOnly = true)
    public Set<String> getEffectivePermissions(Long userID) {
        return resolveEffectivePermissions(assignedRoles(userID));
    }

    @Override
    @Transactional(readOnly = true)
    public boolean hasPermission(Long userID, String permission) {
        return permissionGranted(resolveEffectivePermissions(assignedRoles(userID)), permission);
    }

    @Override
    @Transactional(readOnly = true)
    public void checkPermission(Long userID, String permission) {
        if (!hasPermission(userID, permission)) {
            throw new RoleAccessDeniedException(
                    "Access denied: user " + userID + " lacks permission '" + permission + "'");
        }
    }

    /**
     * Resolves the effective permission set for a set of assigned roles, honouring the
     * role hierarchy: a Vocational Admin (super) role inherits ALL permissions ("*").
     * Only {@link RoleStatus#Active} roles contribute. Pure function â€” no I/O â€” to keep the
     * hierarchy logic unit-testable in isolation.
     */
    public static Set<String> resolveEffectivePermissions(List<Role> roles) {
        Set<String> effective = new LinkedHashSet<>();
        if (roles == null) {
            return effective;
        }
        for (Role role : roles) {
            if (role == null || role.getStatus() != RoleStatus.Active) {
                continue;
            }
            if (role.isSuperRole()) {
                effective.clear();
                effective.add(Role.ALL_PERMISSIONS);
                return effective;
            }
            if (role.getPermissions() != null) {
                effective.addAll(role.getPermissions());
            }
        }
        return effective;
    }

    /** True if the effective permission set grants {@code permission} (wildcard aware). */
    public static boolean permissionGranted(Set<String> effective, String permission) {
        return effective != null
                && (effective.contains(Role.ALL_PERMISSIONS) || effective.contains(permission));
    }

    // â”€â”€ Helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    private List<Role> assignedRoles(Long userID) {
        List<Long> roleIDs = userRoleRepository.findByUserID(userID).stream()
                .map(UserRole::getRoleID).collect(Collectors.toList());
        return roleIDs.isEmpty() ? new ArrayList<>() : roleRepository.findByRoleIDIn(roleIDs);
    }

    private Role findRole(Long roleID) {
        return roleRepository.findById(roleID)
                .orElseThrow(() -> new RoleNotFoundException("Role not found with ID: " + roleID));
    }

    private void ensureUserExists(Long userID) {
        if (!userRepository.existsById(userID)) {
            throw new UserNotFoundException("User not found with ID: " + userID);
        }
    }

    private List<String> normalize(List<String> permissions) {
        if (permissions == null) {
            return new ArrayList<>();
        }
        return permissions.stream()
                .filter(p -> p != null && !p.isBlank())
                .map(String::trim)
                .distinct()
                .collect(Collectors.toList());
    }

    private void audit(String action) {
        platformClient.recordAudit(new AuditLogRequest(0L, action, MODULE));
    }

    private RoleResponseDTO toResponseDTO(Role r) {
        return RoleResponseDTO.builder()
                .roleID(r.getRoleID())
                .roleName(r.getRoleName())
                .permissions(new ArrayList<>(r.getPermissions()))
                .description(r.getDescription())
                .status(r.getStatus())
                .build();
    }
}
