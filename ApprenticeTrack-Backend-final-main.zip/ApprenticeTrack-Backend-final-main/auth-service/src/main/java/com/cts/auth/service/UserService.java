package com.cts.auth.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.auth.dto.AdminResetPasswordRequestDTO;
import com.cts.auth.dto.ChangePasswordRequestDTO;
import com.cts.auth.dto.UserRegistrationRequestDTO;
import com.cts.auth.dto.UserRegistrationResponseDTO;
import com.cts.auth.dto.UserSummaryResponseDTO;

public interface UserService {

    UserRegistrationResponseDTO registerUser(UserRegistrationRequestDTO requestDTO);

    /** Paginated, optionally filtered user directory for the Admin console. */
    Page<UserSummaryResponseDTO> listUsers(String role, String status, String search, Pageable pageable);

    /**
     * Resolves a user by ID for other services' {@code AuthClient} (e.g. resolving
     * an assessor/supervisor/trainer name). Throws {@code UserNotFoundException}
     * (mapped to 404) when no such user exists — combined with the Feign circuit
     * breaker, callers see this the same way as a connectivity failure: a null
     * result from their fallback.
     */
    UserSummaryResponseDTO getUserById(Long userId);

    /** Active users holding a given role, e.g. Assessor — replaces {@code UserRepository.findByRoleAndStatus}. */
    List<UserSummaryResponseDTO> getUsersByRoleAndStatus(String role, String status);

    /** Admin action: permanently delete a user account (and its auth-side dependents). */
    void deleteUser(Long userId);

    /** Self-service: the signed-in user (resolved by email) deletes their own account. */
    void deleteOwnAccount(String email);

    /**
     * Authenticated password change for the signed-in user (resolved by email).
     * Verifies the current password, enforces strength/confirmation rules, updates the
     * password, and clears the first-login "must change password" flag.
     */
    void changePassword(String email, ChangePasswordRequestDTO requestDTO);

    /**
     * Admin action: set a new (temporary) password on any user's account. Sets the
     * "must change password" flag so the user is forced to change it on next login,
     * and invalidates the target's existing sessions/refresh tokens.
     */
    void resetPasswordByAdmin(Long userId, AdminResetPasswordRequestDTO requestDTO);
}
