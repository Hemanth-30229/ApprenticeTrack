package com.cts.auth.service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.criteria.Predicate;

import com.cts.auth.common.UserRole;
import com.cts.auth.common.UserStatus;
import com.cts.auth.dto.AdminResetPasswordRequestDTO;
import com.cts.auth.dto.ChangePasswordRequestDTO;
import com.cts.auth.dto.UserRegistrationRequestDTO;
import com.cts.auth.dto.UserRegistrationResponseDTO;
import com.cts.auth.dto.UserSummaryResponseDTO;
import com.cts.auth.exception.DuplicateEmailException;
import com.cts.auth.exception.InvalidCredentialsException;
import com.cts.auth.exception.LastAdminException;
import com.cts.auth.exception.PasswordMismatchException;
import com.cts.auth.exception.UserNotFoundException;
import com.cts.auth.exception.WeakPasswordException;
import com.cts.auth.entity.User;
import com.cts.auth.repository.RefreshTokenRepository;
import com.cts.auth.repository.UserRepository;
import com.cts.auth.repository.UserRoleRepository;
import com.cts.auth.client.PlatformClient;
import com.cts.auth.client.dto.AuditLogRequest;

@Service
public class UserServiceImpl implements UserService {

    /** >=8 chars, >=1 uppercase, >=1 digit, >=1 special char (mirrors the reset-password rule). */
    private static final Pattern STRONG_PASSWORD = Pattern.compile(
            "^(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,}$");

    private final UserRepository userRepository;
    private final PlatformClient platformClient;
    private final PasswordEncoder passwordEncoder;
    private final RefreshTokenRepository refreshTokenRepository;
    private final UserRoleRepository userRoleRepository;

    public UserServiceImpl(UserRepository userRepository,
                           PlatformClient platformClient,
                           PasswordEncoder passwordEncoder,
                           RefreshTokenRepository refreshTokenRepository,
                           UserRoleRepository userRoleRepository) {
        this.userRepository = userRepository;
        this.platformClient = platformClient;
        this.passwordEncoder = passwordEncoder;
        this.refreshTokenRepository = refreshTokenRepository;
        this.userRoleRepository = userRoleRepository;
    }

    @Override
    @Transactional
    public UserRegistrationResponseDTO registerUser(UserRegistrationRequestDTO dto) {

        // Check email uniqueness
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new DuplicateEmailException("Email already registered: " + dto.getEmail());
        }

        // Build user with BCrypt-encoded password
        User user = User.builder()
                .name(dto.getName())
                .role(dto.getRole())
                .email(dto.getEmail())
                .password(passwordEncoder.encode(dto.getPassword()))
                .phone(dto.getPhone())
                .instituteID(dto.getInstituteID())
                .status(UserStatus.Active)
                // Admin supplies a temporary password; force the user to change it on first login.
                .mustChangePassword(true)
                .build();

        User saved = userRepository.save(user);

        platformClient.recordAudit(new AuditLogRequest(saved.getUserID(), "UserRegistered", "Identity"));

        return UserRegistrationResponseDTO.builder()
                .userID(saved.getUserID())
                .name(saved.getName())
                .role(saved.getRole())
                .email(saved.getEmail())
                .phone(saved.getPhone())
                .instituteID(saved.getInstituteID())
                .status(saved.getStatus())
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public UserSummaryResponseDTO getUserById(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));
        return toSummaryDTO(user);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<UserSummaryResponseDTO> listUsers(String role, String status, String search, Pageable pageable) {
        final UserRole roleEnum = (role != null && !role.isBlank()) ? UserRole.valueOf(role) : null;
        final UserStatus statusEnum = (status != null && !status.isBlank()) ? UserStatus.valueOf(status) : null;
        final String term = (search != null && !search.isBlank()) ? search.trim().toLowerCase() : null;

        // Dynamic Specification: only add a predicate for filters that are set,
        // so we never bind a null enum parameter (which Hibernate can't type).
        Specification<User> spec = (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            if (roleEnum != null) predicates.add(cb.equal(root.get("role"), roleEnum));
            if (statusEnum != null) predicates.add(cb.equal(root.get("status"), statusEnum));
            if (term != null) {
                String like = "%" + term + "%";
                predicates.add(cb.or(
                        cb.like(cb.lower(root.<String>get("name")), like),
                        cb.like(cb.lower(root.<String>get("email")), like)));
            }
            return cb.and(predicates.toArray(new Predicate[0]));
        };

        return userRepository.findAll(spec, pageable).map(this::toSummaryDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserSummaryResponseDTO> getUsersByRoleAndStatus(String role, String status) {
        UserRole roleEnum = UserRole.valueOf(role);
        UserStatus statusEnum = UserStatus.valueOf(status);
        return userRepository.findByRoleAndStatus(roleEnum, statusEnum).stream()
                .map(this::toSummaryDTO)
                .toList();
    }

    @Override
    @Transactional
    public void deleteUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));

        // Safety guard: never remove the last active administrator, or the system
        // would be left with no one able to manage accounts.
        if (user.getRole() == UserRole.Admin && user.getStatus() == UserStatus.Active
                && userRepository.countByRoleAndStatus(UserRole.Admin, UserStatus.Active) <= 1) {
            throw new LastAdminException("Cannot delete the last active administrator account.");
        }

        // Remove auth-side dependents first. RefreshToken has a FK to users; the
        // user_roles links reference the userID. (PasswordResetToken/LoginAttempt
        // are keyed by email, not a user FK, so they need no cleanup here.)
        refreshTokenRepository.deleteByUser(user);
        List<com.cts.auth.entity.UserRole> roleLinks = userRoleRepository.findByUserID(userId);
        if (!roleLinks.isEmpty()) {
            userRoleRepository.deleteAll(roleLinks);
        }

        userRepository.delete(user);
        platformClient.recordAudit(new AuditLogRequest(userId, "UserDeleted", "Identity"));
    }

    @Override
    @Transactional
    public void deleteOwnAccount(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("No account found for the current user."));
        deleteUser(user.getUserID());
    }

    @Override
    @Transactional
    public void changePassword(String email, ChangePasswordRequestDTO dto) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("No account found for the current user."));

        if (!passwordEncoder.matches(dto.getCurrentPassword(), user.getPassword())) {
            throw new InvalidCredentialsException("Current password is incorrect");
        }
        if (!dto.getNewPassword().equals(dto.getConfirmPassword())) {
            throw new PasswordMismatchException("Passwords do not match");
        }
        if (!STRONG_PASSWORD.matcher(dto.getNewPassword()).matches()) {
            throw new WeakPasswordException(
                    "Password must be at least 8 characters and include an uppercase letter, "
                    + "a number, and a special character.");
        }
        if (passwordEncoder.matches(dto.getNewPassword(), user.getPassword())) {
            throw new WeakPasswordException("New password must be different from the current password.");
        }

        user.setPassword(passwordEncoder.encode(dto.getNewPassword()));
        user.setMustChangePassword(false);
        userRepository.save(user);

        platformClient.recordAudit(new AuditLogRequest(user.getUserID(), "PasswordChanged", "Identity"));
    }

    @Override
    @Transactional
    public void resetPasswordByAdmin(Long userId, AdminResetPasswordRequestDTO dto) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));

        if (!dto.getNewPassword().equals(dto.getConfirmPassword())) {
            throw new PasswordMismatchException("Passwords do not match");
        }
        if (!STRONG_PASSWORD.matcher(dto.getNewPassword()).matches()) {
            throw new WeakPasswordException(
                    "Password must be at least 8 characters and include an uppercase letter, "
                    + "a number, and a special character.");
        }

        user.setPassword(passwordEncoder.encode(dto.getNewPassword()));
        // Force the user to change this admin-set temporary password on first login.
        user.setMustChangePassword(true);
        // Invalidate all existing JWT sessions and refresh tokens for the target user.
        user.setTokensValidAfter(Instant.now());
        userRepository.save(user);
        refreshTokenRepository.deleteByUser(user);

        platformClient.recordAudit(new AuditLogRequest(user.getUserID(), "PasswordReset", "Identity"));
    }

    private UserSummaryResponseDTO toSummaryDTO(User user) {
        return UserSummaryResponseDTO.builder()
                .userID(user.getUserID())
                .name(user.getName())
                .email(user.getEmail())
                .role(user.getRole())
                .status(user.getStatus())
                .build();
    }
}