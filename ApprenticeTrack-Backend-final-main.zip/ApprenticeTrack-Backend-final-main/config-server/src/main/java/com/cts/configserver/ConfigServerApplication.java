package com.cts.configserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

/**
 * Spring Cloud Config Server for the ApprenticeTrack platform.
 *
 * <p>Serves centralized configuration to every microservice from the bundled
 * native config repository ({@code classpath:/config-repo}) and registers
 * itself with Eureka so services can locate it via discovery.</p>
 */
@EnableConfigServer
@SpringBootApplication
public class ConfigServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConfigServerApplication.class, args);
        System.out.println("Config server running on port 8888");
    }
}