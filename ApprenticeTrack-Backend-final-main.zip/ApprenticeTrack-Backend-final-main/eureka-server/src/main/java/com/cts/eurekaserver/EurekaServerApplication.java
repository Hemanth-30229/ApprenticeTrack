package com.cts.eurekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * Netflix Eureka service registry for the ApprenticeTrack platform.
 *
 * <p>All microservices register here and use it to discover one another for
 * load-balanced ({@code lb://}) Feign and Gateway routing.</p>
 */
@EnableEurekaServer
@SpringBootApplication
public class EurekaServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(EurekaServerApplication.class, args);
        System.out.println("Eureka server running on port 8761");
    }
}