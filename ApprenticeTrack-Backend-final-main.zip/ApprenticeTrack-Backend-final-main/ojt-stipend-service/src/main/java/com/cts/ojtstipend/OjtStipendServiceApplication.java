package com.cts.ojtstipend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Ojt-stipend-service: OJT logs, monthly attendance summaries, and stipend
 * disbursements (MIGRATION_PLAN.md §1). Supervisor identity and stipend eligibility
 * validation go through auth-service and placement-service via Resilience4j-backed
 * Feign clients; audit/notification go to platform-service.
 */
@SpringBootApplication
@EnableFeignClients
public class OjtStipendServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(OjtStipendServiceApplication.class, args);
    }
}
