package com.cts.ojtstipend.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cts.ojtstipend.client.dto.UserContract;

/**
 * Degraded-mode fallback for {@link AuthClient}. When auth-service is unreachable, the
 * user lookup returns {@code null} (callers fail closed with not-found / unauthorized).
 */
@Component
public class AuthClientFallback implements AuthClient {

    private static final Logger log = LoggerFactory.getLogger(AuthClientFallback.class);

    @Override
    public UserContract getUser(Long userId) {
        log.warn("auth-service unavailable; cannot resolve userID={}", userId);
        return null;
    }
}
