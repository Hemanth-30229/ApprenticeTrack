package com.cts.ojtstipend.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cts.ojtstipend.client.dto.PlacementContract;
import com.cts.ojtstipend.client.dto.VacancyContract;

/**
 * Feign client to placement-service, which owns placements and vacancies
 * (MIGRATION_PLAN.md §6). Replaces the in-process {@code PlacementRepository} and
 * {@code ApprenticeshipVacancyRepository} reads the monolith OJT-log/stipend code
 * performed. Guarded by {@link PlacementClientFallback}.
 */
@FeignClient(name = "placement-service", fallback = PlacementClientFallback.class)
public interface PlacementClient {

    /** Returns the placement, or {@code null} if placement-service reports none. */
    @GetMapping("/api/placements/{placementId}")
    PlacementContract getPlacement(@PathVariable("placementId") Long placementId);

    /** Returns the vacancy, or {@code null} if placement-service reports none. */
    @GetMapping("/api/vacancies/{vacancyId}")
    VacancyContract getVacancy(@PathVariable("vacancyId") Long vacancyId);
}
