package com.cts.ojtstipend.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cts.ojtstipend.client.dto.PlacementContract;
import com.cts.ojtstipend.client.dto.VacancyContract;

/**
 * Degraded-mode fallback for {@link PlacementClient}. When placement-service is
 * unreachable, both lookups return {@code null} (callers fail closed with not-found).
 */
@Component
public class PlacementClientFallback implements PlacementClient {

    private static final Logger log = LoggerFactory.getLogger(PlacementClientFallback.class);

    @Override
    public PlacementContract getPlacement(Long placementId) {
        log.warn("placement-service unavailable; cannot resolve placementID={}", placementId);
        return null;
    }

    @Override
    public VacancyContract getVacancy(Long vacancyId) {
        log.warn("placement-service unavailable; cannot resolve vacancyID={}", vacancyId);
        return null;
    }
}
