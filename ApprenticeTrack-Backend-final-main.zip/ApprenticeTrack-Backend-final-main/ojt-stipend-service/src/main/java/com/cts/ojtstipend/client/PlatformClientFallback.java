package com.cts.ojtstipend.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cts.ojtstipend.client.dto.AuditLogRequest;
import com.cts.ojtstipend.client.dto.NotificationRequest;

/**
 * Degraded-mode fallback for {@link PlatformClient}. Audit and notification are non-critical
 * to the OJT-log/stipend transaction, so when platform-service is unreachable the failure is
 * logged and swallowed rather than failing the operation.
 */
@Component
public class PlatformClientFallback implements PlatformClient {

    private static final Logger log = LoggerFactory.getLogger(PlatformClientFallback.class);

    @Override
    public void recordAudit(AuditLogRequest request) {
        log.warn("platform-service unavailable; audit entry dropped: userID={} action={} module={}",
                request.getUserID(), request.getAction(), request.getModule());
    }

    @Override
    public void notify(NotificationRequest request) {
        log.warn("platform-service unavailable; notification dropped: {}={} category={}",
                request.getRecipientType(), request.getRecipientID(), request.getCategory());
    }
}
