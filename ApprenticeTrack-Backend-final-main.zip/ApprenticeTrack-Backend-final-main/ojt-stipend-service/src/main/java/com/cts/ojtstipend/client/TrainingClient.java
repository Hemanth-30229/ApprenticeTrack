package com.cts.ojtstipend.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cts.ojtstipend.client.dto.EnrollmentContract;
import com.cts.ojtstipend.client.dto.TradeCourseContract;

/**
 * Feign client to training-service, which owns trainees, courses and enrollments
 * (MIGRATION_PLAN.md §6). Used to resolve a placement's trainee to their active
 * course so attendance can derive the required OJT working days from the course's
 * {@code ojtWeeks}. Guarded by {@link TrainingClientFallback}.
 */
@FeignClient(name = "training-service", fallback = TrainingClientFallback.class)
public interface TrainingClient {

    /** All enrollments for a trainee — used to find the active (OJTInProgress) course. */
    @GetMapping("/api/enrollments/trainee/{traineeId}")
    List<EnrollmentContract> getEnrollmentsForTrainee(@PathVariable("traineeId") Long traineeId);

    /** Returns the course (including its OJT-week split), or {@code null} if none. */
    @GetMapping("/api/trade-courses/{courseId}")
    TradeCourseContract getCourse(@PathVariable("courseId") Long courseId);
}
