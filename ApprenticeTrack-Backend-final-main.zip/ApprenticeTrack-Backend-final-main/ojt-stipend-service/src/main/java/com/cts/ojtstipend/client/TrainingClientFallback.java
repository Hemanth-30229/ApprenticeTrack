package com.cts.ojtstipend.client;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cts.ojtstipend.client.dto.EnrollmentContract;
import com.cts.ojtstipend.client.dto.TradeCourseContract;

/**
 * Degraded-mode fallback for {@link TrainingClient}. When training-service is
 * unreachable, enrollment/course lookups return empty/null so attendance falls back
 * to its default working-days rather than failing the computation.
 */
@Component
public class TrainingClientFallback implements TrainingClient {

    private static final Logger log = LoggerFactory.getLogger(TrainingClientFallback.class);

    @Override
    public List<EnrollmentContract> getEnrollmentsForTrainee(Long traineeId) {
        log.warn("training-service unavailable; returning no enrollments for traineeID={}", traineeId);
        return Collections.emptyList();
    }

    @Override
    public TradeCourseContract getCourse(Long courseId) {
        log.warn("training-service unavailable; cannot resolve courseID={}", courseId);
        return null;
    }
}
