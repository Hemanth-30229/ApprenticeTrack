package com.cts.ojtstipend.client.dto;

/**
 * Payload sent to platform-service to record an audit-log entry. Replaces the direct
 * {@code AuditLogRepository.save(...)} / {@code AuditService.record(...)} the monolith
 * performed in-process.
 */
public class AuditLogRequest {

    private Long userID;
    private String action;
    private String module;
    private String details;

    public AuditLogRequest() {}

    public AuditLogRequest(Long userID, String action, String module, String details) {
        this.userID = userID;
        this.action = action;
        this.module = module;
        this.details = details;
    }

    public Long getUserID() { return userID; }
    public void setUserID(Long userID) { this.userID = userID; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getModule() { return module; }
    public void setModule(String module) { this.module = module; }

    public String getDetails() { return details; }
    public void setDetails(String details) { this.details = details; }
}
