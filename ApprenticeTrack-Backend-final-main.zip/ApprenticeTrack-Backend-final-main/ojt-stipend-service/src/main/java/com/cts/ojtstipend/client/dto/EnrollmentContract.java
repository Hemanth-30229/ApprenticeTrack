package com.cts.ojtstipend.client.dto;

/**
 * Lightweight view of a training-service {@code CourseEnrollment}. Carries the
 * {@code courseID} and {@code status} so ojt-stipend-service can resolve a trainee's
 * active (OJTInProgress) course to read its OJT-week split. Unknown JSON fields are
 * ignored by Jackson's default deserialization.
 */
public class EnrollmentContract {

    private Long enrollmentID;
    private Long traineeID;
    private Long courseID;
    private Long batchID;
    private String status;

    public EnrollmentContract() {}

    public Long getEnrollmentID() { return enrollmentID; }
    public void setEnrollmentID(Long enrollmentID) { this.enrollmentID = enrollmentID; }

    public Long getTraineeID() { return traineeID; }
    public void setTraineeID(Long traineeID) { this.traineeID = traineeID; }

    public Long getCourseID() { return courseID; }
    public void setCourseID(Long courseID) { this.courseID = courseID; }

    public Long getBatchID() { return batchID; }
    public void setBatchID(Long batchID) { this.batchID = batchID; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
