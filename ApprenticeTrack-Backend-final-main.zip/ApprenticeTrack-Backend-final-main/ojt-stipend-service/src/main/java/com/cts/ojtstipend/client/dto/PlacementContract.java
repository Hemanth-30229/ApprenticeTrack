package com.cts.ojtstipend.client.dto;

import java.time.LocalDate;

/**
 * Lightweight view of a placement-service {@code Placement}. Carries {@code vacancyID}
 * (to resolve the stipend rate) and {@code supervisorName} (to authorize OJT-log
 * approve/reject) so ojt-stipend-service does not own the placement table.
 */
public class PlacementContract {

    private Long placementID;
    private Long traineeID;
    private Long vacancyID;
    private Long employerID;
    private String supervisorName;
    private String supervisorPhone;
    private LocalDate placementDate;
    private String status;

    public PlacementContract() {}

    public Long getPlacementID() { return placementID; }
    public void setPlacementID(Long placementID) { this.placementID = placementID; }

    public Long getTraineeID() { return traineeID; }
    public void setTraineeID(Long traineeID) { this.traineeID = traineeID; }

    public Long getVacancyID() { return vacancyID; }
    public void setVacancyID(Long vacancyID) { this.vacancyID = vacancyID; }

    public Long getEmployerID() { return employerID; }
    public void setEmployerID(Long employerID) { this.employerID = employerID; }

    public String getSupervisorName() { return supervisorName; }
    public void setSupervisorName(String supervisorName) { this.supervisorName = supervisorName; }

    public String getSupervisorPhone() { return supervisorPhone; }
    public void setSupervisorPhone(String supervisorPhone) { this.supervisorPhone = supervisorPhone; }

    public LocalDate getPlacementDate() { return placementDate; }
    public void setPlacementDate(LocalDate placementDate) { this.placementDate = placementDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
