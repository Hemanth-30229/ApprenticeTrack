package com.cts.ojtstipend.client.dto;

/**
 * Lightweight view of a training-service {@code TradeCourse}. Carries the week split
 * ({@code ojtWeeks} in particular) so ojt-stipend-service can derive the required OJT
 * working days for attendance. Unknown JSON fields are ignored by Jackson.
 */
public class TradeCourseContract {

    private Long courseID;
    private Integer durationWeeks;
    private Integer classroomWeeks;
    private Integer ojtWeeks;

    public TradeCourseContract() {}

    public Long getCourseID() { return courseID; }
    public void setCourseID(Long courseID) { this.courseID = courseID; }

    public Integer getDurationWeeks() { return durationWeeks; }
    public void setDurationWeeks(Integer durationWeeks) { this.durationWeeks = durationWeeks; }

    public Integer getClassroomWeeks() { return classroomWeeks; }
    public void setClassroomWeeks(Integer classroomWeeks) { this.classroomWeeks = classroomWeeks; }

    public Integer getOjtWeeks() { return ojtWeeks; }
    public void setOjtWeeks(Integer ojtWeeks) { this.ojtWeeks = ojtWeeks; }
}
