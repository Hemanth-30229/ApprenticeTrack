package com.cts.ojtstipend.client.dto;

import java.math.BigDecimal;

/**
 * Lightweight view of a placement-service {@code ApprenticeshipVacancy}, carrying only
 * the {@code stipendOffered} rate ojt-stipend-service needs to prorate a monthly stipend.
 */
public class VacancyContract {

    private Long vacancyID;
    private BigDecimal stipendOffered;

    public VacancyContract() {}

    public Long getVacancyID() { return vacancyID; }
    public void setVacancyID(Long vacancyID) { this.vacancyID = vacancyID; }

    public BigDecimal getStipendOffered() { return stipendOffered; }
    public void setStipendOffered(BigDecimal stipendOffered) { this.stipendOffered = stipendOffered; }
}
