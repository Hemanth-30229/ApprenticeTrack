package com.cts.ojtstipend.common;

/**
 * AP-19 attendance summary lifecycle: a summary is Computed on creation and
 * transitions to Approved by a stipend administrator. Only Approved summaries
 * are eligible for stipend disbursement processing.
 */
public enum OJTAttendanceSummaryStatus {
    Computed, Approved
}
