package com.cts.ojtstipend.common;

public enum OJTLogStatus {
    Submitted, SupervisorConfirmed, Rejected
}
