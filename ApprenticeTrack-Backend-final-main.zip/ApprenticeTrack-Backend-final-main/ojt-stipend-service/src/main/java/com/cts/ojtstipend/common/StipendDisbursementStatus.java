package com.cts.ojtstipend.common;

public enum StipendDisbursementStatus {
    Pending, Approved, Disbursed, Withheld
}
