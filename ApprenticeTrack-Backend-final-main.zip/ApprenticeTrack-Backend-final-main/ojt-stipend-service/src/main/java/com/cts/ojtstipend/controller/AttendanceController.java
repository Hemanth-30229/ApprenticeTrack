package com.cts.ojtstipend.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ojtstipend.common.OJTAttendanceSummaryStatus;
import com.cts.ojtstipend.dto.AttendanceBulkApproveRequestDTO;
import com.cts.ojtstipend.dto.AttendanceComputeRequestDTO;
import com.cts.ojtstipend.dto.AttendanceReportDTO;
import com.cts.ojtstipend.dto.AttendanceSummaryResponseDTO;
import com.cts.ojtstipend.dto.BulkApproveResponseDTO;
import com.cts.ojtstipend.security.AuthUser;
import com.cts.ojtstipend.service.AttendanceService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

/**
 * AP-19 Attendance Summary API. Computes monthly OJT attendance per placement,
 * flags stipend eligibility, and lets a stipend administrator approve summaries
 * (only Approved summaries feed stipend disbursement).
 */
@RestController
@RequestMapping("/api/attendance-summaries")
@SecurityRequirement(name = "bearerAuth")
public class AttendanceController {

    private final AttendanceService attendanceService;

    public AttendanceController(AttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }

    @PostMapping("/compute")
    public ResponseEntity<AttendanceSummaryResponseDTO> compute(
            @Valid @RequestBody AttendanceComputeRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(attendanceService.compute(requestDTO, user == null ? null : user.userID()));
    }

    @GetMapping
    public ResponseEntity<Page<AttendanceSummaryResponseDTO>> list(
            @RequestParam(required = false) Long traineeID,
            @RequestParam(required = false) Long placementID,
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year,
            @RequestParam(required = false) Boolean stipendEligible,
            @RequestParam(required = false) OJTAttendanceSummaryStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "year,desc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("asc")
                ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(
                attendanceService.list(traineeID, placementID, month, year, stipendEligible, status, pageable));
    }

    @GetMapping("/report")
    public ResponseEntity<AttendanceReportDTO> report(
            @RequestParam Integer month, @RequestParam Integer year) {
        return ResponseEntity.ok(attendanceService.report(month, year));
    }

    @PutMapping("/{id}/approve")
    public ResponseEntity<AttendanceSummaryResponseDTO> approve(
            @PathVariable Long id, @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(attendanceService.approve(id, user == null ? null : user.userID()));
    }

    /** Recompute an existing summary (AP-19: PUT to recompute after a duplicate 409). */
    @PutMapping("/{id}/recompute")
    public ResponseEntity<AttendanceSummaryResponseDTO> recompute(
            @PathVariable Long id, @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(attendanceService.recompute(id, user == null ? null : user.userID()));
    }

    /** Bulk-approve convenience for the review screen (approves each Computed summary). */
    @PutMapping("/bulk-approve")
    public ResponseEntity<BulkApproveResponseDTO> bulkApprove(
            @Valid @RequestBody AttendanceBulkApproveRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(
                attendanceService.bulkApprove(requestDTO.getSummaryIDs(), user == null ? null : user.userID()));
    }
}
