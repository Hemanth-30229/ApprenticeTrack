package com.cts.ojtstipend.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import com.cts.ojtstipend.dto.BulkApproveResponseDTO;
import com.cts.ojtstipend.dto.OJTLogBulkApproveRequestDTO;
import com.cts.ojtstipend.dto.OJTLogBulkCreateRequestDTO;
import com.cts.ojtstipend.dto.OJTLogCreateRequestDTO;
import com.cts.ojtstipend.dto.OJTLogRejectRequestDTO;
import com.cts.ojtstipend.dto.OJTLogResponseDTO;
import com.cts.ojtstipend.common.OJTLogStatus;
import com.cts.ojtstipend.security.AuthUser;
import com.cts.ojtstipend.service.OJTLogService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/ojt-logs")
@SecurityRequirement(name = "bearerAuth")
public class OJTLogController {

    private final OJTLogService ojtLogService;

    public OJTLogController(OJTLogService ojtLogService) {
        this.ojtLogService = ojtLogService;
    }

    /** Trainee submits a new daily OJT log (AP-17). */
    @PostMapping
    public ResponseEntity<OJTLogResponseDTO> create(
            @Valid @RequestBody OJTLogCreateRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ojtLogService.createLog(requestDTO, user != null ? user.userID() : null));
    }

    /** Trainee submits multiple OJT logs at once (AP-17), e.g. back-filling past dates. */
    @PostMapping("/bulk")
    public ResponseEntity<List<OJTLogResponseDTO>> createBulk(
            @Valid @RequestBody OJTLogBulkCreateRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ojtLogService.createLogsBulk(requestDTO.getLogs(), user != null ? user.userID() : null));
    }

    /** Trainee edits & resubmits a rejected log (AP-17). */
    @PutMapping("/{id}")
    public ResponseEntity<OJTLogResponseDTO> update(
            @PathVariable Long id,
            @Valid @RequestBody OJTLogCreateRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(
                ojtLogService.updateLog(id, requestDTO, user != null ? user.userID() : null));
    }

    @PutMapping("/{id}/approve")
    public ResponseEntity<OJTLogResponseDTO> approve(@PathVariable Long id, @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(ojtLogService.approve(id, user.userID()));
    }

    @PutMapping("/{id}/reject")
    public ResponseEntity<OJTLogResponseDTO> reject(
            @PathVariable Long id,
            @Valid @RequestBody OJTLogRejectRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(
                ojtLogService.reject(id, requestDTO.getRejectionReason(), user.userID()));
    }

    @PutMapping("/bulk-approve")
    public ResponseEntity<BulkApproveResponseDTO> bulkApprove(
            @Valid @RequestBody OJTLogBulkApproveRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(
                ojtLogService.bulkApprove(requestDTO.getLogIDs(), user.userID()));
    }

    @GetMapping
    public ResponseEntity<Page<OJTLogResponseDTO>> getLogs(
            @RequestParam(required = false) OJTLogStatus status,
            @RequestParam(required = false) Long placementId,
            @RequestParam(required = false) Long traineeID,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "logDate,desc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("asc")
                ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(ojtLogService.getLogs(status, placementId, traineeID, pageable));
    }
}
