package com.cts.ojtstipend.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ojtstipend.dto.BulkApproveResponseDTO;
import com.cts.ojtstipend.dto.StipendBulkApproveRequestDTO;
import com.cts.ojtstipend.dto.StipendCalculateRequestDTO;
import com.cts.ojtstipend.dto.StipendDisbursementResponseDTO;
import com.cts.ojtstipend.common.StipendDisbursementStatus;
import com.cts.ojtstipend.security.AuthUser;
import com.cts.ojtstipend.service.StipendService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/stipend-disbursements")
@SecurityRequirement(name = "bearerAuth")
public class StipendController {

    private final StipendService stipendService;

    public StipendController(StipendService stipendService) {
        this.stipendService = stipendService;
    }

    @PostMapping("/calculate")
    public ResponseEntity<StipendDisbursementResponseDTO> calculate(
            @Valid @RequestBody StipendCalculateRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(stipendService.calculate(requestDTO, user.userID()));
    }

    @GetMapping
    public ResponseEntity<Page<StipendDisbursementResponseDTO>> getDisbursements(
            @RequestParam(required = false) Long traineeID,
            @RequestParam(required = false) Long placementID,
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year,
            @RequestParam(required = false) StipendDisbursementStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "disbursementID,desc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("asc")
                ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(
                stipendService.getDisbursements(traineeID, placementID, month, year, status, pageable));
    }

    @PutMapping("/{id}/approve")
    public ResponseEntity<StipendDisbursementResponseDTO> approve(
            @PathVariable Long id, @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(stipendService.approve(id, user.userID()));
    }

    @PutMapping("/{id}/disburse")
    public ResponseEntity<StipendDisbursementResponseDTO> disburse(
            @PathVariable Long id, @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(stipendService.disburse(id, user.userID()));
    }

    @PutMapping("/bulk-approve")
    public ResponseEntity<BulkApproveResponseDTO> bulkApprove(
            @Valid @RequestBody StipendBulkApproveRequestDTO requestDTO,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(
                stipendService.bulkApprove(requestDTO.getDisbursementIDs(), user.userID()));
    }
}
