package com.cts.ojtstipend.dto;

import java.util.List;

import jakarta.validation.constraints.NotEmpty;

public class AttendanceBulkApproveRequestDTO {

    @NotEmpty(message = "At least one SummaryID is required")
    private List<Long> summaryIDs;

    public AttendanceBulkApproveRequestDTO() {}

    public List<Long> getSummaryIDs() { return summaryIDs; }
    public void setSummaryIDs(List<Long> summaryIDs) { this.summaryIDs = summaryIDs; }
}
