package com.cts.ojtstipend.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class AttendanceComputeRequestDTO {

    @NotNull(message = "PlacementID is required")
    private Long placementID;

    @NotNull(message = "Month is required")
    @Min(value = 1, message = "Month must be between 1 and 12")
    @Max(value = 12, message = "Month must be between 1 and 12")
    private Integer month;

    @NotNull(message = "Year is required")
    private Integer year;

    public AttendanceComputeRequestDTO() {}

    public Long getPlacementID() { return placementID; }
    public Integer getMonth() { return month; }
    public Integer getYear() { return year; }

    public void setPlacementID(Long placementID) { this.placementID = placementID; }
    public void setMonth(Integer month) { this.month = month; }
    public void setYear(Integer year) { this.year = year; }
}
