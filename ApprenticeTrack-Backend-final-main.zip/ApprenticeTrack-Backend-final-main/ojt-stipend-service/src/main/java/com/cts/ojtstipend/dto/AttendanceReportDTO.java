package com.cts.ojtstipend.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** AP-19 monthly attendance report with a trainee-wise breakdown. */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AttendanceReportDTO {
    private Integer month;
    private Integer year;
    private int totalTrainees;
    private int eligibleCount;
    private int ineligibleCount;
    private int approvedCount;
    private Double averageAttendancePercent;
    private List<AttendanceSummaryResponseDTO> summaries;
}
