package com.cts.ojtstipend.dto;

import com.cts.ojtstipend.common.OJTAttendanceSummaryStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AttendanceSummaryResponseDTO {
    private Long summaryID;
    private Long placementID;
    private Long traineeID;
    private Integer month;
    private Integer year;
    private Integer workingDays;
    private Integer daysAttended;
    private Double attendancePercent;
    private Boolean stipendEligible;
    private OJTAttendanceSummaryStatus status;
}
