package com.cts.ojtstipend.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * Result of a bulk approval (OJT logs or stipend disbursements): which items were
 * confirmed and which were skipped (with a reason), so a partial batch can report
 * per-item outcomes.
 */
public class BulkApproveResponseDTO {

    private int totalRequested;
    private List<Long> approved = new ArrayList<>();
    private List<FailedLog> failed = new ArrayList<>();

    public int getTotalRequested() { return totalRequested; }
    public List<Long> getApproved() { return approved; }
    public List<FailedLog> getFailed() { return failed; }

    public void setTotalRequested(int totalRequested) { this.totalRequested = totalRequested; }
    public void setApproved(List<Long> approved) { this.approved = approved; }
    public void setFailed(List<FailedLog> failed) { this.failed = failed; }

    public void addApproved(Long logID) { this.approved.add(logID); }
    public void addFailed(Long logID, String reason) { this.failed.add(new FailedLog(logID, reason)); }

    public static class FailedLog {
        private Long logID;
        private String reason;

        public FailedLog() {}
        public FailedLog(Long logID, String reason) { this.logID = logID; this.reason = reason; }

        public Long getLogID() { return logID; }
        public String getReason() { return reason; }
        public void setLogID(Long logID) { this.logID = logID; }
        public void setReason(String reason) { this.reason = reason; }
    }
}
