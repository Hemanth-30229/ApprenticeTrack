package com.cts.ojtstipend.dto;

import java.util.List;

import jakarta.validation.constraints.NotEmpty;

public class OJTLogBulkApproveRequestDTO {

    @NotEmpty(message = "At least one LogID is required")
    private List<Long> logIDs;

    public OJTLogBulkApproveRequestDTO() {}

    public List<Long> getLogIDs() { return logIDs; }
    public void setLogIDs(List<Long> logIDs) { this.logIDs = logIDs; }
}
