package com.cts.ojtstipend.dto;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

/**
 * Bulk submission of OJT logs (AP-17), e.g. a trainee back-filling logs for several past
 * dates in one request. Each entry is validated like a single create. Past dates are
 * allowed; {@code logDate} carries no past/future constraint.
 */
public class OJTLogBulkCreateRequestDTO {

    @NotEmpty(message = "At least one OJT log is required")
    @Size(max = 60, message = "A maximum of 60 logs can be submitted at once")
    @Valid
    private List<OJTLogCreateRequestDTO> logs;

    public OJTLogBulkCreateRequestDTO() {}

    public List<OJTLogCreateRequestDTO> getLogs() { return logs; }
    public void setLogs(List<OJTLogCreateRequestDTO> logs) { this.logs = logs; }
}
