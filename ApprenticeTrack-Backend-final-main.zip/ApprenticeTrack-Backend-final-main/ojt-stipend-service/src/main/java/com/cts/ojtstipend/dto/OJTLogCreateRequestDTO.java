package com.cts.ojtstipend.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Trainee-submitted OJT log (AP-17). Used for both create (POST) and
 * edit/resubmit (PUT). placementID and traineeID are supplied by the client
 * (the trainee portal resolves them from the trainee's active placement).
 */
public class OJTLogCreateRequestDTO {

    @NotNull(message = "PlacementID is required")
    private Long placementID;

    @NotNull(message = "TraineeID is required")
    private Long traineeID;

    @NotNull(message = "Log date is required")
    private LocalDate logDate;

    @NotBlank(message = "Tasks performed is required")
    @Size(min = 10, max = 1000, message = "Tasks performed must be between 10 and 1000 characters")
    private String tasksPerformed;

    @NotNull(message = "Hours worked is required")
    @DecimalMin(value = "0.0", message = "Hours worked must be between 0 and 24")
    @DecimalMax(value = "24.0", message = "Hours worked must be between 0 and 24")
    private Double hoursWorked;

    public OJTLogCreateRequestDTO() {}

    public Long getPlacementID() { return placementID; }
    public Long getTraineeID() { return traineeID; }
    public LocalDate getLogDate() { return logDate; }
    public String getTasksPerformed() { return tasksPerformed; }
    public Double getHoursWorked() { return hoursWorked; }
    public void setPlacementID(Long v) { this.placementID = v; }
    public void setTraineeID(Long v) { this.traineeID = v; }
    public void setLogDate(LocalDate v) { this.logDate = v; }
    public void setTasksPerformed(String v) { this.tasksPerformed = v; }
    public void setHoursWorked(Double v) { this.hoursWorked = v; }
}
