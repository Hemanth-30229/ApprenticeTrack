package com.cts.ojtstipend.dto;

import jakarta.validation.constraints.NotBlank;

public class OJTLogRejectRequestDTO {

    @NotBlank(message = "Rejection reason is required")
    private String rejectionReason;

    public OJTLogRejectRequestDTO() {}

    public String getRejectionReason() { return rejectionReason; }
    public void setRejectionReason(String rejectionReason) { this.rejectionReason = rejectionReason; }
}
