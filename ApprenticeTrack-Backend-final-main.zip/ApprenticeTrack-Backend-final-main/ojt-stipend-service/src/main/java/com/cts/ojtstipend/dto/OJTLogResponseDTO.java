package com.cts.ojtstipend.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.cts.ojtstipend.common.OJTLogStatus;

public class OJTLogResponseDTO {

    private Long logID, placementID, traineeID;
    private LocalDate logDate;
    private String tasksPerformed;
    private Double hoursWorked;
    private LocalDateTime traineeSubmittedAt, supervisorConfirmedAt;
    private String rejectionReason;
    private OJTLogStatus status;

    public OJTLogResponseDTO() {}

    public Long getLogID() { return logID; }
    public Long getPlacementID() { return placementID; }
    public Long getTraineeID() { return traineeID; }
    public LocalDate getLogDate() { return logDate; }
    public String getTasksPerformed() { return tasksPerformed; }
    public Double getHoursWorked() { return hoursWorked; }
    public LocalDateTime getTraineeSubmittedAt() { return traineeSubmittedAt; }
    public LocalDateTime getSupervisorConfirmedAt() { return supervisorConfirmedAt; }
    public String getRejectionReason() { return rejectionReason; }
    public OJTLogStatus getStatus() { return status; }

    public void setLogID(Long v) { this.logID = v; }
    public void setPlacementID(Long v) { this.placementID = v; }
    public void setTraineeID(Long v) { this.traineeID = v; }
    public void setLogDate(LocalDate v) { this.logDate = v; }
    public void setTasksPerformed(String v) { this.tasksPerformed = v; }
    public void setHoursWorked(Double v) { this.hoursWorked = v; }
    public void setTraineeSubmittedAt(LocalDateTime v) { this.traineeSubmittedAt = v; }
    public void setSupervisorConfirmedAt(LocalDateTime v) { this.supervisorConfirmedAt = v; }
    public void setRejectionReason(String v) { this.rejectionReason = v; }
    public void setStatus(OJTLogStatus v) { this.status = v; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long logID, placementID, traineeID;
        private LocalDate logDate;
        private String tasksPerformed;
        private Double hoursWorked;
        private LocalDateTime traineeSubmittedAt, supervisorConfirmedAt;
        private String rejectionReason;
        private OJTLogStatus status;

        public Builder logID(Long v) { this.logID = v; return this; }
        public Builder placementID(Long v) { this.placementID = v; return this; }
        public Builder traineeID(Long v) { this.traineeID = v; return this; }
        public Builder logDate(LocalDate v) { this.logDate = v; return this; }
        public Builder tasksPerformed(String v) { this.tasksPerformed = v; return this; }
        public Builder hoursWorked(Double v) { this.hoursWorked = v; return this; }
        public Builder traineeSubmittedAt(LocalDateTime v) { this.traineeSubmittedAt = v; return this; }
        public Builder supervisorConfirmedAt(LocalDateTime v) { this.supervisorConfirmedAt = v; return this; }
        public Builder rejectionReason(String v) { this.rejectionReason = v; return this; }
        public Builder status(OJTLogStatus v) { this.status = v; return this; }

        public OJTLogResponseDTO build() {
            OJTLogResponseDTO d = new OJTLogResponseDTO();
            d.logID = logID; d.placementID = placementID; d.traineeID = traineeID;
            d.logDate = logDate; d.tasksPerformed = tasksPerformed; d.hoursWorked = hoursWorked;
            d.traineeSubmittedAt = traineeSubmittedAt; d.supervisorConfirmedAt = supervisorConfirmedAt;
            d.rejectionReason = rejectionReason; d.status = status;
            return d;
        }
    }
}
