package com.cts.ojtstipend.dto;

import java.util.List;

import jakarta.validation.constraints.NotEmpty;

public class StipendBulkApproveRequestDTO {

    @NotEmpty(message = "At least one DisbursementID is required")
    private List<Long> disbursementIDs;

    public StipendBulkApproveRequestDTO() {}

    public List<Long> getDisbursementIDs() { return disbursementIDs; }
    public void setDisbursementIDs(List<Long> disbursementIDs) { this.disbursementIDs = disbursementIDs; }
}
