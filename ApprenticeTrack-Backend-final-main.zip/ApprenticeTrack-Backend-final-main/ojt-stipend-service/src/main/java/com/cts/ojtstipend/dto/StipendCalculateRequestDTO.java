package com.cts.ojtstipend.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class StipendCalculateRequestDTO {

    @NotNull(message = "TraineeID is required")
    private Long traineeID;

    @NotNull(message = "PlacementID is required")
    private Long placementID;

    @NotNull(message = "Month is required")
    @Min(value = 1, message = "Month must be between 1 and 12")
    @Max(value = 12, message = "Month must be between 1 and 12")
    private Integer month;

    @NotNull(message = "Year is required")
    @Min(value = 2000, message = "Year must be a valid 4-digit year")
    private Integer year;

    public StipendCalculateRequestDTO() {}

    public Long getTraineeID() { return traineeID; }
    public Long getPlacementID() { return placementID; }
    public Integer getMonth() { return month; }
    public Integer getYear() { return year; }

    public void setTraineeID(Long traineeID) { this.traineeID = traineeID; }
    public void setPlacementID(Long placementID) { this.placementID = placementID; }
    public void setMonth(Integer month) { this.month = month; }
    public void setYear(Integer year) { this.year = year; }
}
