package com.cts.ojtstipend.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.cts.ojtstipend.common.StipendDisbursementStatus;

public class StipendDisbursementResponseDTO {

    private Long disbursementID, traineeID, placementID;
    private Integer month, year;
    private Double attendancePercent;
    private BigDecimal stipendAmount;
    private LocalDate disbursedDate;
    private StipendDisbursementStatus status;

    public StipendDisbursementResponseDTO() {}

    public Long getDisbursementID() { return disbursementID; }
    public Long getTraineeID() { return traineeID; }
    public Long getPlacementID() { return placementID; }
    public Integer getMonth() { return month; }
    public Integer getYear() { return year; }
    public Double getAttendancePercent() { return attendancePercent; }
    public BigDecimal getStipendAmount() { return stipendAmount; }
    public LocalDate getDisbursedDate() { return disbursedDate; }
    public StipendDisbursementStatus getStatus() { return status; }

    public void setDisbursementID(Long v) { this.disbursementID = v; }
    public void setTraineeID(Long v) { this.traineeID = v; }
    public void setPlacementID(Long v) { this.placementID = v; }
    public void setMonth(Integer v) { this.month = v; }
    public void setYear(Integer v) { this.year = v; }
    public void setAttendancePercent(Double v) { this.attendancePercent = v; }
    public void setStipendAmount(BigDecimal v) { this.stipendAmount = v; }
    public void setDisbursedDate(LocalDate v) { this.disbursedDate = v; }
    public void setStatus(StipendDisbursementStatus v) { this.status = v; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long disbursementID, traineeID, placementID;
        private Integer month, year;
        private Double attendancePercent;
        private BigDecimal stipendAmount;
        private LocalDate disbursedDate;
        private StipendDisbursementStatus status;

        public Builder disbursementID(Long v) { this.disbursementID = v; return this; }
        public Builder traineeID(Long v) { this.traineeID = v; return this; }
        public Builder placementID(Long v) { this.placementID = v; return this; }
        public Builder month(Integer v) { this.month = v; return this; }
        public Builder year(Integer v) { this.year = v; return this; }
        public Builder attendancePercent(Double v) { this.attendancePercent = v; return this; }
        public Builder stipendAmount(BigDecimal v) { this.stipendAmount = v; return this; }
        public Builder disbursedDate(LocalDate v) { this.disbursedDate = v; return this; }
        public Builder status(StipendDisbursementStatus v) { this.status = v; return this; }

        public StipendDisbursementResponseDTO build() {
            StipendDisbursementResponseDTO d = new StipendDisbursementResponseDTO();
            d.disbursementID = disbursementID; d.traineeID = traineeID; d.placementID = placementID;
            d.month = month; d.year = year; d.attendancePercent = attendancePercent;
            d.stipendAmount = stipendAmount; d.disbursedDate = disbursedDate; d.status = status;
            return d;
        }
    }
}
