package com.cts.ojtstipend.entity;

import com.cts.ojtstipend.common.OJTAttendanceSummaryStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Monthly OJT attendance summary for a placement. Minimal entity introduced to
 * support stipend calculation (approved-attendance lookup).
 * TODO: reconcile with the Attendance API (AP-19) when that module lands.
 */
@Entity
@Table(name = "ojt_attendance_summaries")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OJTAttendanceSummary {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long summaryID;

    @Column(nullable = false)
    private Long placementID;

    @Column(nullable = false)
    private Long traineeID;

    @Column(nullable = false)
    private Integer month;

    @Column(nullable = false)
    private Integer year;

    @Column(nullable = false)
    private Integer workingDays;

    @Column(nullable = false)
    private Integer daysAttended;

    @Column(nullable = false)
    private Double attendancePercent;

    @Column(nullable = false)
    private Boolean stipendEligible;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private OJTAttendanceSummaryStatus status = OJTAttendanceSummaryStatus.Computed;
}
