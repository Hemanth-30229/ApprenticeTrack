package com.cts.ojtstipend.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.cts.ojtstipend.common.OJTLogStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ojt_logs")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OJTLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long logID;

    @Column(nullable = false)
    private Long placementID;

    @Column(nullable = false)
    private Long traineeID;

    @Column(nullable = false)
    private LocalDate logDate;

    @Column(length = 1000)
    private String tasksPerformed;

    private Double hoursWorked;

    private LocalDateTime traineeSubmittedAt;

    /** Set when the supervisor confirms the log. */
    private LocalDateTime supervisorConfirmedAt;

    /** Populated on rejection; required by the reject endpoint. */
    @Column(length = 500)
    private String rejectionReason;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private OJTLogStatus status = OJTLogStatus.Submitted;
}
