package com.cts.ojtstipend.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.cts.ojtstipend.common.StipendDisbursementStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "stipend_disbursements")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StipendDisbursement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long disbursementID;

    @Column(nullable = false)
    private Long traineeID;

    @Column(nullable = false)
    private Long placementID;

    @Column(nullable = false)
    private Integer month;

    @Column(nullable = false)
    private Integer year;

    @Column(nullable = false)
    private Double attendancePercent;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal stipendAmount;

    private LocalDate disbursedDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private StipendDisbursementStatus status = StipendDisbursementStatus.Pending;
}
