package com.cts.ojtstipend.exception;

public class AttendanceSummaryNotFoundException extends RuntimeException {
    public AttendanceSummaryNotFoundException(String message) {
        super(message);
    }
}
