package com.cts.ojtstipend.exception;

public class DuplicateAttendanceSummaryException extends RuntimeException {
    public DuplicateAttendanceSummaryException(String message) {
        super(message);
    }
}
