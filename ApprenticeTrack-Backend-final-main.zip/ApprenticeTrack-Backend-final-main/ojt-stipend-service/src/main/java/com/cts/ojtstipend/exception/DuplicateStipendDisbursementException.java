package com.cts.ojtstipend.exception;

public class DuplicateStipendDisbursementException extends RuntimeException {
    public DuplicateStipendDisbursementException(String message) {
        super(message);
    }
}
