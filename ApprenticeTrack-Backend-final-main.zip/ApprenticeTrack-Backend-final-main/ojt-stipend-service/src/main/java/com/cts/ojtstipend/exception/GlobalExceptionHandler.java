package com.cts.ojtstipend.exception;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Centralized exception handling for ojt-stipend-service. Scoped to the exceptions
 * this service raises (OJT logs, stipend disbursements) plus the cross-domain
 * lookup failures it reports when a placement-service Feign call comes back empty.
 * Response shape and status codes match the monolith's for client compatibility.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    // 400 - Validation errors (field-level)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationErrors(MethodArgumentNotValidException ex) {
        Map<String, String> fieldErrors = new HashMap<>();
        ex.getBindingResult().getFieldErrors()
                .forEach(err -> fieldErrors.put(err.getField(), err.getDefaultMessage()));

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("status", HttpStatus.BAD_REQUEST.value());
        body.put("error", "Validation Failed");
        body.put("fieldErrors", fieldErrors);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }

    // 400 - Malformed / unreadable request body (e.g. invalid enum value)
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, Object>> handleUnreadableBody(HttpMessageNotReadableException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", "Malformed or invalid request body");
    }

    // 400 - Invalid OJT log status for approve/reject
    @ExceptionHandler(InvalidOJTLogStatusException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidOJTLogStatus(InvalidOJTLogStatusException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 400 - Invalid stipend status transition
    @ExceptionHandler(InvalidStipendStatusTransitionException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidStipendTransition(InvalidStipendStatusTransitionException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 400 - No approved attendance summary to calculate a stipend against
    @ExceptionHandler(NoApprovedAttendanceException.class)
    public ResponseEntity<Map<String, Object>> handleNoApprovedAttendance(NoApprovedAttendanceException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 400 - Attendance summary not in a state that allows the requested transition
    @ExceptionHandler(InvalidAttendanceStatusException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidAttendanceStatus(InvalidAttendanceStatusException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 403 - Actor is not the supervisor linked to the placement
    @ExceptionHandler(UnauthorizedSupervisorException.class)
    public ResponseEntity<Map<String, Object>> handleUnauthorizedSupervisor(UnauthorizedSupervisorException ex) {
        return error(HttpStatus.FORBIDDEN, "Forbidden", ex.getMessage());
    }

    // 403 - Spring Security authorization failure (@PreAuthorize / URL rules)
    @ExceptionHandler(org.springframework.security.access.AccessDeniedException.class)
    public ResponseEntity<Map<String, Object>> handleAccessDenied(
            org.springframework.security.access.AccessDeniedException ex) {
        return error(HttpStatus.FORBIDDEN, "Forbidden",
                "Access denied: you do not have permission to perform this action.");
    }

    // 404 - Not found
    @ExceptionHandler(OJTLogNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleOJTLogNotFound(OJTLogNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(StipendDisbursementNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleStipendDisbursementNotFound(StipendDisbursementNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(PlacementNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handlePlacementNotFound(PlacementNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(AttendanceSummaryNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleAttendanceSummaryNotFound(AttendanceSummaryNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(VacancyNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleVacancyNotFound(VacancyNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    // 409 - Conflicts
    @ExceptionHandler(DuplicateStipendDisbursementException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicateStipendDisbursement(DuplicateStipendDisbursementException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(DuplicateAttendanceSummaryException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicateAttendanceSummary(DuplicateAttendanceSummaryException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    // 500 - Generic fallback
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGenericException(Exception ex) {
        return error(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error", ex.getMessage());
    }

    // ── helper ────────────────────────────────────────────────────────────────

    private ResponseEntity<Map<String, Object>> error(HttpStatus status, String error, String message) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("status", status.value());
        body.put("error", error);
        body.put("message", message);
        return ResponseEntity.status(status).body(body);
    }
}
