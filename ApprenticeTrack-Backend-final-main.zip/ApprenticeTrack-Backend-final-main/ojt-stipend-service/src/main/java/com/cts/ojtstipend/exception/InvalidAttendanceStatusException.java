package com.cts.ojtstipend.exception;

public class InvalidAttendanceStatusException extends RuntimeException {
    public InvalidAttendanceStatusException(String message) {
        super(message);
    }
}
