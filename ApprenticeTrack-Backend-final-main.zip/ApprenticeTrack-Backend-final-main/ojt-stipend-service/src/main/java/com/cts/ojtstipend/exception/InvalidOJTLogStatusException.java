package com.cts.ojtstipend.exception;

/**
 * Thrown when an approval/rejection is attempted on a log that is not in
 * "Submitted" status. Mapped to 400 Bad Request.
 */
public class InvalidOJTLogStatusException extends RuntimeException {
    public InvalidOJTLogStatusException(String message) {
        super(message);
    }
}
