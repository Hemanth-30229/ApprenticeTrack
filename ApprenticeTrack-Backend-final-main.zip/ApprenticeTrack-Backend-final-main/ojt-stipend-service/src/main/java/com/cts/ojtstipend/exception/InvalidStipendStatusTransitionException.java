package com.cts.ojtstipend.exception;

/**
 * Thrown when a stipend disbursement status change violates the allowed
 * workflow (Pending → Approved → Disbursed). Mapped to 400 Bad Request.
 */
public class InvalidStipendStatusTransitionException extends RuntimeException {
    public InvalidStipendStatusTransitionException(String message) {
        super(message);
    }
}
