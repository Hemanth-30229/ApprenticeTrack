package com.cts.ojtstipend.exception;

/**
 * Thrown when no approved OJTAttendanceSummary exists for the given
 * placement/month/year. Mapped to 400 Bad Request.
 */
public class NoApprovedAttendanceException extends RuntimeException {
    public NoApprovedAttendanceException(String message) {
        super(message);
    }
}
