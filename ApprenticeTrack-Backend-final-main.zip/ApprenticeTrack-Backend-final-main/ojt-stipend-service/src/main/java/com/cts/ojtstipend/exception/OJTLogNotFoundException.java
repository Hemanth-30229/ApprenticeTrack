package com.cts.ojtstipend.exception;

public class OJTLogNotFoundException extends RuntimeException {
    public OJTLogNotFoundException(String message) {
        super(message);
    }
}
