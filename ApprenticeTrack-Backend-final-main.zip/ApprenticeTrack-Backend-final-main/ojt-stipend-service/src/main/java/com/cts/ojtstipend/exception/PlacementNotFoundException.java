package com.cts.ojtstipend.exception;

/**
 * Thrown when placement-service reports no such placement for a PlacementID
 * referenced by an OJT log or a stipend calculation request.
 */
public class PlacementNotFoundException extends RuntimeException {
    public PlacementNotFoundException(String message) {
        super(message);
    }
}
