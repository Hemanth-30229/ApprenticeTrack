package com.cts.ojtstipend.exception;

public class StipendDisbursementNotFoundException extends RuntimeException {
    public StipendDisbursementNotFoundException(String message) {
        super(message);
    }
}
