package com.cts.ojtstipend.exception;

/**
 * Thrown when a user who is not the supervisor linked to the placement tries to
 * approve/reject an OJT log. Mapped to 403 Forbidden.
 */
public class UnauthorizedSupervisorException extends RuntimeException {
    public UnauthorizedSupervisorException(String message) {
        super(message);
    }
}
