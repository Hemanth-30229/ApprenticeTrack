package com.cts.ojtstipend.exception;

/**
 * Thrown when placement-service reports no such vacancy for the VacancyID
 * resolved from a placement during stipend calculation (stipendOffered lookup).
 */
public class VacancyNotFoundException extends RuntimeException {
    public VacancyNotFoundException(String message) {
        super(message);
    }
}
