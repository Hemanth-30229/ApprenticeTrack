package com.cts.ojtstipend.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.ojtstipend.common.OJTAttendanceSummaryStatus;
import com.cts.ojtstipend.entity.OJTAttendanceSummary;

@Repository
public interface OJTAttendanceSummaryRepository extends JpaRepository<OJTAttendanceSummary, Long> {

    /** Approved-attendance lookup used by stipend calculation. */
    Optional<OJTAttendanceSummary> findByPlacementIDAndMonthAndYearAndStatus(
            Long placementID, Integer month, Integer year, OJTAttendanceSummaryStatus status);

    /** Duplicate-computation guard (AP-19: one summary per placement+month+year). */
    boolean existsByPlacementIDAndMonthAndYear(Long placementID, Integer month, Integer year);

    /** Monthly report: every summary for a month/year, trainee-wise. */
    List<OJTAttendanceSummary> findByMonthAndYearOrderByTraineeIDAsc(Integer month, Integer year);

    /** Paginated filtering; all params optional (null = no filter). */
    @Query("SELECT s FROM OJTAttendanceSummary s WHERE " +
           "(:traineeID IS NULL OR s.traineeID = :traineeID) AND " +
           "(:placementID IS NULL OR s.placementID = :placementID) AND " +
           "(:month IS NULL OR s.month = :month) AND " +
           "(:year IS NULL OR s.year = :year) AND " +
           "(:stipendEligible IS NULL OR s.stipendEligible = :stipendEligible) AND " +
           "(:status IS NULL OR s.status = :status)")
    Page<OJTAttendanceSummary> findAllWithFilters(
            @Param("traineeID") Long traineeID,
            @Param("placementID") Long placementID,
            @Param("month") Integer month,
            @Param("year") Integer year,
            @Param("stipendEligible") Boolean stipendEligible,
            @Param("status") OJTAttendanceSummaryStatus status,
            Pageable pageable);
}
