package com.cts.ojtstipend.repository;

import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.ojtstipend.common.OJTLogStatus;
import com.cts.ojtstipend.entity.OJTLog;

@Repository
public interface OJTLogRepository extends JpaRepository<OJTLog, Long> {

    /** AP-19: DaysAttended = count of SupervisorConfirmed logs within the month window. */
    long countByPlacementIDAndStatusAndLogDateBetween(
            Long placementID, OJTLogStatus status, LocalDate from, LocalDate to);

    /** Count of logs in a given status for a placement across the whole OJT period (no date window). */
    long countByPlacementIDAndStatus(Long placementID, OJTLogStatus status);

    /**
     * Paginated filtering by Status, PlacementID and TraineeID (all optional).
     */
    @Query("SELECT l FROM OJTLog l WHERE " +
           "(:status IS NULL OR l.status = :status) AND " +
           "(:placementID IS NULL OR l.placementID = :placementID) AND " +
           "(:traineeID IS NULL OR l.traineeID = :traineeID)")
    Page<OJTLog> findAllWithFilters(
            @Param("status") OJTLogStatus status,
            @Param("placementID") Long placementID,
            @Param("traineeID") Long traineeID,
            Pageable pageable);
}
