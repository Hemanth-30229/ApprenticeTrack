package com.cts.ojtstipend.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.ojtstipend.common.StipendDisbursementStatus;
import com.cts.ojtstipend.entity.StipendDisbursement;

@Repository
public interface StipendDisbursementRepository extends JpaRepository<StipendDisbursement, Long> {

    boolean existsByTraineeIDAndPlacementIDAndMonthAndYear(
            Long traineeID, Long placementID, Integer month, Integer year);

    /**
     * Paginated filtering by TraineeID, PlacementID, Month, Year, and Status.
     * All params optional — null means no filter applied.
     */
    @Query("SELECT s FROM StipendDisbursement s WHERE " +
           "(:traineeID IS NULL OR s.traineeID = :traineeID) AND " +
           "(:placementID IS NULL OR s.placementID = :placementID) AND " +
           "(:month IS NULL OR s.month = :month) AND " +
           "(:year IS NULL OR s.year = :year) AND " +
           "(:status IS NULL OR s.status = :status)")
    Page<StipendDisbursement> findAllWithFilters(
            @Param("traineeID") Long traineeID,
            @Param("placementID") Long placementID,
            @Param("month") Integer month,
            @Param("year") Integer year,
            @Param("status") StipendDisbursementStatus status,
            Pageable pageable);
}
