package com.cts.ojtstipend.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.ojtstipend.common.OJTAttendanceSummaryStatus;
import com.cts.ojtstipend.dto.AttendanceComputeRequestDTO;
import com.cts.ojtstipend.dto.AttendanceReportDTO;
import com.cts.ojtstipend.dto.AttendanceSummaryResponseDTO;
import com.cts.ojtstipend.dto.BulkApproveResponseDTO;

import java.util.List;

public interface AttendanceService {

    AttendanceSummaryResponseDTO compute(AttendanceComputeRequestDTO dto, Long actorUserID);

    /** Recompute an existing (not yet Approved) summary — used after a duplicate 409. */
    AttendanceSummaryResponseDTO recompute(Long summaryID, Long actorUserID);

    Page<AttendanceSummaryResponseDTO> list(Long traineeID, Long placementID, Integer month, Integer year,
                                            Boolean stipendEligible, OJTAttendanceSummaryStatus status,
                                            Pageable pageable);

    AttendanceSummaryResponseDTO approve(Long summaryID, Long actorUserID);

    BulkApproveResponseDTO bulkApprove(List<Long> summaryIDs, Long actorUserID);

    AttendanceReportDTO report(Integer month, Integer year);
}
