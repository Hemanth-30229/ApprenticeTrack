package com.cts.ojtstipend.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.ojtstipend.client.PlacementClient;
import com.cts.ojtstipend.client.PlatformClient;
import com.cts.ojtstipend.client.TrainingClient;
import com.cts.ojtstipend.client.dto.AuditLogRequest;
import com.cts.ojtstipend.client.dto.EnrollmentContract;
import com.cts.ojtstipend.client.dto.PlacementContract;
import com.cts.ojtstipend.client.dto.TradeCourseContract;
import com.cts.ojtstipend.common.OJTAttendanceSummaryStatus;
import com.cts.ojtstipend.common.OJTLogStatus;
import com.cts.ojtstipend.dto.AttendanceComputeRequestDTO;
import com.cts.ojtstipend.dto.AttendanceReportDTO;
import com.cts.ojtstipend.dto.AttendanceSummaryResponseDTO;
import com.cts.ojtstipend.dto.BulkApproveResponseDTO;
import com.cts.ojtstipend.entity.OJTAttendanceSummary;
import com.cts.ojtstipend.exception.AttendanceSummaryNotFoundException;
import com.cts.ojtstipend.exception.DuplicateAttendanceSummaryException;
import com.cts.ojtstipend.exception.InvalidAttendanceStatusException;
import com.cts.ojtstipend.exception.PlacementNotFoundException;
import com.cts.ojtstipend.repository.OJTAttendanceSummaryRepository;
import com.cts.ojtstipend.repository.OJTLogRepository;

@Service
public class AttendanceServiceImpl implements AttendanceService {

    private static final String MODULE = "Attendance";
    private static final String ENROLLMENT_OJT_IN_PROGRESS = "OJTInProgress";

    private final OJTAttendanceSummaryRepository summaryRepository;
    private final OJTLogRepository ojtLogRepository;
    private final PlacementClient placementClient;
    private final PlatformClient platformClient;
    private final TrainingClient trainingClient;

    /**
     * Fallback working-days used only when the trainee's course OJT-week split cannot be
     * resolved from training-service. Normally the required days derive from the course:
     * {@code ojtWeeks * daysPerOjtWeek}.
     */
    @Value("${attendance.working-days-per-month:22}")
    private int workingDaysPerMonth;

    /** Working days counted per OJT week when deriving required days from the course. */
    @Value("${attendance.days-per-ojt-week:5}")
    private int daysPerOjtWeek;

    /** Minimum attendance % for stipend eligibility. */
    @Value("${attendance.eligibility-threshold-percent:80}")
    private double eligibilityThresholdPercent;

    public AttendanceServiceImpl(OJTAttendanceSummaryRepository summaryRepository,
                                 OJTLogRepository ojtLogRepository,
                                 PlacementClient placementClient,
                                 PlatformClient platformClient,
                                 TrainingClient trainingClient) {
        this.summaryRepository = summaryRepository;
        this.ojtLogRepository = ojtLogRepository;
        this.placementClient = placementClient;
        this.platformClient = platformClient;
        this.trainingClient = trainingClient;
    }

    @Override
    @Transactional
    public AttendanceSummaryResponseDTO compute(AttendanceComputeRequestDTO dto, Long actorUserID) {
        if (summaryRepository.existsByPlacementIDAndMonthAndYear(
                dto.getPlacementID(), dto.getMonth(), dto.getYear())) {
            throw new DuplicateAttendanceSummaryException(
                    "An attendance summary already exists for PlacementID=" + dto.getPlacementID()
                    + ", Month=" + dto.getMonth() + ", Year=" + dto.getYear()
                    + ". Use recompute (PUT) to recalculate it.");
        }

        PlacementContract placement = placementClient.getPlacement(dto.getPlacementID());
        if (placement == null) {
            throw new PlacementNotFoundException("Placement not found with ID: " + dto.getPlacementID());
        }

        OJTAttendanceSummary summary = OJTAttendanceSummary.builder()
                .placementID(dto.getPlacementID())
                .traineeID(placement.getTraineeID())
                .month(dto.getMonth())
                .year(dto.getYear())
                .status(OJTAttendanceSummaryStatus.Computed)
                .build();
        applyComputation(summary);

        OJTAttendanceSummary saved = summaryRepository.save(summary);
        audit(actorUserID, "AttendanceComputed: PlacementID=" + saved.getPlacementID()
                + ", Month=" + saved.getMonth() + ", Year=" + saved.getYear()
                + ", DaysAttended=" + saved.getDaysAttended() + "/" + saved.getWorkingDays()
                + " (" + saved.getAttendancePercent() + "%), Eligible=" + saved.getStipendEligible()
                + " [SummaryID=" + saved.getSummaryID() + "]");
        return toResponseDTO(saved);
    }

    @Override
    @Transactional
    public AttendanceSummaryResponseDTO recompute(Long summaryID, Long actorUserID) {
        OJTAttendanceSummary summary = findSummary(summaryID);
        if (summary.getStatus() == OJTAttendanceSummaryStatus.Approved) {
            throw new InvalidAttendanceStatusException(
                    "Approved summaries cannot be recomputed. SummaryID: " + summaryID);
        }
        applyComputation(summary);
        OJTAttendanceSummary saved = summaryRepository.save(summary);
        audit(actorUserID, "AttendanceRecomputed: SummaryID=" + summaryID
                + ", DaysAttended=" + saved.getDaysAttended() + "/" + saved.getWorkingDays()
                + " (" + saved.getAttendancePercent() + "%)");
        return toResponseDTO(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<AttendanceSummaryResponseDTO> list(Long traineeID, Long placementID, Integer month, Integer year,
                                                   Boolean stipendEligible, OJTAttendanceSummaryStatus status,
                                                   Pageable pageable) {
        return summaryRepository
                .findAllWithFilters(traineeID, placementID, month, year, stipendEligible, status, pageable)
                .map(this::toResponseDTO);
    }

    @Override
    @Transactional
    public AttendanceSummaryResponseDTO approve(Long summaryID, Long actorUserID) {
        OJTAttendanceSummary summary = findSummary(summaryID);
        if (summary.getStatus() != OJTAttendanceSummaryStatus.Computed) {
            throw new InvalidAttendanceStatusException(
                    "Only summaries in 'Computed' status can be approved. Current status: "
                    + summary.getStatus() + ". SummaryID: " + summaryID);
        }
        summary.setStatus(OJTAttendanceSummaryStatus.Approved);
        OJTAttendanceSummary saved = summaryRepository.save(summary);
        audit(actorUserID, "AttendanceApproved: [SummaryID=" + saved.getSummaryID() + "]");
        return toResponseDTO(saved);
    }

    @Override
    @Transactional
    public BulkApproveResponseDTO bulkApprove(List<Long> summaryIDs, Long actorUserID) {
        BulkApproveResponseDTO response = new BulkApproveResponseDTO();
        response.setTotalRequested(summaryIDs == null ? 0 : summaryIDs.size());
        if (summaryIDs == null) return response;
        for (Long id : summaryIDs) {
            try {
                approve(id, actorUserID);
                response.addApproved(id);
            } catch (RuntimeException ex) {
                response.addFailed(id, ex.getMessage());
            }
        }
        return response;
    }

    @Override
    @Transactional(readOnly = true)
    public AttendanceReportDTO report(Integer month, Integer year) {
        List<OJTAttendanceSummary> rows = summaryRepository.findByMonthAndYearOrderByTraineeIDAsc(month, year);
        List<AttendanceSummaryResponseDTO> summaries = rows.stream().map(this::toResponseDTO).toList();

        int eligible = (int) rows.stream().filter(r -> Boolean.TRUE.equals(r.getStipendEligible())).count();
        int approved = (int) rows.stream()
                .filter(r -> r.getStatus() == OJTAttendanceSummaryStatus.Approved).count();
        double avg = rows.isEmpty() ? 0.0
                : rows.stream().mapToDouble(r -> r.getAttendancePercent() == null ? 0.0 : r.getAttendancePercent())
                        .average().orElse(0.0);

        return AttendanceReportDTO.builder()
                .month(month)
                .year(year)
                .totalTrainees(rows.size())
                .eligibleCount(eligible)
                .ineligibleCount(rows.size() - eligible)
                .approvedCount(approved)
                .averageAttendancePercent(round2(avg))
                .summaries(summaries)
                .build();
    }

    // ── helpers ──

    /**
     * Recomputes DaysAttended / AttendancePercent / StipendEligible on the given summary.
     *
     * <p>Required days derive from the trainee's course OJT-week split ({@code ojtWeeks *
     * daysPerOjtWeek}) over the whole OJT period, not a fixed monthly figure. DaysAttended
     * is the count of supervisor-confirmed logs across the entire OJT period, and the
     * percentage is capped at 100% (submitting more logs than required cannot exceed 100%).
     */
    private void applyComputation(OJTAttendanceSummary summary) {
        int daysAttended = (int) ojtLogRepository.countByPlacementIDAndStatus(
                summary.getPlacementID(), OJTLogStatus.SupervisorConfirmed);
        int workingDays = resolveRequiredOjtDays(summary.getTraineeID());
        double percent = workingDays <= 0 ? 0.0
                : Math.min(100.0, round2((daysAttended * 100.0) / workingDays));

        summary.setWorkingDays(workingDays);
        summary.setDaysAttended(daysAttended);
        summary.setAttendancePercent(percent);
        summary.setStipendEligible(percent >= eligibilityThresholdPercent);
    }

    /**
     * Required OJT working days for a trainee = their active course's {@code ojtWeeks *
     * daysPerOjtWeek}. Falls back to {@code workingDaysPerMonth} if the course cannot be
     * resolved (training-service down, no active enrollment, or ojtWeeks unset).
     */
    private int resolveRequiredOjtDays(Long traineeID) {
        if (traineeID == null) {
            return workingDaysPerMonth;
        }
        List<EnrollmentContract> enrollments = trainingClient.getEnrollmentsForTrainee(traineeID);
        if (enrollments == null || enrollments.isEmpty()) {
            return workingDaysPerMonth;
        }
        EnrollmentContract active = enrollments.stream()
                .filter(e -> ENROLLMENT_OJT_IN_PROGRESS.equals(e.getStatus()))
                .findFirst()
                .orElse(enrollments.get(0));
        if (active.getCourseID() == null) {
            return workingDaysPerMonth;
        }
        TradeCourseContract course = trainingClient.getCourse(active.getCourseID());
        if (course == null || course.getOjtWeeks() == null || course.getOjtWeeks() <= 0) {
            return workingDaysPerMonth;
        }
        return course.getOjtWeeks() * daysPerOjtWeek;
    }

    private double round2(double value) {
        return BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    private OJTAttendanceSummary findSummary(Long summaryID) {
        return summaryRepository.findById(summaryID)
                .orElseThrow(() -> new AttendanceSummaryNotFoundException(
                        "Attendance summary not found with ID: " + summaryID));
    }

    private void audit(Long userID, String action) {
        platformClient.recordAudit(new AuditLogRequest(userID, action, MODULE, null));
    }

    private AttendanceSummaryResponseDTO toResponseDTO(OJTAttendanceSummary s) {
        return AttendanceSummaryResponseDTO.builder()
                .summaryID(s.getSummaryID())
                .placementID(s.getPlacementID())
                .traineeID(s.getTraineeID())
                .month(s.getMonth())
                .year(s.getYear())
                .workingDays(s.getWorkingDays())
                .daysAttended(s.getDaysAttended())
                .attendancePercent(s.getAttendancePercent())
                .stipendEligible(s.getStipendEligible())
                .status(s.getStatus())
                .build();
    }
}
