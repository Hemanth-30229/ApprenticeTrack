package com.cts.ojtstipend.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.ojtstipend.dto.BulkApproveResponseDTO;
import com.cts.ojtstipend.dto.OJTLogCreateRequestDTO;
import com.cts.ojtstipend.dto.OJTLogResponseDTO;
import com.cts.ojtstipend.common.OJTLogStatus;

public interface OJTLogService {

    /** Trainee submits a new daily OJT log (AP-17). */
    OJTLogResponseDTO createLog(OJTLogCreateRequestDTO dto, Long actorUserID);

    /** Trainee submits multiple OJT logs at once, e.g. back-filling past dates (AP-17). */
    List<OJTLogResponseDTO> createLogsBulk(List<OJTLogCreateRequestDTO> logs, Long actorUserID);

    /** Trainee edits & resubmits a rejected log (AP-17). */
    OJTLogResponseDTO updateLog(Long logID, OJTLogCreateRequestDTO dto, Long actorUserID);

    OJTLogResponseDTO approve(Long logID, Long supervisorUserID);

    OJTLogResponseDTO reject(Long logID, String rejectionReason, Long supervisorUserID);

    BulkApproveResponseDTO bulkApprove(List<Long> logIDs, Long supervisorUserID);

    Page<OJTLogResponseDTO> getLogs(OJTLogStatus status, Long placementID, Long traineeID, Pageable pageable);
}
