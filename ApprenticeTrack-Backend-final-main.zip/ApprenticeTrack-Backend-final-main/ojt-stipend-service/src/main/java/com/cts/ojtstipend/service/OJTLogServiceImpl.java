package com.cts.ojtstipend.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.ojtstipend.client.AuthClient;
import com.cts.ojtstipend.client.PlacementClient;
import com.cts.ojtstipend.client.PlatformClient;
import com.cts.ojtstipend.client.dto.AuditLogRequest;
import com.cts.ojtstipend.client.dto.NotificationRequest;
import com.cts.ojtstipend.client.dto.PlacementContract;
import com.cts.ojtstipend.client.dto.UserContract;
import com.cts.ojtstipend.dto.BulkApproveResponseDTO;
import com.cts.ojtstipend.dto.OJTLogCreateRequestDTO;
import com.cts.ojtstipend.dto.OJTLogResponseDTO;
import com.cts.ojtstipend.common.OJTLogStatus;
import com.cts.ojtstipend.entity.OJTLog;
import com.cts.ojtstipend.exception.InvalidOJTLogStatusException;
import com.cts.ojtstipend.exception.OJTLogNotFoundException;
import com.cts.ojtstipend.exception.UnauthorizedSupervisorException;
import com.cts.ojtstipend.repository.OJTLogRepository;

@Service
public class OJTLogServiceImpl implements OJTLogService {

    private static final String MODULE = "OJTLog";
    private static final String CATEGORY_OJT = "OJT";

    private final OJTLogRepository ojtLogRepository;
    private final PlacementClient placementClient;
    private final AuthClient authClient;
    private final PlatformClient platformClient;

    public OJTLogServiceImpl(OJTLogRepository ojtLogRepository,
                             PlacementClient placementClient,
                             AuthClient authClient,
                             PlatformClient platformClient) {
        this.ojtLogRepository = ojtLogRepository;
        this.placementClient = placementClient;
        this.authClient = authClient;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional
    public OJTLogResponseDTO createLog(OJTLogCreateRequestDTO dto, Long actorUserID) {
        OJTLog log = OJTLog.builder()
                .placementID(dto.getPlacementID())
                .traineeID(dto.getTraineeID())
                .logDate(dto.getLogDate())
                .tasksPerformed(dto.getTasksPerformed())
                .hoursWorked(dto.getHoursWorked())
                .traineeSubmittedAt(LocalDateTime.now())
                .status(OJTLogStatus.Submitted)
                .build();
        OJTLog saved = ojtLogRepository.save(log);
        audit(actorUserID, "OJTLogSubmitted",
                "OJT log submitted. LogID=" + saved.getLogID()
                + ", TraineeID=" + saved.getTraineeID() + ", PlacementID=" + saved.getPlacementID());
        return toResponseDTO(saved);
    }

    @Override
    @Transactional
    public List<OJTLogResponseDTO> createLogsBulk(List<OJTLogCreateRequestDTO> logs, Long actorUserID) {
        List<OJTLog> toSave = logs.stream()
                .map(dto -> OJTLog.builder()
                        .placementID(dto.getPlacementID())
                        .traineeID(dto.getTraineeID())
                        .logDate(dto.getLogDate())
                        .tasksPerformed(dto.getTasksPerformed())
                        .hoursWorked(dto.getHoursWorked())
                        .traineeSubmittedAt(LocalDateTime.now())
                        .status(OJTLogStatus.Submitted)
                        .build())
                .toList();
        List<OJTLog> saved = ojtLogRepository.saveAll(toSave);
        audit(actorUserID, "OJTLogsBulkSubmitted",
                "Bulk OJT logs submitted. Count=" + saved.size()
                + (saved.isEmpty() ? "" : ", TraineeID=" + saved.get(0).getTraineeID()
                        + ", PlacementID=" + saved.get(0).getPlacementID()));
        return saved.stream().map(this::toResponseDTO).toList();
    }

    @Override
    @Transactional
    public OJTLogResponseDTO updateLog(Long logID, OJTLogCreateRequestDTO dto, Long actorUserID) {
        OJTLog log = findLog(logID);
        // Only rejected logs can be edited & resubmitted; Submitted is awaiting
        // review and SupervisorConfirmed is final.
        if (log.getStatus() != OJTLogStatus.Rejected) {
            throw new InvalidOJTLogStatusException(
                    "Only rejected logs can be edited and resubmitted. Current status: "
                    + log.getStatus() + ". LogID: " + logID);
        }
        log.setLogDate(dto.getLogDate());
        log.setTasksPerformed(dto.getTasksPerformed());
        log.setHoursWorked(dto.getHoursWorked());
        log.setRejectionReason(null);
        log.setStatus(OJTLogStatus.Submitted);
        log.setTraineeSubmittedAt(LocalDateTime.now());
        OJTLog saved = ojtLogRepository.save(log);
        audit(actorUserID, "OJTLogResubmitted", "OJT log resubmitted. LogID=" + saved.getLogID());
        return toResponseDTO(saved);
    }

    @Override
    @Transactional
    public OJTLogResponseDTO approve(Long logID, Long supervisorUserID) {
        OJTLog log = findLog(logID);
        authorizeSupervisor(log, supervisorUserID);
        doApprove(log, supervisorUserID);
        return toResponseDTO(log);
    }

    @Override
    @Transactional
    public OJTLogResponseDTO reject(Long logID, String rejectionReason, Long supervisorUserID) {
        OJTLog log = findLog(logID);
        authorizeSupervisor(log, supervisorUserID);
        doReject(log, supervisorUserID, rejectionReason);
        return toResponseDTO(log);
    }

    @Override
    @Transactional
    public BulkApproveResponseDTO bulkApprove(List<Long> logIDs, Long supervisorUserID) {
        BulkApproveResponseDTO result = new BulkApproveResponseDTO();
        result.setTotalRequested(logIDs.size());

        for (Long logID : logIDs) {
            try {
                OJTLog log = findLog(logID);
                authorizeSupervisor(log, supervisorUserID);
                doApprove(log, supervisorUserID);
                result.addApproved(logID);
            } catch (RuntimeException ex) {
                result.addFailed(logID, ex.getMessage());
            }
        }
        return result;
    }

    @Override
    @Transactional(readOnly = true)
    public Page<OJTLogResponseDTO> getLogs(OJTLogStatus status, Long placementID, Long traineeID, Pageable pageable) {
        return ojtLogRepository.findAllWithFilters(status, placementID, traineeID, pageable)
                .map(this::toResponseDTO);
    }

    // ── Core operations ────────────────────────────────────────────────────────
    private void doApprove(OJTLog log, Long actorUserID) {
        requireSubmitted(log);
        log.setStatus(OJTLogStatus.SupervisorConfirmed);
        log.setSupervisorConfirmedAt(LocalDateTime.now());
        ojtLogRepository.save(log);

        audit(actorUserID, "OJTLogApproved",
                "OJT log confirmed by supervisor. LogID=" + log.getLogID()
                + ", TraineeID=" + log.getTraineeID() + ", PlacementID=" + log.getPlacementID());

        notifyTrainee(log.getTraineeID(),
                "Your OJT log (ID " + log.getLogID() + ") has been confirmed by your supervisor.");
    }

    private void doReject(OJTLog log, Long actorUserID, String rejectionReason) {
        requireSubmitted(log);
        log.setStatus(OJTLogStatus.Rejected);
        log.setRejectionReason(rejectionReason);
        ojtLogRepository.save(log);

        audit(actorUserID, "OJTLogRejected",
                "OJT log rejected. LogID=" + log.getLogID() + ", Reason=" + rejectionReason);

        notifyTrainee(log.getTraineeID(),
                "Your OJT log (ID " + log.getLogID() + ") was rejected. Reason: " + rejectionReason);
    }

    // ── Guards ─────────────────────────────────────────────────────────────────
    private void requireSubmitted(OJTLog log) {
        if (log.getStatus() != OJTLogStatus.Submitted) {
            throw new InvalidOJTLogStatusException(
                    "Only logs in 'Submitted' status can be approved/rejected. "
                    + "Current status: " + log.getStatus() + ". LogID: " + log.getLogID());
        }
    }

    /**
     * Authorizes the actor as the placement's supervisor. The only available link
     * between an authenticated user and Placement.supervisorName is the user's
     * name, so we match on that (case-insensitive) — same rule as the monolith,
     * now resolved via placement-service and auth-service Feign calls.
     */
    private void authorizeSupervisor(OJTLog log, Long actorUserID) {
        PlacementContract placement = placementClient.getPlacement(log.getPlacementID());
        String supervisorName = placement != null ? placement.getSupervisorName() : null;

        UserContract actor = authClient.getUser(actorUserID);
        String actorName = actor != null ? actor.getName() : null;

        if (supervisorName == null || actorName == null
                || !supervisorName.trim().equalsIgnoreCase(actorName.trim())) {
            throw new UnauthorizedSupervisorException(
                    "User is not the supervisor linked to this placement. LogID: " + log.getLogID());
        }
    }

    // ── Lookups & mapping ────────────────────────────────────────────────────
    private OJTLog findLog(Long logID) {
        return ojtLogRepository.findById(logID)
                .orElseThrow(() -> new OJTLogNotFoundException("OJT log not found with ID: " + logID));
    }

    private void audit(Long userID, String action, String details) {
        platformClient.recordAudit(new AuditLogRequest(userID, action, MODULE, details));
    }

    private void notifyTrainee(Long traineeID, String message) {
        platformClient.notify(new NotificationRequest("TRAINEE", traineeID, message, CATEGORY_OJT));
    }

    private OJTLogResponseDTO toResponseDTO(OJTLog l) {
        return OJTLogResponseDTO.builder()
                .logID(l.getLogID())
                .placementID(l.getPlacementID())
                .traineeID(l.getTraineeID())
                .logDate(l.getLogDate())
                .tasksPerformed(l.getTasksPerformed())
                .hoursWorked(l.getHoursWorked())
                .traineeSubmittedAt(l.getTraineeSubmittedAt())
                .supervisorConfirmedAt(l.getSupervisorConfirmedAt())
                .rejectionReason(l.getRejectionReason())
                .status(l.getStatus())
                .build();
    }
}
