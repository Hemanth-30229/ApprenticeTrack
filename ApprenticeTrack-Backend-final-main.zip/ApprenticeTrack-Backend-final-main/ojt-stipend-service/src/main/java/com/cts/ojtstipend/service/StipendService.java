package com.cts.ojtstipend.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.ojtstipend.dto.BulkApproveResponseDTO;
import com.cts.ojtstipend.dto.StipendCalculateRequestDTO;
import com.cts.ojtstipend.dto.StipendDisbursementResponseDTO;
import com.cts.ojtstipend.common.StipendDisbursementStatus;

public interface StipendService {

    StipendDisbursementResponseDTO calculate(StipendCalculateRequestDTO dto, Long actorUserID);

    Page<StipendDisbursementResponseDTO> getDisbursements(Long traineeID, Long placementID,
                                                          Integer month, Integer year, StipendDisbursementStatus status,
                                                          Pageable pageable);

    StipendDisbursementResponseDTO approve(Long disbursementID, Long actorUserID);

    StipendDisbursementResponseDTO disburse(Long disbursementID, Long actorUserID);

    BulkApproveResponseDTO bulkApprove(List<Long> disbursementIDs, Long actorUserID);
}
