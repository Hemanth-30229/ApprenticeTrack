package com.cts.ojtstipend.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.ojtstipend.client.PlacementClient;
import com.cts.ojtstipend.client.PlatformClient;
import com.cts.ojtstipend.client.dto.AuditLogRequest;
import com.cts.ojtstipend.client.dto.NotificationRequest;
import com.cts.ojtstipend.client.dto.PlacementContract;
import com.cts.ojtstipend.client.dto.VacancyContract;
import com.cts.ojtstipend.dto.BulkApproveResponseDTO;
import com.cts.ojtstipend.dto.StipendCalculateRequestDTO;
import com.cts.ojtstipend.common.OJTAttendanceSummaryStatus;
import com.cts.ojtstipend.common.StipendDisbursementStatus;
import com.cts.ojtstipend.dto.StipendDisbursementResponseDTO;
import com.cts.ojtstipend.entity.OJTAttendanceSummary;
import com.cts.ojtstipend.entity.StipendDisbursement;
import com.cts.ojtstipend.exception.DuplicateStipendDisbursementException;
import com.cts.ojtstipend.exception.InvalidStipendStatusTransitionException;
import com.cts.ojtstipend.exception.NoApprovedAttendanceException;
import com.cts.ojtstipend.exception.PlacementNotFoundException;
import com.cts.ojtstipend.exception.StipendDisbursementNotFoundException;
import com.cts.ojtstipend.exception.VacancyNotFoundException;
import com.cts.ojtstipend.repository.OJTAttendanceSummaryRepository;
import com.cts.ojtstipend.repository.StipendDisbursementRepository;

@Service
public class StipendServiceImpl implements StipendService {

    private static final String MODULE = "Stipend";
    private static final String CATEGORY_STIPEND = "Stipend";

    private final StipendDisbursementRepository stipendRepository;
    private final OJTAttendanceSummaryRepository attendanceRepository;
    private final PlacementClient placementClient;
    private final PlatformClient platformClient;

    @Value("${stipend.eligibility-threshold-percent:80}")
    private double eligibilityThresholdPercent;

    public StipendServiceImpl(StipendDisbursementRepository stipendRepository,
                              OJTAttendanceSummaryRepository attendanceRepository,
                              PlacementClient placementClient,
                              PlatformClient platformClient) {
        this.stipendRepository = stipendRepository;
        this.attendanceRepository = attendanceRepository;
        this.placementClient = placementClient;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional
    public StipendDisbursementResponseDTO calculate(StipendCalculateRequestDTO dto, Long actorUserID) {
        PlacementContract placement = placementClient.getPlacement(dto.getPlacementID());
        if (placement == null) {
            throw new PlacementNotFoundException("Placement not found with ID: " + dto.getPlacementID());
        }

        if (stipendRepository.existsByTraineeIDAndPlacementIDAndMonthAndYear(
                dto.getTraineeID(), dto.getPlacementID(), dto.getMonth(), dto.getYear())) {
            throw new DuplicateStipendDisbursementException(
                    "A stipend disbursement already exists for TraineeID=" + dto.getTraineeID()
                    + ", PlacementID=" + dto.getPlacementID() + ", Month=" + dto.getMonth()
                    + ", Year=" + dto.getYear());
        }

        OJTAttendanceSummary summary = attendanceRepository
                .findByPlacementIDAndMonthAndYearAndStatus(
                        dto.getPlacementID(), dto.getMonth(), dto.getYear(),
                        OJTAttendanceSummaryStatus.Approved)
                .orElseThrow(() -> new NoApprovedAttendanceException(
                        "No approved attendance summary for PlacementID=" + dto.getPlacementID()
                        + ", Month=" + dto.getMonth() + ", Year=" + dto.getYear()));

        double attendancePercent = summary.getAttendancePercent();
        VacancyContract vacancy = placementClient.getVacancy(placement.getVacancyID());
        if (vacancy == null) {
            throw new VacancyNotFoundException("Vacancy not found with ID: " + placement.getVacancyID());
        }

        BigDecimal stipendAmount;
        StipendDisbursementStatus status;
        if (attendancePercent < eligibilityThresholdPercent) {
            stipendAmount = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
            status = StipendDisbursementStatus.Withheld;
        } else {
            stipendAmount = prorate(vacancy.getStipendOffered(), attendancePercent);
            status = StipendDisbursementStatus.Pending;
        }

        StipendDisbursement disbursement = StipendDisbursement.builder()
                .traineeID(dto.getTraineeID())
                .placementID(dto.getPlacementID())
                .month(dto.getMonth())
                .year(dto.getYear())
                .attendancePercent(attendancePercent)
                .stipendAmount(stipendAmount)
                .status(status)
                .build();
        StipendDisbursement saved = stipendRepository.save(disbursement);

        audit(actorUserID, "StipendCalculated", "TraineeID=" + saved.getTraineeID()
                + ", PlacementID=" + saved.getPlacementID() + ", " + saved.getMonth() + "/" + saved.getYear()
                + ", Attendance=" + attendancePercent + "%, Amount=" + stipendAmount
                + ", Status=" + status + " [DisbursementID=" + saved.getDisbursementID() + "]");

        String message = status == StipendDisbursementStatus.Withheld
                ? "Your stipend for " + saved.getMonth() + "/" + saved.getYear()
                        + " was withheld due to attendance below the eligibility threshold."
                : "Your stipend for " + saved.getMonth() + "/" + saved.getYear()
                        + " has been calculated: " + stipendAmount + ".";
        notifyTrainee(saved.getTraineeID(), message);

        return toResponseDTO(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<StipendDisbursementResponseDTO> getDisbursements(Long traineeID, Long placementID,
                                                                 Integer month, Integer year, StipendDisbursementStatus status,
                                                                 Pageable pageable) {
        return stipendRepository.findAllWithFilters(traineeID, placementID, month, year, status, pageable)
                .map(this::toResponseDTO);
    }

    @Override
    @Transactional
    public StipendDisbursementResponseDTO approve(Long disbursementID, Long actorUserID) {
        StipendDisbursement disbursement = findDisbursement(disbursementID);
        doApprove(disbursement, actorUserID);
        return toResponseDTO(disbursement);
    }

    @Override
    @Transactional
    public StipendDisbursementResponseDTO disburse(Long disbursementID, Long actorUserID) {
        StipendDisbursement disbursement = findDisbursement(disbursementID);

        if (disbursement.getStatus() != StipendDisbursementStatus.Approved) {
            throw new InvalidStipendStatusTransitionException(
                    "Only Approved disbursements can be disbursed. Current status: "
                    + disbursement.getStatus() + ". DisbursementID: " + disbursementID);
        }
        disbursement.setStatus(StipendDisbursementStatus.Disbursed);
        disbursement.setDisbursedDate(LocalDate.now());
        stipendRepository.save(disbursement);

        audit(actorUserID, "StipendDisbursed", "[DisbursementID=" + disbursementID + "]");
        notifyTrainee(disbursement.getTraineeID(),
                "Your stipend (ID " + disbursementID + ") has been disbursed on " + disbursement.getDisbursedDate() + ".");
        return toResponseDTO(disbursement);
    }

    @Override
    @Transactional
    public BulkApproveResponseDTO bulkApprove(List<Long> disbursementIDs, Long actorUserID) {
        BulkApproveResponseDTO response = new BulkApproveResponseDTO();
        response.setTotalRequested(disbursementIDs.size());

        for (Long id : disbursementIDs) {
            try {
                StipendDisbursement disbursement = findDisbursement(id);
                doApprove(disbursement, actorUserID);
                response.addApproved(id);
            } catch (RuntimeException ex) {
                response.addFailed(id, ex.getMessage());
            }
        }
        return response;
    }

    // ── Core ─────────────────────────────────────────────────────────────────
    private void doApprove(StipendDisbursement disbursement, Long actorUserID) {
        if (disbursement.getStatus() != StipendDisbursementStatus.Pending) {
            throw new InvalidStipendStatusTransitionException(
                    "Only Pending disbursements can be approved. Current status: "
                    + disbursement.getStatus() + ". DisbursementID: " + disbursement.getDisbursementID());
        }
        disbursement.setStatus(StipendDisbursementStatus.Approved);
        stipendRepository.save(disbursement);
        audit(actorUserID, "StipendApproved",
                "Stipend approved. DisbursementID=" + disbursement.getDisbursementID()
                + ", TraineeID=" + disbursement.getTraineeID()
                + ", Amount=" + disbursement.getStipendAmount());
        notifyTrainee(disbursement.getTraineeID(),
                "Your stipend (ID " + disbursement.getDisbursementID() + ") has been approved.");
    }

    /** Full stipend at 100%+, otherwise prorated by attendance percent. */
    private BigDecimal prorate(BigDecimal stipendOffered, double attendancePercent) {
        if (attendancePercent >= 100.0) {
            return stipendOffered.setScale(2, RoundingMode.HALF_UP);
        }
        return stipendOffered
                .multiply(BigDecimal.valueOf(attendancePercent))
                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
    }

    // ── Lookups & mapping ────────────────────────────────────────────────────
    private StipendDisbursement findDisbursement(Long disbursementID) {
        return stipendRepository.findById(disbursementID)
                .orElseThrow(() -> new StipendDisbursementNotFoundException(
                        "Stipend disbursement not found with ID: " + disbursementID));
    }

    private void audit(Long userID, String action, String details) {
        platformClient.recordAudit(new AuditLogRequest(userID, action, MODULE, details));
    }

    private void notifyTrainee(Long traineeID, String message) {
        platformClient.notify(new NotificationRequest("TRAINEE", traineeID, message, CATEGORY_STIPEND));
    }

    private StipendDisbursementResponseDTO toResponseDTO(StipendDisbursement s) {
        return StipendDisbursementResponseDTO.builder()
                .disbursementID(s.getDisbursementID())
                .traineeID(s.getTraineeID())
                .placementID(s.getPlacementID())
                .month(s.getMonth())
                .year(s.getYear())
                .attendancePercent(s.getAttendancePercent())
                .stipendAmount(s.getStipendAmount())
                .disbursedDate(s.getDisbursedDate())
                .status(s.getStatus())
                .build();
    }
}
