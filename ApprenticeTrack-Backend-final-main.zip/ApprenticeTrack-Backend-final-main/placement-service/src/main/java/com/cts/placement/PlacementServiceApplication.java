package com.cts.placement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Placement-service: employers, apprenticeship vacancies, and trainee placements
 * (MIGRATION_PLAN.md §1). Trainee validation/enrollment writes go to training-service
 * and audit/notification to platform-service via Resilience4j-backed Feign clients.
 *
 * <p>{@code @EnableScheduling} drives {@code VacancyExpiryScheduler}'s daily expiry job.
 */
@SpringBootApplication
@EnableFeignClients
@EnableScheduling
public class PlacementServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(PlacementServiceApplication.class, args);
    }
}