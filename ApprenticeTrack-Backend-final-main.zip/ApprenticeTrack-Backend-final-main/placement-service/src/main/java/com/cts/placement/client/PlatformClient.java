package com.cts.placement.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cts.placement.client.dto.AuditLogRequest;
import com.cts.placement.client.dto.NotificationRequest;

/**
 * Feign client to platform-service, which owns audit logging and notification dispatch
 * (MIGRATION_PLAN.md §6). Both calls are best-effort: {@link PlatformClientFallback} keeps
 * placement flows working when platform-service is down.
 */
@FeignClient(name = "platform-service", fallback = PlatformClientFallback.class)
public interface PlatformClient {

    /** Records an audit-log entry (was a direct {@code AuditLogRepository.save} in the monolith). */
    @PostMapping("/api/audit-logs")
    void recordAudit(@RequestBody AuditLogRequest request);

    /** Raises an in-app notification (was {@code NotificationDispatcher} in the monolith). */
    @PostMapping("/api/notifications")
    void notify(@RequestBody NotificationRequest request);
}