package com.cts.placement.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.placement.client.dto.TraineeContract;

/**
 * Feign client to training-service, which owns trainees and course enrollments
 * (MIGRATION_PLAN.md §6). Replaces the in-process {@code TraineeRepository} and
 * {@code CourseEnrollmentRepository} reads/writes the monolith placement code performed.
 * Guarded by {@link TrainingClientFallback}.
 */
@FeignClient(name = "training-service", fallback = TrainingClientFallback.class)
public interface TrainingClient {

    /** Returns the trainee, or {@code null} if training-service reports none. */
    @GetMapping("/api/trainees/{traineeId}")
    TraineeContract getTrainee(@PathVariable("traineeId") Long traineeId);

    /**
     * Whether the trainee has an OJTInProgress enrollment — replaces
     * {@code CourseEnrollmentRepository.existsByTraineeIDAndStatus(id, OJTInProgress)}.
     */
    @GetMapping("/api/enrollments/ojt-in-progress")
    Boolean isTraineeInOjt(@RequestParam("traineeId") Long traineeId);

    /**
     * Cross-service write: promotes the trainee's Enrolled enrollments to OJTInProgress
     * when a placement is created. Owned by training-service.
     */
    @PutMapping("/api/enrollments/promote-ojt")
    void promoteEnrollmentsToOjt(@RequestParam("traineeId") Long traineeId);
}