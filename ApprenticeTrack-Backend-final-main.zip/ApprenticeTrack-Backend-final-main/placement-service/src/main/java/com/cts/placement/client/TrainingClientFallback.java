package com.cts.placement.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cts.placement.client.dto.TraineeContract;

/**
 * Degraded-mode fallback for {@link TrainingClient}. When training-service is unreachable,
 * the trainee lookup returns {@code null} (callers fail closed with not-found), the OJT check
 * returns {@code false}, and the enrollment promotion is dropped with a warning.
 */
@Component
public class TrainingClientFallback implements TrainingClient {

    private static final Logger log = LoggerFactory.getLogger(TrainingClientFallback.class);

    @Override
    public TraineeContract getTrainee(Long traineeId) {
        log.warn("training-service unavailable; cannot resolve traineeID={}", traineeId);
        return null;
    }

    @Override
    public Boolean isTraineeInOjt(Long traineeId) {
        log.warn("training-service unavailable; cannot verify OJT status for traineeID={}", traineeId);
        return false;
    }

    @Override
    public void promoteEnrollmentsToOjt(Long traineeId) {
        log.warn("training-service unavailable; enrollment OJT promotion dropped for traineeID={}", traineeId);
    }
}