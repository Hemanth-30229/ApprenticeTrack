package com.cts.placement.client.dto;

/**
 * Lightweight view of a training-service {@code Trainee}. Carries {@code status} so
 * placement-service can check eligibility without owning the trainee table. Status is a
 * plain string to avoid depending on the training-owned enum.
 */
public class TraineeContract {

    private Long traineeID;
    private String name;
    private String status;

    public TraineeContract() {}

    public Long getTraineeID() { return traineeID; }
    public void setTraineeID(Long traineeID) { this.traineeID = traineeID; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}