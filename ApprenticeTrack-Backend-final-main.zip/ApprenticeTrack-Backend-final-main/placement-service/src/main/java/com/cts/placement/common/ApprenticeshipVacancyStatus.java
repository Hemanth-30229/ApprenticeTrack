package com.cts.placement.common;

public enum ApprenticeshipVacancyStatus {
    Open, PartiallyFilled, Filled, Expired
}
