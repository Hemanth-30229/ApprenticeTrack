package com.cts.placement.common;

public enum EmployerStatus {
    Active, Suspended, Deregistered
}
