package com.cts.placement.common;

public enum PlacementStatus {
    Active, Completed, Terminated
}
