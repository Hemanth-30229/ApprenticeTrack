package com.cts.placement.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.placement.dto.EmployerCreateRequestDTO;
import com.cts.placement.dto.EmployerResponseDTO;
import com.cts.placement.dto.EmployerStatusUpdateRequestDTO;
import com.cts.placement.dto.EmployerUpdateRequestDTO;
import com.cts.placement.common.EmployerStatus;
import com.cts.placement.service.EmployerService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/employers")
@SecurityRequirement(name = "bearerAuth")
public class EmployerController {

    private final EmployerService employerService;

    public EmployerController(EmployerService employerService) {
        this.employerService = employerService;
    }

    @PostMapping
    public ResponseEntity<EmployerResponseDTO> registerEmployer(
            @Valid @RequestBody EmployerCreateRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(employerService.registerEmployer(requestDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EmployerResponseDTO> getEmployer(@PathVariable Long id) {
        return ResponseEntity.ok(employerService.getEmployerById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EmployerResponseDTO> updateEmployer(
            @PathVariable Long id, @Valid @RequestBody EmployerUpdateRequestDTO requestDTO) {
        return ResponseEntity.ok(employerService.updateEmployer(id, requestDTO));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<EmployerResponseDTO> updateStatus(
            @PathVariable Long id, @Valid @RequestBody EmployerStatusUpdateRequestDTO requestDTO) {
        return ResponseEntity.ok(employerService.updateStatus(id, requestDTO));
    }

    @GetMapping
    public ResponseEntity<Page<EmployerResponseDTO>> getAllEmployers(
            @RequestParam(required = false) EmployerStatus status,
            @RequestParam(required = false) String industrySector,
            @RequestParam(required = false) String companyName,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "companyName,asc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("desc")
                ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(
                employerService.getAllEmployers(status, industrySector, companyName, pageable));
    }
}