package com.cts.placement.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.placement.dto.PlacementCreateRequestDTO;
import com.cts.placement.dto.PlacementResponseDTO;
import com.cts.placement.dto.PlacementStatusUpdateRequestDTO;
import com.cts.placement.common.PlacementStatus;
import com.cts.placement.service.PlacementService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/placements")
@SecurityRequirement(name = "bearerAuth")
public class PlacementController {

    private final PlacementService placementService;

    public PlacementController(PlacementService placementService) {
        this.placementService = placementService;
    }

    @PostMapping
    public ResponseEntity<PlacementResponseDTO> createPlacement(
            @Valid @RequestBody PlacementCreateRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(placementService.createPlacement(requestDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<PlacementResponseDTO> getPlacement(@PathVariable Long id) {
        return ResponseEntity.ok(placementService.getPlacementById(id));
    }

    @GetMapping
    public ResponseEntity<Page<PlacementResponseDTO>> getAllPlacements(
            @RequestParam(required = false) Long traineeID,
            @RequestParam(required = false) Long employerID,
            @RequestParam(required = false) Long vacancyID,
            @RequestParam(required = false) PlacementStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "placementDate,desc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("asc")
                ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(
                placementService.getAllPlacements(traineeID, employerID, vacancyID, status, pageable));
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<PlacementResponseDTO> updateStatus(
            @PathVariable Long id, @Valid @RequestBody PlacementStatusUpdateRequestDTO requestDTO) {
        return ResponseEntity.ok(placementService.updateStatus(id, requestDTO.getStatus()));
    }
}
