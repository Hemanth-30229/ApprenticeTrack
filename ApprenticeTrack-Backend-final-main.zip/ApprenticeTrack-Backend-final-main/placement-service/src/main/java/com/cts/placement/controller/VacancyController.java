package com.cts.placement.controller;

import java.time.LocalDate;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.placement.dto.VacancyCreateRequestDTO;
import com.cts.placement.dto.VacancyResponseDTO;
import com.cts.placement.dto.VacancyUpdateRequestDTO;
import com.cts.placement.common.ApprenticeshipVacancyStatus;
import com.cts.placement.service.VacancyService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/vacancies")
@SecurityRequirement(name = "bearerAuth")
public class VacancyController {

    private final VacancyService vacancyService;

    public VacancyController(VacancyService vacancyService) {
        this.vacancyService = vacancyService;
    }

    @PostMapping
    public ResponseEntity<VacancyResponseDTO> createVacancy(
            @Valid @RequestBody VacancyCreateRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(vacancyService.createVacancy(requestDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<VacancyResponseDTO> getVacancy(@PathVariable Long id) {
        return ResponseEntity.ok(vacancyService.getVacancyById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<VacancyResponseDTO> updateVacancy(
            @PathVariable Long id, @Valid @RequestBody VacancyUpdateRequestDTO requestDTO) {
        return ResponseEntity.ok(vacancyService.updateVacancy(id, requestDTO));
    }

    @GetMapping
    public ResponseEntity<Page<VacancyResponseDTO>> getAllVacancies(
            @RequestParam(required = false) Long employerID,
            @RequestParam(required = false) String tradeRequired,
            @RequestParam(required = false) ApprenticeshipVacancyStatus status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "postedDate,desc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("asc")
                ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(
                vacancyService.getAllVacancies(employerID, tradeRequired, status,
                        fromDate, toDate, pageable));
    }

    @PostMapping("/expire")
    public ResponseEntity<Map<String, Object>> triggerExpiry() {
        int count = vacancyService.expireOldVacancies();
        return ResponseEntity.ok(Map.of("message", "Expiry job completed", "expiredCount", count));
    }
}