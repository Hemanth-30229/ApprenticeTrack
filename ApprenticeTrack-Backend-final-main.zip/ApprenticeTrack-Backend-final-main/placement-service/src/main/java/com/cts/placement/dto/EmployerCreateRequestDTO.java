package com.cts.placement.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class EmployerCreateRequestDTO {
    @NotBlank(message = "Company name is required") private String companyName;
    @NotBlank(message = "Industry sector is required") private String industrySector;
    @NotBlank(message = "Address is required") private String address;
    @NotBlank(message = "Contact person is required") private String contactPerson;
    @NotNull(message = "Apprenticeship capacity is required")
    @Positive(message = "Apprenticeship capacity must be a positive integer")
    private Integer apprenticeshipCapacity;

    public EmployerCreateRequestDTO() {}
    public String getCompanyName() { return companyName; }
    public String getIndustrySector() { return industrySector; }
    public String getAddress() { return address; }
    public String getContactPerson() { return contactPerson; }
    public Integer getApprenticeshipCapacity() { return apprenticeshipCapacity; }
    public void setCompanyName(String v) { this.companyName = v; }
    public void setIndustrySector(String v) { this.industrySector = v; }
    public void setAddress(String v) { this.address = v; }
    public void setContactPerson(String v) { this.contactPerson = v; }
    public void setApprenticeshipCapacity(Integer v) { this.apprenticeshipCapacity = v; }
}