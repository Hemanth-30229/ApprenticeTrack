package com.cts.placement.dto;

import java.time.LocalDate;

import com.cts.placement.common.EmployerStatus;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmployerResponseDTO {

    private Long employerID;
    private String companyName;
    private String industrySector;
    private String address;
    private String contactPerson;
    private Integer apprenticeshipCapacity;
    private LocalDate registrationDate;
    private EmployerStatus status;
}