package com.cts.placement.dto;

import com.cts.placement.common.EmployerStatus;

import jakarta.validation.constraints.NotNull;

public class EmployerStatusUpdateRequestDTO {
    @NotNull(message = "Status is required") private EmployerStatus status;
    public EmployerStatusUpdateRequestDTO() {}
    public EmployerStatus getStatus() { return status; }
    public void setStatus(EmployerStatus status) { this.status = status; }
}
