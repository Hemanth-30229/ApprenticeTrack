package com.cts.placement.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class EmployerUpdateRequestDTO {
    @NotBlank(message = "Address is required") private String address;
    @NotBlank(message = "Contact person is required") private String contactPerson;
    @NotNull(message = "Apprenticeship capacity is required")
    @Positive(message = "Apprenticeship capacity must be a positive integer")
    private Integer apprenticeshipCapacity;
    @NotBlank(message = "Industry sector is required") private String industrySector;

    public EmployerUpdateRequestDTO() {}
    public String getAddress() { return address; }
    public String getContactPerson() { return contactPerson; }
    public Integer getApprenticeshipCapacity() { return apprenticeshipCapacity; }
    public String getIndustrySector() { return industrySector; }
    public void setAddress(String v) { this.address = v; }
    public void setContactPerson(String v) { this.contactPerson = v; }
    public void setApprenticeshipCapacity(Integer v) { this.apprenticeshipCapacity = v; }
    public void setIndustrySector(String v) { this.industrySector = v; }
}