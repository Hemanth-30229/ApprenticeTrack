package com.cts.placement.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class PlacementCreateRequestDTO {

    @NotNull(message = "TraineeID is required")
    private Long traineeID;

    @NotNull(message = "VacancyID is required")
    private Long vacancyID;

    @NotNull(message = "EmployerID is required")
    private Long employerID;

    @NotBlank(message = "Supervisor name is required")
    private String supervisorName;

    @NotBlank(message = "Supervisor phone is required")
    @Pattern(regexp = "^[6-9]\\d{9}$", message = "Supervisor phone must be a valid 10-digit Indian mobile number")
    private String supervisorPhone;

    /** Optional — defaults to the current date when omitted. */
    private LocalDate placementDate;

    public PlacementCreateRequestDTO() {}

    public Long getTraineeID() { return traineeID; }
    public Long getVacancyID() { return vacancyID; }
    public Long getEmployerID() { return employerID; }
    public String getSupervisorName() { return supervisorName; }
    public String getSupervisorPhone() { return supervisorPhone; }
    public LocalDate getPlacementDate() { return placementDate; }

    public void setTraineeID(Long traineeID) { this.traineeID = traineeID; }
    public void setVacancyID(Long vacancyID) { this.vacancyID = vacancyID; }
    public void setEmployerID(Long employerID) { this.employerID = employerID; }
    public void setSupervisorName(String supervisorName) { this.supervisorName = supervisorName; }
    public void setSupervisorPhone(String supervisorPhone) { this.supervisorPhone = supervisorPhone; }
    public void setPlacementDate(LocalDate placementDate) { this.placementDate = placementDate; }
}
