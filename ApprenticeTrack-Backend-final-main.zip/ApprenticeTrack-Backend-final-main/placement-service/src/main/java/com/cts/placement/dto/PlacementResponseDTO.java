package com.cts.placement.dto;

import java.time.LocalDate;

import com.cts.placement.common.PlacementStatus;

public class PlacementResponseDTO {

    private Long placementID, traineeID, vacancyID, employerID;
    private String traineeName, employerName, supervisorName, supervisorPhone;
    private LocalDate placementDate;
    private PlacementStatus status;

    public PlacementResponseDTO() {}

    public Long getPlacementID() { return placementID; }
    public Long getTraineeID() { return traineeID; }
    public Long getVacancyID() { return vacancyID; }
    public Long getEmployerID() { return employerID; }
    public String getTraineeName() { return traineeName; }
    public String getEmployerName() { return employerName; }
    public String getSupervisorName() { return supervisorName; }
    public String getSupervisorPhone() { return supervisorPhone; }
    public LocalDate getPlacementDate() { return placementDate; }
    public PlacementStatus getStatus() { return status; }

    public void setPlacementID(Long v) { this.placementID = v; }
    public void setTraineeID(Long v) { this.traineeID = v; }
    public void setVacancyID(Long v) { this.vacancyID = v; }
    public void setEmployerID(Long v) { this.employerID = v; }
    public void setTraineeName(String v) { this.traineeName = v; }
    public void setEmployerName(String v) { this.employerName = v; }
    public void setSupervisorName(String v) { this.supervisorName = v; }
    public void setSupervisorPhone(String v) { this.supervisorPhone = v; }
    public void setPlacementDate(LocalDate v) { this.placementDate = v; }
    public void setStatus(PlacementStatus v) { this.status = v; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long placementID, traineeID, vacancyID, employerID;
        private String traineeName, employerName, supervisorName, supervisorPhone;
        private LocalDate placementDate;
        private PlacementStatus status;

        public Builder placementID(Long v) { this.placementID = v; return this; }
        public Builder traineeID(Long v) { this.traineeID = v; return this; }
        public Builder vacancyID(Long v) { this.vacancyID = v; return this; }
        public Builder employerID(Long v) { this.employerID = v; return this; }
        public Builder traineeName(String v) { this.traineeName = v; return this; }
        public Builder employerName(String v) { this.employerName = v; return this; }
        public Builder supervisorName(String v) { this.supervisorName = v; return this; }
        public Builder supervisorPhone(String v) { this.supervisorPhone = v; return this; }
        public Builder placementDate(LocalDate v) { this.placementDate = v; return this; }
        public Builder status(PlacementStatus v) { this.status = v; return this; }

        public PlacementResponseDTO build() {
            PlacementResponseDTO d = new PlacementResponseDTO();
            d.placementID = placementID; d.traineeID = traineeID; d.vacancyID = vacancyID;
            d.employerID = employerID; d.traineeName = traineeName; d.employerName = employerName;
            d.supervisorName = supervisorName; d.supervisorPhone = supervisorPhone;
            d.placementDate = placementDate; d.status = status;
            return d;
        }
    }
}
