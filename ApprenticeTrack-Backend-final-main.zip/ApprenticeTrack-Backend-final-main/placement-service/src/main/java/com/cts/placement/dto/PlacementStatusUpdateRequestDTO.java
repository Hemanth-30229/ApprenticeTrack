package com.cts.placement.dto;

import com.cts.placement.common.PlacementStatus;

import jakarta.validation.constraints.NotNull;

public class PlacementStatusUpdateRequestDTO {

    @NotNull(message = "Status is required")
    private PlacementStatus status;

    public PlacementStatusUpdateRequestDTO() {}

    public PlacementStatus getStatus() { return status; }
    public void setStatus(PlacementStatus status) { this.status = status; }
}
