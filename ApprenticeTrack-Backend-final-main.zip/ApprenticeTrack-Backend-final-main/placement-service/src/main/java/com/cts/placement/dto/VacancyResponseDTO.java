package com.cts.placement.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.cts.placement.common.ApprenticeshipVacancyStatus;

public class VacancyResponseDTO {
    private Long vacancyID, employerID; private String companyName, tradeRequired;
    private Integer vacancyCount, filledCount; private BigDecimal stipendOffered;
    private LocalDate postedDate; private ApprenticeshipVacancyStatus status;

    public VacancyResponseDTO() {}
    public Long getVacancyID() { return vacancyID; }
    public Long getEmployerID() { return employerID; }
    public String getCompanyName() { return companyName; }
    public String getTradeRequired() { return tradeRequired; }
    public Integer getVacancyCount() { return vacancyCount; }
    public Integer getFilledCount() { return filledCount; }
    public BigDecimal getStipendOffered() { return stipendOffered; }
    public LocalDate getPostedDate() { return postedDate; }
    public ApprenticeshipVacancyStatus getStatus() { return status; }
    public void setVacancyID(Long v) { this.vacancyID = v; }
    public void setEmployerID(Long v) { this.employerID = v; }
    public void setCompanyName(String v) { this.companyName = v; }
    public void setTradeRequired(String v) { this.tradeRequired = v; }
    public void setVacancyCount(Integer v) { this.vacancyCount = v; }
    public void setFilledCount(Integer v) { this.filledCount = v; }
    public void setStipendOffered(BigDecimal v) { this.stipendOffered = v; }
    public void setPostedDate(LocalDate v) { this.postedDate = v; }
    public void setStatus(ApprenticeshipVacancyStatus v) { this.status = v; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long vacancyID, employerID; private String companyName, tradeRequired;
        private Integer vacancyCount, filledCount; private BigDecimal stipendOffered;
        private LocalDate postedDate; private ApprenticeshipVacancyStatus status;
        public Builder vacancyID(Long v) { this.vacancyID = v; return this; }
        public Builder employerID(Long v) { this.employerID = v; return this; }
        public Builder companyName(String v) { this.companyName = v; return this; }
        public Builder tradeRequired(String v) { this.tradeRequired = v; return this; }
        public Builder vacancyCount(Integer v) { this.vacancyCount = v; return this; }
        public Builder filledCount(Integer v) { this.filledCount = v; return this; }
        public Builder stipendOffered(BigDecimal v) { this.stipendOffered = v; return this; }
        public Builder postedDate(LocalDate v) { this.postedDate = v; return this; }
        public Builder status(ApprenticeshipVacancyStatus v) { this.status = v; return this; }
        public VacancyResponseDTO build() {
            VacancyResponseDTO d = new VacancyResponseDTO();
            d.vacancyID=vacancyID; d.employerID=employerID; d.companyName=companyName;
            d.tradeRequired=tradeRequired; d.vacancyCount=vacancyCount; d.filledCount=filledCount;
            d.stipendOffered=stipendOffered; d.postedDate=postedDate; d.status=status; return d;
        }
    }
}