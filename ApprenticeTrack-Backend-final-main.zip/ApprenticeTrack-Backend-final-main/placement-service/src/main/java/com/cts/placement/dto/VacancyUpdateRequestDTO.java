package com.cts.placement.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class VacancyUpdateRequestDTO {
    @NotBlank(message = "Trade required is required") private String tradeRequired;
    @NotNull(message = "Vacancy count is required")
    @Positive(message = "Vacancy count must be a positive integer") private Integer vacancyCount;
    @NotNull(message = "Stipend offered is required")
    @DecimalMin(value = "0.0", inclusive = true, message = "Stipend offered must be non-negative")
    @Digits(integer = 8, fraction = 2, message = "Stipend must be a valid decimal") private BigDecimal stipendOffered;

    public VacancyUpdateRequestDTO() {}
    public String getTradeRequired() { return tradeRequired; }
    public Integer getVacancyCount() { return vacancyCount; }
    public BigDecimal getStipendOffered() { return stipendOffered; }
    public void setTradeRequired(String v) { this.tradeRequired = v; }
    public void setVacancyCount(Integer v) { this.vacancyCount = v; }
    public void setStipendOffered(BigDecimal v) { this.stipendOffered = v; }
}