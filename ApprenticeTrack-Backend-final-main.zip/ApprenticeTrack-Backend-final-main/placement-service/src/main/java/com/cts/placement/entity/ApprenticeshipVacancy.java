package com.cts.placement.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.cts.placement.common.ApprenticeshipVacancyStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity
@Table(name = "apprenticeship_vacancies")
public class ApprenticeshipVacancy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long vacancyID;

    @NotNull(message = "EmployerID is required")
    @Column(nullable = false)
    private Long employerID;

    @NotBlank(message = "Trade required is required")
    @Column(nullable = false)
    private String tradeRequired;

    @NotNull(message = "Vacancy count is required")
    @Positive(message = "Vacancy count must be a positive integer")
    @Column(nullable = false)
    private Integer vacancyCount;

    @NotNull(message = "Stipend offered is required")
    @DecimalMin(value = "0.0", inclusive = true, message = "Stipend offered must be non-negative")
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal stipendOffered;

    @Column(nullable = false)
    private LocalDate postedDate = LocalDate.now();

    @Column(nullable = false)
    private Integer filledCount = 0;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ApprenticeshipVacancyStatus status = ApprenticeshipVacancyStatus.Open;

    public ApprenticeshipVacancy() {}

    public void recalculateStatus() {
        if (this.status == ApprenticeshipVacancyStatus.Expired) {
			return;
		}
        if (this.filledCount >= this.vacancyCount) {
            this.status = ApprenticeshipVacancyStatus.Filled;
        } else if (this.filledCount > 0) {
            this.status = ApprenticeshipVacancyStatus.PartiallyFilled;
        } else {
            this.status = ApprenticeshipVacancyStatus.Open;
        }
    }

    // ── Getters ───────────────────────────────────────────────────────────────
    public Long getVacancyID() { return vacancyID; }
    public Long getEmployerID() { return employerID; }
    public String getTradeRequired() { return tradeRequired; }
    public Integer getVacancyCount() { return vacancyCount; }
    public BigDecimal getStipendOffered() { return stipendOffered; }
    public LocalDate getPostedDate() { return postedDate; }
    public Integer getFilledCount() { return filledCount; }
    public ApprenticeshipVacancyStatus getStatus() { return status; }

    // ── Setters ───────────────────────────────────────────────────────────────
    public void setVacancyID(Long vacancyID) { this.vacancyID = vacancyID; }
    public void setEmployerID(Long employerID) { this.employerID = employerID; }
    public void setTradeRequired(String tradeRequired) { this.tradeRequired = tradeRequired; }
    public void setVacancyCount(Integer vacancyCount) { this.vacancyCount = vacancyCount; }
    public void setStipendOffered(BigDecimal stipendOffered) { this.stipendOffered = stipendOffered; }
    public void setPostedDate(LocalDate postedDate) { this.postedDate = postedDate; }
    public void setFilledCount(Integer filledCount) { this.filledCount = filledCount; }
    public void setStatus(ApprenticeshipVacancyStatus status) { this.status = status; }

    // ── Builder ───────────────────────────────────────────────────────────────
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long vacancyID, employerID;
        private String tradeRequired;
        private Integer vacancyCount;
        private BigDecimal stipendOffered;
        private LocalDate postedDate = LocalDate.now();
        private Integer filledCount = 0;
        private ApprenticeshipVacancyStatus status = ApprenticeshipVacancyStatus.Open;

        public Builder vacancyID(Long v) { this.vacancyID = v; return this; }
        public Builder employerID(Long v) { this.employerID = v; return this; }
        public Builder tradeRequired(String v) { this.tradeRequired = v; return this; }
        public Builder vacancyCount(Integer v) { this.vacancyCount = v; return this; }
        public Builder stipendOffered(BigDecimal v) { this.stipendOffered = v; return this; }
        public Builder postedDate(LocalDate v) { this.postedDate = v; return this; }
        public Builder filledCount(Integer v) { this.filledCount = v; return this; }
        public Builder status(ApprenticeshipVacancyStatus v) { this.status = v; return this; }

        public ApprenticeshipVacancy build() {
            ApprenticeshipVacancy av = new ApprenticeshipVacancy();
            av.vacancyID = this.vacancyID; av.employerID = this.employerID;
            av.tradeRequired = this.tradeRequired; av.vacancyCount = this.vacancyCount;
            av.stipendOffered = this.stipendOffered; av.postedDate = this.postedDate;
            av.filledCount = this.filledCount; av.status = this.status;
            return av;
        }
    }
}