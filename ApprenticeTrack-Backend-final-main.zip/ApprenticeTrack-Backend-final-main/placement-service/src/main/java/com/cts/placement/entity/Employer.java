package com.cts.placement.entity;

import java.time.LocalDate;

import com.cts.placement.common.EmployerStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity
@Table(name = "employers",
    uniqueConstraints = @UniqueConstraint(name = "uq_company_sector",
        columnNames = {"company_name", "industry_sector"}))
public class Employer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long employerID;

    @NotBlank(message = "Company name is required")
    @Column(name = "company_name", nullable = false)
    private String companyName;

    @NotBlank(message = "Industry sector is required")
    @Column(name = "industry_sector", nullable = false)
    private String industrySector;

    @NotBlank(message = "Address is required")
    @Column(nullable = false, length = 500)
    private String address;

    @NotBlank(message = "Contact person is required")
    @Column(nullable = false)
    private String contactPerson;

    @NotNull(message = "Apprenticeship capacity is required")
    @Positive(message = "Apprenticeship capacity must be a positive integer")
    @Column(nullable = false)
    private Integer apprenticeshipCapacity;

    @Column(nullable = false)
    private LocalDate registrationDate = LocalDate.now();

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EmployerStatus status = EmployerStatus.Active;

    public Employer() {}

    // ── Getters ───────────────────────────────────────────────────────────────
    public Long getEmployerID() { return employerID; }
    public String getCompanyName() { return companyName; }
    public String getIndustrySector() { return industrySector; }
    public String getAddress() { return address; }
    public String getContactPerson() { return contactPerson; }
    public Integer getApprenticeshipCapacity() { return apprenticeshipCapacity; }
    public LocalDate getRegistrationDate() { return registrationDate; }
    public EmployerStatus getStatus() { return status; }

    // ── Setters ───────────────────────────────────────────────────────────────
    public void setEmployerID(Long employerID) { this.employerID = employerID; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }
    public void setIndustrySector(String industrySector) { this.industrySector = industrySector; }
    public void setAddress(String address) { this.address = address; }
    public void setContactPerson(String contactPerson) { this.contactPerson = contactPerson; }
    public void setApprenticeshipCapacity(Integer v) { this.apprenticeshipCapacity = v; }
    public void setRegistrationDate(LocalDate registrationDate) { this.registrationDate = registrationDate; }
    public void setStatus(EmployerStatus status) { this.status = status; }

    // ── Builder ───────────────────────────────────────────────────────────────
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long employerID;
        private String companyName, industrySector, address, contactPerson;
        private Integer apprenticeshipCapacity;
        private LocalDate registrationDate = LocalDate.now();
        private EmployerStatus status = EmployerStatus.Active;

        public Builder employerID(Long v) { this.employerID = v; return this; }
        public Builder companyName(String v) { this.companyName = v; return this; }
        public Builder industrySector(String v) { this.industrySector = v; return this; }
        public Builder address(String v) { this.address = v; return this; }
        public Builder contactPerson(String v) { this.contactPerson = v; return this; }
        public Builder apprenticeshipCapacity(Integer v) { this.apprenticeshipCapacity = v; return this; }
        public Builder registrationDate(LocalDate v) { this.registrationDate = v; return this; }
        public Builder status(EmployerStatus v) { this.status = v; return this; }

        public Employer build() {
            Employer e = new Employer();
            e.employerID = this.employerID; e.companyName = this.companyName;
            e.industrySector = this.industrySector; e.address = this.address;
            e.contactPerson = this.contactPerson;
            e.apprenticeshipCapacity = this.apprenticeshipCapacity;
            e.registrationDate = this.registrationDate; e.status = this.status;
            return e;
        }
    }
}