package com.cts.placement.entity;

import java.time.LocalDate;

import com.cts.placement.common.PlacementStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "placements")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Placement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long placementID;

    @Column(nullable = false)
    private Long traineeID;

    @Column(nullable = false)
    private Long vacancyID;

    @Column(nullable = false)
    private Long employerID;

    @Column(nullable = false)
    private LocalDate placementDate;

    private String supervisorName;

    private String supervisorPhone;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private PlacementStatus status = PlacementStatus.Active;
}
