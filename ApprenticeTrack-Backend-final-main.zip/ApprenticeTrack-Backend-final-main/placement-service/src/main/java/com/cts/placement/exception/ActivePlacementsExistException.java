package com.cts.placement.exception;

public class ActivePlacementsExistException extends RuntimeException {
    public ActivePlacementsExistException(String message) {
        super(message);
    }
}
