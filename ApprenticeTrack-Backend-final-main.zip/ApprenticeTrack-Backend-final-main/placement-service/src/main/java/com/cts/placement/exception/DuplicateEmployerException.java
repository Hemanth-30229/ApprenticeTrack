package com.cts.placement.exception;

public class DuplicateEmployerException extends RuntimeException {
    public DuplicateEmployerException(String message) {
        super(message);
    }
}
