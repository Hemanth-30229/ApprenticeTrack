package com.cts.placement.exception;

public class DuplicatePlacementException extends RuntimeException {
    public DuplicatePlacementException(String message) {
        super(message);
    }
}
