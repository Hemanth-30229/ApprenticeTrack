package com.cts.placement.exception;

public class EmployerNotActiveException extends RuntimeException {
    public EmployerNotActiveException(String message) {
        super(message);
    }
}
