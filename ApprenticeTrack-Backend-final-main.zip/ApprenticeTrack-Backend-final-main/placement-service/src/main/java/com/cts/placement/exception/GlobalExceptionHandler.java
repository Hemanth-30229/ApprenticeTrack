package com.cts.placement.exception;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Centralized exception handling for placement-service. Scoped to the exceptions this
 * service raises (employers, vacancies, placements) plus the cross-domain validation
 * failures it reports when a training-service Feign lookup comes back empty. Response
 * shape and status codes match the monolith's for client compatibility.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    // 400 - Validation errors (field-level)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationErrors(MethodArgumentNotValidException ex) {
        Map<String, String> fieldErrors = new HashMap<>();
        ex.getBindingResult().getFieldErrors()
                .forEach(err -> fieldErrors.put(err.getField(), err.getDefaultMessage()));

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("status", HttpStatus.BAD_REQUEST.value());
        body.put("error", "Validation Failed");
        body.put("fieldErrors", fieldErrors);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }

    // 400 - Malformed / unreadable request body (e.g. invalid enum value)
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, Object>> handleUnreadableBody(HttpMessageNotReadableException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", "Malformed or invalid request body");
    }

    // 400 - Invalid placement status transition
    @ExceptionHandler(InvalidPlacementStatusTransitionException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidPlacementTransition(InvalidPlacementStatusTransitionException ex) {
        return error(HttpStatus.BAD_REQUEST, "Bad Request", ex.getMessage());
    }

    // 403 - Employer not active (Suspended/Deregistered cannot post vacancies)
    @ExceptionHandler(EmployerNotActiveException.class)
    public ResponseEntity<Map<String, Object>> handleEmployerNotActive(EmployerNotActiveException ex) {
        return error(HttpStatus.FORBIDDEN, "Forbidden", ex.getMessage());
    }

    // 403 - Spring Security authorization failure (@PreAuthorize / URL rules)
    @ExceptionHandler(org.springframework.security.access.AccessDeniedException.class)
    public ResponseEntity<Map<String, Object>> handleAccessDenied(
            org.springframework.security.access.AccessDeniedException ex) {
        return error(HttpStatus.FORBIDDEN, "Forbidden",
                "Access denied: you do not have permission to perform this action.");
    }

    // 404 - Not found
    @ExceptionHandler(EmployerNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleEmployerNotFound(EmployerNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(VacancyNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleVacancyNotFound(VacancyNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(PlacementNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handlePlacementNotFound(PlacementNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    @ExceptionHandler(TraineeNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleTraineeNotFound(TraineeNotFoundException ex) {
        return error(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage());
    }

    // 409 - Conflicts
    @ExceptionHandler(DuplicateEmployerException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicateEmployer(DuplicateEmployerException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(ActivePlacementsExistException.class)
    public ResponseEntity<Map<String, Object>> handleActivePlacements(ActivePlacementsExistException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(InvalidStatusTransitionException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidStatusTransition(InvalidStatusTransitionException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(DuplicatePlacementException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicatePlacement(DuplicatePlacementException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(TraineeNotEligibleException.class)
    public ResponseEntity<Map<String, Object>> handleTraineeNotEligible(TraineeNotEligibleException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(VacancyNotOpenException.class)
    public ResponseEntity<Map<String, Object>> handleVacancyNotOpen(VacancyNotOpenException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(VacancyExpiredException.class)
    public ResponseEntity<Map<String, Object>> handleVacancyExpired(VacancyExpiredException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    @ExceptionHandler(VacancyAlreadyFilledException.class)
    public ResponseEntity<Map<String, Object>> handleVacancyFilled(VacancyAlreadyFilledException ex) {
        return error(HttpStatus.CONFLICT, "Conflict", ex.getMessage());
    }

    // 500 - Generic fallback
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGenericException(Exception ex) {
        return error(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error", ex.getMessage());
    }

    // ── helper ────────────────────────────────────────────────────────────────

    private ResponseEntity<Map<String, Object>> error(HttpStatus status, String error, String message) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("status", status.value());
        body.put("error", error);
        body.put("message", message);
        return ResponseEntity.status(status).body(body);
    }
}