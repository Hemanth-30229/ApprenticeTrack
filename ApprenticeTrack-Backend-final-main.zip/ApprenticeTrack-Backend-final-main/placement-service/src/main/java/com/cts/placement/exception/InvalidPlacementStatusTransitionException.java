package com.cts.placement.exception;

/**
 * Thrown when a placement status change violates the allowed lifecycle
 * (only Active → Completed or Active → Terminated). Mapped to 400 Bad Request.
 */
public class InvalidPlacementStatusTransitionException extends RuntimeException {
    public InvalidPlacementStatusTransitionException(String message) {
        super(message);
    }
}
