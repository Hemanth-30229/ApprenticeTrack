package com.cts.placement.exception;

/**
 * Thrown when a trainee is not eligible for placement (not Active and has no
 * OJTInProgress enrollment). Mapped to 409 Conflict.
 */
public class TraineeNotEligibleException extends RuntimeException {
    public TraineeNotEligibleException(String message) {
        super(message);
    }
}
