package com.cts.placement.exception;

public class VacancyAlreadyFilledException extends RuntimeException {
    public VacancyAlreadyFilledException(String message) {
        super(message);
    }
}
