package com.cts.placement.exception;

public class VacancyExpiredException extends RuntimeException {
    public VacancyExpiredException(String message) {
        super(message);
    }
}
