package com.cts.placement.exception;

/**
 * Thrown when a placement targets a vacancy that is not Open or PartiallyFilled.
 * Mapped to 409 Conflict.
 */
public class VacancyNotOpenException extends RuntimeException {
    public VacancyNotOpenException(String message) {
        super(message);
    }
}
