package com.cts.placement.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.placement.entity.ApprenticeshipVacancy;
import com.cts.placement.common.ApprenticeshipVacancyStatus;

@Repository
public interface ApprenticeshipVacancyRepository extends JpaRepository<ApprenticeshipVacancy, Long> {

    /**
     * Paginated filtering by EmployerID, TradeRequired, Status, and date range.
     */
    @Query("SELECT v FROM ApprenticeshipVacancy v WHERE " +
           "(:employerID IS NULL OR v.employerID = :employerID) AND " +
           "(:tradeRequired IS NULL OR LOWER(v.tradeRequired) = LOWER(:tradeRequired)) AND " +
           "(:status IS NULL OR v.status = :status) AND " +
           "(:fromDate IS NULL OR v.postedDate >= :fromDate) AND " +
           "(:toDate IS NULL OR v.postedDate <= :toDate)")
    Page<ApprenticeshipVacancy> findAllWithFilters(
            @Param("employerID") Long employerID,
            @Param("tradeRequired") String tradeRequired,
            @Param("status") ApprenticeshipVacancyStatus status,
            @Param("fromDate") LocalDate fromDate,
            @Param("toDate") LocalDate toDate,
            Pageable pageable);

    /**
     * Find all Open/PartiallyFilled vacancies posted before a threshold date
     * — used by the expiry scheduler.
     */
    @Query("SELECT v FROM ApprenticeshipVacancy v WHERE " +
           "v.postedDate < :expiryThreshold AND " +
           "v.status IN ('Open', 'PartiallyFilled')")
    List<ApprenticeshipVacancy> findExpiredCandidates(@Param("expiryThreshold") LocalDate expiryThreshold);

    /**
     * Bulk-mark vacancies as Expired by ID list.
     */
    @Modifying
    @Query("UPDATE ApprenticeshipVacancy v SET v.status = 'Expired' WHERE v.vacancyID IN :ids")
    int bulkExpire(@Param("ids") List<Long> ids);

    long countByStatus(ApprenticeshipVacancyStatus status);

    long countByEmployerIDAndStatus(Long employerID, ApprenticeshipVacancyStatus status);
}
