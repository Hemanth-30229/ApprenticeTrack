package com.cts.placement.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.placement.entity.Employer;
import com.cts.placement.common.EmployerStatus;

@Repository
public interface EmployerRepository extends JpaRepository<Employer, Long> {

    boolean existsByCompanyNameAndIndustrySector(String companyName, String industrySector);

    long countByStatus(EmployerStatus status);

    /**
     * Paginated list with optional status, industrySector, and companyName filters.
     */
    @Query("SELECT e FROM Employer e WHERE " +
           "(:status IS NULL OR e.status = :status) AND " +
           "(:industrySector IS NULL OR LOWER(e.industrySector) = LOWER(:industrySector)) AND " +
           "(:companyName IS NULL OR LOWER(e.companyName) LIKE LOWER(CONCAT('%', :companyName, '%')))")
    Page<Employer> findAllWithFilters(
            @Param("status") EmployerStatus status,
            @Param("industrySector") String industrySector,
            @Param("companyName") String companyName,
            Pageable pageable);
}
