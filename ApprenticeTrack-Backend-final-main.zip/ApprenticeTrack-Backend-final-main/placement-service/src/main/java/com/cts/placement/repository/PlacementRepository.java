package com.cts.placement.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.placement.common.PlacementStatus;
import com.cts.placement.entity.Placement;

@Repository
public interface PlacementRepository extends JpaRepository<Placement, Long> {

    boolean existsByEmployerIDAndStatus(Long employerID, PlacementStatus status);

    boolean existsByTraineeIDAndStatus(Long traineeID, PlacementStatus status);

    /**
     * Paginated filtering by TraineeID, EmployerID, VacancyID, and Status.
     * All params optional — null means no filter applied.
     */
    @Query("SELECT p FROM Placement p WHERE " +
           "(:traineeID IS NULL OR p.traineeID = :traineeID) AND " +
           "(:employerID IS NULL OR p.employerID = :employerID) AND " +
           "(:vacancyID IS NULL OR p.vacancyID = :vacancyID) AND " +
           "(:status IS NULL OR p.status = :status)")
    Page<Placement> findAllWithFilters(
            @Param("traineeID") Long traineeID,
            @Param("employerID") Long employerID,
            @Param("vacancyID") Long vacancyID,
            @Param("status") PlacementStatus status,
            Pageable pageable);

    long countByStatus(PlacementStatus status);

    long countByEmployerID(Long employerID);

    long countByEmployerIDAndStatus(Long employerID, PlacementStatus status);

    /** Distinct trainees that have at least one placement (any status). */
    @Query("SELECT COUNT(DISTINCT p.traineeID) FROM Placement p")
    long countDistinctPlacedTrainees();

    /** Distinct trainees that have a placement in the given status. */
    @Query("SELECT COUNT(DISTINCT p.traineeID) FROM Placement p WHERE p.status = :status")
    long countDistinctTraineesByStatus(@Param("status") PlacementStatus status);
}
