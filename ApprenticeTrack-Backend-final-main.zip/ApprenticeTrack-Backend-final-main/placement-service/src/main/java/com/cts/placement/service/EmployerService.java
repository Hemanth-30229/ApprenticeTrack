package com.cts.placement.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.placement.dto.EmployerCreateRequestDTO;
import com.cts.placement.dto.EmployerResponseDTO;
import com.cts.placement.dto.EmployerStatusUpdateRequestDTO;
import com.cts.placement.dto.EmployerUpdateRequestDTO;
import com.cts.placement.common.EmployerStatus;

public interface EmployerService {

    EmployerResponseDTO registerEmployer(EmployerCreateRequestDTO requestDTO);

    EmployerResponseDTO getEmployerById(Long employerID);

    EmployerResponseDTO updateEmployer(Long employerID, EmployerUpdateRequestDTO requestDTO);

    EmployerResponseDTO updateStatus(Long employerID, EmployerStatusUpdateRequestDTO requestDTO);

    Page<EmployerResponseDTO> getAllEmployers(EmployerStatus status, String industrySector,
                                              String companyName, Pageable pageable);
}
