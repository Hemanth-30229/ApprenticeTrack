package com.cts.placement.service;

import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.placement.client.PlatformClient;
import com.cts.placement.client.dto.AuditLogRequest;
import com.cts.placement.common.EmployerStatus;
import com.cts.placement.common.PlacementStatus;
import com.cts.placement.dto.EmployerCreateRequestDTO;
import com.cts.placement.dto.EmployerResponseDTO;
import com.cts.placement.dto.EmployerStatusUpdateRequestDTO;
import com.cts.placement.dto.EmployerUpdateRequestDTO;
import com.cts.placement.entity.Employer;
import com.cts.placement.exception.ActivePlacementsExistException;
import com.cts.placement.exception.DuplicateEmployerException;
import com.cts.placement.exception.EmployerNotFoundException;
import com.cts.placement.exception.InvalidStatusTransitionException;
import com.cts.placement.repository.EmployerRepository;
import com.cts.placement.repository.PlacementRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmployerServiceImpl implements EmployerService {

    private static final String MODULE = "EmployerRegistration";

    private final EmployerRepository employerRepository;
    private final PlacementRepository placementRepository;
    private final PlatformClient platformClient;

    @Override
    @Transactional
    public EmployerResponseDTO registerEmployer(EmployerCreateRequestDTO dto) {

        if (employerRepository.existsByCompanyNameAndIndustrySector(
                dto.getCompanyName(),
                dto.getIndustrySector())) {

            throw new DuplicateEmployerException(
                    "Employer '" + dto.getCompanyName()
                            + "' already registered in sector '"
                            + dto.getIndustrySector() + "'");
        }

        Employer employer = Employer.builder()
                .companyName(dto.getCompanyName())
                .industrySector(dto.getIndustrySector())
                .address(dto.getAddress())
                .contactPerson(dto.getContactPerson())
                .apprenticeshipCapacity(dto.getApprenticeshipCapacity())
                .registrationDate(LocalDate.now())
                .status(EmployerStatus.Active)
                .build();

        Employer saved = employerRepository.save(employer);

        audit(0L, "EmployerRegistered");

        return toResponseDTO(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public EmployerResponseDTO getEmployerById(Long employerID) {
        return toResponseDTO(findEmployer(employerID));
    }

    @Override
    @Transactional
    public EmployerResponseDTO updateEmployer(
            Long employerID,
            EmployerUpdateRequestDTO dto) {

        Employer employer = findEmployer(employerID);

        employer.setAddress(dto.getAddress());
        employer.setContactPerson(dto.getContactPerson());
        employer.setApprenticeshipCapacity(dto.getApprenticeshipCapacity());
        employer.setIndustrySector(dto.getIndustrySector());

        Employer updated = employerRepository.save(employer);

        audit(0L, "EmployerUpdated");

        return toResponseDTO(updated);
    }

    @Override
    @Transactional
    public EmployerResponseDTO updateStatus(
            Long employerID,
            EmployerStatusUpdateRequestDTO dto) {

        Employer employer = findEmployer(employerID);

        EmployerStatus current = employer.getStatus();
        EmployerStatus target = dto.getStatus();

        validateStatusTransition(current, target, employerID);

        employer.setStatus(target);

        Employer updated = employerRepository.save(employer);

        audit(0L,
                "EmployerStatusChanged: "
                        + current + " -> " + target);

        return toResponseDTO(updated);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<EmployerResponseDTO> getAllEmployers(
            EmployerStatus status,
            String industrySector,
            String companyName,
            Pageable pageable) {

        return employerRepository
                .findAllWithFilters(
                        status,
                        industrySector,
                        companyName,
                        pageable)
                .map(this::toResponseDTO);
    }

    private Employer findEmployer(Long employerID) {

        return employerRepository.findById(employerID)
                .orElseThrow(() ->
                        new EmployerNotFoundException(
                                "Employer not found with ID: "
                                        + employerID));
    }

    private void validateStatusTransition(
            EmployerStatus current,
            EmployerStatus target,
            Long employerID) {

        if (current == EmployerStatus.Deregistered) {
            throw new InvalidStatusTransitionException(
                    "Deregistered employers cannot change status.");
        }

        if (current == EmployerStatus.Active
                && target == EmployerStatus.Deregistered) {

            throw new InvalidStatusTransitionException(
                    "Employer must be Suspended before Deregistration.");
        }

        if (target == EmployerStatus.Deregistered
                && placementRepository.existsByEmployerIDAndStatus(
                        employerID,
                        PlacementStatus.Active)) {

            throw new ActivePlacementsExistException(
                    "Employer cannot be deregistered while active placements exist.");
        }

        if (current == target) {
            throw new InvalidStatusTransitionException(
                    "Employer is already in '" + current + "' status.");
        }
    }

    private void audit(Long userID, String action) {
        platformClient.recordAudit(
                new AuditLogRequest(
                        userID,
                        action,
                        MODULE,
                        null));
    }

    private EmployerResponseDTO toResponseDTO(Employer employer) {

        return EmployerResponseDTO.builder()
                .employerID(employer.getEmployerID())
                .companyName(employer.getCompanyName())
                .industrySector(employer.getIndustrySector())
                .address(employer.getAddress())
                .contactPerson(employer.getContactPerson())
                .apprenticeshipCapacity(employer.getApprenticeshipCapacity())
                .registrationDate(employer.getRegistrationDate())
                .status(employer.getStatus())
                .build();
    }
}