package com.cts.placement.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.placement.dto.PlacementCreateRequestDTO;
import com.cts.placement.dto.PlacementResponseDTO;
import com.cts.placement.common.PlacementStatus;

public interface PlacementService {

    PlacementResponseDTO createPlacement(PlacementCreateRequestDTO dto);

    PlacementResponseDTO getPlacementById(Long placementID);

    Page<PlacementResponseDTO> getAllPlacements(Long traineeID, Long employerID,
                                                Long vacancyID, PlacementStatus status, Pageable pageable);

    PlacementResponseDTO updateStatus(Long placementID, PlacementStatus newStatus);
}
