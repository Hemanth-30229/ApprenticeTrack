package com.cts.placement.service;

import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.placement.client.PlatformClient;
import com.cts.placement.client.TrainingClient;
import com.cts.placement.client.dto.AuditLogRequest;
import com.cts.placement.client.dto.NotificationRequest;
import com.cts.placement.client.dto.TraineeContract;
import com.cts.placement.common.ApprenticeshipVacancyStatus;
import com.cts.placement.common.PlacementStatus;
import com.cts.placement.dto.PlacementCreateRequestDTO;
import com.cts.placement.dto.PlacementResponseDTO;
import com.cts.placement.entity.ApprenticeshipVacancy;
import com.cts.placement.entity.Employer;
import com.cts.placement.entity.Placement;
import com.cts.placement.exception.DuplicatePlacementException;
import com.cts.placement.exception.EmployerNotFoundException;
import com.cts.placement.exception.InvalidPlacementStatusTransitionException;
import com.cts.placement.exception.PlacementNotFoundException;
import com.cts.placement.exception.TraineeNotEligibleException;
import com.cts.placement.exception.TraineeNotFoundException;
import com.cts.placement.exception.VacancyNotFoundException;
import com.cts.placement.exception.VacancyNotOpenException;
import com.cts.placement.repository.ApprenticeshipVacancyRepository;
import com.cts.placement.repository.EmployerRepository;
import com.cts.placement.repository.PlacementRepository;

@Service
public class PlacementServiceImpl implements PlacementService {

    private static final String MODULE = "PlacementManagement";
    private static final String CATEGORY_PLACEMENT = "Placement";
    private static final String TRAINEE_STATUS_ACTIVE = "Active";

    private final PlacementRepository placementRepository;
    private final ApprenticeshipVacancyRepository vacancyRepository;
    private final EmployerRepository employerRepository;
    private final TrainingClient trainingClient;
    private final PlatformClient platformClient;

    public PlacementServiceImpl(PlacementRepository placementRepository,
                                ApprenticeshipVacancyRepository vacancyRepository,
                                EmployerRepository employerRepository,
                                TrainingClient trainingClient,
                                PlatformClient platformClient) {
        this.placementRepository = placementRepository;
        this.vacancyRepository = vacancyRepository;
        this.employerRepository = employerRepository;
        this.trainingClient = trainingClient;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional
    public PlacementResponseDTO createPlacement(PlacementCreateRequestDTO dto) {
        TraineeContract trainee = findTrainee(dto.getTraineeID());
        ApprenticeshipVacancy vacancy = findVacancy(dto.getVacancyID());
        Employer employer = findEmployer(dto.getEmployerID());

        requireEligibleTrainee(trainee);
        requireOpenVacancy(vacancy);

        if (placementRepository.existsByTraineeIDAndStatus(dto.getTraineeID(), PlacementStatus.Active)) {
            throw new DuplicatePlacementException(
                    "Trainee already has an active placement. TraineeID: " + dto.getTraineeID());
        }

        LocalDate placementDate = dto.getPlacementDate() != null
                ? dto.getPlacementDate() : LocalDate.now();

        Placement placement = Placement.builder()
                .traineeID(dto.getTraineeID())
                .vacancyID(dto.getVacancyID())
                .employerID(dto.getEmployerID())
                .placementDate(placementDate)
                .supervisorName(dto.getSupervisorName())
                .supervisorPhone(dto.getSupervisorPhone())
                .status(PlacementStatus.Active)
                .build();
        Placement saved = placementRepository.save(placement);

        // Increment the vacancy's filled count and recompute its status.
        vacancy.setFilledCount(vacancy.getFilledCount() + 1);
        vacancy.recalculateStatus();
        vacancyRepository.save(vacancy);

        // Move the trainee's enrollment(s) into OJTInProgress (owned by training-service).
        trainingClient.promoteEnrollmentsToOjt(dto.getTraineeID());

        audit(saved.getTraineeID(),
                "PlacementCreated: TraineeID=" + saved.getTraineeID()
                        + ", VacancyID=" + saved.getVacancyID() + ", EmployerID=" + saved.getEmployerID()
                        + " [PlacementID=" + saved.getPlacementID() + "]");

        notifyTrainee(saved.getTraineeID(),
                "You have been matched to a placement with " + employer.getCompanyName() + ".");

        return toResponseDTO(saved, trainee.getName(), employer.getCompanyName());
    }

    @Override
    @Transactional(readOnly = true)
    public PlacementResponseDTO getPlacementById(Long placementID) {
        Placement placement = findPlacement(placementID);
        return toResponseDTO(placement,
                resolveTraineeName(placement.getTraineeID()),
                resolveEmployerName(placement.getEmployerID()));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PlacementResponseDTO> getAllPlacements(Long traineeID, Long employerID,
                                                       Long vacancyID, PlacementStatus status, Pageable pageable) {
        return placementRepository
                .findAllWithFilters(traineeID, employerID, vacancyID, status, pageable)
                .map(p -> toResponseDTO(p,
                        resolveTraineeName(p.getTraineeID()),
                        resolveEmployerName(p.getEmployerID())));
    }

    @Override
    @Transactional
    public PlacementResponseDTO updateStatus(Long placementID, PlacementStatus newStatus) {
        Placement placement = findPlacement(placementID);
        PlacementStatus current = placement.getStatus();

        if (current != PlacementStatus.Active
                || (newStatus != PlacementStatus.Completed && newStatus != PlacementStatus.Terminated)) {
            throw new InvalidPlacementStatusTransitionException(
                    "Invalid status transition: " + current + " → " + newStatus
                    + ". Only Active → Completed or Active → Terminated is allowed. PlacementID: " + placementID);
        }

        placement.setStatus(newStatus);
        Placement updated = placementRepository.save(placement);

        // Terminating frees up the vacancy slot.
        if (newStatus == PlacementStatus.Terminated) {
            vacancyRepository.findById(updated.getVacancyID()).ifPresent(vacancy -> {
                vacancy.setFilledCount(Math.max(0, vacancy.getFilledCount() - 1));
                vacancy.recalculateStatus();
                vacancyRepository.save(vacancy);
            });
        }

        audit(updated.getTraineeID(),
                "PlacementStatusChanged: " + current + " → " + newStatus
                        + " [PlacementID=" + updated.getPlacementID() + "]");

        notifyTrainee(updated.getTraineeID(),
                "Your placement status changed to " + newStatus + ".");

        return toResponseDTO(updated,
                resolveTraineeName(updated.getTraineeID()),
                resolveEmployerName(updated.getEmployerID()));
    }

    // ── Business rules ───────────────────────────────────────────────────────
    private void requireEligibleTrainee(TraineeContract trainee) {
        boolean eligible = TRAINEE_STATUS_ACTIVE.equals(trainee.getStatus())
                || Boolean.TRUE.equals(trainingClient.isTraineeInOjt(trainee.getTraineeID()));
        if (!eligible) {
            throw new TraineeNotEligibleException(
                    "Trainee is not eligible for placement (requires Active status or an "
                    + "OJTInProgress enrollment). TraineeID: " + trainee.getTraineeID());
        }
    }

    private void requireOpenVacancy(ApprenticeshipVacancy vacancy) {
        if (vacancy.getStatus() != ApprenticeshipVacancyStatus.Open
                && vacancy.getStatus() != ApprenticeshipVacancyStatus.PartiallyFilled) {
            throw new VacancyNotOpenException(
                    "Vacancy is not open for placement (status " + vacancy.getStatus()
                    + "). VacancyID: " + vacancy.getVacancyID());
        }
    }

    // ── Lookups ────────────────────────────────────────────────────────────────
    private TraineeContract findTrainee(Long traineeID) {
        TraineeContract trainee = trainingClient.getTrainee(traineeID);
        if (trainee == null) {
            throw new TraineeNotFoundException("Trainee not found with ID: " + traineeID);
        }
        return trainee;
    }

    private ApprenticeshipVacancy findVacancy(Long vacancyID) {
        return vacancyRepository.findById(vacancyID)
                .orElseThrow(() -> new VacancyNotFoundException("Vacancy not found with ID: " + vacancyID));
    }

    private Employer findEmployer(Long employerID) {
        return employerRepository.findById(employerID)
                .orElseThrow(() -> new EmployerNotFoundException("Employer not found with ID: " + employerID));
    }

    private Placement findPlacement(Long placementID) {
        return placementRepository.findById(placementID)
                .orElseThrow(() -> new PlacementNotFoundException("Placement not found with ID: " + placementID));
    }

    private String resolveTraineeName(Long traineeID) {
        TraineeContract trainee = trainingClient.getTrainee(traineeID);
        return trainee == null ? null : trainee.getName();
    }

    private String resolveEmployerName(Long employerID) {
        return employerRepository.findById(employerID).map(Employer::getCompanyName).orElse(null);
    }

    private void audit(Long userID, String action) {
        platformClient.recordAudit(new AuditLogRequest(userID, action, MODULE, null));
    }

    private void notifyTrainee(Long traineeID, String message) {
        platformClient.notify(new NotificationRequest("TRAINEE", traineeID, message, CATEGORY_PLACEMENT));
    }

    private PlacementResponseDTO toResponseDTO(Placement p, String traineeName, String employerName) {
        return PlacementResponseDTO.builder()
                .placementID(p.getPlacementID())
                .traineeID(p.getTraineeID())
                .traineeName(traineeName)
                .vacancyID(p.getVacancyID())
                .employerID(p.getEmployerID())
                .employerName(employerName)
                .placementDate(p.getPlacementDate())
                .supervisorName(p.getSupervisorName())
                .supervisorPhone(p.getSupervisorPhone())
                .status(p.getStatus())
                .build();
    }
}