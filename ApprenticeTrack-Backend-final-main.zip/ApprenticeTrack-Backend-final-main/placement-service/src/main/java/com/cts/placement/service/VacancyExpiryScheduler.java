package com.cts.placement.service;

import java.util.logging.Logger;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class VacancyExpiryScheduler {

    private static final Logger log = Logger.getLogger(VacancyExpiryScheduler.class.getName());

    private final VacancyService vacancyService;

    public VacancyExpiryScheduler(VacancyService vacancyService) {
        this.vacancyService = vacancyService;
    }

    @Scheduled(cron = "0 0 0 * * *")
    public void runDailyExpiry() {
        log.info("VacancyExpiryScheduler: starting daily expiry job...");
        int count = vacancyService.expireOldVacancies();
        log.info("VacancyExpiryScheduler: completed — " + count + " vacancies expired.");
    }
}