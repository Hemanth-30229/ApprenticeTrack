package com.cts.placement.service;

import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.placement.dto.VacancyCreateRequestDTO;
import com.cts.placement.dto.VacancyResponseDTO;
import com.cts.placement.dto.VacancyUpdateRequestDTO;
import com.cts.placement.common.ApprenticeshipVacancyStatus;

public interface VacancyService {

    VacancyResponseDTO createVacancy(VacancyCreateRequestDTO requestDTO);

    VacancyResponseDTO getVacancyById(Long vacancyID);

    VacancyResponseDTO updateVacancy(Long vacancyID, VacancyUpdateRequestDTO requestDTO);

    Page<VacancyResponseDTO> getAllVacancies(Long employerID, String tradeRequired,
                                             ApprenticeshipVacancyStatus status, LocalDate fromDate,
                                             LocalDate toDate, Pageable pageable);

    int expireOldVacancies(); // manual trigger — returns count of expired vacancies
}
