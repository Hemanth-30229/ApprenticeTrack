package com.cts.placement.service;

import java.time.LocalDate;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.placement.client.PlatformClient;
import com.cts.placement.client.dto.AuditLogRequest;
import com.cts.placement.dto.VacancyCreateRequestDTO;
import com.cts.placement.dto.VacancyResponseDTO;
import com.cts.placement.dto.VacancyUpdateRequestDTO;
import com.cts.placement.common.ApprenticeshipVacancyStatus;
import com.cts.placement.common.EmployerStatus;
import com.cts.placement.entity.ApprenticeshipVacancy;
import com.cts.placement.entity.Employer;
import com.cts.placement.exception.EmployerNotActiveException;
import com.cts.placement.exception.EmployerNotFoundException;
import com.cts.placement.exception.VacancyAlreadyFilledException;
import com.cts.placement.exception.VacancyExpiredException;
import com.cts.placement.exception.VacancyNotFoundException;
import com.cts.placement.repository.ApprenticeshipVacancyRepository;
import com.cts.placement.repository.EmployerRepository;

@Service
public class VacancyServiceImpl implements VacancyService {

    private static final Logger log = Logger.getLogger(VacancyServiceImpl.class.getName());
    private static final String MODULE = "VacancyManagement";

    private final ApprenticeshipVacancyRepository vacancyRepository;
    private final EmployerRepository employerRepository;
    private final PlatformClient platformClient;

    @Value("${vacancy.expiry-days:90}")
    private int expiryDays;

    public VacancyServiceImpl(ApprenticeshipVacancyRepository vacancyRepository,
                               EmployerRepository employerRepository,
                               PlatformClient platformClient) {
        this.vacancyRepository = vacancyRepository;
        this.employerRepository = employerRepository;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional
    public VacancyResponseDTO createVacancy(VacancyCreateRequestDTO dto) {
        Employer employer = findActiveEmployer(dto.getEmployerID());
        ApprenticeshipVacancy vacancy = ApprenticeshipVacancy.builder()
                .employerID(dto.getEmployerID()).tradeRequired(dto.getTradeRequired())
                .vacancyCount(dto.getVacancyCount()).stipendOffered(dto.getStipendOffered())
                .postedDate(LocalDate.now()).filledCount(0).status(ApprenticeshipVacancyStatus.Open).build();
        ApprenticeshipVacancy saved = vacancyRepository.save(vacancy);
        audit(employer.getEmployerID(),
                "VacancyCreated: " + saved.getTradeRequired() + " [VacancyID=" + saved.getVacancyID() + "]");
        return toResponseDTO(saved, employer.getCompanyName());
    }

    @Override
    @Transactional(readOnly = true)
    public VacancyResponseDTO getVacancyById(Long vacancyID) {
        ApprenticeshipVacancy vacancy = findVacancy(vacancyID);
        Employer employer = findEmployerById(vacancy.getEmployerID());
        return toResponseDTO(vacancy, employer.getCompanyName());
    }

    @Override
    @Transactional
    public VacancyResponseDTO updateVacancy(Long vacancyID, VacancyUpdateRequestDTO dto) {
        ApprenticeshipVacancy vacancy = findVacancy(vacancyID);
        if (vacancy.getStatus() == ApprenticeshipVacancyStatus.Expired) {
            throw new VacancyExpiredException("Expired vacancies cannot be updated. VacancyID: " + vacancyID);
        }
        if (vacancy.getStatus() == ApprenticeshipVacancyStatus.Filled) {
            throw new VacancyAlreadyFilledException("Filled vacancies cannot be updated. VacancyID: " + vacancyID);
        }
        vacancy.setTradeRequired(dto.getTradeRequired());
        vacancy.setVacancyCount(dto.getVacancyCount());
        vacancy.setStipendOffered(dto.getStipendOffered());
        vacancy.recalculateStatus();
        ApprenticeshipVacancy updated = vacancyRepository.save(vacancy);
        Employer employer = findEmployerById(updated.getEmployerID());
        audit(employer.getEmployerID(), "VacancyUpdated: [VacancyID=" + updated.getVacancyID() + "]");
        return toResponseDTO(updated, employer.getCompanyName());
    }

    @Override
    @Transactional(readOnly = true)
    public Page<VacancyResponseDTO> getAllVacancies(Long employerID, String tradeRequired,
                                                    ApprenticeshipVacancyStatus status, LocalDate fromDate,
                                                    LocalDate toDate, Pageable pageable) {
        return vacancyRepository
                .findAllWithFilters(employerID, tradeRequired, status, fromDate, toDate, pageable)
                .map(v -> toResponseDTO(v, findEmployerById(v.getEmployerID()).getCompanyName()));
    }

    @Override
    @Transactional
    public int expireOldVacancies() {
        LocalDate threshold = LocalDate.now().minusDays(expiryDays);
        List<ApprenticeshipVacancy> candidates = vacancyRepository.findExpiredCandidates(threshold);
        if (candidates.isEmpty()) {
            log.info("VacancyExpiry: no vacancies to expire.");
            return 0;
        }
        List<Long> ids = candidates.stream()
                .map(v -> v.getVacancyID()).collect(Collectors.toList());
        int count = vacancyRepository.bulkExpire(ids);
        log.info("VacancyExpiry: " + count + " vacancies expired (threshold=" + threshold + ")");
        audit(0L, "BulkVacancyExpired: count=" + count + ", threshold=" + threshold);
        return count;
    }

    private Employer findActiveEmployer(Long employerID) {
        Employer employer = findEmployerById(employerID);
        if (employer.getStatus() != EmployerStatus.Active) {
            throw new EmployerNotActiveException(
                    "Only Active employers can post vacancies. Employer status: " + employer.getStatus());
        }
        return employer;
    }

    private Employer findEmployerById(Long employerID) {
        return employerRepository.findById(employerID)
                .orElseThrow(() -> new EmployerNotFoundException("Employer not found with ID: " + employerID));
    }

    private ApprenticeshipVacancy findVacancy(Long vacancyID) {
        return vacancyRepository.findById(vacancyID)
                .orElseThrow(() -> new VacancyNotFoundException("Vacancy not found with ID: " + vacancyID));
    }

    private void audit(Long userID, String action) {
        platformClient.recordAudit(new AuditLogRequest(userID, action, MODULE, null));
    }

    private VacancyResponseDTO toResponseDTO(ApprenticeshipVacancy v, String companyName) {
        return VacancyResponseDTO.builder()
                .vacancyID(v.getVacancyID()).employerID(v.getEmployerID())
                .companyName(companyName).tradeRequired(v.getTradeRequired())
                .vacancyCount(v.getVacancyCount()).stipendOffered(v.getStipendOffered())
                .postedDate(v.getPostedDate()).filledCount(v.getFilledCount())
                .status(v.getStatus()).build();
    }
}