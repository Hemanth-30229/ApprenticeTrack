package com.cts.platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Platform-service: notifications, transactional email, the audit-trail sink, and
 * dashboard aggregation (MIGRATION_PLAN.md §1). Every business service is a client
 * of this service for notification dispatch and audit logging; this service is in
 * turn a client of training-service and placement-service for dashboard metrics.
 * {@code @EnableAsync} lives on {@code AsyncConfig} so notification persistence
 * doesn't block the caller.
 */
@SpringBootApplication
@EnableFeignClients
public class PlatformServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(PlatformServiceApplication.class, args);
    }
}
