package com.cts.platform.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.platform.client.dto.PageCountContract;

/**
 * Feign client to assessment-service, which owns trade tests, competency results and
 * trade certificates (MIGRATION_PLAN.md §6). Used by {@link com.cts.platform.service.DashboardServiceImpl}
 * to source certificate status for the trainee dashboard. Guarded by {@link AssessmentClientFallback}.
 *
 * <p>Count methods derive totals from the existing paginated list endpoints'
 * {@code totalElements} (see {@link PageCountContract}) rather than requiring
 * assessment-service to expose dedicated count endpoints.
 */
@FeignClient(name = "assessment-service", fallback = AssessmentClientFallback.class)
public interface AssessmentClient {

    /** Certificates for a trainee, optionally filtered by status (e.g. {@code Issued}). */
    @GetMapping("/api/certificates")
    PageCountContract countCertificates(@RequestParam(value = "traineeID", required = false) Long traineeId,
                                        @RequestParam(value = "status", required = false) String status,
                                        @RequestParam(value = "page", defaultValue = "0") int page,
                                        @RequestParam(value = "size", defaultValue = "1") int size);
}
