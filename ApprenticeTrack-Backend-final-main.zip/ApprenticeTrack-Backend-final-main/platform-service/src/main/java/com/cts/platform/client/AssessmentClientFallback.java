package com.cts.platform.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cts.platform.client.dto.PageCountContract;

/**
 * Degraded-mode fallback for {@link AssessmentClient}. When assessment-service is
 * unreachable, certificate-derived dashboard metrics degrade to zero/empty rather
 * than failing the whole dashboard response (MIGRATION_PLAN.md §10).
 */
@Component
public class AssessmentClientFallback implements AssessmentClient {

    private static final Logger log = LoggerFactory.getLogger(AssessmentClientFallback.class);

    @Override
    public PageCountContract countCertificates(Long traineeId, String status, int page, int size) {
        log.warn("assessment-service unavailable; certificate count degraded to 0 (traineeID={}, status={})",
                traineeId, status);
        return new PageCountContract();
    }
}
