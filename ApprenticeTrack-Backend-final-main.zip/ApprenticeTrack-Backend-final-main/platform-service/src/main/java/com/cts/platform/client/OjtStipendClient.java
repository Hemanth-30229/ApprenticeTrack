package com.cts.platform.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.platform.client.dto.PageCountContract;
import com.cts.platform.client.dto.StipendPageContract;

/**
 * Feign client to ojt-stipend-service, which owns OJT logs, attendance and stipend
 * disbursements (MIGRATION_PLAN.md §6). Used by {@link com.cts.platform.service.DashboardServiceImpl}
 * to source a trainee's pending OJT logs and stipend history. Guarded by
 * {@link OjtStipendClientFallback}.
 *
 * <p>Counts derive from the existing paginated list endpoints' {@code totalElements}
 * (see {@link PageCountContract}); the stipend total is summed from a single generously
 * sized page (see {@link StipendPageContract}) as ojt-stipend-service exposes no SUM endpoint.
 */
@FeignClient(name = "ojt-stipend-service", fallback = OjtStipendClientFallback.class)
public interface OjtStipendClient {

    /** OJT logs for a trainee, optionally filtered by status (e.g. {@code Submitted} = awaiting confirmation). */
    @GetMapping("/api/ojt-logs")
    PageCountContract countOjtLogs(@RequestParam(value = "traineeID", required = false) Long traineeId,
                                   @RequestParam(value = "status", required = false) String status,
                                   @RequestParam(value = "page", defaultValue = "0") int page,
                                   @RequestParam(value = "size", defaultValue = "1") int size);

    /**
     * Stipend disbursements, optionally filtered by trainee, status (e.g. {@code Pending},
     * {@code Withheld}, {@code Disbursed}) and month/year. Reads {@code totalElements} for
     * counts and sums {@code stipendAmount} for totals (see {@link StipendPageContract}).
     */
    @GetMapping("/api/stipend-disbursements")
    StipendPageContract getStipendDisbursements(@RequestParam(value = "traineeID", required = false) Long traineeId,
                                                @RequestParam(value = "status", required = false) String status,
                                                @RequestParam(value = "month", required = false) Integer month,
                                                @RequestParam(value = "year", required = false) Integer year,
                                                @RequestParam(value = "page", defaultValue = "0") int page,
                                                @RequestParam(value = "size", defaultValue = "500") int size);

    /** Attendance summaries, optionally filtered by stipend eligibility — used for the compliance rate. */
    @GetMapping("/api/attendance-summaries")
    PageCountContract countAttendanceSummaries(@RequestParam(value = "stipendEligible", required = false) Boolean stipendEligible,
                                               @RequestParam(value = "page", defaultValue = "0") int page,
                                               @RequestParam(value = "size", defaultValue = "1") int size);
}
