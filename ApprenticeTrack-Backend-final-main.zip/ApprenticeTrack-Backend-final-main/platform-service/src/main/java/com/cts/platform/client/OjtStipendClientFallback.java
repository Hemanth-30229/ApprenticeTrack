package com.cts.platform.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cts.platform.client.dto.PageCountContract;
import com.cts.platform.client.dto.StipendPageContract;

/**
 * Degraded-mode fallback for {@link OjtStipendClient}. When ojt-stipend-service is
 * unreachable, OJT-log and stipend dashboard metrics degrade to zero/empty rather
 * than failing the whole dashboard response (MIGRATION_PLAN.md §10).
 */
@Component
public class OjtStipendClientFallback implements OjtStipendClient {

    private static final Logger log = LoggerFactory.getLogger(OjtStipendClientFallback.class);

    @Override
    public PageCountContract countOjtLogs(Long traineeId, String status, int page, int size) {
        log.warn("ojt-stipend-service unavailable; OJT log count degraded to 0 (traineeID={}, status={})",
                traineeId, status);
        return new PageCountContract();
    }

    @Override
    public StipendPageContract getStipendDisbursements(Long traineeId, String status, Integer month, Integer year,
                                                       int page, int size) {
        log.warn("ojt-stipend-service unavailable; stipend data degraded to empty (traineeID={}, status={}, {}/{})",
                traineeId, status, month, year);
        return new StipendPageContract();
    }

    @Override
    public PageCountContract countAttendanceSummaries(Boolean stipendEligible, int page, int size) {
        log.warn("ojt-stipend-service unavailable; attendance-summary count degraded to 0 (stipendEligible={})",
                stipendEligible);
        return new PageCountContract();
    }
}
