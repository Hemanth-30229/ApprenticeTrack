package com.cts.platform.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.platform.client.dto.EmployerContract;
import com.cts.platform.client.dto.PageCountContract;

/**
 * Feign client to placement-service, which owns employers, vacancies and
 * placements (MIGRATION_PLAN.md §6). Replaces the in-process
 * {@code EmployerRepository} / {@code ApprenticeshipVacancyRepository} /
 * {@code PlacementRepository} reads the monolith's {@code DashboardServiceImpl}
 * performed. Guarded by {@link PlacementClientFallback}.
 *
 * <p>Count methods derive totals from the existing paginated list endpoints'
 * {@code totalElements} (see {@link PageCountContract}) rather than requiring
 * placement-service to expose dedicated count endpoints.
 */
@FeignClient(name = "placement-service", fallback = PlacementClientFallback.class)
public interface PlacementClient {

    /** Returns the employer, or {@code null} if placement-service reports none. */
    @GetMapping("/api/employers/{employerId}")
    EmployerContract getEmployer(@PathVariable("employerId") Long employerId);

    /** Total placements, optionally scoped by employerID and/or status. */
    @GetMapping("/api/placements")
    PageCountContract countPlacements(@RequestParam(value = "employerID", required = false) Long employerId,
                                      @RequestParam(value = "status", required = false) String status,
                                      @RequestParam(value = "page", defaultValue = "0") int page,
                                      @RequestParam(value = "size", defaultValue = "1") int size);

    /** Total vacancies, optionally scoped by employerID and/or status. */
    @GetMapping("/api/vacancies")
    PageCountContract countVacancies(@RequestParam(value = "employerID", required = false) Long employerId,
                                     @RequestParam(value = "status", required = false) String status,
                                     @RequestParam(value = "page", defaultValue = "0") int page,
                                     @RequestParam(value = "size", defaultValue = "1") int size);

    /** Total employers, optionally filtered by status. */
    @GetMapping("/api/employers")
    PageCountContract countEmployers(@RequestParam(value = "status", required = false) String status,
                                     @RequestParam(value = "page", defaultValue = "0") int page,
                                     @RequestParam(value = "size", defaultValue = "1") int size);
}
