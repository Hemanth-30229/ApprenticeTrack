package com.cts.platform.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cts.platform.client.dto.EmployerContract;
import com.cts.platform.client.dto.PageCountContract;

/**
 * Degraded-mode fallback for {@link PlacementClient}. When placement-service is
 * unreachable, dashboard metrics sourced from it degrade to zero/null rather than
 * failing the whole dashboard response (MIGRATION_PLAN.md §10).
 */
@Component
public class PlacementClientFallback implements PlacementClient {

    private static final Logger log = LoggerFactory.getLogger(PlacementClientFallback.class);

    @Override
    public EmployerContract getEmployer(Long employerId) {
        log.warn("placement-service unavailable; cannot resolve employerID={}", employerId);
        return null;
    }

    @Override
    public PageCountContract countPlacements(Long employerId, String status, int page, int size) {
        log.warn("placement-service unavailable; placement count degraded to 0 (employerID={}, status={})",
                employerId, status);
        return new PageCountContract();
    }

    @Override
    public PageCountContract countVacancies(Long employerId, String status, int page, int size) {
        log.warn("placement-service unavailable; vacancy count degraded to 0 (employerID={}, status={})",
                employerId, status);
        return new PageCountContract();
    }

    @Override
    public PageCountContract countEmployers(String status, int page, int size) {
        log.warn("placement-service unavailable; employer count degraded to 0 (status={})", status);
        return new PageCountContract();
    }
}
