package com.cts.platform.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.platform.client.dto.EnrollmentContract;
import com.cts.platform.client.dto.PageCountContract;
import com.cts.platform.client.dto.TraineeContract;

/**
 * Feign client to training-service, which owns trainees, training batches and
 * course enrollments (MIGRATION_PLAN.md §6). Replaces the in-process
 * {@code TraineeRepository} / {@code TrainingBatchRepository} /
 * {@code CourseEnrollmentRepository} reads the monolith's
 * {@code NotificationDispatcherImpl} and {@code DashboardServiceImpl} performed.
 * Guarded by {@link TrainingClientFallback}.
 *
 * <p>Count methods derive totals from the existing paginated list endpoints'
 * {@code totalElements} (see {@link PageCountContract}) rather than requiring
 * training-service to expose dedicated count endpoints.
 */
@FeignClient(name = "training-service", fallback = TrainingClientFallback.class)
public interface TrainingClient {

    /** Returns the trainee, or {@code null} if training-service reports none. */
    @GetMapping("/api/trainees/{traineeId}")
    TraineeContract getTrainee(@PathVariable("traineeId") Long traineeId);

    /** Returns the trainee linked to a UserID, or {@code null} if none exists. */
    @GetMapping("/api/trainees/by-user/{userId}")
    TraineeContract getTraineeByUserId(@PathVariable("userId") Long userId);

    /** All enrollments for a trainee — replaces {@code CourseEnrollmentRepository.findByTraineeID}. */
    @GetMapping("/api/enrollments/trainee/{traineeId}")
    List<EnrollmentContract> getEnrollmentsForTrainee(@PathVariable("traineeId") Long traineeId);

    /** Total trainees, optionally filtered by status — replaces {@code TraineeRepository.count()}/{@code countByStatus}. */
    @GetMapping("/api/trainees")
    PageCountContract countTrainees(@RequestParam(value = "status", required = false) String status,
                                    @RequestParam(value = "page", defaultValue = "0") int page,
                                    @RequestParam(value = "size", defaultValue = "1") int size);

    /** Total training batches by status — replaces {@code TrainingBatchRepository.countByStatus}. */
    @GetMapping("/api/batches")
    PageCountContract countBatches(@RequestParam(value = "status", required = false) String status,
                                   @RequestParam(value = "page", defaultValue = "0") int page,
                                   @RequestParam(value = "size", defaultValue = "1") int size);
}
