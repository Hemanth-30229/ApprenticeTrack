package com.cts.platform.client;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cts.platform.client.dto.EnrollmentContract;
import com.cts.platform.client.dto.PageCountContract;
import com.cts.platform.client.dto.TraineeContract;

/**
 * Degraded-mode fallback for {@link TrainingClient}. When training-service is
 * unreachable, trainee-targeted notifications are dropped (logged) and dashboard
 * metrics sourced from training-service degrade to zero/empty rather than failing
 * the whole dashboard response (MIGRATION_PLAN.md §10).
 */
@Component
public class TrainingClientFallback implements TrainingClient {

    private static final Logger log = LoggerFactory.getLogger(TrainingClientFallback.class);

    @Override
    public TraineeContract getTrainee(Long traineeId) {
        log.warn("training-service unavailable; cannot resolve traineeID={}", traineeId);
        return null;
    }

    @Override
    public TraineeContract getTraineeByUserId(Long userId) {
        log.warn("training-service unavailable; cannot resolve trainee for userID={}", userId);
        return null;
    }

    @Override
    public List<EnrollmentContract> getEnrollmentsForTrainee(Long traineeId) {
        log.warn("training-service unavailable; returning no enrollments for traineeID={}", traineeId);
        return Collections.emptyList();
    }

    @Override
    public PageCountContract countTrainees(String status, int page, int size) {
        log.warn("training-service unavailable; trainee count degraded to 0 (status={})", status);
        return new PageCountContract();
    }

    @Override
    public PageCountContract countBatches(String status, int page, int size) {
        log.warn("training-service unavailable; batch count degraded to 0 (status={})", status);
        return new PageCountContract();
    }
}
