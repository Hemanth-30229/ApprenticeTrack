package com.cts.platform.client.dto;

/**
 * Lightweight view of a placement-service {@code Employer}. Only carries what the
 * employer dashboard needs to confirm the employer exists before scoping metrics
 * to it (replaces the monolith's in-process {@code EmployerRepository.findById}).
 */
public class EmployerContract {

    private Long employerID;
    private String companyName;
    private String status;

    public EmployerContract() {}

    public Long getEmployerID() { return employerID; }
    public void setEmployerID(Long employerID) { this.employerID = employerID; }

    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
