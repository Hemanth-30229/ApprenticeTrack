package com.cts.platform.client.dto;

import java.time.LocalDate;

/**
 * Lightweight view of a training-service {@code CourseEnrollment}, carrying only
 * the fields the trainee dashboard's "activeEnrollment" metric needs.
 */
public class EnrollmentContract {

    private Long enrollmentID;
    private Long traineeID;
    private Long courseID;
    private Long batchID;
    private String status;
    private LocalDate expectedCompletionDate;

    public EnrollmentContract() {}

    public Long getEnrollmentID() { return enrollmentID; }
    public void setEnrollmentID(Long enrollmentID) { this.enrollmentID = enrollmentID; }

    public Long getTraineeID() { return traineeID; }
    public void setTraineeID(Long traineeID) { this.traineeID = traineeID; }

    public Long getCourseID() { return courseID; }
    public void setCourseID(Long courseID) { this.courseID = courseID; }

    public Long getBatchID() { return batchID; }
    public void setBatchID(Long batchID) { this.batchID = batchID; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDate getExpectedCompletionDate() { return expectedCompletionDate; }
    public void setExpectedCompletionDate(LocalDate expectedCompletionDate) { this.expectedCompletionDate = expectedCompletionDate; }
}
