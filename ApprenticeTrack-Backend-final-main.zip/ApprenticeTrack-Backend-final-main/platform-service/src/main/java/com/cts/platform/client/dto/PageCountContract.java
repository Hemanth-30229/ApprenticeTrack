package com.cts.platform.client.dto;

/**
 * Minimal view of a Spring Data {@code Page<T>} JSON response — only the
 * {@code totalElements} field is read. Lets dashboard aggregation derive counts
 * (e.g. "active trainees", "open vacancies") from the paginated list endpoints
 * every business service already exposes, instead of requiring each provider to
 * add dedicated count endpoints. Unknown fields (content, pageable, etc.) are
 * ignored by Jackson's default deserialization.
 */
public class PageCountContract {

    private long totalElements;

    public PageCountContract() {}

    public long getTotalElements() { return totalElements; }
    public void setTotalElements(long totalElements) { this.totalElements = totalElements; }
}
