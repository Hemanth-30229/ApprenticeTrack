package com.cts.platform.client.dto;

import java.math.BigDecimal;
import java.util.List;

/**
 * Minimal view of ojt-stipend-service's paginated {@code GET /api/stipend-disbursements}
 * response. Reads {@code totalElements} (disbursement count) and each row's
 * {@code stipendAmount} so the dashboard can derive a trainee's total disbursed amount.
 *
 * <p>ojt-stipend-service exposes no aggregate/SUM endpoint; consistent with the rest of
 * the dashboard (see {@link PageCountContract}), the total is summed here from a single
 * generously-sized page rather than requiring a new provider-side endpoint. Unknown JSON
 * fields are ignored by Jackson's default deserialization.
 */
public class StipendPageContract {

    private long totalElements;
    private List<Row> content = List.of();

    public StipendPageContract() {}

    public long getTotalElements() { return totalElements; }
    public void setTotalElements(long totalElements) { this.totalElements = totalElements; }

    public List<Row> getContent() { return content; }
    public void setContent(List<Row> content) { this.content = (content == null ? List.of() : content); }

    /** Sum of {@code stipendAmount} across the returned rows (zero when none). */
    public BigDecimal totalStipendAmount() {
        return content.stream()
                .map(Row::getStipendAmount)
                .filter(a -> a != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public static class Row {
        private BigDecimal stipendAmount;

        public Row() {}

        public BigDecimal getStipendAmount() { return stipendAmount; }
        public void setStipendAmount(BigDecimal stipendAmount) { this.stipendAmount = stipendAmount; }
    }
}
