package com.cts.platform.client.dto;

/**
 * Lightweight view of a training-service {@code Trainee}. Carries {@code userID}
 * so platform-service can resolve a trainee-targeted notification to the linked
 * user (replaces the monolith's in-process {@code TraineeRepository.findById(...)
 * .getUserID()} / {@code findByUserID(...)} reads).
 */
public class TraineeContract {

    private Long traineeID;
    private Long userID;
    private String name;
    private String status;

    public TraineeContract() {}

    public Long getTraineeID() { return traineeID; }
    public void setTraineeID(Long traineeID) { this.traineeID = traineeID; }

    public Long getUserID() { return userID; }
    public void setUserID(Long userID) { this.userID = userID; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
