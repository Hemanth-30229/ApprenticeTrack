package com.cts.platform.common;

public enum NotificationCategory {
    Enrollment, Placement, OJT, Assessment, Stipend, Certification
}
