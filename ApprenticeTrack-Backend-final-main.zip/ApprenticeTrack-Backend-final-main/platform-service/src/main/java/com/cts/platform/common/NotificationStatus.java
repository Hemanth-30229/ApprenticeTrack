package com.cts.platform.common;

public enum NotificationStatus {
    Unread, Read, Dismissed
}
