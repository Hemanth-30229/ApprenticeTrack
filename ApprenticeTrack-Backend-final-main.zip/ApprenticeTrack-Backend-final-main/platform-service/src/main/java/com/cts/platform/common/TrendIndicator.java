package com.cts.platform.common;

/**
 * Trend of a dashboard metric compared to the previous period.
 */
public enum TrendIndicator {
    up, down, stable
}
