package com.cts.platform.config;

import java.util.concurrent.Executor;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskDecorator;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.cts.platform.security.AuthTokenHolder;

/**
 * Enables {@code @Async} execution for {@code NotificationDispatcherImpl}, whose
 * persist-and-forget methods must not block the caller (an incoming
 * {@code POST /api/notifications} request, or previously an in-process call from
 * another module in the monolith).
 */
@Configuration
@EnableAsync
public class AsyncConfig {

    @Bean(name = "notificationTaskExecutor")
    public Executor notificationTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(2);
        executor.setMaxPoolSize(8);
        executor.setQueueCapacity(200);
        executor.setThreadNamePrefix("notif-dispatch-");
        // Carry the caller's JWT onto the worker thread so the async notifyTrainee()
        // lookup (Feign getTrainee) is still authenticated — RequestContextHolder is
        // thread-bound and empty on these threads otherwise.
        executor.setTaskDecorator(authForwardingDecorator());
        executor.initialize();
        return executor;
    }

    private TaskDecorator authForwardingDecorator() {
        return runnable -> {
            String token = currentAuthToken();
            return () -> {
                AuthTokenHolder.set(token);
                try {
                    runnable.run();
                } finally {
                    AuthTokenHolder.clear();
                }
            };
        };
    }

    /** Read the current request's Authorization header on the submitting (request) thread. */
    private String currentAuthToken() {
        if (RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes attrs) {
            return attrs.getRequest().getHeader("Authorization");
        }
        return null;
    }
}
