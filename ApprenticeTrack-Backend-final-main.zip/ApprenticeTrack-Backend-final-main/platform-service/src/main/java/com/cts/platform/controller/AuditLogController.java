package com.cts.platform.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.platform.dto.AuditLogCreateRequestDTO;
import com.cts.platform.dto.AuditLogResponseDTO;
import com.cts.platform.service.AuditService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

/**
 * Audit-trail API. {@code POST} is the dispatch endpoint every business service's
 * {@code PlatformClient.recordAudit(...)} calls (replaces the monolith's direct
 * {@code AuditLogRepository.save(...)} in-process write). {@code GET} is a
 * read-only query restricted to Vocational Admins — audit entries are immutable,
 * so there are no update/delete operations.
 */
@RestController
@RequestMapping("/api/audit-logs")
@SecurityRequirement(name = "bearerAuth")
public class AuditLogController {

    private final AuditService auditService;

    public AuditLogController(AuditService auditService) {
        this.auditService = auditService;
    }

    @PostMapping
    public ResponseEntity<Void> record(@Valid @RequestBody AuditLogCreateRequestDTO requestDTO) {
        auditService.record(requestDTO.getUserID(), requestDTO.getAction(),
                requestDTO.getModule(), requestDTO.getDetails());
        return ResponseEntity.accepted().build();
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('Admin','VocationalAdmin')")
    public ResponseEntity<Page<AuditLogResponseDTO>> getAuditLogs(
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) String module,
            @RequestParam(required = false) String action,
            @RequestParam(required = false)
                @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false)
                @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "timestamp,desc") String sort) {

        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("asc")
                ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));

        LocalDateTime start = startDate != null ? startDate.atStartOfDay() : null;
        LocalDateTime end = endDate != null ? endDate.atTime(LocalTime.MAX) : null;

        return ResponseEntity.ok(
                auditService.getAuditLogs(userId, module, action, start, end, pageable));
    }
}
