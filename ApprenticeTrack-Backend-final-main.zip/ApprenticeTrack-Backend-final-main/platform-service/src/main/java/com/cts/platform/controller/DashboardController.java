package com.cts.platform.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.platform.dto.DashboardResponseDTO;
import com.cts.platform.security.AuthUser;
import com.cts.platform.service.DashboardService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@RequestMapping("/api/dashboard")
@SecurityRequirement(name = "bearerAuth")
public class DashboardController {

    private final DashboardService dashboardService;

    public DashboardController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    /**
     * Role-specific summary metrics for the authenticated user's home dashboard.
     * Role and userID come straight from the JWT (auth-service is the root of
     * trust for both), so no auth-service lookup is needed here.
     *
     * @param employerID optional employer scope, honoured only for the Employer role
     */
    @GetMapping
    public ResponseEntity<DashboardResponseDTO> getDashboard(
            @RequestParam(required = false) Long employerID,
            @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(dashboardService.getDashboard(user.userID(), user.role(), employerID));
    }
}
