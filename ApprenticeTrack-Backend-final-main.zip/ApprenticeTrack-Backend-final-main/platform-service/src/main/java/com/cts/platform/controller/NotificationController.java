package com.cts.platform.controller;

import java.time.LocalDate;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.platform.dto.NotificationDispatchRequestDTO;
import com.cts.platform.dto.NotificationResponseDTO;
import com.cts.platform.common.NotificationCategory;
import com.cts.platform.common.NotificationStatus;
import com.cts.platform.security.AuthUser;
import com.cts.platform.service.NotificationDispatcher;
import com.cts.platform.service.NotificationService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/notifications")
@SecurityRequirement(name = "bearerAuth")
public class NotificationController {

    private final NotificationService notificationService;
    private final NotificationDispatcher notificationDispatcher;

    public NotificationController(NotificationService notificationService,
                                  NotificationDispatcher notificationDispatcher) {
        this.notificationService = notificationService;
        this.notificationDispatcher = notificationDispatcher;
    }

    /**
     * Dispatch endpoint called by every business service's {@code PlatformClient.notify(...)}
     * (replaces the monolith's in-process {@code NotificationDispatcher} trigger). Persists
     * asynchronously, so this returns immediately.
     */
    @PostMapping
    public ResponseEntity<Void> dispatch(@Valid @RequestBody NotificationDispatchRequestDTO requestDTO) {
        if ("TRAINEE".equalsIgnoreCase(requestDTO.getRecipientType())) {
            notificationDispatcher.notifyTrainee(
                    requestDTO.getRecipientID(), requestDTO.getMessage(), requestDTO.getCategory());
        } else {
            notificationDispatcher.notifyUser(
                    requestDTO.getRecipientID(), requestDTO.getMessage(), requestDTO.getCategory());
        }
        return ResponseEntity.accepted().build();
    }

    @GetMapping
    public ResponseEntity<Page<NotificationResponseDTO>> getForUser(
            @RequestParam(required = false) NotificationCategory category,
            @RequestParam(required = false) NotificationStatus status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @AuthenticationPrincipal AuthUser user) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdDate"));
        return ResponseEntity.ok(
                notificationService.getForUser(user.userID(), category, status, fromDate, toDate, pageable));
    }

    @GetMapping("/unread-count")
    public ResponseEntity<Map<String, Long>> unreadCount(@AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(Map.of("unreadCount", notificationService.unreadCount(user.userID())));
    }

    @PutMapping("/{id}/read")
    public ResponseEntity<NotificationResponseDTO> markRead(
            @PathVariable Long id, @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(notificationService.markRead(id, user.userID()));
    }

    @PutMapping("/{id}/dismiss")
    public ResponseEntity<NotificationResponseDTO> dismiss(
            @PathVariable Long id, @AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(notificationService.dismiss(id, user.userID()));
    }

    @PutMapping("/mark-all-read")
    public ResponseEntity<Map<String, Integer>> markAllRead(@AuthenticationPrincipal AuthUser user) {
        return ResponseEntity.ok(Map.of("markedRead", notificationService.markAllRead(user.userID())));
    }
}
