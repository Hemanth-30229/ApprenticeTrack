package com.cts.platform.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * Wire contract for {@code POST /api/audit-logs}. Every business service's
 * {@code PlatformClient.recordAudit(...)} sends this exact shape (see e.g.
 * auth-service / placement-service / assessment-service / ojt-stipend-service
 * {@code client.dto.AuditLogRequest}) — replaces the monolith's direct
 * {@code AuditLogRepository.save(...)} / {@code AuditService.record(...)} call.
 */
public class AuditLogCreateRequestDTO {

    @NotNull(message = "userID is required")
    private Long userID;

    @NotBlank(message = "action is required")
    private String action;

    @NotBlank(message = "module is required")
    private String module;

    private String details;

    public AuditLogCreateRequestDTO() {}

    public Long getUserID() { return userID; }
    public void setUserID(Long userID) { this.userID = userID; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getModule() { return module; }
    public void setModule(String module) { this.module = module; }

    public String getDetails() { return details; }
    public void setDetails(String details) { this.details = details; }
}
