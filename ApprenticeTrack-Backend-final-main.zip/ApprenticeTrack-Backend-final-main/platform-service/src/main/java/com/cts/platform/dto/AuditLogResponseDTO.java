package com.cts.platform.dto;

import java.time.LocalDateTime;

public class AuditLogResponseDTO {
    private Long auditID;
    private Long userID;
    private String action;
    private String module;
    private LocalDateTime timestamp;
    private String ipAddress;
    private String details;

    public AuditLogResponseDTO() {}
    public Long getAuditID() { return auditID; }
    public Long getUserID() { return userID; }
    public String getAction() { return action; }
    public String getModule() { return module; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public String getIpAddress() { return ipAddress; }
    public String getDetails() { return details; }
    public void setAuditID(Long v) { this.auditID = v; }
    public void setUserID(Long v) { this.userID = v; }
    public void setAction(String v) { this.action = v; }
    public void setModule(String v) { this.module = v; }
    public void setTimestamp(LocalDateTime v) { this.timestamp = v; }
    public void setIpAddress(String v) { this.ipAddress = v; }
    public void setDetails(String v) { this.details = v; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long auditID;
        private Long userID;
        private String action;
        private String module;
        private LocalDateTime timestamp;
        private String ipAddress;
        private String details;
        public Builder auditID(Long v) { this.auditID = v; return this; }
        public Builder userID(Long v) { this.userID = v; return this; }
        public Builder action(String v) { this.action = v; return this; }
        public Builder module(String v) { this.module = v; return this; }
        public Builder timestamp(LocalDateTime v) { this.timestamp = v; return this; }
        public Builder ipAddress(String v) { this.ipAddress = v; return this; }
        public Builder details(String v) { this.details = v; return this; }
        public AuditLogResponseDTO build() {
            AuditLogResponseDTO d = new AuditLogResponseDTO();
            d.auditID = auditID; d.userID = userID; d.action = action; d.module = module;
            d.timestamp = timestamp; d.ipAddress = ipAddress; d.details = details;
            return d;
        }
    }
}
