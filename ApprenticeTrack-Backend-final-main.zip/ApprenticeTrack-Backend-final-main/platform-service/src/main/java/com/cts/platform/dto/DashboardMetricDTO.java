package com.cts.platform.dto;

/**
 * A single dashboard metric: a machine-readable name, its computed value
 * (scalar, string, or a nested map for composite metrics), and a trend
 * indicator relative to the previous period.
 */
import com.cts.platform.common.TrendIndicator;

public class DashboardMetricDTO {

    private String name;
    private Object value;
    private TrendIndicator trend;

    public DashboardMetricDTO() {}

    public DashboardMetricDTO(String name, Object value, TrendIndicator trend) {
        this.name = name;
        this.value = value;
        this.trend = trend;
    }

    /** Convenience factory defaulting the trend to {@link TrendIndicator#stable}. */
    public static DashboardMetricDTO of(String name, Object value) {
        return new DashboardMetricDTO(name, value, TrendIndicator.stable);
    }

    public static DashboardMetricDTO of(String name, Object value, TrendIndicator trend) {
        return new DashboardMetricDTO(name, value, trend);
    }

    public String getName() { return name; }
    public Object getValue() { return value; }
    public TrendIndicator getTrend() { return trend; }

    public void setName(String name) { this.name = name; }
    public void setValue(Object value) { this.value = value; }
    public void setTrend(TrendIndicator trend) { this.trend = trend; }
}
