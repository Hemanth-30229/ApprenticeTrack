package com.cts.platform.dto;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Role-specific dashboard payload returned by {@code GET /api/dashboard}.
 */
public class DashboardResponseDTO {

    private String role;
    private LocalDateTime generatedAt;
    private boolean cached;
    private List<DashboardMetricDTO> metrics;

    public DashboardResponseDTO() {}

    public String getRole() { return role; }
    public LocalDateTime getGeneratedAt() { return generatedAt; }
    public boolean isCached() { return cached; }
    public List<DashboardMetricDTO> getMetrics() { return metrics; }

    public void setRole(String role) { this.role = role; }
    public void setGeneratedAt(LocalDateTime generatedAt) { this.generatedAt = generatedAt; }
    public void setCached(boolean cached) { this.cached = cached; }
    public void setMetrics(List<DashboardMetricDTO> metrics) { this.metrics = metrics; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String role;
        private LocalDateTime generatedAt;
        private boolean cached;
        private List<DashboardMetricDTO> metrics;

        public Builder role(String v) { this.role = v; return this; }
        public Builder generatedAt(LocalDateTime v) { this.generatedAt = v; return this; }
        public Builder cached(boolean v) { this.cached = v; return this; }
        public Builder metrics(List<DashboardMetricDTO> v) { this.metrics = v; return this; }

        public DashboardResponseDTO build() {
            DashboardResponseDTO d = new DashboardResponseDTO();
            d.role = role; d.generatedAt = generatedAt;
            d.cached = cached; d.metrics = metrics;
            return d;
        }
    }
}
