package com.cts.platform.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

/**
 * Wire contract for {@code POST /api/notifications}. Every business service's
 * {@code PlatformClient.notify(...)} sends this exact shape (see e.g.
 * placement-service / ojt-stipend-service / assessment-service
 * {@code client.dto.NotificationRequest}) — it replaces the monolith's in-process
 * {@code NotificationDispatcher.notifyUser}/{@code notifyTrainee} trigger, now
 * crossing a service boundary instead of a Java method call.
 */
public class NotificationDispatchRequestDTO {

    /** {@code "USER"} or {@code "TRAINEE"}; TRAINEE is resolved to a UserID via training-service. */
    @NotBlank(message = "recipientType is required")
    @Pattern(regexp = "USER|TRAINEE", message = "recipientType must be USER or TRAINEE")
    private String recipientType;

    @NotNull(message = "recipientID is required")
    private Long recipientID;

    @NotBlank(message = "message is required")
    private String message;

    /** Notification category name, e.g. {@code "OJT"} or {@code "Stipend"} (see Notification.Category). */
    @NotBlank(message = "category is required")
    private String category;

    public NotificationDispatchRequestDTO() {}

    public String getRecipientType() { return recipientType; }
    public void setRecipientType(String recipientType) { this.recipientType = recipientType; }

    public Long getRecipientID() { return recipientID; }
    public void setRecipientID(Long recipientID) { this.recipientID = recipientID; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
}
