package com.cts.platform.dto;

import java.time.LocalDateTime;

import com.cts.platform.common.NotificationCategory;
import com.cts.platform.common.NotificationStatus;

public class NotificationResponseDTO {

    private Long notificationID, userID;
    private String message;
    private NotificationCategory category;
    private NotificationStatus status;
    private LocalDateTime createdDate;

    public NotificationResponseDTO() {}

    public Long getNotificationID() { return notificationID; }
    public Long getUserID() { return userID; }
    public String getMessage() { return message; }
    public NotificationCategory getCategory() { return category; }
    public NotificationStatus getStatus() { return status; }
    public LocalDateTime getCreatedDate() { return createdDate; }

    public void setNotificationID(Long v) { this.notificationID = v; }
    public void setUserID(Long v) { this.userID = v; }
    public void setMessage(String v) { this.message = v; }
    public void setCategory(NotificationCategory v) { this.category = v; }
    public void setStatus(NotificationStatus v) { this.status = v; }
    public void setCreatedDate(LocalDateTime v) { this.createdDate = v; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long notificationID, userID;
        private String message;
        private NotificationCategory category;
        private NotificationStatus status;
        private LocalDateTime createdDate;

        public Builder notificationID(Long v) { this.notificationID = v; return this; }
        public Builder userID(Long v) { this.userID = v; return this; }
        public Builder message(String v) { this.message = v; return this; }
        public Builder category(NotificationCategory v) { this.category = v; return this; }
        public Builder status(NotificationStatus v) { this.status = v; return this; }
        public Builder createdDate(LocalDateTime v) { this.createdDate = v; return this; }

        public NotificationResponseDTO build() {
            NotificationResponseDTO d = new NotificationResponseDTO();
            d.notificationID = notificationID; d.userID = userID; d.message = message;
            d.category = category; d.status = status; d.createdDate = createdDate;
            return d;
        }
    }
}
