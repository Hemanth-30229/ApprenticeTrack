package com.cts.platform.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "audit_log")
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long auditID;

    @Column(nullable = false)
    private Long userID;

    @Column(nullable = false)
    private String action;

    @Column(nullable = false)
    private String module;

    @Column(nullable = false)
    private LocalDateTime timestamp = LocalDateTime.now();

    @Column(name = "ip_address")
    private String ipAddress;

    @Column(length = 1000)
    private String details;

    public AuditLog() {}

    // ── Getters ───────────────────────────────────────────────────────────────
    public Long getAuditID() { return auditID; }
    public Long getUserID() { return userID; }
    public String getAction() { return action; }
    public String getModule() { return module; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public String getIpAddress() { return ipAddress; }
    public String getDetails() { return details; }

    // ── Setters ───────────────────────────────────────────────────────────────
    public void setAuditID(Long auditID) { this.auditID = auditID; }
    public void setUserID(Long userID) { this.userID = userID; }
    public void setAction(String action) { this.action = action; }
    public void setModule(String module) { this.module = module; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
    public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }
    public void setDetails(String details) { this.details = details; }

    // ── Builder ───────────────────────────────────────────────────────────────
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long userID;
        private String action;
        private String module;
        private LocalDateTime timestamp = LocalDateTime.now();
        private String ipAddress;
        private String details;

        public Builder userID(Long userID) { this.userID = userID; return this; }
        public Builder action(String action) { this.action = action; return this; }
        public Builder module(String module) { this.module = module; return this; }
        public Builder timestamp(LocalDateTime timestamp) { this.timestamp = timestamp; return this; }
        public Builder ipAddress(String ipAddress) { this.ipAddress = ipAddress; return this; }
        public Builder details(String details) { this.details = details; return this; }

        public AuditLog build() {
            AuditLog a = new AuditLog();
            a.userID = this.userID; a.action = this.action;
            a.module = this.module; a.timestamp = this.timestamp;
            a.ipAddress = this.ipAddress; a.details = this.details;
            return a;
        }
    }
}
