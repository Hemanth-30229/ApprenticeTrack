package com.cts.platform.exception;

/**
 * Thrown when a notification status transition is not allowed (e.g. marking a
 * non-Unread notification as Read). Mapped to 400 Bad Request.
 */
public class InvalidNotificationStatusException extends RuntimeException {
    public InvalidNotificationStatusException(String message) {
        super(message);
    }
}
