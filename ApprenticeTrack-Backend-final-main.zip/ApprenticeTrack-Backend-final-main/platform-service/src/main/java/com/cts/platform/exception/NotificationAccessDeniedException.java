package com.cts.platform.exception;

/**
 * Thrown when a user tries to act on a notification that belongs to someone
 * else. Mapped to 403 Forbidden.
 */
public class NotificationAccessDeniedException extends RuntimeException {
    public NotificationAccessDeniedException(String message) {
        super(message);
    }
}
