package com.cts.platform.exception;

/**
 * Thrown when the authenticated Trainee-role user has no linked Trainee profile
 * in training-service. Mapped to 404 Not Found.
 */
public class TraineeNotFoundException extends RuntimeException {
    public TraineeNotFoundException(String message) {
        super(message);
    }
}
