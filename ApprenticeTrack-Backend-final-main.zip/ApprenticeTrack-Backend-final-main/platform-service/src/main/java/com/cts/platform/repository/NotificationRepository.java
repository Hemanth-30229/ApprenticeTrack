package com.cts.platform.repository;

import java.time.LocalDateTime;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.platform.common.NotificationCategory;
import com.cts.platform.common.NotificationStatus;
import com.cts.platform.entity.Notification;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {

    long countByUserIDAndStatus(Long userID, NotificationStatus status);

    /**
     * Paginated filtering for a single user by Category, Status, and date range.
     * Category/Status/dates are optional — null means no filter applied.
     */
    @Query("SELECT n FROM Notification n WHERE " +
           "n.userID = :userID AND " +
           "(:category IS NULL OR n.category = :category) AND " +
           "(:status IS NULL OR n.status = :status) AND " +
           "(:fromDate IS NULL OR n.createdDate >= :fromDate) AND " +
           "(:toDate IS NULL OR n.createdDate <= :toDate)")
    Page<Notification> findForUserWithFilters(
            @Param("userID") Long userID,
            @Param("category") NotificationCategory category,
            @Param("status") NotificationStatus status,
            @Param("fromDate") LocalDateTime fromDate,
            @Param("toDate") LocalDateTime toDate,
            Pageable pageable);

    @Modifying
    @Query("UPDATE Notification n SET n.status = 'Read' WHERE n.userID = :userID AND n.status = 'Unread'")
    int markAllReadForUser(@Param("userID") Long userID);
}
