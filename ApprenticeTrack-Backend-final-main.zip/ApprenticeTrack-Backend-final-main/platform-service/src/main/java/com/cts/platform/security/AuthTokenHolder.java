package com.cts.platform.security;

/**
 * Carries the caller's {@code Authorization} (JWT) header across an {@code @Async}
 * thread hop. The Feign {@code authForwardingInterceptor} normally reads the token
 * from {@code RequestContextHolder}, but that is thread-bound and empty on the
 * {@code notificationTaskExecutor} worker threads used by
 * {@code NotificationDispatcherImpl.notifyTrainee}. The async {@code TaskDecorator}
 * captures the token on the request thread and re-binds it here on the worker thread
 * so the outbound {@code getTrainee} lookup is still authenticated.
 */
public final class AuthTokenHolder {

    private static final ThreadLocal<String> TOKEN = new ThreadLocal<>();

    private AuthTokenHolder() {}

    public static void set(String token) {
        TOKEN.set(token);
    }

    public static String get() {
        return TOKEN.get();
    }

    public static void clear() {
        TOKEN.remove();
    }
}
