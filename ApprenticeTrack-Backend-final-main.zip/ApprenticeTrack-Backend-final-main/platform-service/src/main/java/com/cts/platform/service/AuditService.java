package com.cts.platform.service;

import java.time.LocalDateTime;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.platform.dto.AuditLogResponseDTO;

public interface AuditService {

    /**
     * Records an immutable audit entry. The client IP address is resolved automatically
     * from the current HTTP request (if any).
     */
    void record(Long userID, String action, String module, String details);

    Page<AuditLogResponseDTO> getAuditLogs(Long userId, String module, String action,
                                           LocalDateTime startDate, LocalDateTime endDate,
                                           Pageable pageable);
}
