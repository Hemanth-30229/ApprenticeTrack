package com.cts.platform.service;

import java.time.LocalDateTime;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.cts.platform.dto.AuditLogResponseDTO;
import com.cts.platform.entity.AuditLog;
import com.cts.platform.repository.AuditLogRepository;

import jakarta.servlet.http.HttpServletRequest;

@Service
public class AuditServiceImpl implements AuditService {

    private final AuditLogRepository auditLogRepository;

    public AuditServiceImpl(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    @Override
    @Transactional
    public void record(Long userID, String action, String module, String details) {
        auditLogRepository.save(AuditLog.builder()
                .userID(userID)
                .action(action)
                .module(module)
                .details(details)
                .ipAddress(resolveClientIp())
                .build());
    }

    @Override
    @Transactional(readOnly = true)
    public Page<AuditLogResponseDTO> getAuditLogs(Long userId, String module, String action,
                                                  LocalDateTime startDate, LocalDateTime endDate,
                                                  Pageable pageable) {
        return auditLogRepository
                .findAllWithFilters(userId, module, action, startDate, endDate, pageable)
                .map(this::toResponseDTO);
    }

    /** Resolves the caller IP from the current request, honouring X-Forwarded-For. */
    private String resolveClientIp() {
        ServletRequestAttributes attrs =
                (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attrs == null) {
            return null;
        }
        HttpServletRequest request = attrs.getRequest();
        String forwarded = request.getHeader("X-Forwarded-For");
        if (forwarded != null && !forwarded.isBlank()) {
            return forwarded.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }

    private AuditLogResponseDTO toResponseDTO(AuditLog a) {
        return AuditLogResponseDTO.builder()
                .auditID(a.getAuditID())
                .userID(a.getUserID())
                .action(a.getAction())
                .module(a.getModule())
                .timestamp(a.getTimestamp())
                .ipAddress(a.getIpAddress())
                .details(a.getDetails())
                .build();
    }
}
