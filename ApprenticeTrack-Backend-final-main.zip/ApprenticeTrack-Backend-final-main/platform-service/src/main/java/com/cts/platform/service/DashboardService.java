package com.cts.platform.service;

import com.cts.platform.dto.DashboardResponseDTO;

public interface DashboardService {

    /**
     * Build the role-specific dashboard for the authenticated user.
     *
     * @param userID     authenticated user's ID (JWT claim)
     * @param role       authenticated user's role (JWT claim)
     * @param employerID optional employer scope, only honoured for the Employer
     *                   role (the Employer entity is not yet linked to User)
     */
    DashboardResponseDTO getDashboard(Long userID, String role, Long employerID);
}
