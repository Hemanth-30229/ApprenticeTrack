package com.cts.platform.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.platform.client.AssessmentClient;
import com.cts.platform.client.OjtStipendClient;
import com.cts.platform.client.PlacementClient;
import com.cts.platform.client.TrainingClient;
import com.cts.platform.client.dto.EmployerContract;
import com.cts.platform.client.dto.EnrollmentContract;
import com.cts.platform.client.dto.StipendPageContract;
import com.cts.platform.client.dto.TraineeContract;
import com.cts.platform.dto.DashboardMetricDTO;
import com.cts.platform.dto.DashboardResponseDTO;
import com.cts.platform.exception.TraineeNotFoundException;

/**
 * Aggregates role-specific summary metrics for the home dashboard.
 *
 * <p>Metrics sourced from not-yet-built modules (OJTLog, OJTAttendanceSummary,
 * TradeTest, CompetencyResult, StipendDisbursement, TradeCertificate,
 * Notification) are emitted with placeholder values and marked with {@code TODO},
 * exactly as in the monolith — those cross-service reads (AssessmentClient,
 * OjtStipendClient) can be wired up incrementally without changing this class's
 * public contract.
 *
 * <p>Trainee/employer/placement/vacancy/batch data is no longer read from local
 * repositories: it comes from training-service ({@link TrainingClient}) and
 * placement-service ({@link PlacementClient}) via Resilience4j-backed Feign calls,
 * degrading to zero/empty metrics if a source service is unavailable.
 *
 * <p>Results are cached per user for a configurable TTL
 * ({@code dashboard.cache-ttl-seconds}, default 300s) to keep response time low.
 */
@Service
public class DashboardServiceImpl implements DashboardService {

    private static final String STATUS_ACTIVE = "Active";
    private static final String VACANCY_OPEN = "Open";
    private static final String VACANCY_PARTIALLY_FILLED = "PartiallyFilled";
    private static final String VACANCY_FILLED = "Filled";
    private static final String OJT_LOG_SUBMITTED = "Submitted";
    private static final String STIPEND_DISBURSED = "Disbursed";
    private static final String STIPEND_PENDING = "Pending";
    private static final String STIPEND_WITHHELD = "Withheld";
    private static final String CERTIFICATE_ISSUED = "Issued";
    private static final String CERTIFICATE_NONE = "NotAvailable";

    private final TrainingClient trainingClient;
    private final PlacementClient placementClient;
    private final OjtStipendClient ojtStipendClient;
    private final AssessmentClient assessmentClient;

    @Value("${dashboard.cache-ttl-seconds:300}")
    private long cacheTtlSeconds;

    private final Map<String, CacheEntry> cache = new ConcurrentHashMap<>();

    public DashboardServiceImpl(TrainingClient trainingClient, PlacementClient placementClient,
                                OjtStipendClient ojtStipendClient, AssessmentClient assessmentClient) {
        this.trainingClient = trainingClient;
        this.placementClient = placementClient;
        this.ojtStipendClient = ojtStipendClient;
        this.assessmentClient = assessmentClient;
    }

    @Override
    @Transactional(readOnly = true)
    public DashboardResponseDTO getDashboard(Long userID, String role, Long employerID) {
        String cacheKey = userID + ":" + (employerID == null ? "" : employerID);
        CacheEntry cached = cache.get(cacheKey);
        if (cached != null && !cached.isExpired()) {
            return copyAsCached(cached.response);
        }

        List<DashboardMetricDTO> metrics = switch (role) {
            case "Trainee" -> traineeMetrics(userID);
            case "Employer" -> employerMetrics(employerID);
            case "Assessor" -> assessorMetrics();
            case "PlacementOfficer" -> placementOfficerMetrics();
            case "StipendAdmin" -> stipendAdminMetrics();
            case "Admin" -> adminMetrics();
            default -> List.of();
        };

        DashboardResponseDTO response = DashboardResponseDTO.builder()
                .role(role)
                .generatedAt(LocalDateTime.now())
                .cached(false)
                .metrics(metrics)
                .build();

        cache.put(cacheKey, new CacheEntry(response,
                System.currentTimeMillis() + cacheTtlSeconds * 1000L));
        return response;
    }

    // ── Trainee ─────────────────────────────────────────────────────────────
    private List<DashboardMetricDTO> traineeMetrics(Long userID) {
        // Degrade gracefully: a trainee-role user without a linked Trainee profile
        // (or a transient training-service outage) should still receive a dashboard
        // with empty metrics rather than a 500 that blocks the whole page.
        TraineeContract trainee = trainingClient.getTraineeByUserId(userID);

        List<EnrollmentContract> enrollments = (trainee != null)
                ? trainingClient.getEnrollmentsForTrainee(trainee.getTraineeID())
                : java.util.List.of();
        if (enrollments == null) {
            enrollments = java.util.List.of();
        }
        EnrollmentContract active = enrollments.stream()
                .filter(e -> !"Withdrawn".equals(e.getStatus()) && !"Completed".equals(e.getStatus()))
                .findFirst()
                .orElse(enrollments.isEmpty() ? null : enrollments.get(0));

        Map<String, Object> enrollmentDetails = new LinkedHashMap<>();
        if (active != null) {
            enrollmentDetails.put("enrollmentID", active.getEnrollmentID());
            enrollmentDetails.put("courseID", active.getCourseID());
            enrollmentDetails.put("batchID", active.getBatchID());
            enrollmentDetails.put("status", active.getStatus());
            enrollmentDetails.put("expectedCompletionDate", active.getExpectedCompletionDate());
        }

        Long traineeID = (trainee != null) ? trainee.getTraineeID() : null;

        // OJT logs still awaiting supervisor confirmation for this trainee.
        long pendingOjtLogs = (traineeID != null)
                ? ojtStipendClient.countOjtLogs(traineeID, OJT_LOG_SUBMITTED, 0, 1).getTotalElements()
                : 0L;

        // Stipend history: count and summed amount of disbursed payments. ojt-stipend-service
        // exposes no SUM endpoint, so the total is summed from the disbursed list here.
        Map<String, Object> stipendHistory = stipendSummary();
        if (traineeID != null) {
            StipendPageContract disbursed =
                    ojtStipendClient.getStipendDisbursements(traineeID, STIPEND_DISBURSED, null, null, 0, 500);
            stipendHistory.put("totalDisbursed", disbursed.totalStipendAmount());
            stipendHistory.put("disbursementCount", disbursed.getTotalElements());
        }

        // Certificate status: Issued when the trainee has at least one issued certificate.
        String certificateStatus = CERTIFICATE_NONE;
        if (traineeID != null
                && assessmentClient.countCertificates(traineeID, CERTIFICATE_ISSUED, 0, 1).getTotalElements() > 0) {
            certificateStatus = CERTIFICATE_ISSUED;
        }

        List<DashboardMetricDTO> metrics = new ArrayList<>();
        metrics.add(DashboardMetricDTO.of("activeEnrollment", enrollmentDetails));
        metrics.add(DashboardMetricDTO.of("pendingOjtLogs", pendingOjtLogs));
        metrics.add(DashboardMetricDTO.of("stipendHistory", stipendHistory));
        metrics.add(DashboardMetricDTO.of("certificateStatus", certificateStatus));
        return metrics;
    }

    // ── Employer ────────────────────────────────────────────────────────────
    private List<DashboardMetricDTO> employerMetrics(Long employerID) {
        List<DashboardMetricDTO> metrics = new ArrayList<>();

        long activeApprentices = 0;
        long placementHistory = 0;
        Map<String, Object> vacancySummary = new LinkedHashMap<>();
        vacancySummary.put("open", 0L);
        vacancySummary.put("filled", 0L);

        // NOTE: the Employer entity is not yet linked to User, so an employer's
        // dashboard can only be scoped when an explicit employerID is supplied.
        if (employerID != null) {
            EmployerContract employer = placementClient.getEmployer(employerID);
            if (employer != null) {
                activeApprentices = placementClient.countPlacements(employerID, STATUS_ACTIVE, 0, 1).getTotalElements();
                placementHistory = placementClient.countPlacements(employerID, null, 0, 1).getTotalElements();
                long open = placementClient.countVacancies(employerID, VACANCY_OPEN, 0, 1).getTotalElements()
                        + placementClient.countVacancies(employerID, VACANCY_PARTIALLY_FILLED, 0, 1).getTotalElements();
                long filled = placementClient.countVacancies(employerID, VACANCY_FILLED, 0, 1).getTotalElements();
                vacancySummary.put("open", open);
                vacancySummary.put("filled", filled);
            }
        }

        metrics.add(DashboardMetricDTO.of("activeApprentices", activeApprentices));
        // TODO: wire to ojt-stipend-service (OjtStipendClient) — logs awaiting this employer's confirmation.
        metrics.add(DashboardMetricDTO.of("pendingOjtLogConfirmations", 0));
        metrics.add(DashboardMetricDTO.of("vacancySummary", vacancySummary));
        metrics.add(DashboardMetricDTO.of("placementHistory", placementHistory));
        return metrics;
    }

    // ── Assessor ────────────────────────────────────────────────────────────
    private List<DashboardMetricDTO> assessorMetrics() {
        List<DashboardMetricDTO> metrics = new ArrayList<>();
        // TODO: wire to assessment-service (AssessmentClient) — scheduled tests with a future date.
        metrics.add(DashboardMetricDTO.of("upcomingTradeTests", 0));
        // TODO: wire to assessment-service (AssessmentClient) — results awaiting entry.
        metrics.add(DashboardMetricDTO.of("pendingResultEntries", 0));
        // TODO: wire to assessment-service (AssessmentClient) — assessments completed this month.
        metrics.add(DashboardMetricDTO.of("completedAssessmentsThisMonth", 0));
        return metrics;
    }

    // ── Placement Officer ─────────────────────────────────────────────────────
    private List<DashboardMetricDTO> placementOfficerMetrics() {
        long totalTrainees = trainingClient.countTrainees(null, 0, 1).getTotalElements();
        long activeTrainees = trainingClient.countTrainees(STATUS_ACTIVE, 0, 1).getTotalElements();
        long activePlacements = placementClient.countPlacements(null, STATUS_ACTIVE, 0, 1).getTotalElements();
        // Approximation of the monolith's countDistinctPlacedTrainees(): placement-service
        // exposes no distinct-trainee-count endpoint, and a trainee can hold at most one
        // Active placement at a time (DuplicatePlacementException), so the current Active
        // placement count is used as the placed-trainee proxy.
        long placedTrainees = activePlacements;
        long unmatchedTrainees = Math.max(0, activeTrainees - placedTrainees);
        long openVacancies = placementClient.countVacancies(null, VACANCY_OPEN, 0, 1).getTotalElements()
                + placementClient.countVacancies(null, VACANCY_PARTIALLY_FILLED, 0, 1).getTotalElements();

        List<DashboardMetricDTO> metrics = new ArrayList<>();
        metrics.add(DashboardMetricDTO.of("totalActivePlacements", activePlacements));
        metrics.add(DashboardMetricDTO.of("unmatchedTrainees", unmatchedTrainees));
        metrics.add(DashboardMetricDTO.of("openVacancies", openVacancies));
        metrics.add(DashboardMetricDTO.of("placementRate", percentage(placedTrainees, totalTrainees)));
        return metrics;
    }

    // ── Stipend Admin ──────────────────────────────────────────────────────────
    private List<DashboardMetricDTO> stipendAdminMetrics() {
        long pendingApprovals = ojtStipendClient
                .getStipendDisbursements(null, STIPEND_PENDING, null, null, 0, 1).getTotalElements();
        long withheldCount = ojtStipendClient
                .getStipendDisbursements(null, STIPEND_WITHHELD, null, null, 0, 1).getTotalElements();

        LocalDate now = LocalDate.now();
        BigDecimal totalDisbursedThisMonth = ojtStipendClient
                .getStipendDisbursements(null, STIPEND_DISBURSED, now.getMonthValue(), now.getYear(), 0, 500)
                .totalStipendAmount();

        long totalSummaries = ojtStipendClient.countAttendanceSummaries(null, 0, 1).getTotalElements();
        long eligibleSummaries = ojtStipendClient.countAttendanceSummaries(true, 0, 1).getTotalElements();
        double attendanceComplianceRate = percentage(eligibleSummaries, totalSummaries);

        List<DashboardMetricDTO> metrics = new ArrayList<>();
        metrics.add(DashboardMetricDTO.of("pendingStipendApprovals", pendingApprovals));
        metrics.add(DashboardMetricDTO.of("totalDisbursedThisMonth", totalDisbursedThisMonth));
        metrics.add(DashboardMetricDTO.of("withheldCount", withheldCount));
        metrics.add(DashboardMetricDTO.of("attendanceComplianceRate", attendanceComplianceRate));
        return metrics;
    }

    // ── Admin ────────────────────────────────────────────────────────────────
    private List<DashboardMetricDTO> adminMetrics() {
        long totalTrainees = trainingClient.countTrainees(null, 0, 1).getTotalElements();
        long activePlacements = placementClient.countPlacements(null, STATUS_ACTIVE, 0, 1).getTotalElements();
        // See placementOfficerMetrics() note on this approximation.
        long placedTrainees = activePlacements;

        long openVacancies = placementClient.countVacancies(null, VACANCY_OPEN, 0, 1).getTotalElements()
                + placementClient.countVacancies(null, VACANCY_PARTIALLY_FILLED, 0, 1).getTotalElements();
        long filledVacancies = placementClient.countVacancies(null, VACANCY_FILLED, 0, 1).getTotalElements();
        Map<String, Object> vacancySummary = new LinkedHashMap<>();
        vacancySummary.put("open", openVacancies);
        vacancySummary.put("filled", filledVacancies);

        List<DashboardMetricDTO> metrics = new ArrayList<>();
        metrics.add(DashboardMetricDTO.of("totalActiveTrainees",
                trainingClient.countTrainees(STATUS_ACTIVE, 0, 1).getTotalElements()));
        metrics.add(DashboardMetricDTO.of("totalActiveEmployers",
                placementClient.countEmployers(STATUS_ACTIVE, 0, 1).getTotalElements()));
        metrics.add(DashboardMetricDTO.of("totalActiveBatches",
                trainingClient.countBatches(STATUS_ACTIVE, 0, 1).getTotalElements()));
        metrics.add(DashboardMetricDTO.of("overallPlacementRate", percentage(placedTrainees, totalTrainees)));
        metrics.add(DashboardMetricDTO.of("vacancySummary", vacancySummary));
        // TODO: wire to local NotificationRepository — undelivered / pending notifications.
        metrics.add(DashboardMetricDTO.of("pendingNotifications", 0));
        return metrics;
    }

    // ── Helpers ────────────────────────────────────────────────────────────────
    private Map<String, Object> stipendSummary() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalDisbursed", BigDecimal.ZERO);
        m.put("disbursementCount", 0);
        return m;
    }

    /** Percentage of {@code part} over {@code total}, rounded to 1 decimal (0 when total is 0). */
    private double percentage(long part, long total) {
        if (total == 0) {
            return 0.0;
        }
        return Math.round(part * 1000.0 / total) / 10.0;
    }

    private DashboardResponseDTO copyAsCached(DashboardResponseDTO source) {
        return DashboardResponseDTO.builder()
                .role(source.getRole())
                .generatedAt(source.getGeneratedAt())
                .cached(true)
                .metrics(source.getMetrics())
                .build();
    }

    private static final class CacheEntry {
        private final DashboardResponseDTO response;
        private final long expiresAtMillis;

        private CacheEntry(DashboardResponseDTO response, long expiresAtMillis) {
            this.response = response;
            this.expiresAtMillis = expiresAtMillis;
        }

        private boolean isExpired() {
            return System.currentTimeMillis() >= expiresAtMillis;
        }
    }
}
