package com.cts.platform.service;

/**
 * Persistence façade for in-app notifications, invoked when
 * {@code POST /api/notifications} is handled. Implementations persist
 * asynchronously so the triggering Feign call from another service is not
 * blocked (MIGRATION_PLAN.md §5 — every business service is a client of
 * platform-service for notification dispatch).
 */
public interface NotificationDispatcher {

    /** Notify a user directly by their UserID. */
    void notifyUser(Long userID, String message, String category);

    /** Notify a trainee (resolves the trainee's UserID via training-service first). */
    void notifyTrainee(Long traineeID, String message, String category);
}
