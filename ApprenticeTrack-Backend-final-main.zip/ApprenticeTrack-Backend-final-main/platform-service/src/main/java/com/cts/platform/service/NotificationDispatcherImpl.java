package com.cts.platform.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.platform.client.TrainingClient;
import com.cts.platform.client.dto.TraineeContract;
import com.cts.platform.common.NotificationCategory;
import com.cts.platform.common.NotificationStatus;
import com.cts.platform.entity.Notification;
import com.cts.platform.repository.NotificationRepository;

/**
 * Persists in-app notifications asynchronously. Runs on a separate thread
 * ({@link Async}) so the triggering {@code POST /api/notifications} request from
 * another service returns without waiting for the write.
 */
@Service
public class NotificationDispatcherImpl implements NotificationDispatcher {

    private static final Logger log = LoggerFactory.getLogger(NotificationDispatcherImpl.class);

    private final NotificationRepository notificationRepository;
    private final TrainingClient trainingClient;

    public NotificationDispatcherImpl(NotificationRepository notificationRepository,
                                      TrainingClient trainingClient) {
        this.notificationRepository = notificationRepository;
        this.trainingClient = trainingClient;
    }

    @Override
    @Async("notificationTaskExecutor")
    @Transactional
    public void notifyUser(Long userID, String message, String category) {
        if (userID == null) {
            log.warn("Skipping notification with null userID: {}", message);
            return;
        }
        save(userID, message, category);
    }

    @Override
    @Async("notificationTaskExecutor")
    @Transactional
    public void notifyTrainee(Long traineeID, String message, String category) {
        TraineeContract trainee = trainingClient.getTrainee(traineeID);
        Long userID = trainee != null ? trainee.getUserID() : null;
        if (userID == null) {
            log.warn("Cannot notify trainee {} (no linked user): {}", traineeID, message);
            return;
        }
        save(userID, message, category);
    }

    private void save(Long userID, String message, String category) {
        notificationRepository.save(Notification.builder()
                .userID(userID)
                .message(message)
                .category(NotificationCategory.valueOf(category))
                .status(NotificationStatus.Unread)
                .build());
    }
}
