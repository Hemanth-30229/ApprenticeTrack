package com.cts.platform.service;

import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.platform.common.NotificationCategory;
import com.cts.platform.common.NotificationStatus;
import com.cts.platform.dto.NotificationResponseDTO;

public interface NotificationService {

    Page<NotificationResponseDTO> getForUser(Long userID, NotificationCategory category, NotificationStatus status,
                                             LocalDate fromDate, LocalDate toDate, Pageable pageable);

    long unreadCount(Long userID);

    NotificationResponseDTO markRead(Long notificationID, Long userID);

    NotificationResponseDTO dismiss(Long notificationID, Long userID);

    int markAllRead(Long userID);
}
