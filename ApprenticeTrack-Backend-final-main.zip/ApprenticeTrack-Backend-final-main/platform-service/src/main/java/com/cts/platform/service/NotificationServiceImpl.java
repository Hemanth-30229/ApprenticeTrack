package com.cts.platform.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.platform.common.NotificationCategory;
import com.cts.platform.common.NotificationStatus;
import com.cts.platform.dto.NotificationResponseDTO;
import com.cts.platform.entity.Notification;
import com.cts.platform.exception.InvalidNotificationStatusException;
import com.cts.platform.exception.NotificationAccessDeniedException;
import com.cts.platform.exception.NotificationNotFoundException;
import com.cts.platform.repository.NotificationRepository;

@Service
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationServiceImpl(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public Page<NotificationResponseDTO> getForUser(Long userID, NotificationCategory category, NotificationStatus status,
                                                    LocalDate fromDate, LocalDate toDate, Pageable pageable) {
        LocalDateTime from = fromDate != null ? fromDate.atStartOfDay() : null;
        LocalDateTime to = toDate != null ? toDate.atTime(LocalTime.MAX) : null;
        return notificationRepository
                .findForUserWithFilters(userID, category, status, from, to, pageable)
                .map(this::toResponseDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public long unreadCount(Long userID) {
        return notificationRepository.countByUserIDAndStatus(userID, NotificationStatus.Unread);
    }

    @Override
    @Transactional
    public NotificationResponseDTO markRead(Long notificationID, Long userID) {
        Notification notification = ownedNotification(notificationID, userID);
        if (notification.getStatus() != NotificationStatus.Unread) {
            throw new InvalidNotificationStatusException(
                    "Only Unread notifications can be marked Read. Current status: "
                    + notification.getStatus() + ". NotificationID: " + notificationID);
        }
        notification.setStatus(NotificationStatus.Read);
        return toResponseDTO(notificationRepository.save(notification));
    }

    @Override
    @Transactional
    public NotificationResponseDTO dismiss(Long notificationID, Long userID) {
        Notification notification = ownedNotification(notificationID, userID);
        if (notification.getStatus() == NotificationStatus.Dismissed) {
            throw new InvalidNotificationStatusException(
                    "Notification is already Dismissed. NotificationID: " + notificationID);
        }
        notification.setStatus(NotificationStatus.Dismissed);
        return toResponseDTO(notificationRepository.save(notification));
    }

    @Override
    @Transactional
    public int markAllRead(Long userID) {
        return notificationRepository.markAllReadForUser(userID);
    }

    // ── Helpers ────────────────────────────────────────────────────────────────
    private Notification ownedNotification(Long notificationID, Long userID) {
        Notification notification = notificationRepository.findById(notificationID)
                .orElseThrow(() -> new NotificationNotFoundException(
                        "Notification not found with ID: " + notificationID));
        if (!notification.getUserID().equals(userID)) {
            throw new NotificationAccessDeniedException(
                    "Notification " + notificationID + " does not belong to the authenticated user.");
        }
        return notification;
    }

    private NotificationResponseDTO toResponseDTO(Notification n) {
        return NotificationResponseDTO.builder()
                .notificationID(n.getNotificationID())
                .userID(n.getUserID())
                .message(n.getMessage())
                .category(n.getCategory())
                .status(n.getStatus())
                .createdDate(n.getCreatedDate())
                .build();
    }
}
