package com.cts.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Training-service: trainees, trade courses, training batches, course
 * enrollments, and institutes (MIGRATION_PLAN.md §1). Root dependency for most
 * other business services (placement, assessment, ojt-stipend, platform all
 * call it via Feign); it in turn depends only on auth-service (validate a
 * userID when creating a Trainee) and platform-service (audit + notify).
 */
@SpringBootApplication
@EnableFeignClients
public class TrainingServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(TrainingServiceApplication.class, args);
    }
}
