package com.cts.training.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cts.training.client.dto.UserContract;

/**
 * Feign client to auth-service, the root of trust for users/roles
 * (MIGRATION_PLAN.md §6). Replaces the in-process {@code UserRepository.existsById(...)}
 * check the monolith performed when creating a Trainee. Guarded by {@link AuthClientFallback}.
 */
@FeignClient(name = "auth-service", fallback = AuthClientFallback.class)
public interface AuthClient {

    /** Returns the user, or {@code null} if auth-service reports no such user. */
    @GetMapping("/api/users/{userId}")
    UserContract getUser(@PathVariable("userId") Long userId);
}
