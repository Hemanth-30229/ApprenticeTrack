package com.cts.training.client.dto;

/**
 * Lightweight view of an auth-service {@code User}. Only existence needs
 * checking when creating a Trainee (replaces the monolith's in-process
 * {@code UserRepository.existsById(...)}), but the full summary is carried in
 * case future logic needs the role/status.
 */
public class UserContract {

    private Long userID;
    private String name;
    private String email;
    private String role;
    private String status;

    public UserContract() {}

    public Long getUserID() { return userID; }
    public void setUserID(Long userID) { this.userID = userID; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
