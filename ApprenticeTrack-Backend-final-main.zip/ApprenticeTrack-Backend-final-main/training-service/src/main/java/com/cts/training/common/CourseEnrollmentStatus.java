package com.cts.training.common;

public enum CourseEnrollmentStatus {
    Enrolled, OJTInProgress, AssessmentPending, Completed, Withdrawn
}
