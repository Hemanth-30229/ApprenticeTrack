package com.cts.training.common;

public enum TradeCourseQualificationLevel {
    Level1, Level2, Level3, Level4
}
