package com.cts.training.common;

public enum TradeCourseStatus {
    Active, Discontinued
}
