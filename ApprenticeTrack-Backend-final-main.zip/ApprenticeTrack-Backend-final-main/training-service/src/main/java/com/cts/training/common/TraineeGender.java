package com.cts.training.common;

public enum TraineeGender { Male, Female, Other }
