package com.cts.training.common;

public enum TraineeStatus { Active, Placed, Completed, Dropout }
