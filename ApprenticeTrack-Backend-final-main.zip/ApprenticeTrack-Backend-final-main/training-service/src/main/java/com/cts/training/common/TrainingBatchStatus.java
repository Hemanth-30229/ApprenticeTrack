package com.cts.training.common;

public enum TrainingBatchStatus { Upcoming, Active, Completed }
