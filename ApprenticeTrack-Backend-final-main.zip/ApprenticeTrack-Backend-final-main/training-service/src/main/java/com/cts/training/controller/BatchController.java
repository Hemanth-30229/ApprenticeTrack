package com.cts.training.controller;

import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.dto.BatchCreateRequestDTO;
import com.cts.training.dto.BatchResponseDTO;
import com.cts.training.dto.BatchStatusUpdateRequestDTO;
import com.cts.training.dto.BatchUpdateRequestDTO;
import com.cts.training.common.TrainingBatchStatus;
import com.cts.training.service.BatchService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/batches")
@SecurityRequirement(name = "bearerAuth")
public class BatchController {

    private final BatchService batchService;

    public BatchController(BatchService batchService) {
        this.batchService = batchService;
    }

    @PostMapping
    public ResponseEntity<BatchResponseDTO> createBatch(
            @Valid @RequestBody BatchCreateRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(batchService.createBatch(requestDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<BatchResponseDTO> getBatch(@PathVariable Long id) {
        return ResponseEntity.ok(batchService.getBatchById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<BatchResponseDTO> updateBatch(
            @PathVariable Long id, @Valid @RequestBody BatchUpdateRequestDTO requestDTO) {
        return ResponseEntity.ok(batchService.updateBatch(id, requestDTO));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<BatchResponseDTO> updateStatus(
            @PathVariable Long id, @Valid @RequestBody BatchStatusUpdateRequestDTO requestDTO) {
        return ResponseEntity.ok(batchService.updateStatus(id, requestDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBatch(@PathVariable Long id) {
        batchService.deleteBatch(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<Page<BatchResponseDTO>> getAllBatches(
            @RequestParam(required = false) Long courseID,
            @RequestParam(required = false) TrainingBatchStatus status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "startDate,asc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("desc")
                ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(
                batchService.getAllBatches(courseID, status, fromDate, toDate, pageable));
    }
}
