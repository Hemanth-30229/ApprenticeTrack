package com.cts.training.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.dto.EnrollmentCreateRequestDTO;
import com.cts.training.dto.EnrollmentResponseDTO;
import com.cts.training.dto.EnrollmentStatusUpdateRequestDTO;
import com.cts.training.common.CourseEnrollmentStatus;
import com.cts.training.service.EnrollmentService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/enrollments")
@SecurityRequirement(name = "bearerAuth")
public class EnrollmentController {

    private final EnrollmentService enrollmentService;

    public EnrollmentController(EnrollmentService enrollmentService) {
        this.enrollmentService = enrollmentService;
    }

    @PostMapping
    public ResponseEntity<EnrollmentResponseDTO> createEnrollment(
            @Valid @RequestBody EnrollmentCreateRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(enrollmentService.createEnrollment(requestDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EnrollmentResponseDTO> getEnrollment(@PathVariable Long id) {
        return ResponseEntity.ok(enrollmentService.getEnrollmentById(id));
    }

    @GetMapping
    public ResponseEntity<Page<EnrollmentResponseDTO>> getAllEnrollments(
            @RequestParam(required = false) Long traineeID,
            @RequestParam(required = false) Long courseID,
            @RequestParam(required = false) Long batchID,
            @RequestParam(required = false) CourseEnrollmentStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "enrollmentDate,desc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("asc")
                ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(
                enrollmentService.getAllEnrollments(traineeID, courseID, batchID, status, pageable));
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<EnrollmentResponseDTO> updateStatus(
            @PathVariable Long id, @Valid @RequestBody EnrollmentStatusUpdateRequestDTO requestDTO) {
        return ResponseEntity.ok(enrollmentService.updateStatus(id, requestDTO.getStatus()));
    }

    // ── Cross-service endpoints (MIGRATION_PLAN.md §6) ─────────────────────────

    /** Served to platform-service's {@code TrainingClient} for dashboard aggregation. */
    @GetMapping("/trainee/{traineeId}")
    public ResponseEntity<List<EnrollmentResponseDTO>> getEnrollmentsForTrainee(@PathVariable Long traineeId) {
        return ResponseEntity.ok(enrollmentService.getEnrollmentsForTrainee(traineeId));
    }

    /**
     * Served to placement-service's {@code TrainingClient} — replaces the monolith's
     * in-process {@code CourseEnrollmentRepository.existsByTraineeIDAndStatus(id, OJTInProgress)}.
     */
    @GetMapping("/ojt-in-progress")
    public ResponseEntity<Boolean> isTraineeInOjt(@RequestParam("traineeId") Long traineeId) {
        return ResponseEntity.ok(enrollmentService.isTraineeInOjt(traineeId));
    }

    /**
     * Served to placement-service's {@code TrainingClient} — promotes the trainee's
     * Enrolled enrollments to OJTInProgress when a placement is created.
     */
    @PutMapping("/promote-ojt")
    public ResponseEntity<Void> promoteEnrollmentsToOjt(@RequestParam("traineeId") Long traineeId) {
        enrollmentService.promoteEnrollmentsToOjt(traineeId);
        return ResponseEntity.noContent().build();
    }

    /**
     * Served to assessment-service's {@code TrainingClient} — replaces the monolith's
     * in-process {@code CourseEnrollmentRepository.findByBatchID(...)}.
     */
    @GetMapping("/batch/{batchId}/trainee-ids")
    public ResponseEntity<List<Long>> getEnrolledTraineeIds(@PathVariable Long batchId) {
        return ResponseEntity.ok(enrollmentService.getEnrolledTraineeIds(batchId));
    }

    /**
     * Served to assessment-service's {@code TrainingClient} — replaces the monolith's
     * in-process {@code existsByTraineeIDAndBatchID}.
     */
    @GetMapping("/exists")
    public ResponseEntity<Boolean> isTraineeEnrolledInBatch(@RequestParam("traineeId") Long traineeId,
                                                            @RequestParam("batchId") Long batchId) {
        return ResponseEntity.ok(enrollmentService.isTraineeEnrolledInBatch(traineeId, batchId));
    }

    /**
     * Served to assessment-service's {@code TrainingClient} — marks the trainee's
     * (non-withdrawn) enrollment for the course Completed after they pass a reassessment.
     */
    @PutMapping("/complete")
    public ResponseEntity<Void> completeEnrollment(@RequestParam("traineeId") Long traineeId,
                                                   @RequestParam("courseId") Long courseId) {
        enrollmentService.completeEnrollment(traineeId, courseId);
        return ResponseEntity.noContent().build();
    }
}
