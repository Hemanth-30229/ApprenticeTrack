package com.cts.training.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.dto.TradeCourseCreateRequestDTO;
import com.cts.training.dto.TradeCourseResponseDTO;
import com.cts.training.dto.TradeCourseUpdateRequestDTO;
import com.cts.training.common.TradeCourseQualificationLevel;
import com.cts.training.common.TradeCourseStatus;
import com.cts.training.service.TradeCourseService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

/**
 * Note: the monolith's {@code GET /{courseId}/competency-units} convenience endpoint
 * is not ported here — competency units are owned by assessment-service
 * (MIGRATION_PLAN.md §1), which already exposes an equivalent
 * {@code GET /api/competency-units?courseID=...} query.
 */
@RestController
@RequestMapping("/api/trade-courses")
@SecurityRequirement(name = "bearerAuth")
public class TradeCourseController {

    private final TradeCourseService tradeCourseService;

    public TradeCourseController(TradeCourseService tradeCourseService) {
        this.tradeCourseService = tradeCourseService;
    }

    @PostMapping
    public ResponseEntity<TradeCourseResponseDTO> createCourse(
            @Valid @RequestBody TradeCourseCreateRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(tradeCourseService.createCourse(requestDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<TradeCourseResponseDTO> getCourse(@PathVariable Long id) {
        return ResponseEntity.ok(tradeCourseService.getCourseById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TradeCourseResponseDTO> updateCourse(
            @PathVariable Long id, @Valid @RequestBody TradeCourseUpdateRequestDTO requestDTO) {
        return ResponseEntity.ok(tradeCourseService.updateCourse(id, requestDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCourse(@PathVariable Long id) {
        tradeCourseService.deleteCourse(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<Page<TradeCourseResponseDTO>> getAllCourses(
            @RequestParam(required = false) String sector,
            @RequestParam(required = false) TradeCourseQualificationLevel qualificationLevel,
            @RequestParam(required = false) TradeCourseStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "courseName,asc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("desc")
                ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(
                tradeCourseService.getAllCourses(sector, qualificationLevel, status, pageable));
    }
}
