package com.cts.training.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.dto.TraineeCreateRequestDTO;
import com.cts.training.dto.TraineeResponseDTO;
import com.cts.training.dto.TraineeUpdateRequestDTO;
import com.cts.training.common.TraineeStatus;
import com.cts.training.service.TraineeService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/trainees")
@SecurityRequirement(name = "bearerAuth")
public class TraineeController {

    private final TraineeService traineeService;

    public TraineeController(TraineeService traineeService) {
        this.traineeService = traineeService;
    }

    @PostMapping
    public ResponseEntity<TraineeResponseDTO> createTrainee(
            @Valid @RequestBody TraineeCreateRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(traineeService.createTrainee(requestDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<TraineeResponseDTO> getTrainee(@PathVariable Long id) {
        return ResponseEntity.ok(traineeService.getTraineeById(id));
    }

    /**
     * Cross-service read used by platform-service's {@code TrainingClient} to
     * resolve the authenticated Trainee-role user's profile for the dashboard.
     * Returns 404 when no trainee is linked to the given UserID.
     */
    @GetMapping("/by-user/{userId}")
    public ResponseEntity<TraineeResponseDTO> getTraineeByUserId(@PathVariable Long userId) {
        TraineeResponseDTO trainee = traineeService.getTraineeByUserId(userId);
        return trainee != null ? ResponseEntity.ok(trainee) : ResponseEntity.notFound().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<TraineeResponseDTO> updateTrainee(
            @PathVariable Long id,
            @Valid @RequestBody TraineeUpdateRequestDTO requestDTO) {
        return ResponseEntity.ok(traineeService.updateTrainee(id, requestDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTrainee(@PathVariable Long id) {
        traineeService.deleteTrainee(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<Page<TraineeResponseDTO>> getAllTrainees(
            @RequestParam(required = false) TraineeStatus status,
            @RequestParam(required = false) String name,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "name,asc") String sort) {
        String[] sp = sort.split(",");
        Sort.Direction dir = sp.length > 1 && sp[1].equalsIgnoreCase("desc")
                ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, sp[0]));
        return ResponseEntity.ok(traineeService.getAllTrainees(status, name, pageable));
    }
}
