package com.cts.training.dto;

import java.time.LocalDate;

import com.cts.training.validation.EndDateAfterStartDate;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@EndDateAfterStartDate
public class BatchCreateRequestDTO {

    @NotNull(message = "CourseID is required") private Long courseID;
    @NotBlank(message = "BatchCode is required") private String batchCode;
    @NotNull(message = "Start date is required") private LocalDate startDate;
    @NotNull(message = "End date is required") private LocalDate endDate;
    @NotNull(message = "TrainerID is required") private Long trainerID;
    @NotNull(message = "VenueID is required") private Long venueID;
    @NotNull(message = "Capacity is required")
    @Positive(message = "Capacity must be a positive integer") private Integer capacity;

    public BatchCreateRequestDTO() {}
    public Long getCourseID() { return courseID; }
    public String getBatchCode() { return batchCode; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public Long getTrainerID() { return trainerID; }
    public Long getVenueID() { return venueID; }
    public Integer getCapacity() { return capacity; }
    public void setCourseID(Long v) { this.courseID = v; }
    public void setBatchCode(String v) { this.batchCode = v; }
    public void setStartDate(LocalDate v) { this.startDate = v; }
    public void setEndDate(LocalDate v) { this.endDate = v; }
    public void setTrainerID(Long v) { this.trainerID = v; }
    public void setVenueID(Long v) { this.venueID = v; }
    public void setCapacity(Integer v) { this.capacity = v; }
}
