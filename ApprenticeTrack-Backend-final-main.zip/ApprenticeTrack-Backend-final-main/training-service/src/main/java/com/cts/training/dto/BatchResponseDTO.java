package com.cts.training.dto;

import java.time.LocalDate;

import com.cts.training.common.TrainingBatchStatus;

public class BatchResponseDTO {
    private Long batchID, courseID, trainerID, venueID;
    private String batchCode; private LocalDate startDate, endDate;
    private Integer capacity; private TrainingBatchStatus status; private long enrolledTraineeCount;

    public BatchResponseDTO() {}
    public Long getBatchID() { return batchID; }
    public Long getCourseID() { return courseID; }
    public String getBatchCode() { return batchCode; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public Long getTrainerID() { return trainerID; }
    public Long getVenueID() { return venueID; }
    public Integer getCapacity() { return capacity; }
    public TrainingBatchStatus getStatus() { return status; }
    public long getEnrolledTraineeCount() { return enrolledTraineeCount; }
    public void setBatchID(Long v) { this.batchID = v; }
    public void setCourseID(Long v) { this.courseID = v; }
    public void setBatchCode(String v) { this.batchCode = v; }
    public void setStartDate(LocalDate v) { this.startDate = v; }
    public void setEndDate(LocalDate v) { this.endDate = v; }
    public void setTrainerID(Long v) { this.trainerID = v; }
    public void setVenueID(Long v) { this.venueID = v; }
    public void setCapacity(Integer v) { this.capacity = v; }
    public void setStatus(TrainingBatchStatus v) { this.status = v; }
    public void setEnrolledTraineeCount(long v) { this.enrolledTraineeCount = v; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long batchID, courseID, trainerID, venueID; private String batchCode;
        private LocalDate startDate, endDate; private Integer capacity;
        private TrainingBatchStatus status; private long enrolledTraineeCount;
        public Builder batchID(Long v) { this.batchID = v; return this; }
        public Builder courseID(Long v) { this.courseID = v; return this; }
        public Builder batchCode(String v) { this.batchCode = v; return this; }
        public Builder startDate(LocalDate v) { this.startDate = v; return this; }
        public Builder endDate(LocalDate v) { this.endDate = v; return this; }
        public Builder trainerID(Long v) { this.trainerID = v; return this; }
        public Builder venueID(Long v) { this.venueID = v; return this; }
        public Builder capacity(Integer v) { this.capacity = v; return this; }
        public Builder status(TrainingBatchStatus v) { this.status = v; return this; }
        public Builder enrolledTraineeCount(long v) { this.enrolledTraineeCount = v; return this; }
        public BatchResponseDTO build() {
            BatchResponseDTO d = new BatchResponseDTO();
            d.batchID=batchID; d.courseID=courseID; d.batchCode=batchCode;
            d.startDate=startDate; d.endDate=endDate; d.trainerID=trainerID;
            d.venueID=venueID; d.capacity=capacity; d.status=status;
            d.enrolledTraineeCount=enrolledTraineeCount; return d;
        }
    }
}
