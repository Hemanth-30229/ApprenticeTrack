package com.cts.training.dto;

import com.cts.training.common.TrainingBatchStatus;

import jakarta.validation.constraints.NotNull;

public class BatchStatusUpdateRequestDTO {
    @NotNull(message = "Status is required") private TrainingBatchStatus status;
    public BatchStatusUpdateRequestDTO() {}
    public TrainingBatchStatus getStatus() { return status; }
    public void setStatus(TrainingBatchStatus status) { this.status = status; }
}
