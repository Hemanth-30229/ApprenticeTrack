package com.cts.training.dto;

import java.time.LocalDate;

import com.cts.training.validation.EndDateAfterStartDate;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@EndDateAfterStartDate
public class BatchUpdateRequestDTO {

    @NotNull(message = "TrainerID is required") private Long trainerID;
    @NotNull(message = "VenueID is required") private Long venueID;
    @NotNull(message = "Capacity is required")
    @Positive(message = "Capacity must be a positive integer") private Integer capacity;
    @NotNull(message = "Start date is required") private LocalDate startDate;
    @NotNull(message = "End date is required") private LocalDate endDate;

    public BatchUpdateRequestDTO() {}
    public Long getTrainerID() { return trainerID; }
    public Long getVenueID() { return venueID; }
    public Integer getCapacity() { return capacity; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public void setTrainerID(Long v) { this.trainerID = v; }
    public void setVenueID(Long v) { this.venueID = v; }
    public void setCapacity(Integer v) { this.capacity = v; }
    public void setStartDate(LocalDate v) { this.startDate = v; }
    public void setEndDate(LocalDate v) { this.endDate = v; }
}
