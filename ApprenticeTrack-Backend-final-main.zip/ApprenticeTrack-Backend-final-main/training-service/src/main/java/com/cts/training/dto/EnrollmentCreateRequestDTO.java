package com.cts.training.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.NotNull;

public class EnrollmentCreateRequestDTO {

    @NotNull(message = "TraineeID is required")
    private Long traineeID;

    @NotNull(message = "CourseID is required")
    private Long courseID;

    @NotNull(message = "BatchID is required")
    private Long batchID;

    /** Optional — defaults to the current date when omitted. */
    private LocalDate enrollmentDate;

    public EnrollmentCreateRequestDTO() {}

    public Long getTraineeID() { return traineeID; }
    public Long getCourseID() { return courseID; }
    public Long getBatchID() { return batchID; }
    public LocalDate getEnrollmentDate() { return enrollmentDate; }

    public void setTraineeID(Long traineeID) { this.traineeID = traineeID; }
    public void setCourseID(Long courseID) { this.courseID = courseID; }
    public void setBatchID(Long batchID) { this.batchID = batchID; }
    public void setEnrollmentDate(LocalDate enrollmentDate) { this.enrollmentDate = enrollmentDate; }
}
