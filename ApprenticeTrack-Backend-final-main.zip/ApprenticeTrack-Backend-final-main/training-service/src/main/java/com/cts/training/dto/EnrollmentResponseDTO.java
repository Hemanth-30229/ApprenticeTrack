package com.cts.training.dto;

import java.time.LocalDate;

import com.cts.training.common.CourseEnrollmentStatus;

public class EnrollmentResponseDTO {

    private Long enrollmentID, traineeID, courseID, batchID;
    private String traineeName, courseName;
    private LocalDate enrollmentDate, expectedCompletionDate, ojtStartDate;
    private CourseEnrollmentStatus status;

    public EnrollmentResponseDTO() {}

    public Long getEnrollmentID() { return enrollmentID; }
    public Long getTraineeID() { return traineeID; }
    public Long getCourseID() { return courseID; }
    public Long getBatchID() { return batchID; }
    public String getTraineeName() { return traineeName; }
    public String getCourseName() { return courseName; }
    public LocalDate getEnrollmentDate() { return enrollmentDate; }
    public LocalDate getExpectedCompletionDate() { return expectedCompletionDate; }
    public LocalDate getOjtStartDate() { return ojtStartDate; }
    public CourseEnrollmentStatus getStatus() { return status; }

    public void setEnrollmentID(Long v) { this.enrollmentID = v; }
    public void setTraineeID(Long v) { this.traineeID = v; }
    public void setCourseID(Long v) { this.courseID = v; }
    public void setBatchID(Long v) { this.batchID = v; }
    public void setTraineeName(String v) { this.traineeName = v; }
    public void setCourseName(String v) { this.courseName = v; }
    public void setEnrollmentDate(LocalDate v) { this.enrollmentDate = v; }
    public void setExpectedCompletionDate(LocalDate v) { this.expectedCompletionDate = v; }
    public void setOjtStartDate(LocalDate v) { this.ojtStartDate = v; }
    public void setStatus(CourseEnrollmentStatus v) { this.status = v; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long enrollmentID, traineeID, courseID, batchID;
        private String traineeName, courseName;
        private LocalDate enrollmentDate, expectedCompletionDate, ojtStartDate;
        private CourseEnrollmentStatus status;

        public Builder enrollmentID(Long v) { this.enrollmentID = v; return this; }
        public Builder traineeID(Long v) { this.traineeID = v; return this; }
        public Builder courseID(Long v) { this.courseID = v; return this; }
        public Builder batchID(Long v) { this.batchID = v; return this; }
        public Builder traineeName(String v) { this.traineeName = v; return this; }
        public Builder courseName(String v) { this.courseName = v; return this; }
        public Builder enrollmentDate(LocalDate v) { this.enrollmentDate = v; return this; }
        public Builder expectedCompletionDate(LocalDate v) { this.expectedCompletionDate = v; return this; }
        public Builder ojtStartDate(LocalDate v) { this.ojtStartDate = v; return this; }
        public Builder status(CourseEnrollmentStatus v) { this.status = v; return this; }

        public EnrollmentResponseDTO build() {
            EnrollmentResponseDTO d = new EnrollmentResponseDTO();
            d.enrollmentID = enrollmentID; d.traineeID = traineeID; d.courseID = courseID;
            d.batchID = batchID; d.traineeName = traineeName; d.courseName = courseName;
            d.enrollmentDate = enrollmentDate; d.expectedCompletionDate = expectedCompletionDate;
            d.ojtStartDate = ojtStartDate; d.status = status;
            return d;
        }
    }
}
