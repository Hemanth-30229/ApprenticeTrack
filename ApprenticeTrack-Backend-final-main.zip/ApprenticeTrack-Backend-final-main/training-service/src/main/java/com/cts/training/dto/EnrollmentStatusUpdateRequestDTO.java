package com.cts.training.dto;

import com.cts.training.common.CourseEnrollmentStatus;

import jakarta.validation.constraints.NotNull;

public class EnrollmentStatusUpdateRequestDTO {

    @NotNull(message = "Status is required")
    private CourseEnrollmentStatus status;

    public EnrollmentStatusUpdateRequestDTO() {}

    public CourseEnrollmentStatus getStatus() { return status; }
    public void setStatus(CourseEnrollmentStatus status) { this.status = status; }
}
