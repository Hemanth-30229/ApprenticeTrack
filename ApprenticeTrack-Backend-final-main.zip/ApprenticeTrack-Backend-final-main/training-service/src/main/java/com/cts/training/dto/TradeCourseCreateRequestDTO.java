package com.cts.training.dto;

import com.cts.training.common.TradeCourseQualificationLevel;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

public class TradeCourseCreateRequestDTO {
    @NotBlank(message = "Course name is required") private String courseName;
    @NotBlank(message = "Trade code is required") private String tradeCode;
    @NotBlank(message = "Sector is required") private String sector;
    @NotNull(message = "Duration weeks is required")
    @PositiveOrZero(message = "Duration weeks must be zero or positive") private Integer durationWeeks;
    @NotNull(message = "Classroom weeks is required")
    @PositiveOrZero(message = "Classroom weeks must be zero or positive") private Integer classroomWeeks;
    @NotNull(message = "OJT weeks is required")
    @PositiveOrZero(message = "OJT weeks must be zero or positive") private Integer ojtWeeks;
    @NotNull(message = "Qualification level is required") private TradeCourseQualificationLevel qualificationLevel;
    private String videoLink;

    public TradeCourseCreateRequestDTO() {}
    public String getVideoLink() { return videoLink; }
    public void setVideoLink(String v) { this.videoLink = v; }
    public String getCourseName() { return courseName; }
    public String getTradeCode() { return tradeCode; }
    public String getSector() { return sector; }
    public Integer getDurationWeeks() { return durationWeeks; }
    public Integer getClassroomWeeks() { return classroomWeeks; }
    public Integer getOjtWeeks() { return ojtWeeks; }
    public TradeCourseQualificationLevel getQualificationLevel() { return qualificationLevel; }
    public void setCourseName(String v) { this.courseName = v; }
    public void setTradeCode(String v) { this.tradeCode = v; }
    public void setSector(String v) { this.sector = v; }
    public void setDurationWeeks(Integer v) { this.durationWeeks = v; }
    public void setClassroomWeeks(Integer v) { this.classroomWeeks = v; }
    public void setOjtWeeks(Integer v) { this.ojtWeeks = v; }
    public void setQualificationLevel(TradeCourseQualificationLevel v) { this.qualificationLevel = v; }
}
