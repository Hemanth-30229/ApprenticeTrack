package com.cts.training.dto;

import com.cts.training.common.TradeCourseQualificationLevel;
import com.cts.training.common.TradeCourseStatus;

public class TradeCourseResponseDTO {
    private Long courseID;
    private String courseName;
    private String tradeCode;
    private String sector;
    private Integer durationWeeks;
    private Integer classroomWeeks;
    private Integer ojtWeeks;
    private TradeCourseQualificationLevel qualificationLevel;
    private TradeCourseStatus status;
    private String videoLink;

    public TradeCourseResponseDTO() {}
    public String getVideoLink() { return videoLink; }
    public void setVideoLink(String v) { this.videoLink = v; }
    public Long getCourseID() { return courseID; }
    public String getCourseName() { return courseName; }
    public String getTradeCode() { return tradeCode; }
    public String getSector() { return sector; }
    public Integer getDurationWeeks() { return durationWeeks; }
    public Integer getClassroomWeeks() { return classroomWeeks; }
    public Integer getOjtWeeks() { return ojtWeeks; }
    public TradeCourseQualificationLevel getQualificationLevel() { return qualificationLevel; }
    public TradeCourseStatus getStatus() { return status; }
    public void setCourseID(Long v) { this.courseID = v; }
    public void setCourseName(String v) { this.courseName = v; }
    public void setTradeCode(String v) { this.tradeCode = v; }
    public void setSector(String v) { this.sector = v; }
    public void setDurationWeeks(Integer v) { this.durationWeeks = v; }
    public void setClassroomWeeks(Integer v) { this.classroomWeeks = v; }
    public void setOjtWeeks(Integer v) { this.ojtWeeks = v; }
    public void setQualificationLevel(TradeCourseQualificationLevel v) { this.qualificationLevel = v; }
    public void setStatus(TradeCourseStatus v) { this.status = v; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long courseID;
        private String courseName;
        private String tradeCode;
        private String sector;
        private Integer durationWeeks;
        private Integer classroomWeeks;
        private Integer ojtWeeks;
        private TradeCourseQualificationLevel qualificationLevel;
        private TradeCourseStatus status;
        private String videoLink;
        public Builder videoLink(String v) { this.videoLink = v; return this; }
        public Builder courseID(Long v) { this.courseID = v; return this; }
        public Builder courseName(String v) { this.courseName = v; return this; }
        public Builder tradeCode(String v) { this.tradeCode = v; return this; }
        public Builder sector(String v) { this.sector = v; return this; }
        public Builder durationWeeks(Integer v) { this.durationWeeks = v; return this; }
        public Builder classroomWeeks(Integer v) { this.classroomWeeks = v; return this; }
        public Builder ojtWeeks(Integer v) { this.ojtWeeks = v; return this; }
        public Builder qualificationLevel(TradeCourseQualificationLevel v) { this.qualificationLevel = v; return this; }
        public Builder status(TradeCourseStatus v) { this.status = v; return this; }
        public TradeCourseResponseDTO build() {
            TradeCourseResponseDTO d = new TradeCourseResponseDTO();
            d.courseID = courseID; d.courseName = courseName; d.tradeCode = tradeCode;
            d.sector = sector; d.durationWeeks = durationWeeks; d.classroomWeeks = classroomWeeks;
            d.ojtWeeks = ojtWeeks; d.qualificationLevel = qualificationLevel; d.status = status;
            d.videoLink = videoLink;
            return d;
        }
    }
}
