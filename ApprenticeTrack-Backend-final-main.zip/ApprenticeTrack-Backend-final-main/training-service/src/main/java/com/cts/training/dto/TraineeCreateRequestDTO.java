package com.cts.training.dto;

import java.time.LocalDate;

import com.cts.training.common.TraineeGender;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;

public class TraineeCreateRequestDTO {

    @NotNull(message = "UserID is required")
    private Long userID;

    @NotBlank(message = "Name is required")
    private String name;

    @NotNull(message = "Date of birth is required")
    @Past(message = "Date of birth must be a past date")
    private LocalDate dateOfBirth;

    @NotNull(message = "Gender is required")
    private TraineeGender gender;

    @NotBlank(message = "Education level is required")
    private String educationLevel;

    @NotBlank(message = "Address is required")
    private String address;

    @NotBlank(message = "Phone is required")
    @Pattern(regexp = "^[6-9]\\d{9}$", message = "Phone must be a valid 10-digit Indian mobile number")
    private String phone;

    @NotNull(message = "Emergency contact is required")
    @Valid
    private EmergencyContactDTO emergencyContact;

    public TraineeCreateRequestDTO() {}

    public Long getUserID() { return userID; }
    public String getName() { return name; }
    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public TraineeGender getGender() { return gender; }
    public String getEducationLevel() { return educationLevel; }
    public String getAddress() { return address; }
    public String getPhone() { return phone; }
    public EmergencyContactDTO getEmergencyContact() { return emergencyContact; }

    public void setUserID(Long v) { this.userID = v; }
    public void setName(String v) { this.name = v; }
    public void setDateOfBirth(LocalDate v) { this.dateOfBirth = v; }
    public void setGender(TraineeGender v) { this.gender = v; }
    public void setEducationLevel(String v) { this.educationLevel = v; }
    public void setAddress(String v) { this.address = v; }
    public void setPhone(String v) { this.phone = v; }
    public void setEmergencyContact(EmergencyContactDTO v) { this.emergencyContact = v; }

    public static class EmergencyContactDTO {

        @NotBlank(message = "Emergency contact name is required")
        private String name;

        @NotBlank(message = "Emergency contact phone is required")
        @Pattern(regexp = "^[6-9]\\d{9}$", message = "Emergency contact phone must be a valid 10-digit number")
        private String phone;

        public EmergencyContactDTO() {}
        public EmergencyContactDTO(String name, String phone) { this.name = name; this.phone = phone; }

        public String getName() { return name; }
        public String getPhone() { return phone; }
        public void setName(String name) { this.name = name; }
        public void setPhone(String phone) { this.phone = phone; }
    }
}
