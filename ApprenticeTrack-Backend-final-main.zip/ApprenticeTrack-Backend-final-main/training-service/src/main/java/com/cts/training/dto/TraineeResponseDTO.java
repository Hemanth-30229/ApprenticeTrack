package com.cts.training.dto;

import java.time.LocalDate;

import com.cts.training.common.TraineeGender;
import com.cts.training.common.TraineeStatus;

public class TraineeResponseDTO {

    private Long traineeID, userID;
    private String name, educationLevel, address, phone;
    private LocalDate dateOfBirth;
    private TraineeGender gender;
    private EmergencyContactDTO emergencyContact;
    private TraineeStatus status;

    public TraineeResponseDTO() {}

    public Long getTraineeID() { return traineeID; }
    public Long getUserID() { return userID; }
    public String getName() { return name; }
    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public TraineeGender getGender() { return gender; }
    public String getEducationLevel() { return educationLevel; }
    public String getAddress() { return address; }
    public String getPhone() { return phone; }
    public EmergencyContactDTO getEmergencyContact() { return emergencyContact; }
    public TraineeStatus getStatus() { return status; }

    public void setTraineeID(Long v) { this.traineeID = v; }
    public void setUserID(Long v) { this.userID = v; }
    public void setName(String v) { this.name = v; }
    public void setDateOfBirth(LocalDate v) { this.dateOfBirth = v; }
    public void setGender(TraineeGender v) { this.gender = v; }
    public void setEducationLevel(String v) { this.educationLevel = v; }
    public void setAddress(String v) { this.address = v; }
    public void setPhone(String v) { this.phone = v; }
    public void setEmergencyContact(EmergencyContactDTO v) { this.emergencyContact = v; }
    public void setStatus(TraineeStatus v) { this.status = v; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long traineeID, userID;
        private String name, educationLevel, address, phone;
        private LocalDate dateOfBirth; private TraineeGender gender;
        private EmergencyContactDTO emergencyContact; private TraineeStatus status;

        public Builder traineeID(Long v) { this.traineeID = v; return this; }
        public Builder userID(Long v) { this.userID = v; return this; }
        public Builder name(String v) { this.name = v; return this; }
        public Builder dateOfBirth(LocalDate v) { this.dateOfBirth = v; return this; }
        public Builder gender(TraineeGender v) { this.gender = v; return this; }
        public Builder educationLevel(String v) { this.educationLevel = v; return this; }
        public Builder address(String v) { this.address = v; return this; }
        public Builder phone(String v) { this.phone = v; return this; }
        public Builder emergencyContact(EmergencyContactDTO v) { this.emergencyContact = v; return this; }
        public Builder status(TraineeStatus v) { this.status = v; return this; }

        public TraineeResponseDTO build() {
            TraineeResponseDTO d = new TraineeResponseDTO();
            d.traineeID = traineeID; d.userID = userID; d.name = name;
            d.dateOfBirth = dateOfBirth; d.gender = gender; d.educationLevel = educationLevel;
            d.address = address; d.phone = phone; d.emergencyContact = emergencyContact;
            d.status = status; return d;
        }
    }

    public static class EmergencyContactDTO {
        private String name, phone;
        public EmergencyContactDTO() {}
        public String getName() { return name; }
        public String getPhone() { return phone; }
        public void setName(String v) { this.name = v; }
        public void setPhone(String v) { this.phone = v; }

        public static Builder builder() { return new Builder(); }
        public static class Builder {
            private String name, phone;
            public Builder name(String v) { this.name = v; return this; }
            public Builder phone(String v) { this.phone = v; return this; }
            public EmergencyContactDTO build() {
                EmergencyContactDTO d = new EmergencyContactDTO();
                d.name = name; d.phone = phone; return d;
            }
        }
    }
}
