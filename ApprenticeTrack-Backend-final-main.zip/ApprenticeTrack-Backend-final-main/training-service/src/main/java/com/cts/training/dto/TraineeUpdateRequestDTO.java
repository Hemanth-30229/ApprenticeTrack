package com.cts.training.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class TraineeUpdateRequestDTO {

    @NotBlank(message = "Name is required")
    private String name;

    @NotBlank(message = "Address is required")
    private String address;

    @NotBlank(message = "Phone is required")
    @Pattern(regexp = "^[6-9]\\d{9}$", message = "Phone must be a valid 10-digit Indian mobile number")
    private String phone;

    @NotBlank(message = "Education level is required")
    private String educationLevel;

    @NotNull(message = "Emergency contact is required")
    @Valid
    private TraineeCreateRequestDTO.EmergencyContactDTO emergencyContact;

    public TraineeUpdateRequestDTO() {}

    public String getName() { return name; }
    public String getAddress() { return address; }
    public String getPhone() { return phone; }
    public String getEducationLevel() { return educationLevel; }
    public TraineeCreateRequestDTO.EmergencyContactDTO getEmergencyContact() { return emergencyContact; }

    public void setName(String v) { this.name = v; }
    public void setAddress(String v) { this.address = v; }
    public void setPhone(String v) { this.phone = v; }
    public void setEducationLevel(String v) { this.educationLevel = v; }
    public void setEmergencyContact(TraineeCreateRequestDTO.EmergencyContactDTO v) { this.emergencyContact = v; }
}
