package com.cts.training.entity;

import java.time.LocalDate;

import com.cts.training.common.CourseEnrollmentStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "course_enrollments")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CourseEnrollment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long enrollmentID;

    @Column(nullable = false)
    private Long traineeID;

    @Column(nullable = false)
    private Long courseID;

    @Column(nullable = false)
    private Long batchID;

    private LocalDate enrollmentDate;
    private LocalDate expectedCompletionDate;
    private LocalDate ojtStartDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private CourseEnrollmentStatus status = CourseEnrollmentStatus.Enrolled;
}
