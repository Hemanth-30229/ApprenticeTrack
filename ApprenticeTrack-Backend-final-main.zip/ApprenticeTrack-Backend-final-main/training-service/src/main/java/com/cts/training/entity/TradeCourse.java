package com.cts.training.entity;

import com.cts.training.common.TradeCourseQualificationLevel;
import com.cts.training.common.TradeCourseStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "trade_courses")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TradeCourse {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long courseID;

    @Column(nullable = false)
    private String courseName;

    @Column(nullable = false)
    private String tradeCode;

    @Column(nullable = false)
    private String sector;

    private Integer durationWeeks;
    private Integer classroomWeeks;
    private Integer ojtWeeks;

    /** Optional learning-content video URL shown to enrolled trainees. */
    @Column(length = 1000)
    private String videoLink;

    @Enumerated(EnumType.STRING)
    private TradeCourseQualificationLevel qualificationLevel;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private TradeCourseStatus status = TradeCourseStatus.Active;
}
