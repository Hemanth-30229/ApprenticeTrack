package com.cts.training.entity;

import java.time.LocalDate;

import com.cts.training.common.TraineeGender;
import com.cts.training.common.TraineeStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name = "trainees")
public class Trainee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long traineeID;

    @NotNull(message = "UserID is required")
    @Column(nullable = false, unique = true)
    private Long userID;

    @NotBlank(message = "Name is required")
    @Column(nullable = false)
    private String name;

    @NotNull(message = "Date of birth is required")
    @Past(message = "Date of birth must be a past date")
    @Column(nullable = false)
    private LocalDate dateOfBirth;

    @NotNull(message = "Gender is required")
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TraineeGender gender;

    @NotBlank(message = "Education level is required")
    @Column(nullable = false)
    private String educationLevel;

    @NotBlank(message = "Address is required")
    @Column(nullable = false, length = 500)
    private String address;

    @NotBlank(message = "Phone is required")
    @Pattern(regexp = "^[6-9]\\d{9}$", message = "Phone must be a valid 10-digit Indian mobile number")
    @Column(nullable = false)
    private String phone;

    @Embedded
    @NotNull(message = "Emergency contact is required")
    private EmergencyContact emergencyContact;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TraineeStatus status = TraineeStatus.Active;

    @Embeddable
    public static class EmergencyContact {

        @Column(name = "emergency_contact_name")
        private String name;

        @Column(name = "emergency_contact_phone")
        private String phone;

        public EmergencyContact() {}
        public EmergencyContact(String name, String phone) { this.name = name; this.phone = phone; }

        public String getName() { return name; }
        public String getPhone() { return phone; }
        public void setName(String name) { this.name = name; }
        public void setPhone(String phone) { this.phone = phone; }
    }

    public Trainee() {}

    // ── Getters ───────────────────────────────────────────────────────────────
    public Long getTraineeID() { return traineeID; }
    public Long getUserID() { return userID; }
    public String getName() { return name; }
    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public TraineeGender getGender() { return gender; }
    public String getEducationLevel() { return educationLevel; }
    public String getAddress() { return address; }
    public String getPhone() { return phone; }
    public EmergencyContact getEmergencyContact() { return emergencyContact; }
    public TraineeStatus getStatus() { return status; }

    // ── Setters ───────────────────────────────────────────────────────────────
    public void setTraineeID(Long traineeID) { this.traineeID = traineeID; }
    public void setUserID(Long userID) { this.userID = userID; }
    public void setName(String name) { this.name = name; }
    public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }
    public void setGender(TraineeGender gender) { this.gender = gender; }
    public void setEducationLevel(String educationLevel) { this.educationLevel = educationLevel; }
    public void setAddress(String address) { this.address = address; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setEmergencyContact(EmergencyContact emergencyContact) { this.emergencyContact = emergencyContact; }
    public void setStatus(TraineeStatus status) { this.status = status; }

    // ── Builder ───────────────────────────────────────────────────────────────
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long traineeID, userID;
        private String name, educationLevel, address, phone;
        private LocalDate dateOfBirth;
        private TraineeGender gender;
        private EmergencyContact emergencyContact;
        private TraineeStatus status = TraineeStatus.Active;

        public Builder traineeID(Long v) { this.traineeID = v; return this; }
        public Builder userID(Long v) { this.userID = v; return this; }
        public Builder name(String v) { this.name = v; return this; }
        public Builder dateOfBirth(LocalDate v) { this.dateOfBirth = v; return this; }
        public Builder gender(TraineeGender v) { this.gender = v; return this; }
        public Builder educationLevel(String v) { this.educationLevel = v; return this; }
        public Builder address(String v) { this.address = v; return this; }
        public Builder phone(String v) { this.phone = v; return this; }
        public Builder emergencyContact(EmergencyContact v) { this.emergencyContact = v; return this; }
        public Builder status(TraineeStatus v) { this.status = v; return this; }

        public Trainee build() {
            Trainee t = new Trainee();
            t.traineeID = this.traineeID; t.userID = this.userID; t.name = this.name;
            t.dateOfBirth = this.dateOfBirth; t.gender = this.gender;
            t.educationLevel = this.educationLevel; t.address = this.address;
            t.phone = this.phone; t.emergencyContact = this.emergencyContact;
            t.status = this.status;
            return t;
        }
    }
}
