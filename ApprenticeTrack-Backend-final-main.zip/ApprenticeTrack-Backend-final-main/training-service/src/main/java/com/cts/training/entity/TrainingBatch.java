package com.cts.training.entity;

import java.time.LocalDate;

import com.cts.training.common.TrainingBatchStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity
@Table(name = "training_batches",
    uniqueConstraints = @UniqueConstraint(name = "uq_batchcode_course",
        columnNames = {"batch_code", "course_id"}))
public class TrainingBatch {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long batchID;

    @NotNull(message = "CourseID is required")
    @Column(name = "course_id", nullable = false)
    private Long courseID;

    @NotBlank(message = "BatchCode is required")
    @Column(name = "batch_code", nullable = false)
    private String batchCode;

    @NotNull(message = "Start date is required")
    @Column(nullable = false)
    private LocalDate startDate;

    @NotNull(message = "End date is required")
    @Column(nullable = false)
    private LocalDate endDate;

    @NotNull(message = "TrainerID is required")
    @Column(nullable = false)
    private Long trainerID;

    @NotNull(message = "VenueID is required")
    @Column(nullable = false)
    private Long venueID;

    @NotNull(message = "Capacity is required")
    @Positive(message = "Capacity must be a positive integer")
    @Column(nullable = false)
    private Integer capacity;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TrainingBatchStatus status = TrainingBatchStatus.Upcoming;

    public TrainingBatch() {}

    // ── Getters ───────────────────────────────────────────────────────────────
    public Long getBatchID() { return batchID; }
    public Long getCourseID() { return courseID; }
    public String getBatchCode() { return batchCode; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public Long getTrainerID() { return trainerID; }
    public Long getVenueID() { return venueID; }
    public Integer getCapacity() { return capacity; }
    public TrainingBatchStatus getStatus() { return status; }

    // ── Setters ───────────────────────────────────────────────────────────────
    public void setBatchID(Long batchID) { this.batchID = batchID; }
    public void setCourseID(Long courseID) { this.courseID = courseID; }
    public void setBatchCode(String batchCode) { this.batchCode = batchCode; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    public void setTrainerID(Long trainerID) { this.trainerID = trainerID; }
    public void setVenueID(Long venueID) { this.venueID = venueID; }
    public void setCapacity(Integer capacity) { this.capacity = capacity; }
    public void setStatus(TrainingBatchStatus status) { this.status = status; }

    // ── Builder ───────────────────────────────────────────────────────────────
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long batchID, courseID, trainerID, venueID;
        private String batchCode;
        private LocalDate startDate, endDate;
        private Integer capacity;
        private TrainingBatchStatus status = TrainingBatchStatus.Upcoming;

        public Builder batchID(Long v) { this.batchID = v; return this; }
        public Builder courseID(Long v) { this.courseID = v; return this; }
        public Builder batchCode(String v) { this.batchCode = v; return this; }
        public Builder startDate(LocalDate v) { this.startDate = v; return this; }
        public Builder endDate(LocalDate v) { this.endDate = v; return this; }
        public Builder trainerID(Long v) { this.trainerID = v; return this; }
        public Builder venueID(Long v) { this.venueID = v; return this; }
        public Builder capacity(Integer v) { this.capacity = v; return this; }
        public Builder status(TrainingBatchStatus v) { this.status = v; return this; }

        public TrainingBatch build() {
            TrainingBatch b = new TrainingBatch();
            b.batchID = this.batchID; b.courseID = this.courseID;
            b.batchCode = this.batchCode; b.startDate = this.startDate;
            b.endDate = this.endDate; b.trainerID = this.trainerID;
            b.venueID = this.venueID; b.capacity = this.capacity;
            b.status = this.status;
            return b;
        }
    }
}
