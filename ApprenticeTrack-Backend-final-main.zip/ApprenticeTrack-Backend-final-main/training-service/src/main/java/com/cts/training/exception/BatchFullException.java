package com.cts.training.exception;

public class BatchFullException extends RuntimeException {
    public BatchFullException(String message) {
        super(message);
    }
}
