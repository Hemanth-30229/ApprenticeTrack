package com.cts.training.exception;

public class BatchHasEnrolledTraineesException extends RuntimeException {
    public BatchHasEnrolledTraineesException(String message) {
        super(message);
    }
}
