package com.cts.training.exception;

public class CourseHasEnrollmentsException extends RuntimeException {
    public CourseHasEnrollmentsException(String message) {
        super(message);
    }
}
