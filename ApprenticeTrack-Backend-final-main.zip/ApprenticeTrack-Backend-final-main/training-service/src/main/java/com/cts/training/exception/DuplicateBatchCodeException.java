package com.cts.training.exception;

public class DuplicateBatchCodeException extends RuntimeException {
    public DuplicateBatchCodeException(String message) {
        super(message);
    }
}
