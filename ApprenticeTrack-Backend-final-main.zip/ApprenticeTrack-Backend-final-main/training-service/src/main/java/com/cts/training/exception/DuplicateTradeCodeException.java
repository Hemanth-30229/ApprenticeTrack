package com.cts.training.exception;

public class DuplicateTradeCodeException extends RuntimeException {
    public DuplicateTradeCodeException(String message) {
        super(message);
    }
}
