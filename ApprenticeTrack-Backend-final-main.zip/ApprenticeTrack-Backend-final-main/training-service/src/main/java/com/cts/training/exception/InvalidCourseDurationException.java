package com.cts.training.exception;

public class InvalidCourseDurationException extends RuntimeException {
    public InvalidCourseDurationException(String message) {
        super(message);
    }
}
