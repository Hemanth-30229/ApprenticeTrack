package com.cts.training.exception;

/**
 * Thrown when an enrollment status change violates the allowed lifecycle.
 * Mapped to 400 Bad Request (per the Enrollment API acceptance criteria).
 */
public class InvalidEnrollmentStatusTransitionException extends RuntimeException {
    public InvalidEnrollmentStatusTransitionException(String message) {
        super(message);
    }
}
