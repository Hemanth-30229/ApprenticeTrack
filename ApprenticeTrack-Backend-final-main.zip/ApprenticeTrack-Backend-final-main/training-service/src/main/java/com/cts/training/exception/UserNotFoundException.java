package com.cts.training.exception;

/**
 * Thrown when auth-service reports no such user for a UserID referenced while
 * creating a Trainee profile (replaces the monolith's in-process
 * {@code UserRepository.existsById} check).
 */
public class UserNotFoundException extends RuntimeException {
    public UserNotFoundException(String message) {
        super(message);
    }
}
