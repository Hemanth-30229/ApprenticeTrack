package com.cts.training.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.training.common.CourseEnrollmentStatus;
import com.cts.training.entity.CourseEnrollment;

@Repository
public interface CourseEnrollmentRepository extends JpaRepository<CourseEnrollment, Long> {

    long countByBatchID(Long batchID);

    boolean existsByBatchID(Long batchID);

    List<CourseEnrollment> findByTraineeID(Long traineeID);

    List<CourseEnrollment> findByTraineeIDAndCourseID(Long traineeID, Long courseID);

    List<CourseEnrollment> findByBatchID(Long batchID);

    boolean existsByTraineeIDAndCourseIDAndBatchID(Long traineeID, Long courseID, Long batchID);

    boolean existsByTraineeIDAndStatus(Long traineeID, CourseEnrollmentStatus status);

    boolean existsByCourseIDAndStatusIn(Long courseID, java.util.Collection<CourseEnrollmentStatus> statuses);

    boolean existsByTraineeIDAndBatchID(Long traineeID, Long batchID);

    /**
     * Paginated filtering by TraineeID, CourseID, BatchID, and Status.
     * All params optional — null means no filter applied.
     */
    @Query("SELECT e FROM CourseEnrollment e WHERE " +
           "(:traineeID IS NULL OR e.traineeID = :traineeID) AND " +
           "(:courseID IS NULL OR e.courseID = :courseID) AND " +
           "(:batchID IS NULL OR e.batchID = :batchID) AND " +
           "(:status IS NULL OR e.status = :status)")
    Page<CourseEnrollment> findAllWithFilters(
            @Param("traineeID") Long traineeID,
            @Param("courseID") Long courseID,
            @Param("batchID") Long batchID,
            @Param("status") CourseEnrollmentStatus status,
            Pageable pageable);
}
