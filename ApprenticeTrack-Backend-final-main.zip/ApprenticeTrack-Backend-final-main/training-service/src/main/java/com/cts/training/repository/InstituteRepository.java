package com.cts.training.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.training.entity.Institute;

@Repository
public interface InstituteRepository extends JpaRepository<Institute, Long> {
}
