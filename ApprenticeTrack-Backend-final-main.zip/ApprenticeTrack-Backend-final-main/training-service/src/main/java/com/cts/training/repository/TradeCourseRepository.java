package com.cts.training.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.training.common.TradeCourseQualificationLevel;
import com.cts.training.common.TradeCourseStatus;
import com.cts.training.entity.TradeCourse;

@Repository
public interface TradeCourseRepository extends JpaRepository<TradeCourse, Long> {

    boolean existsByTradeCodeIgnoreCase(String tradeCode);

    /**
     * Paginated list with optional sector, qualification level, and status filters.
     */
    @Query("SELECT c FROM TradeCourse c WHERE " +
           "(:sector IS NULL OR LOWER(c.sector) = LOWER(:sector)) AND " +
           "(:qualificationLevel IS NULL OR c.qualificationLevel = :qualificationLevel) AND " +
           "(:status IS NULL OR c.status = :status)")
    Page<TradeCourse> findAllWithFilters(
            @Param("sector") String sector,
            @Param("qualificationLevel") TradeCourseQualificationLevel qualificationLevel,
            @Param("status") TradeCourseStatus status,
            Pageable pageable);
}
