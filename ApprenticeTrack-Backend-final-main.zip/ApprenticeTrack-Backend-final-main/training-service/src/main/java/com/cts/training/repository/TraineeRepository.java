package com.cts.training.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.training.common.TraineeStatus;
import com.cts.training.entity.Trainee;

@Repository
public interface TraineeRepository extends JpaRepository<Trainee, Long> {

    boolean existsByUserID(Long userID);

    Optional<Trainee> findByUserID(Long userID);

    long countByStatus(TraineeStatus status);

    /**
     * Paginated list with optional status filter and name search (case-insensitive).
     * Null params are treated as "no filter".
     */
    @Query("SELECT t FROM Trainee t WHERE " +
           "(:status IS NULL OR t.status = :status) AND " +
           "(:name IS NULL OR LOWER(t.name) LIKE LOWER(CONCAT('%', :name, '%')))")
    Page<Trainee> findAllWithFilters(
            @Param("status") TraineeStatus status,
            @Param("name") String name,
            Pageable pageable);
}
