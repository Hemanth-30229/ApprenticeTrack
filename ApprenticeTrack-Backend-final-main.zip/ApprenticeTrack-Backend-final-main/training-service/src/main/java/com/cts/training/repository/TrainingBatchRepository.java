package com.cts.training.repository;

import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.training.common.TrainingBatchStatus;
import com.cts.training.entity.TrainingBatch;

@Repository
public interface TrainingBatchRepository extends JpaRepository<TrainingBatch, Long> {

    boolean existsByCourseIDAndBatchCode(Long courseID, String batchCode);

    long countByStatus(TrainingBatchStatus status);

    /**
     * Paginated filtering by CourseID, Status, and date range.
     * All params optional — null means no filter applied.
     */
    @Query("SELECT b FROM TrainingBatch b WHERE " +
           "(:courseID IS NULL OR b.courseID = :courseID) AND " +
           "(:status IS NULL OR b.status = :status) AND " +
           "(:fromDate IS NULL OR b.startDate >= :fromDate) AND " +
           "(:toDate IS NULL OR b.endDate <= :toDate)")
    Page<TrainingBatch> findAllWithFilters(
            @Param("courseID") Long courseID,
            @Param("status") TrainingBatchStatus status,
            @Param("fromDate") LocalDate fromDate,
            @Param("toDate") LocalDate toDate,
            Pageable pageable);
}
