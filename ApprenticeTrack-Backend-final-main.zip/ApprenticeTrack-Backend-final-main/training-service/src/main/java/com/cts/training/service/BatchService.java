package com.cts.training.service;

import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.training.dto.BatchCreateRequestDTO;
import com.cts.training.dto.BatchResponseDTO;
import com.cts.training.dto.BatchStatusUpdateRequestDTO;
import com.cts.training.dto.BatchUpdateRequestDTO;
import com.cts.training.common.TrainingBatchStatus;

public interface BatchService {

    BatchResponseDTO createBatch(BatchCreateRequestDTO requestDTO);

    BatchResponseDTO getBatchById(Long batchID);

    BatchResponseDTO updateBatch(Long batchID, BatchUpdateRequestDTO requestDTO);

    BatchResponseDTO updateStatus(Long batchID, BatchStatusUpdateRequestDTO requestDTO);

    void deleteBatch(Long batchID);

    Page<BatchResponseDTO> getAllBatches(Long courseID, TrainingBatchStatus status,
                                         LocalDate fromDate, LocalDate toDate,
                                         Pageable pageable);
}
