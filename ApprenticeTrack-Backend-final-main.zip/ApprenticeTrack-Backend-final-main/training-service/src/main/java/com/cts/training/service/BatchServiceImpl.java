package com.cts.training.service;

import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.training.client.PlatformClient;
import com.cts.training.client.dto.AuditLogRequest;
import com.cts.training.dto.BatchCreateRequestDTO;
import com.cts.training.dto.BatchResponseDTO;
import com.cts.training.dto.BatchStatusUpdateRequestDTO;
import com.cts.training.dto.BatchUpdateRequestDTO;
import com.cts.training.exception.BatchHasEnrolledTraineesException;
import com.cts.training.exception.BatchNotFoundException;
import com.cts.training.exception.CourseNotFoundException;
import com.cts.training.exception.DuplicateBatchCodeException;
import com.cts.training.exception.InvalidStatusTransitionException;
import com.cts.training.common.TrainingBatchStatus;
import com.cts.training.entity.TrainingBatch;
import com.cts.training.repository.CourseEnrollmentRepository;
import com.cts.training.repository.TradeCourseRepository;
import com.cts.training.repository.TrainingBatchRepository;

@Service
public class BatchServiceImpl implements BatchService {

    private static final String MODULE = "BatchManagement";

    private final TrainingBatchRepository batchRepository;
    private final TradeCourseRepository tradeCourseRepository;
    private final CourseEnrollmentRepository enrollmentRepository;
    private final PlatformClient platformClient;

    public BatchServiceImpl(TrainingBatchRepository batchRepository,
                             TradeCourseRepository tradeCourseRepository,
                             CourseEnrollmentRepository enrollmentRepository,
                             PlatformClient platformClient) {
        this.batchRepository = batchRepository;
        this.tradeCourseRepository = tradeCourseRepository;
        this.enrollmentRepository = enrollmentRepository;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional
    public BatchResponseDTO createBatch(BatchCreateRequestDTO dto) {
        if (!tradeCourseRepository.existsById(dto.getCourseID())) {
            throw new CourseNotFoundException("Course not found with ID: " + dto.getCourseID());
        }
        if (batchRepository.existsByCourseIDAndBatchCode(dto.getCourseID(), dto.getBatchCode())) {
            throw new DuplicateBatchCodeException("BatchCode '" + dto.getBatchCode() +
                    "' already exists for CourseID: " + dto.getCourseID());
        }
        TrainingBatch batch = TrainingBatch.builder()
                .courseID(dto.getCourseID()).batchCode(dto.getBatchCode())
                .startDate(dto.getStartDate()).endDate(dto.getEndDate())
                .trainerID(dto.getTrainerID()).venueID(dto.getVenueID())
                .capacity(dto.getCapacity()).status(TrainingBatchStatus.Upcoming).build();
        TrainingBatch saved = batchRepository.save(batch);
        audit("BatchCreated: " + saved.getBatchCode());
        return toResponseDTO(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public BatchResponseDTO getBatchById(Long batchID) {
        return toResponseDTO(findBatch(batchID));
    }

    @Override
    @Transactional
    public BatchResponseDTO updateBatch(Long batchID, BatchUpdateRequestDTO dto) {
        TrainingBatch batch = findBatch(batchID);
        if (batch.getStatus() == TrainingBatchStatus.Completed) {
            throw new InvalidStatusTransitionException("Completed batches cannot be updated.");
        }
        batch.setTrainerID(dto.getTrainerID());
        batch.setVenueID(dto.getVenueID());
        batch.setCapacity(dto.getCapacity());
        batch.setStartDate(dto.getStartDate());
        batch.setEndDate(dto.getEndDate());
        TrainingBatch updated = batchRepository.save(batch);
        audit("BatchUpdated: " + updated.getBatchCode());
        return toResponseDTO(updated);
    }

    @Override
    @Transactional
    public BatchResponseDTO updateStatus(Long batchID, BatchStatusUpdateRequestDTO dto) {
        TrainingBatch batch = findBatch(batchID);
        TrainingBatchStatus current = batch.getStatus();
        TrainingBatchStatus target = dto.getStatus();
        validateStatusTransition(current, target);
        batch.setStatus(target);
        TrainingBatch updated = batchRepository.save(batch);
        audit("BatchStatusChanged: " + current + " -> " + target + " [" + updated.getBatchCode() + "]");
        return toResponseDTO(updated);
    }

    @Override
    @Transactional
    public void deleteBatch(Long batchID) {
        TrainingBatch batch = findBatch(batchID);
        if (enrollmentRepository.existsByBatchID(batchID)) {
            throw new BatchHasEnrolledTraineesException("Batch '" + batch.getBatchCode() +
                    "' cannot be deleted — trainees are enrolled.");
        }
        batchRepository.delete(batch);
        audit("BatchDeleted: " + batch.getBatchCode());
    }

    @Override
    @Transactional(readOnly = true)
    public Page<BatchResponseDTO> getAllBatches(Long courseID, TrainingBatchStatus status,
                                                LocalDate fromDate, LocalDate toDate,
                                                Pageable pageable) {
        return batchRepository.findAllWithFilters(courseID, status, fromDate, toDate, pageable)
                .map(this::toResponseDTO);
    }

    private TrainingBatch findBatch(Long batchID) {
        return batchRepository.findById(batchID)
                .orElseThrow(() -> new BatchNotFoundException("Batch not found with ID: " + batchID));
    }

    private void validateStatusTransition(TrainingBatchStatus current, TrainingBatchStatus target) {
        if (current == target) {
            throw new InvalidStatusTransitionException("Batch is already in '" + current + "' status.");
        }
        boolean valid = (current == TrainingBatchStatus.Upcoming && target == TrainingBatchStatus.Active)
                     || (current == TrainingBatchStatus.Active && target == TrainingBatchStatus.Completed);
        if (!valid) {
            throw new InvalidStatusTransitionException(
                    "Invalid transition: " + current + " -> " + target +
                    ". Allowed: Upcoming -> Active -> Completed only.");
        }
    }

    private void audit(String action) {
        platformClient.recordAudit(new AuditLogRequest(0L, action, MODULE, null));
    }

    private BatchResponseDTO toResponseDTO(TrainingBatch b) {
        long enrolledCount = enrollmentRepository.countByBatchID(b.getBatchID());
        return BatchResponseDTO.builder()
                .batchID(b.getBatchID()).courseID(b.getCourseID()).batchCode(b.getBatchCode())
                .startDate(b.getStartDate()).endDate(b.getEndDate())
                .trainerID(b.getTrainerID()).venueID(b.getVenueID())
                .capacity(b.getCapacity()).status(b.getStatus())
                .enrolledTraineeCount(enrolledCount).build();
    }
}
