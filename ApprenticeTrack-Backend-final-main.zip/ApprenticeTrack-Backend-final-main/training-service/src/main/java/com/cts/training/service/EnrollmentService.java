package com.cts.training.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.training.dto.EnrollmentCreateRequestDTO;
import com.cts.training.dto.EnrollmentResponseDTO;
import com.cts.training.common.CourseEnrollmentStatus;

public interface EnrollmentService {

    EnrollmentResponseDTO createEnrollment(EnrollmentCreateRequestDTO dto);

    EnrollmentResponseDTO getEnrollmentById(Long enrollmentID);

    Page<EnrollmentResponseDTO> getAllEnrollments(Long traineeID, Long courseID,
                                                  Long batchID, CourseEnrollmentStatus status, Pageable pageable);

    EnrollmentResponseDTO updateStatus(Long enrollmentID, CourseEnrollmentStatus newStatus);

    // ── Cross-service reads/writes (MIGRATION_PLAN.md §6) ──────────────────────

    /** All enrollments for a trainee, unpaged — served to platform-service's TrainingClient. */
    List<EnrollmentResponseDTO> getEnrollmentsForTrainee(Long traineeID);

    /** Whether the trainee has an OJTInProgress enrollment — served to placement-service's TrainingClient. */
    boolean isTraineeInOjt(Long traineeID);

    /**
     * Promotes the trainee's Enrolled enrollments to OJTInProgress — called by
     * placement-service when a placement is created.
     */
    void promoteEnrollmentsToOjt(Long traineeID);

    /** TraineeIDs enrolled in a batch — served to assessment-service's TrainingClient. */
    List<Long> getEnrolledTraineeIds(Long batchID);

    /** Whether a trainee is enrolled in a batch — served to assessment-service's TrainingClient. */
    boolean isTraineeEnrolledInBatch(Long traineeID, Long batchID);

    /**
     * Marks the trainee's (non-withdrawn) enrollment for the course Completed —
     * called by assessment-service after the trainee passes a reassessment.
     */
    void completeEnrollment(Long traineeID, Long courseID);
}
