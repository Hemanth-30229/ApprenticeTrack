package com.cts.training.service;

import java.time.LocalDate;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.training.client.PlatformClient;
import com.cts.training.client.dto.AuditLogRequest;
import com.cts.training.client.dto.NotificationRequest;
import com.cts.training.dto.EnrollmentCreateRequestDTO;
import com.cts.training.dto.EnrollmentResponseDTO;
import com.cts.training.exception.BatchFullException;
import com.cts.training.exception.BatchNotFoundException;
import com.cts.training.exception.CourseNotFoundException;
import com.cts.training.exception.DuplicateEnrollmentException;
import com.cts.training.exception.EnrollmentNotFoundException;
import com.cts.training.exception.InvalidEnrollmentStatusTransitionException;
import com.cts.training.exception.TraineeNotFoundException;
import com.cts.training.common.CourseEnrollmentStatus;
import com.cts.training.entity.CourseEnrollment;
import com.cts.training.entity.Trainee;
import com.cts.training.entity.TradeCourse;
import com.cts.training.entity.TrainingBatch;
import com.cts.training.repository.CourseEnrollmentRepository;
import com.cts.training.repository.TradeCourseRepository;
import com.cts.training.repository.TraineeRepository;
import com.cts.training.repository.TrainingBatchRepository;

@Service
public class EnrollmentServiceImpl implements EnrollmentService {

    private static final String MODULE = "Enrollment";
    private static final String CATEGORY_ENROLLMENT = "Enrollment";

    /** Allowed forward transitions; Withdrawn is reachable from any non-terminal state. */
    private static final Map<CourseEnrollmentStatus, Set<CourseEnrollmentStatus>> ALLOWED_TRANSITIONS = new EnumMap<>(CourseEnrollmentStatus.class);
    static {
        ALLOWED_TRANSITIONS.put(CourseEnrollmentStatus.Enrolled, Set.of(CourseEnrollmentStatus.OJTInProgress, CourseEnrollmentStatus.Withdrawn));
        ALLOWED_TRANSITIONS.put(CourseEnrollmentStatus.OJTInProgress, Set.of(CourseEnrollmentStatus.AssessmentPending, CourseEnrollmentStatus.Withdrawn));
        ALLOWED_TRANSITIONS.put(CourseEnrollmentStatus.AssessmentPending, Set.of(CourseEnrollmentStatus.Completed, CourseEnrollmentStatus.Withdrawn));
        ALLOWED_TRANSITIONS.put(CourseEnrollmentStatus.Completed, Set.of());
        ALLOWED_TRANSITIONS.put(CourseEnrollmentStatus.Withdrawn, Set.of());
    }

    private final CourseEnrollmentRepository enrollmentRepository;
    private final TraineeRepository traineeRepository;
    private final TradeCourseRepository courseRepository;
    private final TrainingBatchRepository batchRepository;
    private final PlatformClient platformClient;

    public EnrollmentServiceImpl(CourseEnrollmentRepository enrollmentRepository,
                                 TraineeRepository traineeRepository,
                                 TradeCourseRepository courseRepository,
                                 TrainingBatchRepository batchRepository,
                                 PlatformClient platformClient) {
        this.enrollmentRepository = enrollmentRepository;
        this.traineeRepository = traineeRepository;
        this.courseRepository = courseRepository;
        this.batchRepository = batchRepository;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional
    public EnrollmentResponseDTO createEnrollment(EnrollmentCreateRequestDTO dto) {
        Trainee trainee = findTrainee(dto.getTraineeID());
        TradeCourse course = findCourse(dto.getCourseID());
        TrainingBatch batch = findBatch(dto.getBatchID());

        if (enrollmentRepository.existsByTraineeIDAndCourseIDAndBatchID(
                dto.getTraineeID(), dto.getCourseID(), dto.getBatchID())) {
            throw new DuplicateEnrollmentException(
                    "Enrollment already exists for TraineeID=" + dto.getTraineeID()
                    + ", CourseID=" + dto.getCourseID() + ", BatchID=" + dto.getBatchID());
        }

        long enrolled = enrollmentRepository.countByBatchID(batch.getBatchID());
        if (enrolled >= batch.getCapacity()) {
            throw new BatchFullException("Batch is full (capacity " + batch.getCapacity()
                    + "). BatchID: " + batch.getBatchID());
        }

        LocalDate enrollmentDate = dto.getEnrollmentDate() != null
                ? dto.getEnrollmentDate() : LocalDate.now();

        LocalDate expectedCompletionDate = course.getDurationWeeks() != null
                ? enrollmentDate.plusWeeks(course.getDurationWeeks()) : null;
        LocalDate ojtStartDate = course.getClassroomWeeks() != null
                ? enrollmentDate.plusWeeks(course.getClassroomWeeks()) : null;

        CourseEnrollment enrollment = CourseEnrollment.builder()
                .traineeID(dto.getTraineeID())
                .courseID(dto.getCourseID())
                .batchID(dto.getBatchID())
                .enrollmentDate(enrollmentDate)
                .expectedCompletionDate(expectedCompletionDate)
                .ojtStartDate(ojtStartDate)
                .status(CourseEnrollmentStatus.Enrolled)
                .build();

        CourseEnrollment saved = enrollmentRepository.save(enrollment);
        platformClient.recordAudit(new AuditLogRequest(saved.getTraineeID(),
                "EnrollmentCreated", MODULE,
                "TraineeID=" + saved.getTraineeID() + ", CourseID=" + saved.getCourseID()
                        + ", BatchID=" + saved.getBatchID() + " [EnrollmentID=" + saved.getEnrollmentID() + "]"));

        notifyTrainee(saved.getTraineeID(), "You have been enrolled in course " + course.getCourseName() + ".");

        return toResponseDTO(saved, trainee.getName(), course.getCourseName());
    }

    @Override
    @Transactional(readOnly = true)
    public EnrollmentResponseDTO getEnrollmentById(Long enrollmentID) {
        CourseEnrollment enrollment = findEnrollment(enrollmentID);
        return toResponseDTO(enrollment,
                resolveTraineeName(enrollment.getTraineeID()),
                resolveCourseName(enrollment.getCourseID()));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<EnrollmentResponseDTO> getAllEnrollments(Long traineeID, Long courseID,
                                                         Long batchID, CourseEnrollmentStatus status, Pageable pageable) {
        return enrollmentRepository
                .findAllWithFilters(traineeID, courseID, batchID, status, pageable)
                .map(e -> toResponseDTO(e,
                        resolveTraineeName(e.getTraineeID()),
                        resolveCourseName(e.getCourseID())));
    }

    @Override
    @Transactional
    public EnrollmentResponseDTO updateStatus(Long enrollmentID, CourseEnrollmentStatus newStatus) {
        CourseEnrollment enrollment = findEnrollment(enrollmentID);
        CourseEnrollmentStatus current = enrollment.getStatus();

        if (!ALLOWED_TRANSITIONS.getOrDefault(current, Set.of()).contains(newStatus)) {
            throw new InvalidEnrollmentStatusTransitionException(
                    "Invalid status transition: " + current + " → " + newStatus
                    + ". EnrollmentID: " + enrollmentID);
        }

        enrollment.setStatus(newStatus);
        CourseEnrollment updated = enrollmentRepository.save(enrollment);
        platformClient.recordAudit(new AuditLogRequest(updated.getTraineeID(),
                "EnrollmentStatusChanged", MODULE,
                current + " → " + newStatus + " [EnrollmentID=" + updated.getEnrollmentID() + "]"));

        notifyTrainee(updated.getTraineeID(), "Your enrollment status changed to " + newStatus + ".");

        return toResponseDTO(updated,
                resolveTraineeName(updated.getTraineeID()),
                resolveCourseName(updated.getCourseID()));
    }

    // ── Cross-service reads/writes ────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public List<EnrollmentResponseDTO> getEnrollmentsForTrainee(Long traineeID) {
        return enrollmentRepository.findByTraineeID(traineeID).stream()
                .map(e -> toResponseDTO(e,
                        resolveTraineeName(e.getTraineeID()),
                        resolveCourseName(e.getCourseID())))
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public boolean isTraineeInOjt(Long traineeID) {
        return enrollmentRepository.existsByTraineeIDAndStatus(traineeID, CourseEnrollmentStatus.OJTInProgress);
    }

    @Override
    @Transactional
    public void promoteEnrollmentsToOjt(Long traineeID) {
        List<CourseEnrollment> enrollments = enrollmentRepository.findByTraineeID(traineeID);
        for (CourseEnrollment e : enrollments) {
            if (e.getStatus() == CourseEnrollmentStatus.Enrolled) {
                e.setStatus(CourseEnrollmentStatus.OJTInProgress);
                enrollmentRepository.save(e);
                platformClient.recordAudit(new AuditLogRequest(traineeID,
                        "EnrollmentStatusChanged", MODULE,
                        "Enrolled → OJTInProgress [EnrollmentID=" + e.getEnrollmentID() + "]"));
            }
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<Long> getEnrolledTraineeIds(Long batchID) {
        return enrollmentRepository.findByBatchID(batchID).stream()
                .map(CourseEnrollment::getTraineeID)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public boolean isTraineeEnrolledInBatch(Long traineeID, Long batchID) {
        return enrollmentRepository.existsByTraineeIDAndBatchID(traineeID, batchID);
    }

    @Override
    @Transactional
    public void completeEnrollment(Long traineeID, Long courseID) {
        List<CourseEnrollment> enrollments =
                enrollmentRepository.findByTraineeIDAndCourseID(traineeID, courseID);
        for (CourseEnrollment e : enrollments) {
            if (e.getStatus() != CourseEnrollmentStatus.Withdrawn && e.getStatus() != CourseEnrollmentStatus.Completed) {
                e.setStatus(CourseEnrollmentStatus.Completed);
                enrollmentRepository.save(e);
                platformClient.recordAudit(new AuditLogRequest(traineeID,
                        "EnrollmentStatusChanged", MODULE,
                        e.getStatus() + " → Completed [EnrollmentID=" + e.getEnrollmentID() + "]"));
            }
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────────
    private Trainee findTrainee(Long traineeID) {
        return traineeRepository.findById(traineeID)
                .orElseThrow(() -> new TraineeNotFoundException("Trainee not found with ID: " + traineeID));
    }

    private TradeCourse findCourse(Long courseID) {
        return courseRepository.findById(courseID)
                .orElseThrow(() -> new CourseNotFoundException("Course not found with ID: " + courseID));
    }

    private TrainingBatch findBatch(Long batchID) {
        return batchRepository.findById(batchID)
                .orElseThrow(() -> new BatchNotFoundException("Batch not found with ID: " + batchID));
    }

    private CourseEnrollment findEnrollment(Long enrollmentID) {
        return enrollmentRepository.findById(enrollmentID)
                .orElseThrow(() -> new EnrollmentNotFoundException("Enrollment not found with ID: " + enrollmentID));
    }

    private String resolveTraineeName(Long traineeID) {
        return traineeRepository.findById(traineeID).map(Trainee::getName).orElse(null);
    }

    private String resolveCourseName(Long courseID) {
        return courseRepository.findById(courseID).map(TradeCourse::getCourseName).orElse(null);
    }

    private void notifyTrainee(Long traineeID, String message) {
        platformClient.notify(new NotificationRequest("TRAINEE", traineeID, message, CATEGORY_ENROLLMENT));
    }

    private EnrollmentResponseDTO toResponseDTO(CourseEnrollment e, String traineeName, String courseName) {
        return EnrollmentResponseDTO.builder()
                .enrollmentID(e.getEnrollmentID())
                .traineeID(e.getTraineeID())
                .traineeName(traineeName)
                .courseID(e.getCourseID())
                .courseName(courseName)
                .batchID(e.getBatchID())
                .enrollmentDate(e.getEnrollmentDate())
                .expectedCompletionDate(e.getExpectedCompletionDate())
                .ojtStartDate(e.getOjtStartDate())
                .status(e.getStatus())
                .build();
    }
}
