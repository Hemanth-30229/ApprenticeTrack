package com.cts.training.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.training.dto.TradeCourseCreateRequestDTO;
import com.cts.training.dto.TradeCourseResponseDTO;
import com.cts.training.dto.TradeCourseUpdateRequestDTO;
import com.cts.training.common.TradeCourseQualificationLevel;
import com.cts.training.common.TradeCourseStatus;

public interface TradeCourseService {

    TradeCourseResponseDTO createCourse(TradeCourseCreateRequestDTO requestDTO);

    TradeCourseResponseDTO getCourseById(Long courseID);

    TradeCourseResponseDTO updateCourse(Long courseID, TradeCourseUpdateRequestDTO requestDTO);

    void deleteCourse(Long courseID);

    Page<TradeCourseResponseDTO> getAllCourses(String sector, TradeCourseQualificationLevel qualificationLevel,
                                               TradeCourseStatus status, Pageable pageable);
}
