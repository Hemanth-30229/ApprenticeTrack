package com.cts.training.service;

import java.util.EnumSet;
import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.training.client.PlatformClient;
import com.cts.training.client.dto.AuditLogRequest;
import com.cts.training.dto.TradeCourseCreateRequestDTO;
import com.cts.training.dto.TradeCourseResponseDTO;
import com.cts.training.dto.TradeCourseUpdateRequestDTO;
import com.cts.training.exception.CourseHasEnrollmentsException;
import com.cts.training.exception.CourseNotFoundException;
import com.cts.training.exception.DuplicateTradeCodeException;
import com.cts.training.exception.InvalidCourseDurationException;
import com.cts.training.common.CourseEnrollmentStatus;
import com.cts.training.common.TradeCourseQualificationLevel;
import com.cts.training.common.TradeCourseStatus;
import com.cts.training.entity.CourseEnrollment;
import com.cts.training.entity.TradeCourse;
import com.cts.training.repository.CourseEnrollmentRepository;
import com.cts.training.repository.TradeCourseRepository;

@Service
public class TradeCourseServiceImpl implements TradeCourseService {

    private static final String MODULE = "TradeCourse";

    /** Enrollment statuses that count as "active" and block course deletion. */
    private static final Set<CourseEnrollmentStatus> ACTIVE_ENROLLMENT_STATUSES = EnumSet.of(
            CourseEnrollmentStatus.Enrolled,
            CourseEnrollmentStatus.OJTInProgress,
            CourseEnrollmentStatus.AssessmentPending);

    private final TradeCourseRepository courseRepository;
    private final CourseEnrollmentRepository enrollmentRepository;
    private final PlatformClient platformClient;

    public TradeCourseServiceImpl(TradeCourseRepository courseRepository,
                                  CourseEnrollmentRepository enrollmentRepository,
                                  PlatformClient platformClient) {
        this.courseRepository = courseRepository;
        this.enrollmentRepository = enrollmentRepository;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional
    public TradeCourseResponseDTO createCourse(TradeCourseCreateRequestDTO dto) {
        validateDuration(dto.getDurationWeeks(), dto.getClassroomWeeks(), dto.getOjtWeeks());
        if (courseRepository.existsByTradeCodeIgnoreCase(dto.getTradeCode())) {
            throw new DuplicateTradeCodeException(
                    "Trade course with code '" + dto.getTradeCode() + "' already exists");
        }
        TradeCourse course = TradeCourse.builder()
                .courseName(dto.getCourseName())
                .tradeCode(dto.getTradeCode())
                .sector(dto.getSector())
                .durationWeeks(dto.getDurationWeeks())
                .classroomWeeks(dto.getClassroomWeeks())
                .ojtWeeks(dto.getOjtWeeks())
                .qualificationLevel(dto.getQualificationLevel())
                .videoLink(dto.getVideoLink())
                .status(TradeCourseStatus.Active)
                .build();
        TradeCourse saved = courseRepository.save(course);
        audit("TradeCourseCreated: " + saved.getTradeCode());
        return toResponseDTO(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public TradeCourseResponseDTO getCourseById(Long courseID) {
        return toResponseDTO(findCourse(courseID));
    }

    @Override
    @Transactional
    public TradeCourseResponseDTO updateCourse(Long courseID, TradeCourseUpdateRequestDTO dto) {
        validateDuration(dto.getDurationWeeks(), dto.getClassroomWeeks(), dto.getOjtWeeks());
        TradeCourse course = findCourse(courseID);
        if (!course.getTradeCode().equalsIgnoreCase(dto.getTradeCode())
                && courseRepository.existsByTradeCodeIgnoreCase(dto.getTradeCode())) {
            throw new DuplicateTradeCodeException(
                    "Trade course with code '" + dto.getTradeCode() + "' already exists");
        }
        course.setCourseName(dto.getCourseName());
        course.setTradeCode(dto.getTradeCode());
        course.setSector(dto.getSector());
        course.setDurationWeeks(dto.getDurationWeeks());
        course.setClassroomWeeks(dto.getClassroomWeeks());
        course.setOjtWeeks(dto.getOjtWeeks());
        course.setQualificationLevel(dto.getQualificationLevel());
        course.setVideoLink(dto.getVideoLink());
        course.setStatus(dto.getStatus());
        TradeCourse updated = courseRepository.save(course);
        audit("TradeCourseUpdated: " + updated.getTradeCode());
        return toResponseDTO(updated);
    }

    @Override
    @Transactional
    public void deleteCourse(Long courseID) {
        TradeCourse course = findCourse(courseID);
        if (enrollmentRepository.existsByCourseIDAndStatusIn(courseID, ACTIVE_ENROLLMENT_STATUSES)) {
            throw new CourseHasEnrollmentsException(
                    "Trade course '" + course.getTradeCode()
                    + "' cannot be deleted while active enrollments exist.");
        }
        courseRepository.delete(course);
        audit("TradeCourseDeleted: " + course.getTradeCode());
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TradeCourseResponseDTO> getAllCourses(String sector, TradeCourseQualificationLevel qualificationLevel,
                                                      TradeCourseStatus status, Pageable pageable) {
        return courseRepository.findAllWithFilters(sector, qualificationLevel, status, pageable)
                .map(this::toResponseDTO);
    }

    // ── Helpers ─────────────────────────────────────────────────────────────

    private void validateDuration(Integer duration, Integer classroom, Integer ojt) {
        if (duration == null || classroom == null || ojt == null) {
            return; // bean validation handles null; guard against NPE here
        }
        if (duration != classroom + ojt) {
            throw new InvalidCourseDurationException(
                    "DurationWeeks (" + duration + ") must equal ClassroomWeeks (" + classroom
                    + ") + OJTWeeks (" + ojt + ") = " + (classroom + ojt));
        }
    }

    private TradeCourse findCourse(Long courseID) {
        return courseRepository.findById(courseID)
                .orElseThrow(() -> new CourseNotFoundException("Trade course not found with ID: " + courseID));
    }

    private void audit(String action) {
        platformClient.recordAudit(new AuditLogRequest(0L, action, MODULE, null));
    }

    private TradeCourseResponseDTO toResponseDTO(TradeCourse c) {
        return TradeCourseResponseDTO.builder()
                .courseID(c.getCourseID())
                .courseName(c.getCourseName())
                .tradeCode(c.getTradeCode())
                .sector(c.getSector())
                .durationWeeks(c.getDurationWeeks())
                .classroomWeeks(c.getClassroomWeeks())
                .ojtWeeks(c.getOjtWeeks())
                .qualificationLevel(c.getQualificationLevel())
                .videoLink(c.getVideoLink())
                .status(c.getStatus())
                .build();
    }
}
