package com.cts.training.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.training.dto.TraineeCreateRequestDTO;
import com.cts.training.dto.TraineeResponseDTO;
import com.cts.training.dto.TraineeUpdateRequestDTO;
import com.cts.training.common.TraineeStatus;

public interface TraineeService {

    TraineeResponseDTO createTrainee(TraineeCreateRequestDTO requestDTO);

    TraineeResponseDTO getTraineeById(Long traineeID);

    /** Returns {@code null} when no trainee is linked to the given UserID. */
    TraineeResponseDTO getTraineeByUserId(Long userID);

    TraineeResponseDTO updateTrainee(Long traineeID, TraineeUpdateRequestDTO requestDTO);

    void deleteTrainee(Long traineeID); // soft-delete → Status = Dropout

    Page<TraineeResponseDTO> getAllTrainees(TraineeStatus status, String name, Pageable pageable);
}
