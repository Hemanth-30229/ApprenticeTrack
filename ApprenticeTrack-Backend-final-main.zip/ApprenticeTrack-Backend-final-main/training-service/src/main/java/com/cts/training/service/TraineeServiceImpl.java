package com.cts.training.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.training.client.AuthClient;
import com.cts.training.client.PlatformClient;
import com.cts.training.client.dto.AuditLogRequest;
import com.cts.training.dto.TraineeCreateRequestDTO;
import com.cts.training.dto.TraineeResponseDTO;
import com.cts.training.dto.TraineeUpdateRequestDTO;
import com.cts.training.exception.TraineeNotFoundException;
import com.cts.training.exception.UserNotFoundException;
import com.cts.training.common.TraineeStatus;
import com.cts.training.entity.Trainee;
import com.cts.training.entity.Trainee.EmergencyContact;
import com.cts.training.repository.TraineeRepository;

@Service
public class TraineeServiceImpl implements TraineeService {

    private static final String MODULE = "TraineeProfile";

    private final TraineeRepository traineeRepository;
    private final AuthClient authClient;
    private final PlatformClient platformClient;

    public TraineeServiceImpl(TraineeRepository traineeRepository,
                               AuthClient authClient,
                               PlatformClient platformClient) {
        this.traineeRepository = traineeRepository;
        this.authClient = authClient;
        this.platformClient = platformClient;
    }

    @Override
    @Transactional
    public TraineeResponseDTO createTrainee(TraineeCreateRequestDTO dto) {
        if (authClient.getUser(dto.getUserID()) == null) {
            throw new UserNotFoundException("User not found with ID: " + dto.getUserID());
        }
        Trainee trainee = Trainee.builder()
                .userID(dto.getUserID()).name(dto.getName())
                .dateOfBirth(dto.getDateOfBirth()).gender(dto.getGender())
                .educationLevel(dto.getEducationLevel()).address(dto.getAddress())
                .phone(dto.getPhone())
                .emergencyContact(new EmergencyContact(
                        dto.getEmergencyContact().getName(),
                        dto.getEmergencyContact().getPhone()))
                .status(TraineeStatus.Active).build();
        Trainee saved = traineeRepository.save(trainee);
        platformClient.recordAudit(new AuditLogRequest(
                dto.getUserID(), "TraineeCreated", MODULE, null));
        return toResponseDTO(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public TraineeResponseDTO getTraineeById(Long traineeID) {
        return toResponseDTO(findTrainee(traineeID));
    }

    @Override
    @Transactional(readOnly = true)
    public TraineeResponseDTO getTraineeByUserId(Long userID) {
        return traineeRepository.findByUserID(userID).map(this::toResponseDTO).orElse(null);
    }

    @Override
    @Transactional
    public TraineeResponseDTO updateTrainee(Long traineeID, TraineeUpdateRequestDTO dto) {
        Trainee trainee = findTrainee(traineeID);
        trainee.setName(dto.getName());
        trainee.setAddress(dto.getAddress());
        trainee.setPhone(dto.getPhone());
        trainee.setEducationLevel(dto.getEducationLevel());
        trainee.setEmergencyContact(new EmergencyContact(
                dto.getEmergencyContact().getName(),
                dto.getEmergencyContact().getPhone()));
        Trainee updated = traineeRepository.save(trainee);
        platformClient.recordAudit(new AuditLogRequest(
                updated.getUserID(), "TraineeUpdated", MODULE, null));
        return toResponseDTO(updated);
    }

    @Override
    @Transactional
    public void deleteTrainee(Long traineeID) {
        Trainee trainee = findTrainee(traineeID);
        trainee.setStatus(TraineeStatus.Dropout);
        traineeRepository.save(trainee);
        platformClient.recordAudit(new AuditLogRequest(
                trainee.getUserID(), "TraineeDeleted", MODULE, null));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TraineeResponseDTO> getAllTrainees(TraineeStatus status, String name, Pageable pageable) {
        return traineeRepository.findAllWithFilters(status, name, pageable).map(this::toResponseDTO);
    }

    private Trainee findTrainee(Long traineeID) {
        return traineeRepository.findById(traineeID)
                .orElseThrow(() -> new TraineeNotFoundException("Trainee not found with ID: " + traineeID));
    }

    private TraineeResponseDTO toResponseDTO(Trainee t) {
        return TraineeResponseDTO.builder()
                .traineeID(t.getTraineeID()).userID(t.getUserID()).name(t.getName())
                .dateOfBirth(t.getDateOfBirth()).gender(t.getGender())
                .educationLevel(t.getEducationLevel()).address(t.getAddress())
                .phone(t.getPhone())
                .emergencyContact(TraineeResponseDTO.EmergencyContactDTO.builder()
                        .name(t.getEmergencyContact().getName())
                        .phone(t.getEmergencyContact().getPhone()).build())
                .status(t.getStatus()).build();
    }
}
