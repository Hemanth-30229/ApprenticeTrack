package com.cts.training.validation;

import java.lang.reflect.Method;
import java.time.LocalDate;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * Validates that endDate is strictly after startDate.
 * Works on any class that exposes getStartDate() and getEndDate() returning LocalDate.
 */
public class EndDateAfterStartDateValidator
        implements ConstraintValidator<EndDateAfterStartDate, Object> {

    @Override
    public boolean isValid(Object obj, ConstraintValidatorContext context) {
        try {
            Method getStartDate = obj.getClass().getMethod("getStartDate");
            Method getEndDate   = obj.getClass().getMethod("getEndDate");

            LocalDate start = (LocalDate) getStartDate.invoke(obj);
            LocalDate end   = (LocalDate) getEndDate.invoke(obj);

            if (start == null || end == null) {
				return true; // let @NotNull handle nulls
			}

            boolean valid = end.isAfter(start);
            if (!valid) {
                context.disableDefaultConstraintViolation();
                context.buildConstraintViolationWithTemplate("End date must be after start date")
                        .addPropertyNode("endDate")
                        .addConstraintViolation();
            }
            return valid;

        } catch (Exception e) {
            return true; // skip if reflection fails
        }
    }
}
