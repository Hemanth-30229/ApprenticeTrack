import { Navigate, Route, Routes } from 'react-router-dom';
import ProtectedRoute from './shared/ProtectedRoute';
import { useAuth } from './shared/auth/AuthContext';
import { homePathForRole, ROLES } from './shared/auth/roles';
import LoginPage from './features/identity/pages/LoginPage';
import ForgotPasswordPage from './features/identity/pages/ForgotPasswordPage';
import ChangePasswordPage from './features/identity/pages/ChangePasswordPage';
import DashboardPage from './features/platform/pages/DashboardPage';
import TraineeListPage from './features/training/pages/TraineeListPage';
import EmployerListPage from './features/placement/pages/EmployerListPage';
import EnrollmentListPage from './features/training/pages/EnrollmentListPage';
import TraineeOjtLogPage from './features/ojt-stipend/pages/TraineeOjtLogPage';
import SupervisorOjtLogPage from './features/ojt-stipend/pages/SupervisorOjtLogPage';
import EmployerVacancyPage from './features/placement/pages/EmployerVacancyPage';
import EmployerRosterPage from './features/placement/pages/EmployerRosterPage';
import EmployerAttendancePage from './features/ojt-stipend/pages/EmployerAttendancePage';
import AssessorTestListPage from './features/assessment/pages/AssessorTestListPage';
import AssessmentEntryPage from './features/assessment/pages/AssessmentEntryPage';
import TestQuestionsPage from './features/assessment/pages/TestQuestionsPage';
import ReassessmentTrackerPage from './features/assessment/pages/ReassessmentTrackerPage';
import PlacementListPage from './features/placement/pages/PlacementListPage';
import AttendanceListPage from './features/ojt-stipend/pages/AttendanceListPage';
import ResultListPage from './features/assessment/pages/ResultListPage';
import TraineeResultsPage from './features/assessment/pages/TraineeResultsPage';
import StipendListPage from './features/ojt-stipend/pages/StipendListPage';
import CertificateListPage from './features/assessment/pages/CertificateListPage';
import TraineeCertificatesPage from './features/assessment/pages/TraineeCertificatesPage';
import TraineeCoursesPage from './features/training/pages/TraineeCoursesPage';
import TraineeCourseContentPage from './features/training/pages/TraineeCourseContentPage';
import TraineeStipendPage from './features/ojt-stipend/pages/TraineeStipendPage';
import TraineePlacementPage from './features/placement/pages/TraineePlacementPage';
import TraineeTestListPage from './features/assessment/pages/TraineeTestListPage';
import TraineeTestAttemptPage from './features/assessment/pages/TraineeTestAttemptPage';
import NotificationListPage from './features/platform/pages/NotificationListPage';
import AuditLogPage from './features/platform/pages/AuditLogPage';
import CourseManagementPage from './features/training/pages/CourseManagementPage';
import UserManagementPage from './features/identity/pages/UserManagementPage';
import AssessorListPage from './features/assessment/pages/AssessorListPage';
import BatchListPage from './features/training/pages/BatchListPage';
import VacancyBoardPage from './features/placement/pages/VacancyBoardPage';
import AppShell from './shared/layout/AppShell';
import ProfilePage from './features/identity/pages/ProfilePage';
import PlaceholderPage from './features/platform/pages/PlaceholderPage';

function RootRedirect() {
  const { isAuthenticated, user } = useAuth();
  return (
    <Navigate
      to={isAuthenticated ? homePathForRole(user.role) : '/login'}
      replace
    />
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<RootRedirect />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/change-password" element={<ChangePasswordPage />} />

      <Route element={<AppShell />}>
      <Route element={<ProtectedRoute />}>
        <Route path="/notifications" element={<NotificationListPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/soon" element={<PlaceholderPage />} />
      </Route>


      <Route element={<ProtectedRoute allow={[ROLES.TRAINEE]} />}>
        <Route path="/trainee" element={<DashboardPage />} />
        <Route path="/trainee/ojt-logs" element={<TraineeOjtLogPage />} />
        <Route path="/trainee/placement" element={<TraineePlacementPage />} />
        <Route path="/trainee/results" element={<TraineeResultsPage />} />
        <Route path="/trainee/stipends" element={<TraineeStipendPage />} />
        <Route path="/trainee/tests" element={<TraineeTestListPage />} />
        <Route path="/trainee/tests/:testId" element={<TraineeTestAttemptPage />} />
        <Route path="/trainee/certificates" element={<TraineeCertificatesPage />} />
        <Route path="/trainee/courses" element={<TraineeCoursesPage />} />
        <Route path="/trainee/courses/:courseId" element={<TraineeCourseContentPage />} />
      </Route>
      <Route element={<ProtectedRoute allow={[ROLES.EMPLOYER]} />}>
        <Route path="/employer" element={<DashboardPage />} />
        <Route path="/employer/vacancies" element={<EmployerVacancyPage />} />
        <Route path="/employer/roster" element={<EmployerRosterPage />} />
        <Route path="/employer/ojt-logs" element={<SupervisorOjtLogPage />} />
        <Route path="/employer/attendance-summary" element={<EmployerAttendancePage />} />
      </Route>
      <Route element={<ProtectedRoute allow={[ROLES.ASSESSOR]} />}>
        <Route path="/assessor" element={<DashboardPage />} />
        <Route path="/assessor/tests" element={<AssessorTestListPage />} />
        <Route path="/assessor/tests/:testId" element={<AssessmentEntryPage />} />
        <Route path="/assessor/tests/:testId/questions" element={<TestQuestionsPage />} />
        <Route path="/assessor/reassessments" element={<ReassessmentTrackerPage />} />
      </Route>
      <Route element={<ProtectedRoute allow={[ROLES.PLACEMENT_OFFICER]} />}>
        <Route path="/placement" element={<DashboardPage />} />
        <Route path="/placements" element={<PlacementListPage />} />
      </Route>
      <Route element={<ProtectedRoute allow={[ROLES.STIPEND_ADMIN]} />}>
        <Route path="/stipend" element={<DashboardPage />} />
        <Route path="/attendance" element={<AttendanceListPage />} />
        <Route path="/stipends" element={<StipendListPage />} />
      </Route>
      <Route element={<ProtectedRoute allow={[ROLES.ADMIN]} />}>
        <Route path="/admin" element={<DashboardPage />} />
        <Route path="/trainees" element={<TraineeListPage />} />
        <Route path="/employers" element={<EmployerListPage />} />
        <Route path="/enrollments" element={<EnrollmentListPage />} />
        <Route path="/results" element={<ResultListPage />} />
        <Route path="/certificates" element={<CertificateListPage />} />
        <Route path="/audit-logs" element={<AuditLogPage />} />
        <Route path="/courses" element={<CourseManagementPage />} />
        <Route path="/users" element={<UserManagementPage />} />
        <Route path="/assessors" element={<AssessorListPage />} />
      </Route>

      <Route element={<ProtectedRoute allow={[ROLES.ADMIN, ROLES.PLACEMENT_OFFICER]} />}>
        <Route path="/batches" element={<BatchListPage />} />
        <Route path="/vacancies" element={<VacancyBoardPage />} />
      </Route>

      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
