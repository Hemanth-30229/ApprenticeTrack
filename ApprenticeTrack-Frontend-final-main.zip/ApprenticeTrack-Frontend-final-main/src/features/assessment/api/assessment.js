// Trade Test API (AP-20) + Assessment Result API (AP-21) via the gateway.

import api from '../../../shared/api/client';

// --- Trade tests -----------------------------------------------------------

export function listTradeTests({
  courseID,
  batchID,
  assessorID,
  status,
  fromDate,
  toDate,
  page = 0,
  size = 10,
  sort = 'testDate,desc',
} = {}) {
  const params = { page, size, sort };
  if (courseID) params.courseID = courseID;
  if (batchID) params.batchID = batchID;
  if (assessorID) params.assessorID = assessorID;
  if (status) params.status = status;
  if (fromDate) params.fromDate = fromDate;
  if (toDate) params.toDate = toDate;
  return api.get('/api/trade-tests', { params }).then((r) => r.data);
}

export function getTradeTest(id) {
  return api.get(`/api/trade-tests/${id}`).then((r) => r.data);
}

/** Create a trade test. body { courseID, batchID, assessorID, testDate, venueID }.
 * New tests start with status "Scheduled" server-side. Returns the created test. */
export function createTradeTest(body) {
  return api.post('/api/trade-tests', body).then((r) => r.data);
}

/** PUT status. body { status } */
export function updateTradeTestStatus(id, status) {
  return api.put(`/api/trade-tests/${id}/status`, { status }).then((r) => r.data);
}

// --- Assessors -------------------------------------------------------------

/** GET /api/assessors/available?courseId= -> AssessorAvailabilityDTO[]
 * { assessorID, name, email, status, scheduledTestCount }. Admin-only. */
export function listAssessorAvailability(courseId) {
  return api.get('/api/assessors/available', { params: { courseId } }).then((r) => r.data);
}

// --- Reassessments ---------------------------------------------------------

/** GET candidates (failed trainees needing reassessment). Returns an array. */
export function listReassessmentCandidates({ courseId, batchId } = {}) {
  const params = {};
  if (courseId) params.courseId = courseId;
  if (batchId) params.batchId = batchId;
  return api.get('/api/reassessments', { params }).then((r) => r.data);
}

/** POST { traineeID, originalTestID, newTestDate, assessorID, venueID } -> 201. */
export function scheduleReassessment(body) {
  return api.post('/api/reassessments', body).then((r) => r.data);
}

// --- Trade test results (final) --------------------------------------------

/**
 * Direct per-trainee result entry (replaces the competency grid).
 * body: { testID, results: [{ traineeID, marksObtained, maxMarks }] }.
 * marksObtained null/omitted = Absent. Returns Draft TradeTestResultResponseDTO[].
 */
export function enterTradeTestResults(testID, results) {
  return api.post('/api/trade-test-results/enter', { testID, results }).then((r) => r.data);
}

export function listTradeTestResults({
  testID,
  traineeID,
  overallOutcome,
  reassessmentRequired, // boolean | undefined
  status,
  page = 0,
  size = 10,
  sort = 'finalResultID,desc',
} = {}) {
  const params = { page, size, sort };
  if (testID) params.testID = testID;
  if (traineeID) params.traineeID = traineeID;
  if (overallOutcome) params.overallOutcome = overallOutcome;
  if (reassessmentRequired !== undefined && reassessmentRequired !== '')
    params.reassessmentRequired = reassessmentRequired;
  if (status) params.status = status;
  return api.get('/api/trade-test-results', { params }).then((r) => r.data);
}

/** PUT /{id}/publish -> published TradeTestResultResponseDTO. */
export function publishTradeTestResult(id) {
  return api.put(`/api/trade-test-results/${id}/publish`).then((r) => r.data);
}

/** PUT /bulk-publish { finalResultIDs:[] } -> { totalRequested, published:[], failed:[] }. */
export function bulkPublishTradeTestResults(finalResultIDs) {
  return api.put('/api/trade-test-results/bulk-publish', { finalResultIDs }).then((r) => r.data);
}
