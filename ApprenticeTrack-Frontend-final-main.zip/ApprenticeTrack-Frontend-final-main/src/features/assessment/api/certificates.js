// Certificate API (AP-24) via the gateway.

import api from '../../../shared/api/client';

export function listCertificates({
  traineeID,
  courseID,
  qualificationLevel,
  status,
  page = 0,
  size = 10,
  sort = 'issuedDate,desc',
} = {}) {
  const params = { page, size, sort };
  if (traineeID) params.traineeID = traineeID;
  if (courseID) params.courseID = courseID;
  if (qualificationLevel) params.qualificationLevel = qualificationLevel;
  if (status) params.status = status;
  return api.get('/api/certificates', { params }).then((r) => r.data);
}

/** POST /generate { traineeID, courseID } -> CertificateResponseDTO (201). */
export function generateCertificate(body) {
  return api.post('/api/certificates/generate', body).then((r) => r.data);
}

/** PUT /{id}/revoke { revocationReason } */
export function revokeCertificate(id, revocationReason) {
  return api.put(`/api/certificates/${id}/revoke`, { revocationReason }).then((r) => r.data);
}

/** GET /{id}/download -> full axios response with a PDF blob (responseType blob). */
export function downloadCertificate(id) {
  return api.get(`/api/certificates/${id}/download`, { responseType: 'blob' });
}
