// Client-side fallback store for the online trade-test feature.
//
// The question/attempt endpoints are an assumed backend contract that may not
// be deployed yet (the gateway returns 404 "No static resource ..."). To keep
// the feature usable, testQuestions.js falls back to this localStorage-backed
// store when the network call fails with a not-found/unavailable error.
//
// NOTE: localStorage is per-browser/per-device, so questions authored on one
// machine won't reach a trainee on another. This is a demo/single-machine
// fallback; real multi-user use requires the backend endpoints.

const QKEY = (testID) => `apt.test-questions.${testID}`;
const AKEY = (testID) => `apt.test-attempts.${testID}`;
const Q_PREFIX = 'apt.test-questions.';
const A_PREFIX = 'apt.test-attempts.';

function read(key) {
  try {
    return JSON.parse(localStorage.getItem(key)) || [];
  } catch {
    return [];
  }
}
function write(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}
function newId() {
  return Date.now() * 1000 + Math.floor(Math.random() * 1000);
}
function keysWithPrefix(prefix) {
  const keys = [];
  for (let i = 0; i < localStorage.length; i += 1) {
    const k = localStorage.key(i);
    if (k && k.startsWith(prefix)) keys.push(k);
  }
  return keys;
}
const sameId = (a, b) => String(a) === String(b);

export const localTestStore = {
  // --- questions ---
  listQuestions(testID) {
    return read(QKEY(testID))
      .slice()
      .sort((a, b) => (a.sequence ?? 0) - (b.sequence ?? 0));
  },

  createQuestion(testID, body) {
    const list = read(QKEY(testID));
    const question = { ...body, questionID: newId(), testID: Number(testID), sequence: list.length + 1 };
    list.push(question);
    write(QKEY(testID), list);
    return question;
  },

  updateQuestion(questionID, body) {
    for (const key of keysWithPrefix(Q_PREFIX)) {
      const list = read(key);
      const idx = list.findIndex((q) => sameId(q.questionID, questionID));
      if (idx >= 0) {
        list[idx] = { ...list[idx], ...body, questionID: list[idx].questionID, testID: list[idx].testID };
        write(key, list);
        return list[idx];
      }
    }
    throw new Error('Question not found');
  },

  deleteQuestion(questionID) {
    for (const key of keysWithPrefix(Q_PREFIX)) {
      const list = read(key);
      const idx = list.findIndex((q) => sameId(q.questionID, questionID));
      if (idx >= 0) {
        list.splice(idx, 1);
        // Re-number remaining questions so sequence stays 1..n.
        list.forEach((q, i) => { q.sequence = i + 1; });
        write(key, list);
        return { deleted: true };
      }
    }
    return { deleted: false };
  },

  // --- attempts ---
  listAttempts(testID) {
    return read(AKEY(testID));
  },

  getMyAttempt(testID, traineeID) {
    return read(AKEY(testID)).filter((a) => sameId(a.traineeID, traineeID));
  },

  submitAttempt(testID, body) {
    const questions = read(QKEY(testID));
    const byId = {};
    questions.forEach((q) => { byId[q.questionID] = q; });

    let autoScore = 0;
    let autoMaxScore = 0;
    let maxScore = 0;
    const answers = (body.answers || []).map((ans) => {
      const q = byId[ans.questionID] || {};
      const marks = Number(q.marks) || 0;
      maxScore += marks;
      if (q.questionType === 'MultipleChoice') {
        autoMaxScore += marks;
        const isCorrect = ans.selectedOptionIndex != null && ans.selectedOptionIndex === q.correctOptionIndex;
        if (isCorrect) autoScore += marks;
        return {
          questionID: ans.questionID,
          questionType: 'MultipleChoice',
          marks,
          selectedOptionIndex: ans.selectedOptionIndex ?? null,
          correctOptionIndex: q.correctOptionIndex,
          isCorrect,
        };
      }
      return {
        questionID: ans.questionID,
        questionType: 'Coding',
        marks,
        codeAnswer: ans.codeAnswer ?? '',
        marksAwarded: null,
      };
    });

    const hasCoding = answers.some((a) => a.questionType === 'Coding');
    const attempt = {
      attemptID: newId(),
      testID: Number(testID),
      traineeID: body.traineeID,
      traineeName: body.traineeName,
      status: hasCoding ? 'Submitted' : 'Graded',
      autoScore,
      autoMaxScore,
      totalScore: hasCoding ? null : autoScore,
      maxScore,
      submittedAt: new Date().toISOString(),
      answers,
    };

    const list = read(AKEY(testID));
    const idx = list.findIndex((a) => sameId(a.traineeID, body.traineeID));
    if (idx >= 0) list[idx] = attempt;
    else list.push(attempt);
    write(AKEY(testID), list);
    return attempt;
  },

  gradeAttempt(attemptID, body) {
    const gradeByQ = {};
    (body.grades || []).forEach((g) => { gradeByQ[g.questionID] = Number(g.marksAwarded); });

    for (const key of keysWithPrefix(A_PREFIX)) {
      const list = read(key);
      const idx = list.findIndex((a) => sameId(a.attemptID, attemptID));
      if (idx >= 0) {
        const attempt = list[idx];
        attempt.answers = (attempt.answers || []).map((a) =>
          a.questionType === 'Coding' && gradeByQ[a.questionID] != null
            ? { ...a, marksAwarded: gradeByQ[a.questionID] }
            : a
        );
        const codingTotal = attempt.answers
          .filter((a) => a.questionType === 'Coding')
          .reduce((sum, a) => sum + (Number(a.marksAwarded) || 0), 0);
        attempt.totalScore = (Number(attempt.autoScore) || 0) + codingTotal;
        attempt.status = 'Graded';
        list[idx] = attempt;
        write(key, list);
        return attempt;
      }
    }
    throw new Error('Attempt not found');
  },
};

/** True when an axios error means the endpoint is missing/unavailable (use fallback). */
export function isEndpointUnavailable(err) {
  const status = err?.response?.status;
  return !err?.response || status === 404 || status === 405 || status === 501 || status === 502 || status === 503;
}
