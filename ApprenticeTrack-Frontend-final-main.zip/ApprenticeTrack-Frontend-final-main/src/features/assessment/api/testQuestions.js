// Online trade-test question paper + trainee attempts, via the gateway.
//
// NOTE: these endpoints are the assumed backend contract for the question-based
// testing feature. They follow the existing /api/* gateway conventions used by
// the rest of the assessment service. The UI is built against this contract.
//
// Question shape:
//   { questionID, testID, questionType: 'MultipleChoice'|'Coding', questionText,
//     marks, sequence,
//     options: [{ optionText }], correctOptionIndex,   // MultipleChoice
//     language, starterCode }                          // Coding
//
// Attempt shape:
//   { attemptID, testID, traineeID, traineeName, status: 'Submitted'|'Graded',
//     autoScore, autoMaxScore, totalScore, maxScore, submittedAt,
//     answers: [{ questionID, questionType, questionText, marks,
//                 selectedOptionIndex, correctOptionIndex, isCorrect,   // MCQ
//                 codeAnswer, marksAwarded }] }                          // Coding

import api from '../../../shared/api/client';
import { isEndpointUnavailable, localTestStore } from './localTestStore';

const TESTS = '/api/trade-tests';

// Try the real gateway endpoint; if it's missing/unavailable (backend not
// deployed yet), transparently fall back to the localStorage store so the
// feature keeps working. Any other error (auth, validation, 500) is rethrown.
async function withFallback(networkFn, localFn) {
  try {
    return await networkFn();
  } catch (err) {
    if (isEndpointUnavailable(err)) return localFn();
    throw err;
  }
}

// --- Question authoring (assessor) -----------------------------------------

/** GET all questions for a test (array or Page). */
export function listTestQuestions(testID) {
  return withFallback(
    () => api.get(`${TESTS}/${testID}/questions`).then((r) => r.data),
    () => localTestStore.listQuestions(testID)
  );
}

/** POST a new question to a test. */
export function createTestQuestion(testID, body) {
  return withFallback(
    () => api.post(`${TESTS}/${testID}/questions`, body).then((r) => r.data),
    () => localTestStore.createQuestion(testID, body)
  );
}

export function updateTestQuestion(questionID, body) {
  return withFallback(
    () => api.put(`/api/test-questions/${questionID}`, body).then((r) => r.data),
    () => localTestStore.updateQuestion(questionID, body)
  );
}

export function deleteTestQuestion(questionID) {
  return withFallback(
    () => api.delete(`/api/test-questions/${questionID}`).then((r) => r.data),
    () => localTestStore.deleteQuestion(questionID)
  );
}

// --- Attempts (trainee submits, assessor reviews) --------------------------

/** GET the signed-in trainee's own attempt for a test (array/Page; may be empty). */
export function getMyTestAttempt(testID, traineeID) {
  return withFallback(
    () => api.get(`${TESTS}/${testID}/attempts`, { params: { traineeID } }).then((r) => r.data),
    () => localTestStore.getMyAttempt(testID, traineeID)
  );
}

/**
 * POST a trainee's submission. body:
 *   { traineeID, answers: [{ questionID, selectedOptionIndex?, codeAnswer? }] }
 * Returns the graded attempt (MCQ auto-scored; coding left for manual review).
 */
export function submitTestAttempt(testID, body) {
  return withFallback(
    () => api.post(`${TESTS}/${testID}/attempts`, body).then((r) => r.data),
    () => localTestStore.submitAttempt(testID, body)
  );
}

/** GET every trainee attempt for a test (assessor review). */
export function listTestAttempts(testID) {
  return withFallback(
    () => api.get(`${TESTS}/${testID}/attempts`).then((r) => r.data),
    () => localTestStore.listAttempts(testID)
  );
}

/**
 * PUT manual marks for coding answers. body:
 *   { grades: [{ questionID, marksAwarded }] }
 * Returns the updated (now Graded) attempt.
 */
export function gradeTestAttempt(attemptID, body) {
  return withFallback(
    () => api.put(`/api/test-attempts/${attemptID}/grade`, body).then((r) => r.data),
    () => localTestStore.gradeAttempt(attemptID, body)
  );
}
