// Author / edit a single trade-test question. Supports MultipleChoice
// (2–6 options with exactly one marked correct, auto-graded) and Coding
// (a prompt + optional starter code, graded manually by the assessor).

import { useMemo, useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import { CODING_LANGUAGES, QUESTION_TYPES, QUESTION_TYPE_LABEL } from '../../constants/testQuestion';

const MAX_OPTIONS = 6;

function emptyForm() {
  return {
    questionType: 'MultipleChoice',
    questionText: '',
    marks: '1',
    options: ['', ''],
    correctOptionIndex: 0,
    language: CODING_LANGUAGES[0],
    starterCode: '',
  };
}

function fromQuestion(q) {
  return {
    questionType: q.questionType || 'MultipleChoice',
    questionText: q.questionText ?? '',
    marks: String(q.marks ?? '1'),
    options: (q.options || []).map((o) => o.optionText ?? '') .concat(['', '']).slice(0, Math.max(2, (q.options || []).length)),
    correctOptionIndex: q.correctOptionIndex ?? 0,
    language: q.language || CODING_LANGUAGES[0],
    starterCode: q.starterCode ?? '',
  };
}

export default function QuestionFormModal({ question, onClose, onSubmit }) {
  const isEdit = Boolean(question);
  const [form, setForm] = useState(() => (isEdit ? fromQuestion(question) : emptyForm()));
  const [touched, setTouched] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const isMcq = form.questionType === 'MultipleChoice';
  const set = (f, v) => setForm((s) => ({ ...s, [f]: v }));

  const errors = useMemo(() => {
    const e = {};
    if (!form.questionText.trim()) e.questionText = 'Question text is required';
    if (!/^\d+$/.test(String(form.marks).trim()) || Number(form.marks) < 1)
      e.marks = 'Marks must be a whole number of at least 1';
    if (isMcq) {
      const filled = form.options.map((o) => o.trim());
      if (filled.filter(Boolean).length < 2) e.options = 'Provide at least two options';
      else if (!filled[form.correctOptionIndex]) e.correctOptionIndex = 'Mark a non-empty option as correct';
    }
    return e;
  }, [form, isMcq]);

  const isValid = Object.keys(errors).length === 0;
  const err = (f) => (touched && errors[f] ? errors[f] : '');

  function setOption(i, value) {
    setForm((s) => {
      const options = [...s.options];
      options[i] = value;
      return { ...s, options };
    });
  }
  function addOption() {
    setForm((s) => (s.options.length >= MAX_OPTIONS ? s : { ...s, options: [...s.options, ''] }));
  }
  function removeOption(i) {
    setForm((s) => {
      if (s.options.length <= 2) return s;
      const options = s.options.filter((_, idx) => idx !== i);
      let correctOptionIndex = s.correctOptionIndex;
      if (i === correctOptionIndex) correctOptionIndex = 0;
      else if (i < correctOptionIndex) correctOptionIndex -= 1;
      return { ...s, options, correctOptionIndex };
    });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched(true);
    if (!isValid) return;
    setSubmitting(true);
    try {
      const base = {
        questionType: form.questionType,
        questionText: form.questionText.trim(),
        marks: Number(form.marks),
      };
      const payload = isMcq
        ? {
            ...base,
            // Drop blank trailing options and re-map the correct index onto the kept list.
            ...(() => {
              const kept = [];
              let correctOptionIndex = 0;
              form.options.forEach((o, idx) => {
                if (o.trim()) {
                  if (idx === form.correctOptionIndex) correctOptionIndex = kept.length;
                  kept.push({ optionText: o.trim() });
                }
              });
              return { options: kept, correctOptionIndex };
            })(),
          }
        : { ...base, language: form.language, starterCode: form.starterCode };
      await onSubmit(payload);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title={isEdit ? 'Edit Question' : 'Add Question'} onClose={onClose} size="lg">
      <form className="form" onSubmit={handleSubmit} noValidate>
        <div className="form__grid">
          <div className="field">
            <label className="field__label" htmlFor="q-type">Question Type</label>
            <select
              id="q-type"
              className="field__input"
              value={form.questionType}
              onChange={(e) => set('questionType', e.target.value)}
              disabled={isEdit}
            >
              {QUESTION_TYPES.map((t) => (
                <option key={t} value={t}>{QUESTION_TYPE_LABEL[t]}</option>
              ))}
            </select>
          </div>
          <div className="field">
            <label className="field__label" htmlFor="q-marks">
              Marks<span className="field__req" aria-hidden="true"> *</span>
            </label>
            <input
              id="q-marks"
              type="number"
              min="1"
              className="field__input"
              value={form.marks}
              onChange={(e) => set('marks', e.target.value)}
              aria-invalid={Boolean(err('marks'))}
            />
            {err('marks') && <p className="field__error" role="alert">{err('marks')}</p>}
          </div>
        </div>

        <div className="field">
          <label className="field__label" htmlFor="q-text">
            Question<span className="field__req" aria-hidden="true"> *</span>
          </label>
          <textarea
            id="q-text"
            className="field__input"
            rows={3}
            value={form.questionText}
            onChange={(e) => set('questionText', e.target.value)}
            aria-invalid={Boolean(err('questionText'))}
          />
          {err('questionText') && <p className="field__error" role="alert">{err('questionText')}</p>}
        </div>

        {isMcq ? (
          <fieldset className="q-options">
            <legend className="field__label">Options (select the correct answer)</legend>
            {form.options.map((opt, i) => (
              <div key={i} className="q-option-row">
                <input
                  type="radio"
                  name="correct-option"
                  className="q-option-radio"
                  checked={form.correctOptionIndex === i}
                  onChange={() => set('correctOptionIndex', i)}
                  aria-label={`Mark option ${i + 1} correct`}
                />
                <input
                  type="text"
                  className="field__input q-option-input"
                  placeholder={`Option ${i + 1}`}
                  value={opt}
                  onChange={(e) => setOption(i, e.target.value)}
                />
                <button
                  type="button"
                  className="btn btn--secondary btn--sm"
                  onClick={() => removeOption(i)}
                  disabled={form.options.length <= 2}
                  aria-label={`Remove option ${i + 1}`}
                >
                  ×
                </button>
              </div>
            ))}
            {(err('options') || err('correctOptionIndex')) && (
              <p className="field__error" role="alert">{err('options') || err('correctOptionIndex')}</p>
            )}
            {form.options.length < MAX_OPTIONS && (
              <button type="button" className="btn btn--secondary btn--sm" onClick={addOption}>
                + Add option
              </button>
            )}
          </fieldset>
        ) : (
          <div className="form__grid">
            <div className="field">
              <label className="field__label" htmlFor="q-lang">Language</label>
              <select
                id="q-lang"
                className="field__input"
                value={form.language}
                onChange={(e) => set('language', e.target.value)}
              >
                {CODING_LANGUAGES.map((l) => <option key={l} value={l}>{l}</option>)}
              </select>
            </div>
            <div className="field field--full">
              <label className="field__label" htmlFor="q-starter">Starter Code (optional)</label>
              <textarea
                id="q-starter"
                className="field__input code-input"
                rows={5}
                value={form.starterCode}
                onChange={(e) => set('starterCode', e.target.value)}
                spellCheck={false}
              />
            </div>
          </div>
        )}

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={submitting}>Cancel</button>
          <button type="submit" className="btn btn--primary" disabled={!isValid || submitting} aria-busy={submitting}>
            {submitting && <Spinner size={16} inline label="Saving" />}
            {isEdit ? 'Save Changes' : 'Add Question'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
