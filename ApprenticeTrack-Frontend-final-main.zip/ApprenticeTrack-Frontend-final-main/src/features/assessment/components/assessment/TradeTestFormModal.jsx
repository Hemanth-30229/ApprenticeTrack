// Schedule a new trade test. The assessor picks a course + one of that course's
// batches, a future test date, and a venue. assessorID is supplied by the page
// (the signed-in assessor). New tests start as "Scheduled" server-side.

import { cloneElement, isValidElement, useEffect, useMemo, useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import { listBatches } from '../../../training/api/batches';

function tomorrowISO() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10);
}
function isPosInt(v) {
  return /^\d+$/.test(String(v).trim()) && Number(v) > 0;
}

function emptyForm() {
  return { courseID: '', batchID: '', testDate: '', venueID: '' };
}

export default function TradeTestFormModal({ courses, assessorID, onClose, onSubmit }) {
  const [form, setForm] = useState(emptyForm);
  const [touched, setTouched] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const [batches, setBatches] = useState([]);
  const [batchesLoading, setBatchesLoading] = useState(false);

  // Load batches for the chosen course; reset the batch selection when it changes.
  useEffect(() => {
    if (!form.courseID) {
      setBatches([]);
      return;
    }
    let alive = true;
    setBatchesLoading(true);
    listBatches({ courseID: Number(form.courseID), size: 500 })
      .then((data) => {
        if (alive) setBatches(data.content || []);
      })
      .catch(() => {
        if (alive) setBatches([]);
      })
      .finally(() => {
        if (alive) setBatchesLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [form.courseID]);

  const errors = useMemo(() => {
    const e = {};
    if (!form.courseID) e.courseID = 'Course is required';
    if (!form.batchID) e.batchID = 'Batch is required';
    if (!form.testDate) e.testDate = 'Test date is required';
    else if (form.testDate < tomorrowISO()) e.testDate = 'Test date must be in the future';
    if (!isPosInt(form.venueID)) e.venueID = 'Enter a valid venue ID';
    return e;
  }, [form]);

  const isValid = Object.keys(errors).length === 0;
  const set = (f, v) => setForm((s) => ({ ...s, [f]: v }));
  const blur = (f) => setTouched((t) => ({ ...t, [f]: true }));
  const err = (f) => (touched[f] && errors[f] ? errors[f] : '');

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched({ courseID: true, batchID: true, testDate: true, venueID: true });
    if (!isValid) return;
    setSubmitting(true);
    try {
      await onSubmit({
        courseID: Number(form.courseID),
        batchID: Number(form.batchID),
        assessorID,
        testDate: form.testDate,
        venueID: Number(form.venueID),
      });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="Schedule Trade Test" onClose={onClose} size="md">
      <form className="form" onSubmit={handleSubmit} noValidate>
        <div className="form__grid">
          <Field label="Course" error={err('courseID')} required>
            <select
              className="field__input"
              value={form.courseID}
              onChange={(e) => set('courseID', e.target.value)}
              onBlur={() => blur('courseID')}
              aria-invalid={Boolean(err('courseID'))}
            >
              <option value="">Select a course…</option>
              {courses.map((c) => (
                <option key={c.courseID} value={c.courseID}>{c.courseName} ({c.tradeCode})</option>
              ))}
            </select>
          </Field>
          <Field label="Batch" error={err('batchID')} required>
            <select
              className="field__input"
              value={form.batchID}
              onChange={(e) => set('batchID', e.target.value)}
              onBlur={() => blur('batchID')}
              disabled={!form.courseID || batchesLoading}
              aria-invalid={Boolean(err('batchID'))}
            >
              <option value="">
                {!form.courseID
                  ? 'Select a course first…'
                  : batchesLoading
                    ? 'Loading batches…'
                    : batches.length === 0
                      ? 'No batches for this course'
                      : 'Select a batch…'}
              </option>
              {batches.map((b) => (
                <option key={b.batchID} value={b.batchID}>{b.batchCode || `Batch #${b.batchID}`}</option>
              ))}
            </select>
          </Field>
          <Field label="Test Date" error={err('testDate')} required>
            <input
              type="date"
              className="field__input"
              min={tomorrowISO()}
              value={form.testDate}
              onChange={(e) => set('testDate', e.target.value)}
              onBlur={() => blur('testDate')}
              aria-invalid={Boolean(err('testDate'))}
            />
          </Field>
          <Field label="Venue ID" error={err('venueID')} required>
            <input
              type="number"
              min="1"
              className="field__input"
              value={form.venueID}
              onChange={(e) => set('venueID', e.target.value)}
              onBlur={() => blur('venueID')}
              aria-invalid={Boolean(err('venueID'))}
            />
          </Field>
        </div>

        <p className="form__note">New trade tests start with status “Scheduled”.</p>

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={submitting}>Cancel</button>
          <button type="submit" className="btn btn--primary" disabled={!isValid || submitting} aria-busy={submitting}>
            {submitting && <Spinner size={16} inline label="Saving" />}
            Schedule Test
          </button>
        </div>
      </form>
    </Modal>
  );
}

function Field({ label, error, required, children }) {
  const id = label.replace(/[^a-z0-9]+/gi, '-').toLowerCase();
  return (
    <div className="field">
      <label className="field__label" htmlFor={id}>
        {label}
        {required && <span className="field__req" aria-hidden="true"> *</span>}
      </label>
      {isValidElement(children)
        ? cloneElement(children, { id, 'aria-describedby': error ? `${id}-error` : undefined })
        : children}
      {error && <p id={`${id}-error`} className="field__error" role="alert">{error}</p>}
    </div>
  );
}
