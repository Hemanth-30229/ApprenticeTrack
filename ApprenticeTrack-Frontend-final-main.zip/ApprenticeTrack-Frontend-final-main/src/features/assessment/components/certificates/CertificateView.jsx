// Minimal, printable certificate. Rendered in a modal; the .print-area class
// (global print CSS) isolates just the certificate for "Save as PDF".

import Modal from '../../../../shared/ui/Modal';
import { formatDate } from '../../../../shared/format';
import './certificate.css';

export default function CertificateView({ cert, traineeName, onClose }) {
  const revoked = cert.status === 'Revoked';
  const name = cert.traineeName || traineeName || `Trainee #${cert.traineeID}`;

  return (
    <Modal title="Certificate" onClose={onClose} size="lg">
      <div className={`certificate print-area ${revoked ? 'certificate--revoked' : ''}`}>
        <div className="certificate__seal" aria-hidden="true">AT</div>
        <p className="certificate__kicker">Certificate of Trade Competency</p>
        <h2 className="certificate__title">ApprenticeTrack</h2>

        <p className="certificate__lead">This is to certify that</p>
        <p className="certificate__name">{name}</p>
        <p className="certificate__lead">has successfully completed</p>

        <p className="certificate__course">{cert.courseName || `Course #${cert.courseID}`}</p>
        <p className="certificate__level">{cert.qualificationLevel}</p>

        <dl className="certificate__meta">
          <div><dt>Certificate No.</dt><dd>{cert.certificateNumber || '—'}</dd></div>
          <div><dt>Issued</dt><dd>{formatDate(cert.issuedDate)}</dd></div>
          <div><dt>Authority</dt><dd>{cert.issuedByName || 'ApprenticeTrack'}</dd></div>
        </dl>

        {revoked && (
          <p className="certificate__revoked">
            REVOKED{cert.revocationReason ? ` — ${cert.revocationReason}` : ''}
          </p>
        )}
      </div>

      <div className="modal__actions no-print">
        <button type="button" className="btn btn--secondary" onClick={onClose}>Close</button>
        <button type="button" className="btn btn--primary" onClick={() => window.print()}>
          Print / Save as PDF
        </button>
      </div>
    </Modal>
  );
}
