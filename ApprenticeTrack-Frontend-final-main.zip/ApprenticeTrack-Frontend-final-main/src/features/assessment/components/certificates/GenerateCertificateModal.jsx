// Generate a certificate. The eligible-trainee list is derived from PUBLISHED
// PASS trade-test results; selecting a trainee narrows the course dropdown to
// the course(s) they passed. A live preview is shown, then a confirmation.

import { useEffect, useMemo, useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import ConfirmDialog from '../../../../shared/ui/ConfirmDialog';
import Spinner from '../../../../shared/Spinner';
import SearchableSelect from '../../../../shared/ui/SearchableSelect';
import { listTradeTestResults } from '../../api/assessment';
import { formatDate } from '../../../../shared/format';

export default function GenerateCertificateModal({ onClose, onGenerate }) {
  const [passResults, setPassResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');

  const [traineeID, setTraineeID] = useState(null);
  const [traineeName, setTraineeName] = useState('');
  const [courseID, setCourseID] = useState('');
  const [confirming, setConfirming] = useState(false);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      try {
        const data = await listTradeTestResults({
          status: 'Published',
          overallOutcome: 'Pass',
          page: 0,
          size: 200,
        });
        if (alive) setPassResults(data.content || []);
      } catch {
        if (alive) setLoadError('Could not load eligible trainees.');
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  // Unique eligible trainees (passed at least one published test).
  const eligibleTrainees = useMemo(() => {
    const map = new Map();
    passResults.forEach((r) => {
      if (!map.has(r.traineeID)) map.set(r.traineeID, r.traineeName || `Trainee #${r.traineeID}`);
    });
    return Array.from(map, ([value, name]) => ({ value, name }));
  }, [passResults]);

  // Courses the selected trainee passed.
  const coursesForTrainee = useMemo(() => {
    const map = new Map();
    passResults
      .filter((r) => r.traineeID === traineeID)
      .forEach((r) => map.set(r.courseID, r.courseName || `Course #${r.courseID}`));
    return Array.from(map, ([id, name]) => ({ courseID: id, courseName: name }));
  }, [passResults, traineeID]);

  const selectedCourse = coursesForTrainee.find((c) => String(c.courseID) === String(courseID));

  function fetchTraineeOptions(query) {
    const q = query.toLowerCase();
    const opts = eligibleTrainees
      .filter((t) => t.name.toLowerCase().includes(q))
      .map((t) => ({ value: t.value, label: t.name, name: t.name }));
    return Promise.resolve(opts);
  }

  async function doGenerate() {
    setGenerating(true);
    try {
      await onGenerate({ traineeID: Number(traineeID), courseID: Number(courseID) });
    } finally {
      setGenerating(false);
      setConfirming(false);
    }
  }

  const canGenerate = traineeID && courseID;

  return (
    <>
      <Modal title="Generate Certificate" onClose={onClose} size="md">
        {loading ? (
          <p className="widget__empty"><Spinner size={18} inline label="Loading" /> Loading eligible trainees…</p>
        ) : loadError ? (
          <p className="field__error" role="alert">{loadError}</p>
        ) : eligibleTrainees.length === 0 ? (
          <p className="widget__empty">No trainees have published Pass results yet.</p>
        ) : (
          <div className="form">
            <div className="field">
              <label className="field__label" htmlFor="cert-trainee">
                Trainee <span className="field__req" aria-hidden="true">*</span>
              </label>
              <SearchableSelect
                value={traineeID}
                selectedLabel={traineeName}
                placeholder="Search trainees who passed…"
                fetchOptions={fetchTraineeOptions}
                onSelect={(opt) => {
                  setTraineeID(opt.value);
                  setTraineeName(opt.name);
                  setCourseID('');
                }}
              />
              <p className="field__hint">Only trainees with published Pass results are listed.</p>
            </div>

            <div className="field">
              <label className="field__label" htmlFor="cert-course">
                Course <span className="field__req" aria-hidden="true">*</span>
              </label>
              <select
                id="cert-course"
                className="field__input"
                value={courseID}
                disabled={!traineeID}
                onChange={(e) => setCourseID(e.target.value)}
              >
                <option value="">{traineeID ? 'Select a passed course…' : 'Select a trainee first'}</option>
                {coursesForTrainee.map((c) => (
                  <option key={c.courseID} value={c.courseID}>{c.courseName}</option>
                ))}
              </select>
            </div>

            {/* Live preview */}
            {canGenerate && (
              <div className="cert-preview" aria-label="Certificate preview">
                <span className="cert-preview__kicker">Certificate of Trade Competency</span>
                <span className="cert-preview__name">{traineeName}</span>
                <span className="cert-preview__course">{selectedCourse?.courseName}</span>
                <span className="cert-preview__date">Issue date: {formatDate(new Date().toISOString())}</span>
                <span className="cert-preview__note">Certificate number &amp; qualification level assigned on generation.</span>
              </div>
            )}

            <div className="modal__actions">
              <button type="button" className="btn btn--secondary" onClick={onClose}>Cancel</button>
              <button type="button" className="btn btn--primary" disabled={!canGenerate} onClick={() => setConfirming(true)}>
                Generate Certificate
              </button>
            </div>
          </div>
        )}
      </Modal>

      {confirming && (
        <ConfirmDialog
          title="Generate certificate?"
          message={`Generate a certificate for "${traineeName}" in ${selectedCourse?.courseName}? This issues an official certificate.`}
          confirmLabel="Generate"
          tone="primary"
          busy={generating}
          onConfirm={doGenerate}
          onCancel={() => (generating ? null : setConfirming(false))}
        />
      )}
    </>
  );
}
