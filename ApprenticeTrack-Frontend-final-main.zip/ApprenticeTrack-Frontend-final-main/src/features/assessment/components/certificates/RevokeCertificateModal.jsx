// Revoke a certificate — revocation reason is required.

import { useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';

export default function RevokeCertificateModal({ certificate, onClose, onConfirm }) {
  const [reason, setReason] = useState('');
  const [touched, setTouched] = useState(false);
  const [busy, setBusy] = useState(false);

  const error = reason.trim() ? '' : 'A revocation reason is required';

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched(true);
    if (error) return;
    setBusy(true);
    try {
      await onConfirm(reason.trim());
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal title="Revoke certificate?" onClose={busy ? () => {} : onClose} size="sm">
      <form className="form" onSubmit={handleSubmit} noValidate>
        <p className="confirm__message">
          Revoke certificate <strong>{certificate.certificateNumber}</strong> for{' '}
          {certificate.traineeName}? This cannot be undone.
        </p>
        <div className="field">
          <label className="field__label" htmlFor="revocationReason">
            Revocation Reason <span className="field__req" aria-hidden="true">*</span>
          </label>
          <textarea
            id="revocationReason"
            className="field__input"
            rows={3}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            onBlur={() => setTouched(true)}
            aria-invalid={touched && Boolean(error)}
            aria-describedby={touched && error ? 'revoke-error' : undefined}
          />
          {touched && error && <p id="revoke-error" className="field__error" role="alert">{error}</p>}
        </div>
        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={busy}>Cancel</button>
          <button type="submit" className="btn btn--danger" disabled={Boolean(error) || busy} aria-busy={busy}>
            {busy && <Spinner size={16} inline label="Revoking" />}
            Revoke
          </button>
        </div>
      </form>
    </Modal>
  );
}
