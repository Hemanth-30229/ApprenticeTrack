// Expanded accordion for a reassessment candidate: the original test's outcome
// and attempt count. (Trade-test results are now a single per-trainee outcome,
// so there is no unit-wise breakdown to show.)

import StatusBadge from '../../../../shared/ui/StatusBadge';
import { RESULT_OUTCOME_TONE } from '../../constants/result';
import { formatDate } from '../../../../shared/format';

export default function ReassessmentHistoryAccordion({ candidate }) {
  return (
    <div className="reassess-history">
      <h4 className="reassess-history__title">Original Test</h4>
      <div className="detail-grid">
        <div className="detail-grid__row">
          <dt className="detail-grid__label">Outcome</dt>
          <dd className="detail-grid__value">
            <StatusBadge
              status={candidate.overallOutcome}
              tone={RESULT_OUTCOME_TONE[candidate.overallOutcome] || 'neutral'}
            />
          </dd>
        </div>
        <div className="detail-grid__row">
          <dt className="detail-grid__label">Original test date</dt>
          <dd className="detail-grid__value">{formatDate(candidate.originalTestDate)}</dd>
        </div>
      </div>
      {Number(candidate.reassessmentCount) > 0 && (
        <p className="reassess-history__note">
          {candidate.reassessmentCount} reassessment attempt(s) scheduled so far.
        </p>
      )}
    </div>
  );
}
