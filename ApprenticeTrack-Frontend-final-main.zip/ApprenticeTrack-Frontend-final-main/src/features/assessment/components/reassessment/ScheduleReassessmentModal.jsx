// Schedule a reassessment for one or more candidates (same date/venue/assessor).
// Enforces newTestDate >= max(originalTestDate) + 7 days across the selection.

import { useMemo, useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import { addDays, COOLING_PERIOD_DAYS } from '../../constants/reassessment';

function isPosInt(v) {
  return /^\d+$/.test(String(v).trim()) && Number(v) > 0;
}

export default function ScheduleReassessmentModal({ candidates, currentUserId, onClose, onSubmit }) {
  const isBulk = candidates.length > 1;

  // Earliest allowed date = latest original test date + 7 days.
  const minDate = useMemo(() => {
    const dates = candidates.map((c) => c.originalTestDate).filter(Boolean).sort();
    const latest = dates[dates.length - 1];
    return latest ? addDays(latest, COOLING_PERIOD_DAYS) : '';
  }, [candidates]);

  const [newTestDate, setNewTestDate] = useState('');
  const [assessorID, setAssessorID] = useState(currentUserId ? String(currentUserId) : '');
  const [venueID, setVenueID] = useState('');
  const [touched, setTouched] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [inlineError, setInlineError] = useState('');

  const errors = {
    newTestDate: !newTestDate
      ? 'New test date is required'
      : minDate && newTestDate < minDate
        ? `Must be on or after ${minDate} (7 days after the original test)`
        : '',
    assessorID: isPosInt(assessorID) ? '' : 'Enter a valid assessor ID',
    venueID: isPosInt(venueID) ? '' : 'Enter a valid venue ID',
  };
  const isValid = !errors.newTestDate && !errors.assessorID && !errors.venueID;
  const err = (f) => (touched[f] && errors[f] ? errors[f] : '');

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched({ newTestDate: true, assessorID: true, venueID: true });
    setInlineError('');
    if (!isValid) return;
    setSubmitting(true);
    try {
      await onSubmit({ newTestDate, assessorID: Number(assessorID), venueID: Number(venueID) });
      // Parent closes the modal on success.
    } catch (error) {
      setInlineError(error?.inline || 'Failed to schedule reassessment.');
      setSubmitting(false);
    }
  }

  return (
    <Modal
      title={isBulk ? `Schedule ${candidates.length} Reassessments` : 'Schedule Reassessment'}
      onClose={submitting ? () => {} : onClose}
      size="sm"
    >
      <form className="form" onSubmit={handleSubmit} noValidate>
        {isBulk && (
          <p className="confirm__message">
            Scheduling the same date, venue and assessor for {candidates.length} selected trainees.
          </p>
        )}

        {inlineError && <div className="login__banner login__banner--error" role="alert">{inlineError}</div>}

        <div className="field">
          <label className="field__label" htmlFor="newTestDate">New Test Date <span className="field__req" aria-hidden="true">*</span></label>
          <input id="newTestDate" type="date" className="field__input" min={minDate || undefined} value={newTestDate} onChange={(e) => setNewTestDate(e.target.value)} onBlur={() => setTouched((t) => ({ ...t, newTestDate: true }))} aria-invalid={Boolean(err('newTestDate'))} />
          {minDate && <p className="field__hint">Earliest allowed: {minDate}</p>}
          {err('newTestDate') && <p className="field__error" role="alert">{err('newTestDate')}</p>}
        </div>

        <div className="field">
          <label className="field__label" htmlFor="assessorID">Assessor ID <span className="field__req" aria-hidden="true">*</span></label>
          <input id="assessorID" type="number" min="1" className="field__input" value={assessorID} onChange={(e) => setAssessorID(e.target.value)} onBlur={() => setTouched((t) => ({ ...t, assessorID: true }))} aria-invalid={Boolean(err('assessorID'))} />
          <p className="field__hint">Pre-filled with you; edit to assign another assessor.</p>
          {err('assessorID') && <p className="field__error" role="alert">{err('assessorID')}</p>}
        </div>

        <div className="field">
          <label className="field__label" htmlFor="venueID">Venue ID <span className="field__req" aria-hidden="true">*</span></label>
          <input id="venueID" type="number" min="1" className="field__input" value={venueID} onChange={(e) => setVenueID(e.target.value)} onBlur={() => setTouched((t) => ({ ...t, venueID: true }))} aria-invalid={Boolean(err('venueID'))} />
          {err('venueID') && <p className="field__error" role="alert">{err('venueID')}</p>}
        </div>

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={submitting}>Cancel</button>
          <button type="submit" className="btn btn--primary" disabled={!isValid || submitting} aria-busy={submitting}>
            {submitting && <Spinner size={16} inline label="Scheduling" />}
            Schedule
          </button>
        </div>
      </form>
    </Modal>
  );
}
