// Assessment enums, tones, and the client-side outcome computation.

export const TRADE_TEST_STATUSES = ['Scheduled', 'Conducted', 'ResultsDeclared', 'Cancelled'];

export const TRADE_TEST_STATUS_TONE = {
  Scheduled: 'info',
  Conducted: 'warning',
  ResultsDeclared: 'success',
  Cancelled: 'neutral',
};

// CompetencyResultAssessmentMethod (same value set as the unit's enum).
export const ASSESSMENT_METHODS = ['Practical', 'Written', 'Observation', 'Portfolio'];

export const OUTCOME_TONE = {
  Competent: 'success', // green
  NotYetCompetent: 'danger', // red
};

// Pass threshold — mirrors backend `assessment.pass-threshold-percent` (default 60,
// inclusive >=). If the backend value is changed in config-server, update this.
export const PASS_THRESHOLD_PERCENT = 60;

// No maxMarks exists on CompetencyUnit server-side; this is the client default.
export const DEFAULT_MAX_MARKS = 100;
