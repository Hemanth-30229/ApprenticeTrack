// Certificate enums + tones.

export const QUALIFICATION_LEVELS = ['Level1', 'Level2', 'Level3', 'Level4'];

export const CERTIFICATE_STATUS_TONE = {
  Issued: 'success', // green
  Revoked: 'danger', // red
};
