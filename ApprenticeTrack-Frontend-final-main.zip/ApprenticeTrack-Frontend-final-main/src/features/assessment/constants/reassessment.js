// Reassessment rules + status derivation (mirrors backend constants).

export const MAX_ATTEMPTS = 3;
export const COOLING_PERIOD_DAYS = 7;

// The candidate DTO has no status field; we derive a best-effort UI status from
// reassessmentCount. "Reassessed - Pass" trainees drop off the candidate list
// entirely; per-attempt Pass/Fail is shown in the history accordion.
export function candidateStatus(candidate) {
  const count = Number(candidate.reassessmentCount) || 0;
  if (count === 0) return { label: 'Awaiting Reassessment', tone: 'pending' };
  return { label: 'Reassessment Scheduled', tone: 'info' };
}

export function addDays(isoDate, days) {
  if (!isoDate) return '';
  const d = new Date(isoDate);
  if (Number.isNaN(d.getTime())) return '';
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}
