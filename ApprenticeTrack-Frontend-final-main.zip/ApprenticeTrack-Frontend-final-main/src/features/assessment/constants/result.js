// Trade test result enums + tones.

export const RESULT_OUTCOMES = ['Pass', 'Fail', 'Absent'];
export const RESULT_OUTCOME_TONE = {
  Pass: 'success', // green
  Fail: 'danger', // red
  Absent: 'neutral', // grey
};

export const RESULT_STATUSES = ['Draft', 'Published'];
export const RESULT_STATUS_TONE = {
  Draft: 'info', // blue
  Published: 'success', // green
};
