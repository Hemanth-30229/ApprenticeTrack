// Online trade-test question bank enums + helpers.
//
// A scheduled trade test can carry a question paper. Two question types are
// supported: MultipleChoice (auto-graded against the correct option) and
// Coding (free-text code captured for the assessor to grade manually).

export const QUESTION_TYPES = ['MultipleChoice', 'Coding'];

export const QUESTION_TYPE_LABEL = {
  MultipleChoice: 'Multiple Choice',
  Coding: 'Coding',
};

// Languages offered for coding questions (used to hint syntax to the trainee).
export const CODING_LANGUAGES = ['Python', 'Java', 'JavaScript', 'C', 'C++', 'SQL'];

// Attempt lifecycle: Submitted (auto-graded MCQ done, coding pending) ->
// Graded (assessor has scored the coding answers).
export const ATTEMPT_STATUS_TONE = {
  Submitted: 'warning',
  Graded: 'success',
};

/** Robustly read a list payload whether the API returns an array or a Page. */
export function asList(data) {
  if (Array.isArray(data)) return data;
  return data?.content || [];
}
