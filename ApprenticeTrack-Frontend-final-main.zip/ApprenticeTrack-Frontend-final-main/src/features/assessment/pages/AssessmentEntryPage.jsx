// Assessor result entry: pick a scheduled test, load its trainee roster (from
// training-service), and enter marks per trainee. Pass/fail is derived from the
// pass threshold. Loads the roster via getBatchRoster; saves results to assessment.
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import ConfirmDialog from '../../../shared/ui/ConfirmDialog';
import { useToast } from '../../../shared/toast/ToastContext';
import {
  bulkPublishTradeTestResults,
  enterTradeTestResults,
  getTradeTest,
  listTradeTestResults,
  updateTradeTestStatus,
} from '../api/assessment';
import { getBatchRoster } from '../../training/api/enrollments';
import { DEFAULT_MAX_MARKS, PASS_THRESHOLD_PERCENT, TRADE_TEST_STATUS_TONE } from '../constants/assessment';
import { formatDate } from '../../../shared/format';
import './AssessmentEntryPage.css';

const MAX = DEFAULT_MAX_MARKS; // out of 100
const PASS_MARK = (MAX * PASS_THRESHOLD_PERCENT) / 100; // 60
const OUTCOME_TONE = { Pass: 'success', Fail: 'danger', Absent: 'neutral' };
const draftKey = (testId) => `apt.result-draft.${testId}`;

/** Blank = Absent; >= pass mark = Pass; else Fail. */
function outcomeFor(value) {
  if (value === '' || value == null) return 'Absent';
  const n = Number(value);
  if (Number.isNaN(n)) return 'Absent';
  return n >= PASS_MARK ? 'Pass' : 'Fail';
}

export default function AssessmentEntryPage() {
  const { testId } = useParams();
  const toast = useToast();

  const [test, setTest] = useState(null);
  const [roster, setRoster] = useState([]);
  const [existing, setExisting] = useState({}); // traineeID -> result row
  const [marks, setMarks] = useState({}); // traineeID -> string
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [conductingBusy, setConductingBusy] = useState(false);
  const [declareOpen, setDeclareOpen] = useState(false);
  const [declaring, setDeclaring] = useState(false);

  const loadResults = useCallback(async () => {
    const res = await listTradeTestResults({ testID: testId, size: 500 });
    const map = {};
    (res.content || []).forEach((r) => { map[r.traineeID] = r; });
    setExisting(map);
    return map;
  }, [testId]);

  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      setError('');
      try {
        const t = await getTradeTest(testId);
        const rosterList = await getBatchRoster(t.batchID);
        const map = await loadResults();
        if (!alive) return;
        setTest(t);
        setRoster(rosterList);
        // Pre-fill from existing results, then overlay any local draft.
        const initial = {};
        rosterList.forEach((tr) => {
          const ex = map[tr.traineeID];
          if (ex && ex.marksObtained != null) initial[tr.traineeID] = String(ex.marksObtained);
        });
        try {
          const saved = JSON.parse(localStorage.getItem(draftKey(testId)) || '{}');
          if (saved && typeof saved === 'object') Object.assign(initial, saved);
        } catch { /* ignore malformed draft */ }
        setMarks(initial);
      } catch {
        if (alive) setError('Could not load the trade test. Please try again.');
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => { alive = false; };
  }, [testId, loadResults]);

  const editable = test?.status === 'Conducted';
  const isLocked = useCallback((traineeID) => existing[traineeID]?.status === 'Published', [existing]);

  function setMark(traineeID, value) {
    setMarks((m) => ({ ...m, [traineeID]: value }));
  }

  const invalidMark = (v) => {
    if (v === '' || v == null) return false; // blank = Absent, allowed
    const n = Number(v);
    return Number.isNaN(n) || n < 0 || n > MAX;
  };
  const anyInvalid = roster.some((tr) => !isLocked(tr.traineeID) && invalidMark(marks[tr.traineeID]));

  const stats = useMemo(() => {
    let published = 0;
    let entered = 0;
    roster.forEach((tr) => {
      if (isLocked(tr.traineeID)) published += 1;
      else if ((marks[tr.traineeID] ?? '') !== '') entered += 1;
    });
    return { published, entered, total: roster.length };
  }, [roster, marks, isLocked]);

  function saveDraft() {
    localStorage.setItem(draftKey(testId), JSON.stringify(marks));
    toast.success('Draft saved on this device.');
  }

  async function markConducted() {
    setConductingBusy(true);
    try {
      const updated = await updateTradeTestStatus(testId, 'Conducted');
      setTest(updated);
      toast.success('Test marked as Conducted. You can now enter results.');
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Could not update the test status.');
    } finally {
      setConductingBusy(false);
    }
  }

  async function submitResults() {
    if (anyInvalid) {
      toast.error(`Marks must be 0–${MAX}, or left blank to mark Absent.`);
      return;
    }
    const results = roster
      .filter((tr) => !isLocked(tr.traineeID))
      .map((tr) => {
        const v = marks[tr.traineeID];
        return {
          traineeID: tr.traineeID,
          marksObtained: v === '' || v == null ? null : Number(v),
          maxMarks: MAX,
        };
      });
    if (results.length === 0) {
      toast.info('All results are already published.');
      return;
    }
    setSubmitting(true);
    try {
      await enterTradeTestResults(testId, results);
      localStorage.removeItem(draftKey(testId));
      await loadResults();
      toast.success('Results saved. Use “Declare Results” to publish them to trainees.');
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to save results.');
    } finally {
      setSubmitting(false);
    }
  }

  async function declareResults() {
    setDeclaring(true);
    try {
      const page = await listTradeTestResults({ testID: testId, status: 'Draft', size: 500 });
      const draftIds = (page.content || []).map((r) => r.finalResultID);
      if (draftIds.length === 0) {
        toast.info('No saved results to declare. Enter and submit results first.');
      } else {
        const res = await bulkPublishTradeTestResults(draftIds);
        const published = res.published?.length ?? draftIds.length;
        const failed = res.failed?.length ?? 0;
        toast.success(
          failed === 0 ? `${published} result(s) declared.` : `${published} declared, ${failed} failed.`
        );
      }
      const t = await getTradeTest(testId);
      setTest(t);
      await loadResults();
      setDeclareOpen(false);
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to declare results.');
    } finally {
      setDeclaring(false);
    }
  }

  if (loading) {
    return (
      <div className="dash">
        <main className="page">
          <div className="table__state"><Spinner size={24} label="Loading" /> Loading test…</div>
        </main>
      </div>
    );
  }

  if (error || !test) {
    return (
      <div className="dash">
        <main className="page">
          <div className="empty-state">
            <p>{error || 'Trade test not found.'}</p>
            <Link to="/assessor/tests" className="login__link">← Back to trade tests</Link>
          </div>
        </main>
      </div>
    );
  }

  const hasDraftResults = Object.values(existing).some((r) => r.status === 'Draft');

  return (
    <div className="dash">
      <main className="page">
        <Link to="/assessor/tests" className="back-link">← Back to trade tests</Link>

        <div className="page__heading">
          <div>
            <h1 className="page__title">{test.courseName || `Course #${test.courseID}`}</h1>
            <p className="page__subtitle">
              {test.batchCode || `Batch #${test.batchID}`} · {formatDate(test.testDate)} ·{' '}
              <StatusBadge status={test.status} tone={TRADE_TEST_STATUS_TONE[test.status] || 'neutral'} />
            </p>
          </div>
          <div className="entry-actions">
            <Link to={`/assessor/tests/${testId}/questions`} className="btn btn--secondary">Question Paper</Link>
            <button type="button" className="btn btn--secondary" onClick={saveDraft} disabled={!editable}>Save Draft</button>
            <button
              type="button"
              className="btn btn--primary"
              onClick={submitResults}
              disabled={!editable || submitting || anyInvalid}
              aria-busy={submitting}
            >
              {submitting && <Spinner size={16} inline label="Saving" />}
              Submit Results
            </button>
          </div>
        </div>

        {/* Status gates */}
        {test.status === 'Scheduled' && (
          <div className="dash__notice" role="status">
            <span>This test must be marked <strong>Conducted</strong> before results can be entered.</span>
            <button type="button" className="btn btn--primary btn--sm" onClick={markConducted} disabled={conductingBusy} aria-busy={conductingBusy}>
              {conductingBusy && <Spinner size={14} inline label="Updating" />}
              Mark as Conducted
            </button>
          </div>
        )}
        {(test.status === 'ResultsDeclared' || test.status === 'Cancelled') && (
          <div className="dash__notice" role="status">
            Results for this test are {test.status === 'Cancelled' ? 'cancelled' : 'declared'}; entry is closed.
          </div>
        )}

        {roster.length === 0 ? (
          <div className="empty-state"><p>No trainees are enrolled in this batch.</p></div>
        ) : (
          <>
            <div className="entry-bar">
              <span className="entry-progress">
                Entered {stats.entered + stats.published} / {stats.total}
                {stats.published > 0 && <span className="text-muted"> ({stats.published} published)</span>}
              </span>
              <span className="text-muted">Pass mark: {PASS_MARK}/{MAX} ({PASS_THRESHOLD_PERCENT}%). Leave blank = Absent.</span>
            </div>

            <div className="table-wrap">
              <table className="table">
                <thead>
                  <tr>
                    <th scope="col">Trainee</th>
                    <th scope="col">Marks (/{MAX})</th>
                    <th scope="col">Outcome</th>
                    <th scope="col">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {roster.map((tr) => {
                    const ex = existing[tr.traineeID];
                    const locked = isLocked(tr.traineeID);
                    const value = marks[tr.traineeID] ?? '';
                    const outcome = locked ? ex.overallOutcome : outcomeFor(value);
                    const bad = !locked && invalidMark(value);
                    return (
                      <tr key={tr.traineeID}>
                        <td data-label="Trainee">{tr.name || `Trainee #${tr.traineeID}`}</td>
                        <td data-label="Marks">
                          {locked ? (
                            <span>{ex.marksObtained ?? '—'}</span>
                          ) : (
                            <input
                              type="number"
                              min="0"
                              max={MAX}
                              className={`field__input cell-input ${bad ? 'cell-input--error' : ''}`}
                              value={value}
                              placeholder="Absent"
                              onChange={(e) => setMark(tr.traineeID, e.target.value)}
                              disabled={!editable}
                              aria-label={`Marks for ${tr.name}`}
                            />
                          )}
                          {bad && <span className="cell-error-text">0–{MAX} or blank</span>}
                        </td>
                        <td data-label="Outcome">
                          <StatusBadge status={outcome} tone={OUTCOME_TONE[outcome] || 'neutral'} />
                          {outcome !== 'Pass' && !locked && value === '' && (
                            <span className="text-muted"> · reassessment</span>
                          )}
                        </td>
                        <td data-label="Status">
                          {ex ? <StatusBadge status={ex.status} tone={ex.status === 'Published' ? 'success' : 'info'} /> : <span className="text-muted">—</span>}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {test.status === 'Conducted' && (
              <div className="declare-row">
                <p className="text-muted">
                  Submit the marks first, then declare to publish outcomes to trainees. Fail/Absent trainees
                  become eligible for reassessment.
                </p>
                <button
                  type="button"
                  className="btn btn--secondary"
                  onClick={() => setDeclareOpen(true)}
                  disabled={!hasDraftResults}
                  title={hasDraftResults ? 'Publish saved results' : 'Submit results first'}
                >
                  Declare Results
                </button>
              </div>
            )}
          </>
        )}
      </main>

      {declareOpen && (
        <ConfirmDialog
          title="Declare results?"
          message="This publishes each trainee's outcome and notifies them. The test will be marked ResultsDeclared. This cannot be undone."
          confirmLabel="Declare"
          tone="primary"
          busy={declaring}
          onConfirm={declareResults}
          onCancel={() => (declaring ? null : setDeclareOpen(false))}
        />
      )}
    </div>
  );
}
