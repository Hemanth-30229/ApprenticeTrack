// Assessors directory (admin): lists assessor accounts (from identity) with their
// availability (from assessment) and lets an admin create a new assessor login.
import { useCallback, useEffect, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import UserFormModal from '../../identity/components/users/UserFormModal';
import { useToast } from '../../../shared/toast/ToastContext';
import { createUser, listAssessors } from '../../identity/api/users';
import { listAssessorAvailability } from '../api/assessment';
import { listCourses } from '../../training/api/courses';
import { apiErrorMessage } from '../../../shared/api/errors';

const STATUSES = ['Active', 'Inactive'];
const STATUS_TONE = { Active: 'success', Inactive: 'neutral', Graduated: 'info' };

export default function AssessorListPage() {
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [status, setStatus] = useState('Active');
  const [courseId, setCourseId] = useState(''); // '' = directory mode; set = availability mode
  const [courses, setCourses] = useState([]);
  const [formOpen, setFormOpen] = useState(false);

  const byCourse = Boolean(courseId);

  useEffect(() => {
    listCourses({ status: undefined, size: 200 })
      .then((p) => setCourses(p.content || []))
      .catch(() => {});
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      if (courseId) {
        const list = await listAssessorAvailability(courseId);
        setRows(list || []);
      } else {
        const list = await listAssessors(status);
        // Normalise to the shared row shape (assessorID from userID).
        setRows((list || []).map((u) => ({ assessorID: u.userID, name: u.name, email: u.email, status: u.status })));
      }
    } catch (err) {
      setError(apiErrorMessage(err, 'Could not load assessors.'));
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [status, courseId]);

  useEffect(() => {
    load();
  }, [load]);

  async function handleCreate(payload) {
    const created = await createUser(payload); // throws -> modal shows error
    toast.success(`Assessor "${created.name}" created (ID ${created.userID}).`);
    setFormOpen(false);
    setCourseId('');
    setStatus('Active');
    load();
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Assessors</h1>
            <p className="page__subtitle">Browse assessors and their test load; onboard new assessors.</p>
          </div>
          <button type="button" className="btn btn--primary" onClick={() => setFormOpen(true)}>
            + Add Assessor
          </button>
        </div>

        <div className="toolbar">
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="field__label field__label--sm">Status</label>
            <select
              id="status-filter"
              className="field__input"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              disabled={byCourse}
            >
              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="course-filter" className="field__label field__label--sm">Test load for course</label>
            <select id="course-filter" className="field__input" value={courseId} onChange={(e) => setCourseId(e.target.value)}>
              <option value="">— Directory (by status) —</option>
              {courses.map((c) => <option key={c.courseID} value={c.courseID}>{c.courseName}</option>)}
            </select>
          </div>
        </div>

        {byCourse && (
          <p className="page__note">
            Showing assessors available for the selected course, with their scheduled test count.
          </p>
        )}

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Assessor</th>
                <th scope="col">Email</th>
                <th scope="col">Status</th>
                {byCourse && <th scope="col">Scheduled Tests</th>}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={byCourse ? 4 : 3} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
              ) : error ? (
                <tr><td colSpan={byCourse ? 4 : 3} className="table__state table__state--error">{error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button></td></tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan={byCourse ? 4 : 3} className="table__state">No assessors found.</td></tr>
              ) : (
                rows.map((a) => (
                  <tr key={a.assessorID}>
                    <td data-label="Assessor">{a.name || `#${a.assessorID}`}</td>
                    <td data-label="Email">{a.email || '—'}</td>
                    <td data-label="Status"><StatusBadge status={a.status} tone={STATUS_TONE[a.status] || 'neutral'} /></td>
                    {byCourse && <td data-label="Scheduled Tests">{a.scheduledTestCount ?? 0}</td>}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </main>

      {formOpen && <UserFormModal defaultRole="Assessor" onClose={() => setFormOpen(false)} onSubmit={handleCreate} />}
    </div>
  );
}
