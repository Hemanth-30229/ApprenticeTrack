// Assessor's trade tests: list the tests (optionally the ones they own) and
// schedule new ones. List-page pattern (see PlacementListPage for the reference).
import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import TradeTestFormModal from '../components/assessment/TradeTestFormModal';
import { useAuth } from '../../../shared/auth/AuthContext';
import { useToast } from '../../../shared/toast/ToastContext';
import { createTradeTest, listTradeTests } from '../api/assessment';
import { listCourses } from '../../training/api/courses';
import { TRADE_TEST_STATUSES, TRADE_TEST_STATUS_TONE } from '../constants/assessment';
import { formatDate } from '../../../shared/format';

const PAGE_SIZE = 10;

export default function AssessorTestListPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);

  const [status, setStatus] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const [createOpen, setCreateOpen] = useState(false);
  const [courses, setCourses] = useState([]);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await listTradeTests({
        assessorID: user.userID, // only this assessor's tests
        status: status || undefined,
        fromDate: fromDate || undefined,
        toDate: toDate || undefined,
        page,
        size: PAGE_SIZE,
        sort: 'testDate,desc',
      });
      setRows(data.content || []);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
    } catch {
      setError('Could not load your trade tests. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [user.userID, status, fromDate, toDate, page]);

  useEffect(() => {
    load();
  }, [load]);

  // Courses for the "Schedule Trade Test" dropdown (loaded lazily on first open).
  async function openCreate() {
    setCreateOpen(true);
    if (courses.length === 0) {
      try {
        const data = await listCourses({ size: 200 });
        setCourses(data.content || []);
      } catch {
        toast.error('Could not load courses. Please try again.');
      }
    }
  }

  async function handleCreate(body) {
    try {
      const created = await createTradeTest(body);
      toast.success('Trade test scheduled.');
      setCreateOpen(false);
      if (created?.testID != null) {
        navigate(`/assessor/tests/${created.testID}`);
      } else {
        load();
      }
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Could not schedule the trade test.');
    }
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Assigned Trade Tests</h1>
            <p className="page__subtitle">Select a test to enter competency results.</p>
          </div>
          <button type="button" className="btn btn--primary" onClick={openCreate}>
            + Schedule Trade Test
          </button>
        </div>

        <div className="toolbar">
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="field__label field__label--sm">Status</label>
            <select
              id="status-filter"
              className="field__input"
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                setPage(0);
              }}
            >
              <option value="">All statuses</option>
              {TRADE_TEST_STATUSES.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="from-date" className="field__label field__label--sm">From</label>
            <input
              id="from-date"
              type="date"
              className="field__input"
              value={fromDate}
              max={toDate || undefined}
              onChange={(e) => {
                setFromDate(e.target.value);
                setPage(0);
              }}
            />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="to-date" className="field__label field__label--sm">To</label>
            <input
              id="to-date"
              type="date"
              className="field__input"
              value={toDate}
              min={fromDate || undefined}
              onChange={(e) => {
                setToDate(e.target.value);
                setPage(0);
              }}
            />
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Course Name</th>
                <th scope="col">Batch Code</th>
                <th scope="col">Test Date</th>
                <th scope="col">Venue</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
              ) : error ? (
                <tr>
                  <td colSpan={6} className="table__state table__state--error">
                    {error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button>
                  </td>
                </tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan={6} className="table__state">No trade tests found.</td></tr>
              ) : (
                rows.map((t) => (
                  <tr key={t.testID}>
                    <td data-label="Course Name">
                      <button type="button" className="link-button" onClick={() => navigate(`/assessor/tests/${t.testID}`)}>
                        {t.courseName || `Course #${t.courseID}`}
                      </button>
                    </td>
                    <td data-label="Batch Code">{t.batchCode || `Batch #${t.batchID}`}</td>
                    <td data-label="Test Date">{formatDate(t.testDate)}</td>
                    <td data-label="Venue">{t.venueID != null ? `Venue #${t.venueID}` : '—'}</td>
                    <td data-label="Status">
                      <StatusBadge status={t.status} tone={TRADE_TEST_STATUS_TONE[t.status] || 'neutral'} />
                    </td>
                    <td data-label="Actions" className="table__actions">
                      <button type="button" className="btn btn--secondary btn--sm" onClick={() => navigate(`/assessor/tests/${t.testID}/questions`)}>
                        Questions
                      </button>
                      <button type="button" className="btn btn--secondary btn--sm" onClick={() => navigate(`/assessor/tests/${t.testID}`)}>
                        Enter Results
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <span className="pagination__info">
            {pageInfo.totalElements > 0 ? `${pageInfo.totalElements} total` : ' '}
          </span>
          <div className="pagination__controls">
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={loading || page === 0}>← Previous</button>
            <span className="pagination__page">Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}</span>
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => p + 1)} disabled={loading || page + 1 >= pageInfo.totalPages}>Next →</button>
          </div>
        </div>
      </main>

      {createOpen && (
        <TradeTestFormModal
          courses={courses}
          assessorID={user.userID}
          onClose={() => setCreateOpen(false)}
          onSubmit={handleCreate}
        />
      )}
    </div>
  );
}
