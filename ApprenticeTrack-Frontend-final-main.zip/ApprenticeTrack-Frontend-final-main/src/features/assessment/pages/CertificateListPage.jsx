// Certificates (admin): list issued/revoked certificates, generate a new one for a
// trainee who passed, revoke, view, and download the PDF. List-page pattern.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import GenerateCertificateModal from '../components/certificates/GenerateCertificateModal';
import RevokeCertificateModal from '../components/certificates/RevokeCertificateModal';
import CertificateView from '../components/certificates/CertificateView';
import { useToast } from '../../../shared/toast/ToastContext';
import {
  downloadCertificate,
  generateCertificate,
  listCertificates,
  revokeCertificate,
} from '../api/certificates';
import { listCourses } from '../../training/api/courses';
import { CERTIFICATE_STATUS_TONE, QUALIFICATION_LEVELS } from '../constants/certificate';
import { formatDate } from '../../../shared/format';
import { filenameFromResponse, saveBlob } from '../../../shared/utils/download';

const PAGE_SIZE = 10;

export default function CertificateListPage() {
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);

  const [courses, setCourses] = useState([]);
  const [courseFilter, setCourseFilter] = useState('');
  const [levelFilter, setLevelFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const debounceRef = useRef(null);

  const [generateOpen, setGenerateOpen] = useState(false);
  const [revoking, setRevoking] = useState(null);
  const [revokeBusy, setRevokeBusy] = useState(false);
  const [downloadingId, setDownloadingId] = useState(null);
  const [viewing, setViewing] = useState(null);

  useEffect(() => {
    listCourses({ status: undefined, size: 200 })
      .then((p) => setCourses(p.content || []))
      .catch(() => {});
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await listCertificates({
        courseID: courseFilter || undefined,
        qualificationLevel: levelFilter || undefined,
        status: statusFilter || undefined,
        page,
        size: PAGE_SIZE,
        sort: 'issuedDate,desc',
      });
      setRows(data.content || []);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
    } catch {
      setError('Could not load certificates. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [courseFilter, levelFilter, statusFilter, page]);

  useEffect(() => {
    load();
  }, [load]);

  function onSearchChange(value) {
    setSearchInput(value);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => setSearch(value.trim().toLowerCase()), 300);
  }

  // Search by trainee name or certificate number (client-side — not server params).
  const visibleRows = useMemo(() => {
    if (!search) return rows;
    return rows.filter(
      (c) =>
        (c.traineeName || '').toLowerCase().includes(search) ||
        (c.certificateNumber || '').toLowerCase().includes(search)
    );
  }, [rows, search]);

  async function handleGenerate(payload) {
    try {
      const cert = await generateCertificate(payload);
      toast.success(`Certificate ${cert.certificateNumber || ''} generated.`);
      setGenerateOpen(false);
      if (page !== 0) setPage(0);
      else load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to generate certificate.');
      throw err;
    }
  }

  async function handleRevoke(reason) {
    try {
      await revokeCertificate(revoking.certificateID, reason);
      toast.success('Certificate revoked.');
      setRevoking(null);
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to revoke certificate.');
      throw err;
    } finally {
      setRevokeBusy(false);
    }
  }

  async function handleDownload(cert) {
    setDownloadingId(cert.certificateID);
    try {
      const res = await downloadCertificate(cert.certificateID);
      saveBlob(res.data, filenameFromResponse(res, `certificate-${cert.certificateID}.pdf`));
    } catch {
      toast.error('Could not download the certificate PDF.');
    } finally {
      setDownloadingId(null);
    }
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Certificates</h1>
            <p className="page__subtitle">Generate and manage trade certificates.</p>
          </div>
          <button type="button" className="btn btn--primary" onClick={() => setGenerateOpen(true)}>
            + Generate Certificate
          </button>
        </div>

        <div className="toolbar">
          <div className="toolbar__search">
            <label htmlFor="cert-search" className="sr-only">Search by trainee name or certificate number</label>
            <input id="cert-search" type="search" className="field__input" placeholder="Search name or certificate no.…" value={searchInput} onChange={(e) => onSearchChange(e.target.value)} />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="course-filter" className="field__label field__label--sm">Course</label>
            <select id="course-filter" className="field__input" value={courseFilter} onChange={(e) => { setCourseFilter(e.target.value); setPage(0); }}>
              <option value="">All courses</option>
              {courses.map((c) => <option key={c.courseID} value={c.courseID}>{c.courseName}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="level-filter" className="field__label field__label--sm">Qualification</label>
            <select id="level-filter" className="field__input" value={levelFilter} onChange={(e) => { setLevelFilter(e.target.value); setPage(0); }}>
              <option value="">All levels</option>
              {QUALIFICATION_LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="field__label field__label--sm">Status</label>
            <select id="status-filter" className="field__input" value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setPage(0); }}>
              <option value="">All statuses</option>
              <option value="Issued">Issued</option>
              <option value="Revoked">Revoked</option>
            </select>
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Trainee Name</th>
                <th scope="col">Course Name</th>
                <th scope="col">Certificate No.</th>
                <th scope="col">Qualification</th>
                <th scope="col">Issued Date</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
              ) : error ? (
                <tr>
                  <td colSpan={7} className="table__state table__state--error">
                    {error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button>
                  </td>
                </tr>
              ) : visibleRows.length === 0 ? (
                <tr><td colSpan={7} className="table__state">No certificates found.</td></tr>
              ) : (
                visibleRows.map((c) => (
                  <tr key={c.certificateID}>
                    <td data-label="Trainee Name">{c.traineeName || `Trainee #${c.traineeID}`}</td>
                    <td data-label="Course Name">{c.courseName || `Course #${c.courseID}`}</td>
                    <td data-label="Certificate No.">{c.certificateNumber}</td>
                    <td data-label="Qualification">{c.qualificationLevel}</td>
                    <td data-label="Issued Date">{formatDate(c.issuedDate)}</td>
                    <td data-label="Status">
                      <StatusBadge status={c.status} tone={CERTIFICATE_STATUS_TONE[c.status] || 'neutral'} />
                    </td>
                    <td data-label="Actions" className="table__actions">
                      <button type="button" className="btn btn--secondary btn--sm" onClick={() => setViewing(c)}>
                        View
                      </button>
                      <button
                        type="button"
                        className="btn btn--secondary btn--sm"
                        onClick={() => handleDownload(c)}
                        disabled={c.status === 'Revoked' || downloadingId === c.certificateID}
                        title={c.status === 'Revoked' ? 'Revoked certificates cannot be downloaded' : 'Download PDF'}
                      >
                        {downloadingId === c.certificateID ? 'Downloading…' : 'Download'}
                      </button>
                      {c.status === 'Issued' && (
                        <button type="button" className="btn btn--danger-ghost btn--sm" onClick={() => setRevoking(c)}>
                          Revoke
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <span className="pagination__info">{pageInfo.totalElements > 0 ? `${pageInfo.totalElements} total` : ' '}</span>
          <div className="pagination__controls">
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={loading || page === 0}>← Previous</button>
            <span className="pagination__page">Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}</span>
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => p + 1)} disabled={loading || page + 1 >= pageInfo.totalPages}>Next →</button>
          </div>
        </div>
      </main>

      {generateOpen && (
        <GenerateCertificateModal onClose={() => setGenerateOpen(false)} onGenerate={handleGenerate} />
      )}

      {revoking && (
        <RevokeCertificateModal
          certificate={revoking}
          onClose={() => (revokeBusy ? null : setRevoking(null))}
          onConfirm={handleRevoke}
        />
      )}

      {viewing && <CertificateView cert={viewing} onClose={() => setViewing(null)} />}
    </div>
  );
}
