// Reassessment tracker: trainees who failed/were absent and need a re-test. The
// assessor schedules a reassessment (single or bulk). Once scheduled, a trainee
// drops off this list until/unless that reassessment is also failed (backend rule).
import { Fragment, useCallback, useEffect, useMemo, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import ScheduleReassessmentModal from '../components/reassessment/ScheduleReassessmentModal';
import ReassessmentHistoryAccordion from '../components/reassessment/ReassessmentHistoryAccordion';
import { useAuth } from '../../../shared/auth/AuthContext';
import { useToast } from '../../../shared/toast/ToastContext';
import { listReassessmentCandidates, scheduleReassessment } from '../api/assessment';
import { listCourses } from '../../training/api/courses';
import { listBatches } from '../../training/api/batches';
import { candidateStatus, MAX_ATTEMPTS } from '../constants/reassessment';
import { formatDate } from '../../../shared/format';
import { exportToCsv } from '../../../shared/utils/csv';

const keyOf = (c) => `${c.traineeID}:${c.originalTestID}`;

export default function ReassessmentTrackerPage() {
  const { user } = useAuth();
  const toast = useToast();

  const [candidates, setCandidates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [courses, setCourses] = useState([]);
  const [batches, setBatches] = useState([]);
  const [courseId, setCourseId] = useState('');
  const [batchId, setBatchId] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const [expanded, setExpanded] = useState(null);
  const [selected, setSelected] = useState(new Set());
  const [single, setSingle] = useState(null); // candidate for single schedule
  const [bulkOpen, setBulkOpen] = useState(false);

  useEffect(() => {
    listCourses({ status: undefined, size: 200 }).then((p) => setCourses(p.content || [])).catch(() => {});
    listBatches({ size: 500 }).then((p) => setBatches(p.content || [])).catch(() => {});
  }, []);

  const courseName = useMemo(() => Object.fromEntries(courses.map((c) => [c.courseID, c.courseName])), [courses]);
  const batchCode = useMemo(() => Object.fromEntries(batches.map((b) => [b.batchID, b.batchCode])), [batches]);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const cands = await listReassessmentCandidates({
        courseId: courseId || undefined,
        batchId: batchId || undefined,
      });
      setCandidates(cands || []);
      setSelected(new Set());
    } catch {
      setError('Could not load reassessment candidates. Please try again.');
      setCandidates([]);
    } finally {
      setLoading(false);
    }
  }, [courseId, batchId]);

  useEffect(() => {
    load();
  }, [load]);

  // Client-side date range on original test date (no server param).
  const visible = useMemo(
    () =>
      candidates.filter((c) => {
        if (fromDate && (!c.originalTestDate || c.originalTestDate < fromDate)) return false;
        if (toDate && (!c.originalTestDate || c.originalTestDate > toDate)) return false;
        return true;
      }),
    [candidates, fromDate, toDate]
  );

  const selectable = visible.filter((c) => Number(c.reassessmentCount) < MAX_ATTEMPTS);
  const allSelected = selectable.length > 0 && selectable.every((c) => selected.has(keyOf(c)));
  const selectedCandidates = visible.filter((c) => selected.has(keyOf(c)));

  function toggle(c) {
    setSelected((prev) => {
      const next = new Set(prev);
      const k = keyOf(c);
      if (next.has(k)) next.delete(k);
      else next.add(k);
      return next;
    });
  }
  function toggleAll() {
    setSelected(allSelected ? new Set() : new Set(selectable.map(keyOf)));
  }

  function attemptLabel(c) {
    const next = Math.min((Number(c.reassessmentCount) || 0) + 1, MAX_ATTEMPTS);
    return `${next} of ${MAX_ATTEMPTS}`;
  }

  // Single schedule: map backend 400s to inline messages.
  async function submitSingle(shared) {
    try {
      await scheduleReassessment({ traineeID: single.traineeID, originalTestID: single.originalTestID, ...shared });
      toast.success('Reassessment scheduled.');
      setSingle(null);
      load();
    } catch (err) {
      const status = err?.response?.status;
      const msg = err?.response?.data?.message || '';
      const e = new Error(msg || 'Failed to schedule reassessment.');
      if (status === 400 && /maximum reassessment attempts/i.test(msg)) {
        e.inline = 'Maximum 3 reassessment attempts reached for this trainee';
      } else if (status === 400 && msg) {
        e.inline = msg;
      } else {
        e.inline = 'Failed to schedule reassessment.';
      }
      throw e;
    }
  }

  // Bulk schedule: same date/venue/assessor for all selected.
  async function submitBulk(shared) {
    const results = await Promise.allSettled(
      selectedCandidates.map((c) => scheduleReassessment({ traineeID: c.traineeID, originalTestID: c.originalTestID, ...shared }))
    );
    const ok = results.filter((r) => r.status === 'fulfilled').length;
    const failed = results.length - ok;
    toast[failed === 0 ? 'success' : 'info'](
      failed === 0 ? `${ok} reassessment(s) scheduled.` : `${ok} scheduled, ${failed} failed (max attempts or date).`
    );
    setBulkOpen(false);
    setSelected(new Set());
    load();
  }

  function handleExport() {
    if (visible.length === 0) { toast.info('Nothing to export.'); return; }
    exportToCsv(
      'reassessment-candidates',
      [
        { key: 'traineeName', label: 'Trainee Name', format: (v, r) => v || `#${r.traineeID}` },
        { key: 'courseID', label: 'Course', format: (v) => courseName[v] || `#${v}` },
        { key: 'batchID', label: 'Batch', format: (v) => batchCode[v] || `#${v}` },
        { key: 'originalTestDate', label: 'Original Test Date', format: (v) => formatDate(v) },
        { key: 'reassessmentCount', label: 'Attempt', format: (_, r) => attemptLabel(r) },
        { key: 'reassessmentCount', label: 'Status', format: (_, r) => candidateStatus(r).label },
      ],
      visible
    );
    toast.success('Reassessment list exported.');
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Reassessment Tracker</h1>
            <p className="page__subtitle">Failed or absent trainees requiring reassessment.</p>
          </div>
          <div className="entry-actions">
            <button type="button" className="btn btn--secondary" onClick={handleExport}>Export CSV</button>
            <button type="button" className="btn btn--primary" onClick={() => setBulkOpen(true)} disabled={selectedCandidates.length === 0}>
              Schedule Selected ({selectedCandidates.length})
            </button>
          </div>
        </div>

        <div className="toolbar">
          <div className="toolbar__filter">
            <label htmlFor="course-filter" className="field__label field__label--sm">Course</label>
            <select id="course-filter" className="field__input" value={courseId} onChange={(e) => setCourseId(e.target.value)}>
              <option value="">All courses</option>
              {courses.map((c) => <option key={c.courseID} value={c.courseID}>{c.courseName}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="batch-filter" className="field__label field__label--sm">Batch</label>
            <select id="batch-filter" className="field__input" value={batchId} onChange={(e) => setBatchId(e.target.value)}>
              <option value="">All batches</option>
              {batches.map((b) => <option key={b.batchID} value={b.batchID}>{b.batchCode}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="from-date" className="field__label field__label--sm">Test date from</label>
            <input id="from-date" type="date" className="field__input" value={fromDate} max={toDate || undefined} onChange={(e) => setFromDate(e.target.value)} />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="to-date" className="field__label field__label--sm">To</label>
            <input id="to-date" type="date" className="field__input" value={toDate} min={fromDate || undefined} onChange={(e) => setToDate(e.target.value)} />
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col" className="table__check-col">
                  <input type="checkbox" aria-label="Select all eligible" checked={allSelected} onChange={toggleAll} disabled={selectable.length === 0} />
                </th>
                <th scope="col">Trainee Name</th>
                <th scope="col">Course</th>
                <th scope="col">Batch</th>
                <th scope="col">Original Test Date</th>
                <th scope="col">Attempt</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={8} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
              ) : error ? (
                <tr><td colSpan={8} className="table__state table__state--error">{error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button></td></tr>
              ) : visible.length === 0 ? (
                <tr><td colSpan={8} className="table__state">No trainees require reassessment.</td></tr>
              ) : (
                visible.map((c) => {
                  const k = keyOf(c);
                  const isOpen = expanded === k;
                  const maxed = Number(c.reassessmentCount) >= MAX_ATTEMPTS;
                  const st = candidateStatus(c);
                  return (
                    <Fragment key={k}>
                      <tr className={isOpen ? 'row--expanded' : ''}>
                        <td data-label="Select" className="table__check-col">
                          <input type="checkbox" aria-label={`Select ${c.traineeName}`} checked={selected.has(k)} onChange={() => toggle(c)} disabled={maxed} />
                        </td>
                        <td data-label="Trainee Name">
                          <button type="button" className="link-button" aria-expanded={isOpen} onClick={() => setExpanded(isOpen ? null : k)}>
                            {c.traineeName || `Trainee #${c.traineeID}`}
                          </button>
                        </td>
                        <td data-label="Course">{courseName[c.courseID] || `Course #${c.courseID}`}</td>
                        <td data-label="Batch">{batchCode[c.batchID] || `Batch #${c.batchID}`}</td>
                        <td data-label="Original Test Date">{formatDate(c.originalTestDate)}</td>
                        <td data-label="Attempt">{attemptLabel(c)}</td>
                        <td data-label="Status"><StatusBadge status={st.label} tone={st.tone} /></td>
                        <td data-label="Actions" className="table__actions">
                          <button type="button" className="btn btn--primary btn--sm" onClick={() => setSingle(c)} disabled={maxed} title={maxed ? 'Maximum attempts reached' : 'Schedule reassessment'}>
                            Schedule Reassessment
                          </button>
                        </td>
                      </tr>
                      {isOpen && (
                        <tr className="row--panel">
                          <td colSpan={8}>
                            <ReassessmentHistoryAccordion candidate={c} />
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </main>

      {single && (
        <ScheduleReassessmentModal
          candidates={[single]}
          currentUserId={user?.userID}
          onClose={() => setSingle(null)}
          onSubmit={submitSingle}
        />
      )}
      {bulkOpen && (
        <ScheduleReassessmentModal
          candidates={selectedCandidates}
          currentUserId={user?.userID}
          onClose={() => setBulkOpen(false)}
          onSubmit={submitBulk}
        />
      )}
    </div>
  );
}
