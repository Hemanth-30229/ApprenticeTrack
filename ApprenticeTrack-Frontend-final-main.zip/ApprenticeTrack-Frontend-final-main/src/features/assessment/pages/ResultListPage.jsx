// Trade test results (admin/assessor): searchable, filterable list of results with
// a detail modal. List-page pattern (see PlacementListPage for the reference).
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import ConfirmDialog from '../../../shared/ui/ConfirmDialog';
import { useToast } from '../../../shared/toast/ToastContext';
import {
  bulkPublishTradeTestResults,
  getTradeTest,
  listTradeTestResults,
  publishTradeTestResult,
} from '../api/assessment';
import {
  RESULT_OUTCOMES,
  RESULT_OUTCOME_TONE,
  RESULT_STATUS_TONE,
  RESULT_STATUSES,
} from '../constants/result';

const PAGE_SIZE = 10;

export default function ResultListPage() {
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);

  const [testID, setTestID] = useState('');
  const [outcome, setOutcome] = useState('');
  const [reassessment, setReassessment] = useState('');
  const [status, setStatus] = useState('');

  const [batchByTest, setBatchByTest] = useState({});
  const batchCacheRef = useRef({});

  const [selected, setSelected] = useState(new Set());
  const [publishTarget, setPublishTarget] = useState(null); // { type:'single'|'bulk', result? }
  const [publishing, setPublishing] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await listTradeTestResults({
        testID: testID || undefined,
        overallOutcome: outcome || undefined,
        reassessmentRequired: reassessment === '' ? undefined : reassessment === 'true',
        status: status || undefined,
        page,
        size: PAGE_SIZE,
        sort: 'finalResultID,desc',
      });
      const content = data.content || [];
      setRows(content);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
      setSelected(new Set());

      // Resolve batch codes for distinct testIDs (cached).
      const missing = [...new Set(content.map((r) => r.testID))].filter(
        (id) => !(id in batchCacheRef.current)
      );
      if (missing.length) {
        await Promise.all(
          missing.map(async (id) => {
            try {
              const t = await getTradeTest(id);
              batchCacheRef.current[id] = t?.batchCode || `Test #${id}`;
            } catch {
              batchCacheRef.current[id] = `Test #${id}`;
            }
          })
        );
        setBatchByTest({ ...batchCacheRef.current });
      }
    } catch {
      setError('Could not load results. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [testID, outcome, reassessment, status, page]);

  useEffect(() => {
    load();
  }, [load]);

  const draftRows = useMemo(() => rows.filter((r) => r.status === 'Draft'), [rows]);
  const allSelected = draftRows.length > 0 && selected.size === draftRows.length;

  function toggle(id) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }
  function toggleAll() {
    setSelected(allSelected ? new Set() : new Set(draftRows.map((r) => r.finalResultID)));
  }

  async function confirmPublish() {
    setPublishing(true);
    try {
      if (publishTarget.type === 'single') {
        await publishTradeTestResult(publishTarget.result.finalResultID);
        toast.success('Result published.');
      } else {
        const ids = Array.from(selected);
        const res = await bulkPublishTradeTestResults(ids);
        const published = res.published?.length ?? ids.length;
        const failed = res.failed?.length ?? 0;
        toast[failed === 0 ? 'success' : 'info'](
          failed === 0 ? `${published} result(s) published.` : `${published} published, ${failed} failed.`
        );
      }
      setPublishTarget(null);
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to publish.');
    } finally {
      setPublishing(false);
    }
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Trade Test Results</h1>
            <p className="page__subtitle">Review draft results and publish outcomes to trainees.</p>
          </div>
          <button
            type="button"
            className="btn btn--primary"
            onClick={() => setPublishTarget({ type: 'bulk' })}
            disabled={selected.size === 0}
          >
            Publish Selected ({selected.size})
          </button>
        </div>

        <div className="toolbar">
          <div className="toolbar__filter">
            <label htmlFor="test-filter" className="field__label field__label--sm">Test ID</label>
            <input
              id="test-filter"
              type="number"
              className="field__input"
              placeholder="e.g. 12"
              value={testID}
              onChange={(e) => { setTestID(e.target.value); setPage(0); }}
            />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="outcome-filter" className="field__label field__label--sm">Outcome</label>
            <select id="outcome-filter" className="field__input" value={outcome} onChange={(e) => { setOutcome(e.target.value); setPage(0); }}>
              <option value="">All outcomes</option>
              {RESULT_OUTCOMES.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="reassess-filter" className="field__label field__label--sm">Reassessment</label>
            <select id="reassess-filter" className="field__input" value={reassessment} onChange={(e) => { setReassessment(e.target.value); setPage(0); }}>
              <option value="">All</option>
              <option value="true">Yes</option>
              <option value="false">No</option>
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="field__label field__label--sm">Status</label>
            <select id="status-filter" className="field__input" value={status} onChange={(e) => { setStatus(e.target.value); setPage(0); }}>
              <option value="">All statuses</option>
              {RESULT_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col" className="table__check-col">
                  <input type="checkbox" aria-label="Select all draft results" checked={allSelected} onChange={toggleAll} disabled={draftRows.length === 0} />
                </th>
                <th scope="col">Trainee Name</th>
                <th scope="col">Course</th>
                <th scope="col">Batch</th>
                <th scope="col">Overall Outcome</th>
                <th scope="col">Reassessment</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={8} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
              ) : error ? (
                <tr>
                  <td colSpan={8} className="table__state table__state--error">
                    {error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button>
                  </td>
                </tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan={8} className="table__state">No results found.</td></tr>
              ) : (
                rows.map((r) => {
                  const isDraft = r.status === 'Draft';
                  return (
                    <tr key={r.finalResultID}>
                      <td data-label="Select" className="table__check-col">
                        <input type="checkbox" aria-label={`Select ${r.traineeName}`} checked={selected.has(r.finalResultID)} onChange={() => toggle(r.finalResultID)} disabled={!isDraft} />
                      </td>
                      <td data-label="Trainee Name">
                        {r.traineeName || `Trainee #${r.traineeID}`}
                      </td>
                      <td data-label="Course">{r.courseName || `Course #${r.courseID}`}</td>
                      <td data-label="Batch">{batchByTest[r.testID] || `Test #${r.testID}`}</td>
                      <td data-label="Overall Outcome">
                        <StatusBadge status={r.overallOutcome} tone={RESULT_OUTCOME_TONE[r.overallOutcome] || 'neutral'} />
                      </td>
                      <td data-label="Reassessment">
                        {r.reassessmentRequired ? (
                          <span className="reassess-flag"><span aria-hidden="true">⚠️</span> Yes</span>
                        ) : (
                          <span className="text-muted">No</span>
                        )}
                      </td>
                      <td data-label="Status">
                        <StatusBadge status={r.status} tone={RESULT_STATUS_TONE[r.status] || 'neutral'} />
                      </td>
                      <td data-label="Actions" className="table__actions">
                        {isDraft && (
                          <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPublishTarget({ type: 'single', result: r })}>
                            Publish
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <span className="pagination__info">{pageInfo.totalElements > 0 ? `${pageInfo.totalElements} total` : ' '}</span>
          <div className="pagination__controls">
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={loading || page === 0}>← Previous</button>
            <span className="pagination__page">Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}</span>
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => p + 1)} disabled={loading || page + 1 >= pageInfo.totalPages}>Next →</button>
          </div>
        </div>
      </main>

      {publishTarget && (
        <ConfirmDialog
          title={publishTarget.type === 'bulk' ? 'Publish selected results?' : 'Publish result?'}
          message={
            publishTarget.type === 'bulk'
              ? `Publish ${selected.size} draft result(s)? Trainees will be notified and the results become read-only.`
              : `Publish the result for "${publishTarget.result.traineeName || `Trainee #${publishTarget.result.traineeID}`}"? This notifies the trainee and cannot be undone.`
          }
          confirmLabel="Publish"
          tone="primary"
          busy={publishing}
          onConfirm={confirmPublish}
          onCancel={() => (publishing ? null : setPublishTarget(null))}
        />
      )}
    </div>
  );
}
