// Assessor: author a scheduled test's question paper and review trainee
// submissions. MCQ answers are auto-graded; coding answers are graded here
// manually. Reached from the trade-test list / entry screen.

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import ConfirmDialog from '../../../shared/ui/ConfirmDialog';
import Modal from '../../../shared/ui/Modal';
import QuestionFormModal from '../components/assessment/QuestionFormModal';
import { useToast } from '../../../shared/toast/ToastContext';
import { getTradeTest } from '../api/assessment';
import {
  createTestQuestion,
  deleteTestQuestion,
  gradeTestAttempt,
  listTestAttempts,
  listTestQuestions,
  updateTestQuestion,
} from '../api/testQuestions';
import {
  ATTEMPT_STATUS_TONE,
  QUESTION_TYPE_LABEL,
  asList,
} from '../constants/testQuestion';
import { TRADE_TEST_STATUS_TONE } from '../constants/assessment';
import { formatDate } from '../../../shared/format';
import './AssessmentEntryPage.css';
import './TestQuestions.css';

export default function TestQuestionsPage() {
  const { testId } = useParams();
  const toast = useToast();

  const [test, setTest] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [attempts, setAttempts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tab, setTab] = useState('questions');

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const [reviewing, setReviewing] = useState(null);

  // Questions/attempts are best-effort: their endpoints may not be available
  // yet, and a failure there should not block the page — it just shows empty.
  const loadQuestions = useCallback(async () => {
    try {
      const data = await listTestQuestions(testId);
      setQuestions(asList(data).slice().sort((a, b) => (a.sequence ?? 0) - (b.sequence ?? 0)));
    } catch {
      setQuestions([]);
    }
  }, [testId]);

  const loadAttempts = useCallback(async () => {
    try {
      const data = await listTestAttempts(testId);
      setAttempts(asList(data));
    } catch {
      setAttempts([]);
    }
  }, [testId]);

  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      setError('');
      try {
        // Only the trade test itself gates the error screen.
        const t = await getTradeTest(testId);
        if (!alive) return;
        setTest(t);
      } catch {
        if (alive) setError('Could not load this trade test. Please try again.');
        if (alive) setLoading(false);
        return;
      }
      await Promise.all([loadQuestions(), loadAttempts()]);
      if (alive) setLoading(false);
    })();
    return () => {
      alive = false;
    };
  }, [testId, loadQuestions, loadAttempts]);

  const totalMarks = useMemo(
    () => questions.reduce((sum, q) => sum + (Number(q.marks) || 0), 0),
    [questions]
  );

  async function handleSubmitQuestion(payload) {
    try {
      if (editing) {
        await updateTestQuestion(editing.questionID, payload);
        toast.success('Question updated.');
      } else {
        await createTestQuestion(testId, payload);
        toast.success('Question added.');
      }
      setFormOpen(false);
      setEditing(null);
      await loadQuestions();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Could not save the question.');
    }
  }

  async function confirmDelete() {
    setDeleteBusy(true);
    try {
      await deleteTestQuestion(deleting.questionID);
      toast.success('Question removed.');
      setDeleting(null);
      await loadQuestions();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Could not remove the question.');
    } finally {
      setDeleteBusy(false);
    }
  }

  async function handleGraded() {
    setReviewing(null);
    await loadAttempts();
  }

  if (loading) {
    return (
      <div className="dash">
        <main className="page"><div className="table__state"><Spinner size={24} label="Loading" /> Loading…</div></main>
      </div>
    );
  }

  if (error || !test) {
    return (
      <div className="dash">
        <main className="page">
          <div className="empty-state">
            <p>{error || 'Trade test not found.'}</p>
            <Link to="/assessor/tests" className="login__link">← Back to trade tests</Link>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="dash">
      <main className="page">
        <Link to="/assessor/tests" className="back-link">← Back to trade tests</Link>

        <div className="page__heading">
          <div>
            <h1 className="page__title">Question Paper</h1>
            <p className="page__subtitle">
              {test.courseName || `Course #${test.courseID}`} · {test.batchCode || `Batch #${test.batchID}`} ·{' '}
              {formatDate(test.testDate)} ·{' '}
              <StatusBadge status={test.status} tone={TRADE_TEST_STATUS_TONE[test.status] || 'neutral'} />
            </p>
          </div>
          {tab === 'questions' && (
            <button type="button" className="btn btn--primary" onClick={() => { setEditing(null); setFormOpen(true); }}>
              + Add Question
            </button>
          )}
        </div>

        <div className="mode-toggle" role="group" aria-label="View">
          <button type="button" className={`mode-toggle__btn ${tab === 'questions' ? 'is-active' : ''}`} onClick={() => setTab('questions')}>
            Questions ({questions.length})
          </button>
          <button type="button" className={`mode-toggle__btn ${tab === 'submissions' ? 'is-active' : ''}`} onClick={() => setTab('submissions')}>
            Submissions ({attempts.length})
          </button>
        </div>

        {tab === 'questions' ? (
          questions.length === 0 ? (
            <div className="empty-state">
              <p>No questions yet.</p>
              <p className="empty-state__hint">Add multiple-choice or coding questions for trainees to answer.</p>
            </div>
          ) : (
            <>
              <p className="text-muted q-total">{questions.length} question(s) · {totalMarks} total marks</p>
              <ol className="q-list">
                {questions.map((q, i) => (
                  <li key={q.questionID} className="q-card">
                    <div className="q-card__head">
                      <span className="q-card__num">Q{i + 1}</span>
                      <span className={`badge badge--${q.questionType === 'Coding' ? 'info' : 'neutral'}`}>
                        {QUESTION_TYPE_LABEL[q.questionType] || q.questionType}
                      </span>
                      <span className="q-card__marks">{q.marks} mark{q.marks === 1 ? '' : 's'}</span>
                      <span className="q-card__actions">
                        <button type="button" className="btn btn--secondary btn--sm" onClick={() => { setEditing(q); setFormOpen(true); }}>Edit</button>
                        <button type="button" className="btn btn--danger btn--sm" onClick={() => setDeleting(q)}>Delete</button>
                      </span>
                    </div>
                    <p className="q-card__text">{q.questionText}</p>
                    {q.questionType === 'MultipleChoice' ? (
                      <ul className="q-card__options">
                        {(q.options || []).map((o, idx) => (
                          <li key={idx} className={idx === q.correctOptionIndex ? 'is-correct' : ''}>
                            {idx === q.correctOptionIndex ? '✓ ' : ''}{o.optionText}
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="q-card__lang">Language: {q.language}{q.starterCode ? ' · starter code provided' : ''}</p>
                    )}
                  </li>
                ))}
              </ol>
            </>
          )
        ) : attempts.length === 0 ? (
          <div className="empty-state">
            <p>No submissions yet.</p>
            <p className="empty-state__hint">Trainee submissions appear here once they write the test.</p>
          </div>
        ) : (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">Trainee</th>
                  <th scope="col">Submitted</th>
                  <th scope="col">Auto (MCQ)</th>
                  <th scope="col">Total</th>
                  <th scope="col">Status</th>
                  <th scope="col" className="table__actions-col">Actions</th>
                </tr>
              </thead>
              <tbody>
                {attempts.map((a) => (
                  <tr key={a.attemptID}>
                    <td data-label="Trainee">{a.traineeName || `Trainee #${a.traineeID}`}</td>
                    <td data-label="Submitted">{formatDate(a.submittedAt)}</td>
                    <td data-label="Auto (MCQ)">{a.autoScore ?? '—'} / {a.autoMaxScore ?? '—'}</td>
                    <td data-label="Total">{a.status === 'Graded' ? `${a.totalScore ?? '—'} / ${a.maxScore ?? totalMarks}` : '—'}</td>
                    <td data-label="Status"><StatusBadge status={a.status} tone={ATTEMPT_STATUS_TONE[a.status] || 'neutral'} /></td>
                    <td data-label="Actions" className="table__actions">
                      <button type="button" className="btn btn--secondary btn--sm" onClick={() => setReviewing(a)}>
                        Review &amp; Grade
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>

      {formOpen && (
        <QuestionFormModal
          question={editing}
          onClose={() => { setFormOpen(false); setEditing(null); }}
          onSubmit={handleSubmitQuestion}
        />
      )}

      {deleting && (
        <ConfirmDialog
          title="Remove question?"
          message="This question and any related answers will be removed. This cannot be undone."
          confirmLabel="Remove"
          busy={deleteBusy}
          onConfirm={confirmDelete}
          onCancel={() => (deleteBusy ? null : setDeleting(null))}
        />
      )}

      {reviewing && (
        <SubmissionReviewModal
          attempt={reviewing}
          questions={questions}
          onClose={() => setReviewing(null)}
          onGraded={handleGraded}
        />
      )}
    </div>
  );
}

/* ---- Review one trainee attempt + grade coding answers ---- */
function SubmissionReviewModal({ attempt, questions, onClose, onGraded }) {
  const toast = useToast();
  const qById = useMemo(() => {
    const m = {};
    questions.forEach((q) => { m[q.questionID] = q; });
    return m;
  }, [questions]);

  const codingAnswers = (attempt.answers || []).filter((ans) => {
    const q = qById[ans.questionID];
    return (q?.questionType || ans.questionType) === 'Coding';
  });

  const [marks, setMarks] = useState(() => {
    const init = {};
    codingAnswers.forEach((ans) => { init[ans.questionID] = ans.marksAwarded ?? ''; });
    return init;
  });
  const [saving, setSaving] = useState(false);

  const setMark = (questionID, v) => setMarks((m) => ({ ...m, [questionID]: v }));

  const invalid = codingAnswers.some((ans) => {
    const q = qById[ans.questionID];
    const v = marks[ans.questionID];
    if (v === '' || v == null) return true;
    const n = Number(v);
    return Number.isNaN(n) || n < 0 || n > (Number(q?.marks) || 0);
  });

  async function save() {
    if (invalid) return;
    setSaving(true);
    try {
      const grades = codingAnswers.map((ans) => ({
        questionID: ans.questionID,
        marksAwarded: Number(marks[ans.questionID]),
      }));
      await gradeTestAttempt(attempt.attemptID, { grades });
      toast.success('Marks saved.');
      onGraded();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Could not save marks.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal title={`Submission — ${attempt.traineeName || `Trainee #${attempt.traineeID}`}`} onClose={onClose} size="lg">
      <ol className="q-list q-list--review">
        {(attempt.answers || []).map((ans, i) => {
          const q = qById[ans.questionID] || {};
          const type = q.questionType || ans.questionType;
          return (
            <li key={ans.questionID ?? i} className="q-card">
              <div className="q-card__head">
                <span className="q-card__num">Q{i + 1}</span>
                <span className={`badge badge--${type === 'Coding' ? 'info' : 'neutral'}`}>
                  {QUESTION_TYPE_LABEL[type] || type}
                </span>
                <span className="q-card__marks">{q.marks} mark{q.marks === 1 ? '' : 's'}</span>
              </div>
              <p className="q-card__text">{q.questionText}</p>

              {type === 'MultipleChoice' ? (
                <ul className="q-card__options">
                  {(q.options || []).map((o, idx) => {
                    const chosen = idx === ans.selectedOptionIndex;
                    const correct = idx === q.correctOptionIndex;
                    return (
                      <li key={idx} className={correct ? 'is-correct' : chosen ? 'is-wrong' : ''}>
                        {correct ? '✓ ' : chosen ? '✗ ' : ''}{o.optionText}
                        {chosen && <span className="text-muted"> (trainee's answer)</span>}
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <>
                  <pre className="code-block">{ans.codeAnswer || '(no answer submitted)'}</pre>
                  <div className="field grade-field">
                    <label className="field__label field__label--sm" htmlFor={`grade-${ans.questionID}`}>
                      Marks awarded (max {q.marks})
                    </label>
                    <input
                      id={`grade-${ans.questionID}`}
                      type="number"
                      min="0"
                      max={q.marks}
                      className="field__input cell-input"
                      value={marks[ans.questionID] ?? ''}
                      onChange={(e) => setMark(ans.questionID, e.target.value)}
                    />
                  </div>
                </>
              )}
            </li>
          );
        })}
      </ol>

      <div className="modal__actions">
        <button type="button" className="btn btn--secondary" onClick={onClose} disabled={saving}>Close</button>
        {codingAnswers.length > 0 && (
          <button type="button" className="btn btn--primary" onClick={save} disabled={invalid || saving} aria-busy={saving}>
            {saving && <Spinner size={16} inline label="Saving" />}
            Save Marks
          </button>
        )}
      </div>
    </Modal>
  );
}
