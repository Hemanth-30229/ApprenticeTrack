// Trainee-facing: my certificates. Resolves my trainee profile from my login and
// lists my certificates, each of which can be viewed.
import { useCallback, useEffect, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import { useAuth } from '../../../shared/auth/AuthContext';
import { getTraineeByUser } from '../../training/api/trainees';
import { listCertificates } from '../api/certificates';
import CertificateView from '../components/certificates/CertificateView';
import { CERTIFICATE_STATUS_TONE } from '../constants/certificate';
import { formatDate } from '../../../shared/format';

export default function TraineeCertificatesPage() {
  const { user } = useAuth();

  const [boot, setBoot] = useState({ loading: true, error: '', traineeID: null });
  const [certs, setCerts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [viewing, setViewing] = useState(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const trainee = await getTraineeByUser(user.userID);
        if (alive) setBoot({ loading: false, error: '', traineeID: trainee.traineeID });
      } catch (err) {
        if (alive)
          setBoot({
            loading: false,
            error: err?.response?.status === 404 ? 'No trainee profile is linked to your account yet.' : 'Could not load your profile.',
            traineeID: null,
          });
      }
    })();
    return () => {
      alive = false;
    };
  }, [user.userID]);

  const load = useCallback(async () => {
    if (!boot.traineeID) return;
    setLoading(true);
    setError('');
    try {
      const data = await listCertificates({ traineeID: boot.traineeID, page: 0, size: 50, sort: 'issuedDate,desc' });
      setCerts(data.content || []);
    } catch {
      setError('Could not load your certificates. Please try again.');
      setCerts([]);
    } finally {
      setLoading(false);
    }
  }, [boot.traineeID]);

  useEffect(() => {
    load();
  }, [load]);

  if (boot.loading) {
    return (
      <div className="dash">
        <main className="page"><div className="table__state"><Spinner size={24} label="Loading" /> Loading…</div></main>
      </div>
    );
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">My Certificates</h1>
            <p className="page__subtitle">View your trade certificates.</p>
          </div>
        </div>

        {boot.error ? (
          <div className="empty-state"><p>{boot.error}</p></div>
        ) : loading ? (
          <div className="table__state"><Spinner size={22} label="Loading" /> Loading…</div>
        ) : error ? (
          <div className="empty-state"><p>{error}</p><button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button></div>
        ) : certs.length === 0 ? (
          <div className="empty-state">
            <p>You have no certificates yet.</p>
            <p className="empty-state__hint">Certificates appear here once issued by your administrator.</p>
          </div>
        ) : (
          <div className="cert-grid">
            {certs.map((c) => {
              const revoked = c.status === 'Revoked';
              return (
                <div key={c.certificateID} className={`cert-item ${revoked ? 'cert-item--revoked' : ''}`}>
                  {revoked && <span className="cert-watermark" aria-hidden="true">REVOKED</span>}
                  <div className="cert-item__body">
                    <span className="cert-item__kicker">Certificate of Trade Competency</span>
                    <h2 className="cert-item__course">{c.courseName || `Course #${c.courseID}`}</h2>
                    <dl className="cert-item__meta">
                      <div><dt>Certificate No.</dt><dd>{c.certificateNumber}</dd></div>
                      <div><dt>Qualification</dt><dd>{c.qualificationLevel}</dd></div>
                      <div><dt>Issued</dt><dd>{formatDate(c.issuedDate)}</dd></div>
                    </dl>
                    {revoked && c.revocationReason && (
                      <p className="cert-item__reason">Reason: {c.revocationReason}</p>
                    )}
                  </div>
                  <div className="cert-item__foot">
                    <StatusBadge status={c.status} tone={CERTIFICATE_STATUS_TONE[c.status] || 'neutral'} />
                    <div className="entry-actions">
                      <button type="button" className="btn btn--secondary btn--sm" onClick={() => setViewing(c)}>
                        View
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {viewing && (
        <CertificateView cert={viewing} traineeName={user?.name} onClose={() => setViewing(null)} />
      )}
    </div>
  );
}
