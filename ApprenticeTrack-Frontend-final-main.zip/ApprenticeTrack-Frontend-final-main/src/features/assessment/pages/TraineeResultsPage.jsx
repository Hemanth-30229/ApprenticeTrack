// Trainee-facing: my trade test results. Resolves my trainee profile from my login
// and lists my results with a detail modal.
import { useCallback, useEffect, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import { useAuth } from '../../../shared/auth/AuthContext';
import { getTraineeByUser } from '../../training/api/trainees';
import { listTradeTestResults } from '../api/assessment';
import { RESULT_OUTCOME_TONE } from '../constants/result';

export default function TraineeResultsPage() {
  const { user } = useAuth();

  const [boot, setBoot] = useState({ loading: true, error: '', traineeID: null });
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const trainee = await getTraineeByUser(user.userID);
        if (alive) setBoot({ loading: false, error: '', traineeID: trainee.traineeID });
      } catch (err) {
        if (alive)
          setBoot({
            loading: false,
            error:
              err?.response?.status === 404
                ? 'No trainee profile is linked to your account yet.'
                : 'Could not load your profile.',
            traineeID: null,
          });
      }
    })();
    return () => {
      alive = false;
    };
  }, [user.userID]);

  const load = useCallback(async () => {
    if (!boot.traineeID) return;
    setLoading(true);
    setError('');
    try {
      const data = await listTradeTestResults({
        traineeID: boot.traineeID,
        status: 'Published', // trainees only see published results
        page: 0,
        size: 50,
        sort: 'finalResultID,desc',
      });
      setResults(data.content || []);
    } catch {
      setError('Could not load your results. Please try again.');
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, [boot.traineeID]);

  useEffect(() => {
    load();
  }, [load]);

  if (boot.loading) {
    return (
      <div className="dash">
        <main className="page">
          <div className="table__state"><Spinner size={24} label="Loading" /> Loading…</div>
        </main>
      </div>
    );
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">My Results</h1>
            <p className="page__subtitle">View your published trade test outcomes.</p>
          </div>
        </div>

        {boot.error ? (
          <div className="empty-state"><p>{boot.error}</p></div>
        ) : loading ? (
          <div className="table__state"><Spinner size={22} label="Loading" /> Loading…</div>
        ) : error ? (
          <div className="empty-state">
            <p>{error}</p>
            <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button>
          </div>
        ) : results.length === 0 ? (
          <div className="empty-state">
            <p>You have no published results yet.</p>
            <p className="empty-state__hint">Results appear here once your assessor publishes them.</p>
          </div>
        ) : (
          <div className="result-grid">
            {results.map((r) => (
              <div
                key={r.finalResultID}
                className={`result-tile result-tile--${RESULT_OUTCOME_TONE[r.overallOutcome] || 'neutral'}`}
              >
                <span className="result-tile__course">{r.courseName || `Course #${r.courseID}`}</span>
                <span className="result-tile__outcome">{r.overallOutcome}</span>
                <span className="result-tile__meta">
                  Test #{r.testID}
                  {r.reassessmentRequired && <span className="reassess-flag"> · ⚠️ Reassessment</span>}
                </span>
                <StatusBadge status={r.status} tone="success" />
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
