// Trainee: write a trade test online. Renders the question paper (MCQ radios +
// coding text areas). On submit, MCQ answers are auto-graded server-side; the
// result summary is shown. If already submitted, shows the read-only outcome.

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import ConfirmDialog from '../../../shared/ui/ConfirmDialog';
import { useAuth } from '../../../shared/auth/AuthContext';
import { useToast } from '../../../shared/toast/ToastContext';
import { getTraineeByUser } from '../../training/api/trainees';
import { getTradeTest } from '../api/assessment';
import { getMyTestAttempt, listTestQuestions, submitTestAttempt } from '../api/testQuestions';
import { asList, ATTEMPT_STATUS_TONE, QUESTION_TYPE_LABEL } from '../constants/testQuestion';
import { formatDate } from '../../../shared/format';
import './AssessmentEntryPage.css';
import './TestQuestions.css';

export default function TraineeTestAttemptPage() {
  const { testId } = useParams();
  const { user } = useAuth();
  const toast = useToast();

  const [test, setTest] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [attempt, setAttempt] = useState(null);
  const [traineeID, setTraineeID] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [answers, setAnswers] = useState({}); // questionID -> { selectedOptionIndex | codeAnswer }
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      // Profile + trade test are required; a failure here gates the error screen.
      const trainee = await getTraineeByUser(user.userID);
      const t = await getTradeTest(testId);
      setTraineeID(trainee.traineeID);
      setTest(t);

      // Questions + existing attempt are best-effort (endpoints may be absent).
      const [qData, aData] = await Promise.all([
        listTestQuestions(testId).catch(() => []),
        getMyTestAttempt(testId, trainee.traineeID).catch(() => []),
      ]);
      setQuestions(asList(qData).slice().sort((a, b) => (a.sequence ?? 0) - (b.sequence ?? 0)));
      setAttempt(asList(aData)[0] || null);
    } catch (err) {
      setError(
        err?.response?.status === 404
          ? 'No trainee profile is linked to your account yet.'
          : 'Could not load this trade test. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  }, [testId, user.userID]);

  useEffect(() => { load(); }, [load]);

  const setMcq = (questionID, idx) => setAnswers((a) => ({ ...a, [questionID]: { selectedOptionIndex: idx } }));
  const setCode = (questionID, code) => setAnswers((a) => ({ ...a, [questionID]: { codeAnswer: code } }));

  const answeredCount = useMemo(
    () => questions.filter((q) => {
      const a = answers[q.questionID];
      if (!a) return false;
      return q.questionType === 'MultipleChoice' ? a.selectedOptionIndex != null : Boolean(a.codeAnswer?.trim());
    }).length,
    [questions, answers]
  );
  const allAnswered = questions.length > 0 && answeredCount === questions.length;

  async function submit() {
    setSubmitting(true);
    try {
      const payload = {
        traineeID,
        answers: questions.map((q) => {
          const a = answers[q.questionID] || {};
          return q.questionType === 'MultipleChoice'
            ? { questionID: q.questionID, selectedOptionIndex: a.selectedOptionIndex ?? null }
            : { questionID: q.questionID, codeAnswer: a.codeAnswer ?? '' };
        }),
      };
      const result = await submitTestAttempt(testId, payload);
      setAttempt(result);
      setConfirmOpen(false);
      toast.success('Test submitted.');
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Could not submit the test.');
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <div className="dash">
        <main className="page"><div className="table__state"><Spinner size={24} label="Loading" /> Loading…</div></main>
      </div>
    );
  }

  if (error || !test) {
    return (
      <div className="dash">
        <main className="page">
          <div className="empty-state">
            <p>{error || 'Trade test not found.'}</p>
            <Link to="/trainee/tests" className="login__link">← Back to my tests</Link>
          </div>
        </main>
      </div>
    );
  }

  const testOpen = test.status === 'Scheduled' || test.status === 'Conducted';

  return (
    <div className="dash">
      <main className="page">
        <Link to="/trainee/tests" className="back-link">← Back to my tests</Link>

        <div className="page__heading">
          <div>
            <h1 className="page__title">{test.courseName || `Course #${test.courseID}`}</h1>
            <p className="page__subtitle">Trade Test · {formatDate(test.testDate)}</p>
          </div>
        </div>

        {attempt ? (
          <AttemptSummary attempt={attempt} questions={questions} />
        ) : !testOpen ? (
          <div className="empty-state"><p>This test is not open for submissions.</p></div>
        ) : questions.length === 0 ? (
          <div className="empty-state">
            <p>No questions have been added to this test yet.</p>
            <p className="empty-state__hint">Please check back once your assessor publishes the question paper.</p>
          </div>
        ) : (
          <>
            <div className="entry-bar">
              <span className="entry-progress">Answered {answeredCount} / {questions.length}</span>
              <button type="button" className="btn btn--primary" onClick={() => setConfirmOpen(true)} disabled={submitting}>
                Submit Test
              </button>
            </div>

            <ol className="q-list">
              {questions.map((q, i) => (
                <li key={q.questionID} className="q-card">
                  <div className="q-card__head">
                    <span className="q-card__num">Q{i + 1}</span>
                    <span className={`badge badge--${q.questionType === 'Coding' ? 'info' : 'neutral'}`}>
                      {QUESTION_TYPE_LABEL[q.questionType] || q.questionType}
                    </span>
                    <span className="q-card__marks">{q.marks} mark{q.marks === 1 ? '' : 's'}</span>
                  </div>
                  <p className="q-card__text">{q.questionText}</p>

                  {q.questionType === 'MultipleChoice' ? (
                    <ul className="q-answer-options">
                      {(q.options || []).map((o, idx) => (
                        <li key={idx}>
                          <label className="q-answer-option">
                            <input
                              type="radio"
                              name={`q-${q.questionID}`}
                              checked={answers[q.questionID]?.selectedOptionIndex === idx}
                              onChange={() => setMcq(q.questionID, idx)}
                            />
                            <span>{o.optionText}</span>
                          </label>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <textarea
                      className="field__input code-input"
                      rows={8}
                      placeholder={`Write your ${q.language || ''} solution here…`}
                      value={answers[q.questionID]?.codeAnswer ?? q.starterCode ?? ''}
                      onChange={(e) => setCode(q.questionID, e.target.value)}
                      spellCheck={false}
                      aria-label={`Answer for question ${i + 1}`}
                    />
                  )}
                </li>
              ))}
            </ol>

            <div className="declare-row">
              <p className="text-muted">
                Multiple-choice answers are graded automatically. Coding answers are reviewed by your assessor.
              </p>
              <button type="button" className="btn btn--primary" onClick={() => setConfirmOpen(true)} disabled={submitting}>
                Submit Test
              </button>
            </div>
          </>
        )}
      </main>

      {confirmOpen && (
        <ConfirmDialog
          title="Submit your test?"
          message={
            allAnswered
              ? 'Once submitted you cannot change your answers.'
              : `You have answered ${answeredCount} of ${questions.length} questions. Unanswered questions will be marked as blank. Submit anyway?`
          }
          confirmLabel="Submit"
          tone="primary"
          busy={submitting}
          onConfirm={submit}
          onCancel={() => (submitting ? null : setConfirmOpen(false))}
        />
      )}
    </div>
  );
}

/* ---- Read-only summary after submission ---- */
function AttemptSummary({ attempt, questions }) {
  const qById = useMemo(() => {
    const m = {};
    questions.forEach((q) => { m[q.questionID] = q; });
    return m;
  }, [questions]);

  return (
    <>
      <div className="dash__notice" role="status">
        <span>
          You submitted this test on {formatDate(attempt.submittedAt)}.{' '}
          <StatusBadge status={attempt.status} tone={ATTEMPT_STATUS_TONE[attempt.status] || 'neutral'} />
        </span>
      </div>

      <div className="attempt-scores">
        <div className="stat-tile">
          <span className="stat-tile__label">Auto-graded (MCQ)</span>
          <span className="stat-tile__value">{attempt.autoScore ?? '—'} / {attempt.autoMaxScore ?? '—'}</span>
        </div>
        <div className="stat-tile">
          <span className="stat-tile__label">Total {attempt.status === 'Graded' ? '' : '(pending review)'}</span>
          <span className="stat-tile__value">
            {attempt.status === 'Graded' ? `${attempt.totalScore ?? '—'} / ${attempt.maxScore ?? '—'}` : '—'}
          </span>
        </div>
      </div>

      <ol className="q-list q-list--review">
        {(attempt.answers || []).map((ans, i) => {
          const q = qById[ans.questionID] || {};
          const type = q.questionType || ans.questionType;
          return (
            <li key={ans.questionID ?? i} className="q-card">
              <div className="q-card__head">
                <span className="q-card__num">Q{i + 1}</span>
                <span className={`badge badge--${type === 'Coding' ? 'info' : 'neutral'}`}>
                  {QUESTION_TYPE_LABEL[type] || type}
                </span>
                {type === 'MultipleChoice' ? (
                  <span className={`badge badge--${ans.isCorrect ? 'success' : 'danger'}`}>
                    {ans.isCorrect ? 'Correct' : 'Incorrect'}
                  </span>
                ) : (
                  <span className="q-card__marks">
                    {ans.marksAwarded != null ? `${ans.marksAwarded} / ${q.marks}` : 'Awaiting review'}
                  </span>
                )}
              </div>
              <p className="q-card__text">{q.questionText}</p>
              {type === 'MultipleChoice' ? (
                <ul className="q-card__options">
                  {(q.options || []).map((o, idx) => (
                    <li key={idx} className={idx === q.correctOptionIndex ? 'is-correct' : idx === ans.selectedOptionIndex ? 'is-wrong' : ''}>
                      {idx === q.correctOptionIndex ? '✓ ' : idx === ans.selectedOptionIndex ? '✗ ' : ''}{o.optionText}
                    </li>
                  ))}
                </ul>
              ) : (
                <pre className="code-block">{ans.codeAnswer || '(no answer submitted)'}</pre>
              )}
            </li>
          );
        })}
      </ol>
    </>
  );
}
