// Trainee: trade tests scheduled for the trainee's batch(es) that they can
// write online. Shows whether each test has already been submitted.

import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import { useAuth } from '../../../shared/auth/AuthContext';
import { getTraineeByUser } from '../../training/api/trainees';
import { listEnrollments } from '../../training/api/enrollments';
import { listTradeTests } from '../api/assessment';
import { getMyTestAttempt } from '../api/testQuestions';
import { asList, ATTEMPT_STATUS_TONE } from '../constants/testQuestion';
import { TRADE_TEST_STATUS_TONE } from '../constants/assessment';
import { formatDate } from '../../../shared/format';

export default function TraineeTestListPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [boot, setBoot] = useState({ loading: true, error: '', traineeID: null });
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const trainee = await getTraineeByUser(user.userID);
        if (alive) setBoot({ loading: false, error: '', traineeID: trainee.traineeID });
      } catch (err) {
        if (alive)
          setBoot({
            loading: false,
            error: err?.response?.status === 404 ? 'No trainee profile is linked to your account yet.' : 'Could not load your profile.',
            traineeID: null,
          });
      }
    })();
    return () => { alive = false; };
  }, [user.userID]);

  const load = useCallback(async () => {
    if (!boot.traineeID) return;
    setLoading(true);
    setError('');
    try {
      // Batches the trainee is enrolled in → the tests scheduled for those batches.
      const enr = await listEnrollments({ traineeID: boot.traineeID, size: 100 });
      const batchIDs = [...new Set(asList(enr).map((e) => e.batchID).filter(Boolean))];

      const testPages = await Promise.all(
        batchIDs.map((batchID) =>
          listTradeTests({ batchID, page: 0, size: 100, sort: 'testDate,desc' }).catch(() => ({ content: [] }))
        )
      );
      const tests = testPages.flatMap((p) => p.content || []);

      // Attach each test's own submission status for this trainee.
      const withAttempts = await Promise.all(
        tests.map(async (t) => {
          try {
            const attempt = asList(await getMyTestAttempt(t.testID, boot.traineeID))[0] || null;
            return { ...t, attempt };
          } catch {
            return { ...t, attempt: null };
          }
        })
      );
      setRows(withAttempts);
    } catch {
      setError('Could not load your trade tests. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [boot.traineeID]);

  useEffect(() => { load(); }, [load]);

  if (boot.loading) {
    return (
      <div className="dash">
        <main className="page"><div className="table__state"><Spinner size={24} label="Loading" /> Loading…</div></main>
      </div>
    );
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">My Trade Tests</h1>
            <p className="page__subtitle">Write your scheduled trade tests online.</p>
          </div>
        </div>

        {boot.error ? (
          <div className="empty-state"><p>{boot.error}</p></div>
        ) : loading ? (
          <div className="table__state"><Spinner size={22} label="Loading" /> Loading…</div>
        ) : error ? (
          <div className="empty-state"><p>{error}</p><button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button></div>
        ) : rows.length === 0 ? (
          <div className="empty-state">
            <p>You have no scheduled trade tests.</p>
            <p className="empty-state__hint">Tests appear here once your assessor schedules them for your batch.</p>
          </div>
        ) : (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">Course</th>
                  <th scope="col">Test Date</th>
                  <th scope="col">Test Status</th>
                  <th scope="col">Your Submission</th>
                  <th scope="col" className="table__actions-col">Actions</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((t) => {
                  const submitted = Boolean(t.attempt);
                  const open = t.status === 'Scheduled' || t.status === 'Conducted';
                  return (
                    <tr key={t.testID}>
                      <td data-label="Course">{t.courseName || `Course #${t.courseID}`}</td>
                      <td data-label="Test Date">{formatDate(t.testDate)}</td>
                      <td data-label="Test Status">
                        <StatusBadge status={t.status} tone={TRADE_TEST_STATUS_TONE[t.status] || 'neutral'} />
                      </td>
                      <td data-label="Your Submission">
                        {submitted ? (
                          <StatusBadge status={t.attempt.status} tone={ATTEMPT_STATUS_TONE[t.attempt.status] || 'neutral'} />
                        ) : (
                          <span className="text-muted">Not submitted</span>
                        )}
                      </td>
                      <td data-label="Actions" className="table__actions">
                        <button
                          type="button"
                          className="btn btn--primary btn--sm"
                          onClick={() => navigate(`/trainee/tests/${t.testID}`)}
                          disabled={!open && !submitted}
                        >
                          {submitted ? 'View' : 'Start Test'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </main>
    </div>
  );
}
