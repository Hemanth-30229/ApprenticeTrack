// User API (AP-8).
//
// POST /api/users is Admin-gated on the backend, so it is used only for
// admin-driven user creation (createUser below).

import api from '../../../shared/api/client';

/**
 * Admin-authenticated user creation (sends the bearer token, which POST /api/users
 * requires). body: { name, role, email, password, phone, instituteID } -> user (201).
 */
export function createUser(body) {
  return api.post('/api/users', body).then((r) => r.data);
}

/** GET /api/users/{id} -> UserSummaryResponseDTO { userID, name, email, role, status } */
export function getUser(userId) {
  return api.get(`/api/users/${userId}`).then((r) => r.data);
}

/** GET /api/users/assessors?status= -> UserSummaryResponseDTO[] (assessors of that status). */
export function listAssessors(status = 'Active') {
  return api.get('/api/users/assessors', { params: { status } }).then((r) => r.data);
}

/** Admin action: permanently delete a user account. DELETE /api/users/{id} -> 204. */
export function deleteUser(userId) {
  return api.delete(`/api/users/${userId}`).then((r) => r.data);
}

/** Self-service: the signed-in user deletes their own account. DELETE /api/users/me -> 204. */
export function deleteMyAccount() {
  return api.delete('/api/users/me').then((r) => r.data);
}

/**
 * Self-service password change for the signed-in user (also used for the forced
 * first-login reset). body: { currentPassword, newPassword, confirmPassword } -> 204.
 */
export function changePassword({ currentPassword, newPassword, confirmPassword }) {
  return api
    .post('/api/users/me/change-password', { currentPassword, newPassword, confirmPassword })
    .then((r) => r.data);
}

/**
 * Admin action: set a new (temporary) password on any user's account. The user is
 * forced to change it on their next login. body: { newPassword, confirmPassword } -> 204.
 * POST /api/users/{id}/reset-password
 */
export function resetUserPassword(userId, { newPassword, confirmPassword }) {
  return api
    .post(`/api/users/${userId}/reset-password`, { newPassword, confirmPassword })
    .then((r) => r.data);
}

/** Admin-only paginated directory. Returns a Spring Page of UserSummaryResponseDTO. */
export function listUsers({ role, status, search, page = 0, size = 10, sort = 'userID,asc' } = {}) {
  const params = { page, size, sort };
  if (role) params.role = role;
  if (status) params.status = status;
  if (search) params.search = search;
  return api.get('/api/users', { params }).then((r) => r.data);
}
