// Password strength meter based on length + complexity rules.

function passwordChecks(pw) {
  return {
    length: pw.length >= 8,
    upper: /[A-Z]/.test(pw),
    number: /[0-9]/.test(pw),
    special: /[^A-Za-z0-9]/.test(pw),
  };
}

export function isStrongPassword(pw) {
  const c = passwordChecks(pw);
  return c.length && c.upper && c.number && c.special;
}

const LEVELS = [
  { label: 'Very weak', tone: 'danger' },
  { label: 'Weak', tone: 'danger' },
  { label: 'Fair', tone: 'warning' },
  { label: 'Good', tone: 'info' },
  { label: 'Strong', tone: 'success' },
];

export default function PasswordStrength({ password }) {
  if (!password) return null;
  const checks = passwordChecks(password);
  const score = Object.values(checks).filter(Boolean).length; // 0..4
  const level = LEVELS[score];

  return (
    <div className="pw-strength" aria-live="polite">
      <div className="pw-strength__bars">
        {[0, 1, 2, 3].map((i) => (
          <span key={i} className={`pw-strength__bar ${i < score ? `pw-strength__bar--${level.tone}` : ''}`} />
        ))}
      </div>
      <span className={`pw-strength__label pw-strength__label--${level.tone}`}>{level.label}</span>
      <ul className="pw-strength__rules">
        <li className={checks.length ? 'ok' : ''}>8+ characters</li>
        <li className={checks.upper ? 'ok' : ''}>uppercase</li>
        <li className={checks.number ? 'ok' : ''}>number</li>
        <li className={checks.special ? 'ok' : ''}>special char</li>
      </ul>
    </div>
  );
}
