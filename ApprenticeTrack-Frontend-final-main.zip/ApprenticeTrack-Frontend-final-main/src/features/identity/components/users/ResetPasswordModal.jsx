// Admin "Reset password" — sets a new temporary password on another user's
// account via POST /api/users/{id}/reset-password. The password is generated
// automatically from the user's role (e.g. "Trainee@12"), and the target user
// is forced to change it on their next login.

import { useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';

export default function ResetPasswordModal({ user, onClose, onSubmit }) {
  const [submitting, setSubmitting] = useState(false);
  const [apiError, setApiError] = useState('');

  // Temporary password based on the user's role, e.g. "Trainee@12".
  const newPassword = `${user.role}@12`;

  async function handleSubmit(e) {
    e.preventDefault();
    setApiError('');
    setSubmitting(true);
    try {
      await onSubmit({ newPassword, confirmPassword: newPassword });
    } catch (error) {
      const status = error?.response?.status;
      if (status === 401 || status === 403) setApiError('You are not authorised to reset passwords.');
      else if (status === 404) setApiError('This user no longer exists.');
      else setApiError(error?.response?.data?.message || 'Failed to reset password.');
      setSubmitting(false);
    }
  }

  return (
    <Modal title="Reset password" onClose={onClose} size="sm">
      <form className="form" onSubmit={handleSubmit}>
        {apiError && <div className="login__banner login__banner--error" role="alert">{apiError}</div>}
        <p className="page__subtitle">
          Reset the password for <strong>{user.name}</strong> ({user.email || user.role}). Their password will
          be set to <strong>{newPassword}</strong>. They will be required to change it the next time they log
          in, and their current sessions will be signed out.
        </p>

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={submitting}>Cancel</button>
          <button type="submit" className="btn btn--primary" disabled={submitting}>
            {submitting && <Spinner size={16} inline label="Resetting" />}
            Reset password
          </button>
        </div>
      </form>
    </Modal>
  );
}
