// Admin "Add User" — creates a login account of any role via POST /api/users.

import { useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import { ROLES } from '../../../../shared/auth/roles';

const ROLE_LIST = Object.values(ROLES);

// Check the form and return an object of error messages (empty = all good).
function validate(form) {
  const errors = {};
  if (!form.name.trim()) errors.name = 'Name is required';
  if (!form.email.trim()) errors.email = 'Email is required';
  if (!form.password) errors.password = 'Password is required';
  else if (form.password.length < 8) errors.password = 'Password must be at least 8 characters';
  if (!form.role) errors.role = 'Role is required';
  if (!form.phone.trim()) errors.phone = 'Phone is required';
  if (String(form.instituteID).trim() === '') errors.instituteID = 'Institute ID is required';
  return errors;
}

export default function UserFormModal({ defaultRole = '', onClose, onSubmit }) {
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    role: defaultRole,
    phone: '',
    instituteID: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState({});
  const [apiError, setApiError] = useState('');

  // Update one field in the form.
  function set(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setApiError('');

    const found = validate(form);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setSubmitting(true);
    try {
      await onSubmit({
        name: form.name.trim(),
        role: form.role,
        email: form.email.trim(),
        password: form.password,
        phone: form.phone.trim(),
        instituteID: Number(form.instituteID),
      });
    } catch (error) {
      const status = error?.response?.status;
      if (status === 409) setApiError('An account with this email already exists.');
      else if (status === 401 || status === 403) setApiError('You are not authorised to create users.');
      else setApiError(error?.response?.data?.message || 'Failed to create user.');
      setSubmitting(false);
    }
  }

  return (
    <Modal title="Add User" onClose={onClose} size="md">
      <form className="form" onSubmit={handleSubmit}>
        {apiError && <div className="login__banner login__banner--error" role="alert">{apiError}</div>}

        <div className="form__grid">
          <Field label="Name" error={errors.name}>
            <input type="text" className="field__input" value={form.name} onChange={(e) => set('name', e.target.value)} />
          </Field>

          <Field label="Role" error={errors.role}>
            <select className="field__input" value={form.role} onChange={(e) => set('role', e.target.value)}>
              <option value="">Select a role…</option>
              {ROLE_LIST.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
          </Field>

          <Field label="Email" error={errors.email}>
            <input type="email" className="field__input" value={form.email} onChange={(e) => set('email', e.target.value)} />
          </Field>

          <Field label="Phone" error={errors.phone}>
            <input type="tel" className="field__input" value={form.phone} onChange={(e) => set('phone', e.target.value)} />
          </Field>

          <Field label="Institute ID" error={errors.instituteID}>
            <input type="number" min="1" className="field__input" value={form.instituteID} onChange={(e) => set('instituteID', e.target.value)} />
          </Field>

          <Field label="Password" error={errors.password}>
            <div className="password-field">
              <input type={showPassword ? 'text' : 'password'} className="field__input" value={form.password} onChange={(e) => set('password', e.target.value)} />
              <button type="button" className="password-toggle" onClick={() => setShowPassword((s) => !s)}>
                {showPassword ? 'Hide' : 'Show'}
              </button>
            </div>
          </Field>
        </div>

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={submitting}>Cancel</button>
          <button type="submit" className="btn btn--primary" disabled={submitting}>
            {submitting && <Spinner size={16} inline label="Creating" />}
            Create User
          </button>
        </div>
      </form>
    </Modal>
  );
}

function Field({ label, error, children }) {
  return (
    <div className="field">
      <label className="field__label">{label}</label>
      {children}
      {error && <p className="field__error" role="alert">{error}</p>}
    </div>
  );
}
