import { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import Spinner from '../../../shared/Spinner';
import { useToast } from '../../../shared/toast/ToastContext';
import { useAuth } from '../../../shared/auth/AuthContext';
import { homePathForRole } from '../../../shared/auth/roles';
import { changePassword } from '../api/users';
import PasswordStrength, { isStrongPassword } from '../components/auth/PasswordStrength';
import './LoginPage.css';

export default function ChangePasswordPage() {
  const { user, isAuthenticated, logout, clearPasswordChangeRequirement } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();

  const [current, setCurrent] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  function validate() {
    if (!current) return 'Current password is required';
    if (!password) return 'New password is required';
    if (!isStrongPassword(password)) return 'Password does not meet the requirements';
    if (password === current) return 'New password must be different from the current password';
    if (confirm !== password) return 'Passwords do not match';
    return '';
  }

  async function handleSubmit(e) {
    e.preventDefault();

    const error = validate();
    if (error) {
      setFormError(error);
      return;
    }

    setFormError('');
    setSubmitting(true);
    try {
      await changePassword({ currentPassword: current, newPassword: password, confirmPassword: confirm });
      clearPasswordChangeRequirement();
      toast.success('Your password has been changed.');
      navigate(homePathForRole(user.role), { replace: true });
    } catch (err) {
      const status = err?.response?.status;
      if (status === 401) setFormError('Your current password is incorrect.');
      else setFormError('Something went wrong. Please try again.');
      setSubmitting(false);
    }
  }

  return (
    <div className="login">
      <div className="login__card">
        <header className="login__header">
          <div className="login__brand">AT</div>
          <h1 className="login__title">Change password</h1>
          <p className="login__subtitle">Set a new password to continue</p>
        </header>

        <div className="login__banner login__banner--info" role="status">
          For your security, you must change your password before continuing.
        </div>

        <form className="login__form" onSubmit={handleSubmit}>
          {formError && <div className="login__banner login__banner--error" role="alert">{formError}</div>}

          <div className="field">
            <label className="field__label" htmlFor="current">Current Password</label>
            <input
              id="current"
              type={showPassword ? 'text' : 'password'}
              className="field__input"
              value={current}
              onChange={(e) => setCurrent(e.target.value)}
            />
          </div>

          <div className="field">
            <label className="field__label" htmlFor="password">New Password</label>
            <div className="password-field">
              <input
                id="password"
                type={showPassword ? 'text' : 'password'}
                className="field__input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <button type="button" className="password-toggle" onClick={() => setShowPassword((s) => !s)}>
                {showPassword ? 'Hide' : 'Show'}
              </button>
            </div>
            <PasswordStrength password={password} />
          </div>

          <div className="field">
            <label className="field__label" htmlFor="confirm">Confirm New Password</label>
            <input
              id="confirm"
              type={showPassword ? 'text' : 'password'}
              className="field__input"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
            />
          </div>

          <button type="submit" className="btn btn--primary login__submit" disabled={submitting}>
            {submitting ? (<><Spinner size={18} inline label="Saving" /><span>Saving…</span></>) : 'Change Password'}
          </button>
        </form>

        <p className="login__footnote login__footnote--center">
          <button type="button" className="login__link login__link--button" onClick={logout}>
            Sign out
          </button>
        </p>
      </div>
    </div>
  );
}
