import { Link } from 'react-router-dom';
import './LoginPage.css';

export default function ForgotPasswordPage() {
  return (
    <div className="login">
      <div className="login__card">
        <header className="login__header">
          <div className="login__brand">AT</div>
          <h1 className="login__title">Forgot password</h1>
          <p className="login__subtitle">Password help</p>
        </header>

        <div className="login__banner login__banner--info" role="status">
          Please contact your administrator to reset your password.
        </div>

        <p className="login__footnote login__footnote--center">
          <Link to="/login" className="login__link">← Back to Login</Link>
        </p>
      </div>
    </div>
  );
}
