import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../../shared/auth/AuthContext';
import { homePathForRole } from '../../../shared/auth/roles';
import Spinner from '../../../shared/Spinner';
import './LoginPage.css';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  async function handleSubmit(event) {
    event.preventDefault();

    if (!email.trim() || !password) {
      setFormError('Please enter your email and password.');
      return;
    }

    setFormError('');
    setSubmitting(true);
    try {
      const profile = await login(email.trim(), password);
      navigate(
        profile.mustChangePassword ? '/change-password' : homePathForRole(profile.role),
        { replace: true },
      );
    } catch (err) {
      setFormError('Invalid email or password. Please try again.');
      setSubmitting(false);
    }
  }

  return (
    <div className="login">
      <div className="login__card">
        <header className="login__header">
          <div className="login__brand">AT</div>
          <h1 className="login__title">ApprenticeTrack</h1>
          <p className="login__subtitle">Sign in to your account</p>
        </header>

        {formError && (
          <div className="login__banner login__banner--error" role="alert">
            {formError}
          </div>
        )}

        <form className="login__form" onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="email" className="field__label">
              Email
            </label>
            <input
              id="email"
              type="email"
              className="field__input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={submitting}
            />
          </div>

          <div className="field">
            <label htmlFor="password" className="field__label">
              Password
            </label>
            <input
              id="password"
              type="password"
              className="field__input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={submitting}
            />
          </div>

          <div className="login__row">
            <Link to="/forgot-password" className="login__link">
              Forgot password?
            </Link>
          </div>

          <button
            type="submit"
            className="btn btn--primary login__submit"
            disabled={submitting}
          >
            {submitting ? (
              <>
                <Spinner size={18} inline label="Signing in" />
                <span>Signing in…</span>
              </>
            ) : (
              'Login'
            )}
          </button>
        </form>
      </div>

      <p className="login__footnote">
        ApprenticeTrack · Skilling & Placement Platform
      </p>
    </div>
  );
}
