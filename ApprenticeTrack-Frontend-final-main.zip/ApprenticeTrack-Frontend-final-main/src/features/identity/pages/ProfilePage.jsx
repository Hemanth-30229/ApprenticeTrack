// My profile: shows the signed-in user's account details (from useAuth + a fresh
// getUser lookup) and lets them delete their own account.
import { useEffect, useState } from 'react';
import { useAuth } from '../../../shared/auth/AuthContext';
import { deleteMyAccount, getUser } from '../api/users';
import { apiErrorMessage } from '../../../shared/api/errors';
import { useToast } from '../../../shared/toast/ToastContext';
import ConfirmDialog from '../../../shared/ui/ConfirmDialog';
import StatusBadge from '../../../shared/ui/StatusBadge';

export default function ProfilePage() {
  const { user, logout } = useAuth();
  const toast = useToast();
  const [details, setDetails] = useState(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  async function handleDeleteAccount() {
    setDeleting(true);
    try {
      await deleteMyAccount();
      toast.success('Your account has been deleted.');
      logout(); // clears the session and redirects to /login
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Could not delete your account. Please try again.'));
      setDeleting(false);
      setConfirmOpen(false);
    }
  }

  // Enrich with email/status from GET /api/users/{id} (best-effort).
  useEffect(() => {
    let alive = true;
    if (user?.userID) {
      getUser(user.userID).then((u) => alive && setDetails(u)).catch(() => {});
    }
    return () => { alive = false; };
  }, [user?.userID]);

  return (
    <div className="page">
      <div className="page__heading">
        <div>
          <h1 className="page__title">My Profile</h1>
          <p className="page__subtitle">Your account details.</p>
        </div>
      </div>

      <div className="placeholder-card" style={{ textAlign: 'left', maxWidth: 520 }}>
        <dl className="detail-grid">
          <div className="detail-grid__row"><dt className="detail-grid__label">Name</dt><dd className="detail-grid__value">{user?.name || '—'}</dd></div>
          <div className="detail-grid__row"><dt className="detail-grid__label">Role</dt><dd className="detail-grid__value"><span className="badge badge--info">{user?.role}</span></dd></div>
          <div className="detail-grid__row"><dt className="detail-grid__label">Email</dt><dd className="detail-grid__value">{details?.email || '—'}</dd></div>
          <div className="detail-grid__row"><dt className="detail-grid__label">Institute ID</dt><dd className="detail-grid__value">{user?.instituteID ?? '—'}</dd></div>
          <div className="detail-grid__row"><dt className="detail-grid__label">User ID</dt><dd className="detail-grid__value">#{user?.userID}</dd></div>
          {details?.status && (
            <div className="detail-grid__row"><dt className="detail-grid__label">Status</dt><dd className="detail-grid__value"><StatusBadge status={details.status} tone={details.status === 'Active' ? 'success' : 'neutral'} /></dd></div>
          )}
        </dl>
        <div className="modal__actions">
          <button type="button" className="btn btn--danger-ghost" onClick={logout}>Logout</button>
        </div>
      </div>

      <div className="placeholder-card" style={{ textAlign: 'left', maxWidth: 520, marginTop: 16 }}>
        <h2 className="form__section-title" style={{ marginTop: 0 }}>Danger zone</h2>
        <p className="muted" style={{ margin: '0 0 12px' }}>
          Deleting your account permanently removes your login. This cannot be undone.
        </p>
        <button type="button" className="btn btn--danger" onClick={() => setConfirmOpen(true)}>
          Delete My Account
        </button>
      </div>

      {confirmOpen && (
        <ConfirmDialog
          title="Delete your account?"
          message="This permanently deletes your login account and signs you out. This cannot be undone."
          confirmLabel="Delete My Account"
          busy={deleting}
          onConfirm={handleDeleteAccount}
          onCancel={() => (deleting ? null : setConfirmOpen(false))}
        />
      )}
    </div>
  );
}
