// User management (admin): the account directory. List-page pattern (see
// PlacementListPage). Create accounts, delete them, and reset a user's password
// (ResetPasswordModal) — a reset forces the user to change it on next login.
import { useEffect, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import ConfirmDialog from '../../../shared/ui/ConfirmDialog';
import UserFormModal from '../components/users/UserFormModal';
import ResetPasswordModal from '../components/users/ResetPasswordModal';
import { useToast } from '../../../shared/toast/ToastContext';
import { createUser, deleteUser, listUsers, resetUserPassword } from '../api/users';
import { useAuth } from '../../../shared/auth/AuthContext';
import { apiErrorMessage } from '../../../shared/api/errors';
import { ROLES } from '../../../shared/auth/roles';

const PAGE_SIZE = 10;
const ROLE_LIST = Object.values(ROLES);
const USER_STATUSES = ['Active', 'Inactive', 'Graduated'];
const STATUS_TONE = { Active: 'success', Inactive: 'neutral', Graduated: 'info' };

export default function UserManagementPage() {
  const toast = useToast();
  const { user: currentUser } = useAuth();

  const [removing, setRemoving] = useState(null);
  const [removeBusy, setRemoveBusy] = useState(false);

  const [resetting, setResetting] = useState(null);

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);

  const [search, setSearch] = useState('');
  const [role, setRole] = useState('');
  const [status, setStatus] = useState('');

  const [formOpen, setFormOpen] = useState(false);

  async function load() {
    setLoading(true);
    setError('');
    try {
      const data = await listUsers({
        role: role || undefined,
        status: status || undefined,
        search: search || undefined,
        page,
        size: PAGE_SIZE,
        sort: 'userID,asc',
      });
      setRows(data.content || []);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
    } catch (err) {
      setError(
        err?.response?.status === 401 || err?.response?.status === 403
          ? 'You are not authorised to view users (Admin only).'
          : 'Could not load users. Please try again.'
      );
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  // Reload whenever a filter or the page changes.
  useEffect(() => {
    load();
  }, [role, status, search, page]);

  async function handleCreate(payload) {
    const created = await createUser(payload); // throws -> modal shows the error
    toast.success(`User created (ID ${created.userID}). Role: ${created.role}.`);
    setFormOpen(false);
    if (page !== 0) setPage(0);
    else load();
  }

  async function handleResetPassword(body) {
    await resetUserPassword(resetting.userID, body); // throws -> modal shows the error
    toast.success(`Password reset for "${resetting.name}". They must change it on next login.`);
    setResetting(null);
  }

  async function handleRemove() {
    setRemoveBusy(true);
    try {
      await deleteUser(removing.userID);
      toast.success(`User "${removing.name}" deleted.`);
      setRemoving(null);
      load();
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Failed to delete user.'));
    } finally {
      setRemoveBusy(false);
    }
  }

  const from = pageInfo.totalElements === 0 ? 0 : page * PAGE_SIZE + 1;
  const to = Math.min((page + 1) * PAGE_SIZE, pageInfo.totalElements);

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Users</h1>
            <p className="page__subtitle">Create and browse login accounts.</p>
          </div>
          <button type="button" className="btn btn--primary" onClick={() => setFormOpen(true)}>
            + Add User
          </button>
        </div>

        <div className="toolbar">
          <div className="toolbar__search">
            <label htmlFor="user-search" className="sr-only">Search users by name or email</label>
            <input id="user-search" type="search" className="field__input" placeholder="Search name or email…" value={search} onChange={(e) => { setSearch(e.target.value); setPage(0); }} />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="role-filter" className="field__label field__label--sm">Role</label>
            <select id="role-filter" className="field__input" value={role} onChange={(e) => { setRole(e.target.value); setPage(0); }}>
              <option value="">All roles</option>
              {ROLE_LIST.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="field__label field__label--sm">Status</label>
            <select id="status-filter" className="field__input" value={status} onChange={(e) => { setStatus(e.target.value); setPage(0); }}>
              <option value="">All statuses</option>
              {USER_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">User ID</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Role</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
              ) : error ? (
                <tr><td colSpan={6} className="table__state table__state--error">{error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button></td></tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan={6} className="table__state">No users found.</td></tr>
              ) : (
                rows.map((u) => (
                  <tr key={u.userID}>
                    <td data-label="User ID">#{u.userID}</td>
                    <td data-label="Name">{u.name}</td>
                    <td data-label="Email">{u.email || '—'}</td>
                    <td data-label="Role">{u.role}</td>
                    <td data-label="Status"><StatusBadge status={u.status} tone={STATUS_TONE[u.status] || 'neutral'} /></td>
                    <td data-label="Actions" className="table__actions">
                      {u.userID === currentUser?.userID ? (
                        <span className="text-muted">You</span>
                      ) : (
                        <>
                          <button type="button" className="btn btn--secondary btn--sm" onClick={() => setResetting(u)}>Reset password</button>
                          <button type="button" className="btn btn--danger-ghost btn--sm" onClick={() => setRemoving(u)}>Delete</button>
                        </>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <span className="pagination__info">
            {pageInfo.totalElements > 0 ? `Showing ${from}–${to} of ${pageInfo.totalElements}` : ' '}
          </span>
          <div className="pagination__controls">
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={loading || page === 0}>← Previous</button>
            <span className="pagination__page">Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}</span>
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => p + 1)} disabled={loading || page + 1 >= pageInfo.totalPages}>Next →</button>
          </div>
        </div>
      </main>

      {formOpen && <UserFormModal onClose={() => setFormOpen(false)} onSubmit={handleCreate} />}

      {resetting && (
        <ResetPasswordModal
          user={resetting}
          onClose={() => setResetting(null)}
          onSubmit={handleResetPassword}
        />
      )}

      {removing && (
        <ConfirmDialog
          title="Delete user?"
          message={`Permanently delete "${removing.name}" (${removing.role})? This removes their login account and cannot be undone.`}
          confirmLabel="Delete"
          busy={removeBusy}
          onConfirm={handleRemove}
          onCancel={() => (removeBusy ? null : setRemoving(null))}
        />
      )}
    </div>
  );
}
