// Attendance Summary API (AP-19), implemented in ojt-stipend-service.
//
// Response DTO (Spring Page of):
//   { summaryID, placementID, traineeID, month, year,
//     workingDays, daysAttended, attendancePercent, stipendEligible, status }
// Status is one of "Computed" | "Approved".

import api from '../../../shared/api/client';

const BASE = '/api/attendance-summaries';

export function listAttendanceSummaries({
  traineeID,
  placementID,
  month,
  year,
  status,
  stipendEligible, // boolean | undefined
  page = 0,
  size = 10,
  sort = 'year,desc',
} = {}) {
  const params = { page, size, sort };
  if (traineeID) params.traineeID = traineeID;
  if (placementID) params.placementID = placementID;
  if (month) params.month = month;
  if (year) params.year = year;
  if (status) params.status = status;
  if (stipendEligible !== undefined && stipendEligible !== '') params.stipendEligible = stipendEligible;
  return api.get(BASE, { params }).then((r) => r.data);
}

/** POST /compute { placementID, month, year } */
export function computeAttendance({ placementID, month, year }) {
  return api.post(`${BASE}/compute`, { placementID, month, year }).then((r) => r.data);
}

export function approveAttendance(id) {
  return api.put(`${BASE}/${id}/approve`).then((r) => r.data);
}

/**
 * Recompute an existing (non-approved) summary so it picks up OJT logs confirmed
 * after the first computation. PUT /{id}/recompute. Approved summaries are frozen
 * server-side and will be rejected.
 */
export function recomputeAttendance(id) {
  return api.put(`${BASE}/${id}/recompute`).then((r) => r.data);
}

/** PUT /bulk-approve { summaryIDs:[] } -> { totalRequested, approved:[], failed:[{summaryID,reason}] } */
export function bulkApproveAttendance(summaryIDs) {
  return api.put(`${BASE}/bulk-approve`, { summaryIDs }).then((r) => r.data);
}
