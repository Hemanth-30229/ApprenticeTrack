// OJT Log API (AP-17, submission) + OJT Approval API (AP-18) via the gateway.
//
// Both sides are implemented in ojt-stipend-service's OJTLogController:
//   AP-17 submission: POST /api/ojt-logs, PUT /api/ojt-logs/{id}
//   AP-18 approval:   PUT /{id}/approve, PUT /{id}/reject, PUT /bulk-approve
// createOjtLog / updateOjtLog send OJTLogCreateRequestDTO
// { placementID, traineeID, logDate, tasksPerformed, hoursWorked }.

import api from '../../../shared/api/client';

// --- AP-18: read + approval side (implemented in backend) ------------------

/** Backend supports these query params: status, placementId, traineeID, page, size, sort. */
export function listOjtLogs({ status, placementId, traineeID, page = 0, size = 10, sort = 'logDate,desc' } = {}) {
  const params = { page, size, sort };
  if (status) params.status = status;
  if (placementId) params.placementId = placementId;
  if (traineeID) params.traineeID = traineeID;
  return api.get('/api/ojt-logs', { params }).then((r) => r.data);
}

export function approveOjtLog(id) {
  return api.put(`/api/ojt-logs/${id}/approve`).then((r) => r.data);
}

export function rejectOjtLog(id, rejectionReason) {
  return api.put(`/api/ojt-logs/${id}/reject`, { rejectionReason }).then((r) => r.data);
}

/** Returns BulkApproveResponseDTO { totalRequested, approved:[], failed:[{logID,reason}] }. */
export function bulkApproveOjtLogs(logIDs) {
  return api.put('/api/ojt-logs/bulk-approve', { logIDs }).then((r) => r.data);
}

// --- AP-17: submission side (implemented in backend) -----------------------

/** body: { logDate, tasksPerformed, hoursWorked, placementID, traineeID } */
export function createOjtLog(body) {
  return api.post('/api/ojt-logs', body).then((r) => r.data);
}

/**
 * Bulk submission for back-filling past dates. body: { logs: [{ logDate, tasksPerformed,
 * hoursWorked, placementID, traineeID }, ...] } -> OJTLogResponseDTO[] (201).
 */
export function bulkCreateOjtLogs(logs) {
  return api.post('/api/ojt-logs/bulk', { logs }).then((r) => r.data);
}

export function updateOjtLog(id, body) {
  return api.put(`/api/ojt-logs/${id}`, body).then((r) => r.data);
}
