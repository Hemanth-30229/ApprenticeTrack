// Stipend API (AP-23) via the gateway.

import api from '../../../shared/api/client';

const BASE = '/api/stipend-disbursements';

export function listStipends({
  traineeID,
  placementID,
  month,
  year,
  status,
  page = 0,
  size = 10,
  sort = 'disbursementID,desc',
} = {}) {
  const params = { page, size, sort };
  if (traineeID) params.traineeID = traineeID;
  if (placementID) params.placementID = placementID;
  if (month) params.month = month;
  if (year) params.year = year;
  if (status) params.status = status;
  return api.get(BASE, { params }).then((r) => r.data);
}

/** POST /calculate { traineeID, placementID, month, year } -> disbursement (201). */
export function calculateStipend(body) {
  return api.post(`${BASE}/calculate`, body).then((r) => r.data);
}

export function approveStipend(id) {
  return api.put(`${BASE}/${id}/approve`).then((r) => r.data);
}

export function disburseStipend(id) {
  return api.put(`${BASE}/${id}/disburse`).then((r) => r.data);
}

/** PUT /bulk-approve { disbursementIDs:[] } -> { totalRequested, approved:[], failed:[] } */
export function bulkApproveStipends(disbursementIDs) {
  return api.put(`${BASE}/bulk-approve`, { disbursementIDs }).then((r) => r.data);
}
