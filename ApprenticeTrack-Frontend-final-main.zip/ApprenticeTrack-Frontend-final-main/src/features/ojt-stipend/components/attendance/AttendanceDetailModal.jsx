// Attendance detail: daily OJT log breakdown for the summary's month.
// Derived from the real GET /api/ojt-logs (filtered client-side by month/year),
// since the backend has no per-day attendance endpoint.

import { useEffect, useMemo, useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import StatusBadge from '../../../../shared/ui/StatusBadge';
import { listOjtLogs } from '../../api/ojtLogs';
import { OJT_LOG_STATUS_TONE } from '../../constants/ojtLog';
import { monthLabel } from '../../constants/attendance';
import { formatDate } from '../../../../shared/format';

export default function AttendanceDetailModal({ summary, onClose }) {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      setError('');
      try {
        // Fetch a generous page of the placement's logs; filter to the month.
        const data = await listOjtLogs({ placementId: summary.placementID, page: 0, size: 200, sort: 'logDate,asc' });
        if (!alive) return;
        setLogs(data.content || []);
      } catch {
        if (alive) setError('Could not load the daily log breakdown.');
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [summary.placementID]);

  const monthLogs = useMemo(
    () =>
      logs.filter((l) => {
        if (!l.logDate) return false;
        const d = new Date(l.logDate);
        return d.getMonth() + 1 === Number(summary.month) && d.getFullYear() === Number(summary.year);
      }),
    [logs, summary.month, summary.year]
  );

  const confirmed = monthLogs.filter((l) => l.status === 'SupervisorConfirmed').length;

  return (
    <Modal title={`Attendance · ${monthLabel(summary.month)} ${summary.year}`} onClose={onClose} size="lg">
      <dl className="detail-grid">
        <Row label="Trainee" value={summary.traineeName || `#${summary.traineeID}`} />
        <Row label="Placement" value={`#${summary.placementID}`} />
        <Row label="Working Days" value={summary.workingDays} />
        <Row label="Days Attended" value={summary.daysAttended} />
        <Row label="Attendance" value={summary.attendancePercent != null ? `${summary.attendancePercent}%` : '—'} />
        <Row label="Confirmed logs this month" value={confirmed} />
      </dl>

      <h3 className="detail-section-title">Daily OJT Logs</h3>
      {loading ? (
        <p className="widget__empty"><Spinner size={18} inline label="Loading" /> Loading…</p>
      ) : error ? (
        <p className="field__error" role="alert">{error}</p>
      ) : monthLogs.length === 0 ? (
        <p className="widget__empty">No OJT logs recorded for this month.</p>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Date</th>
                <th scope="col">Tasks</th>
                <th scope="col">Hours</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
              {monthLogs.map((l) => (
                <tr key={l.logID}>
                  <td data-label="Date">{formatDate(l.logDate)}</td>
                  <td data-label="Tasks">
                    <span title={l.tasksPerformed}>
                      {l.tasksPerformed && l.tasksPerformed.length > 70
                        ? `${l.tasksPerformed.slice(0, 70)}…`
                        : l.tasksPerformed || '—'}
                    </span>
                  </td>
                  <td data-label="Hours">{l.hoursWorked ?? '—'}</td>
                  <td data-label="Status">
                    <StatusBadge status={l.status} tone={OJT_LOG_STATUS_TONE[l.status] || 'neutral'} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="modal__actions">
        <button type="button" className="btn btn--secondary" onClick={onClose}>Close</button>
      </div>
    </Modal>
  );
}

function Row({ label, value }) {
  return (
    <div className="detail-grid__row">
      <dt className="detail-grid__label">{label}</dt>
      <dd className="detail-grid__value">{value ?? '—'}</dd>
    </div>
  );
}
