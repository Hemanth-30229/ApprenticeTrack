// Trigger monthly attendance computation for a placement/month/year.

import { useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import PlacementSelect from '../../../placement/components/placements/PlacementSelect';
import { MONTHS, recentYears } from '../../constants/attendance';

export default function ComputeAttendanceModal({ onClose, onCompute }) {
  const now = new Date();
  const [placement, setPlacement] = useState(null); // { value, label, traineeID }
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [touched, setTouched] = useState(false);
  const [busy, setBusy] = useState(false);

  const placementError = placement ? '' : 'Select a placement';
  const isValid = !placementError && month && year;

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched(true);
    if (!isValid) return;
    setBusy(true);
    try {
      await onCompute({ placementID: Number(placement.value), month: Number(month), year: Number(year) });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal title="Compute Attendance" onClose={busy ? () => {} : onClose} size="sm">
      <form className="form" onSubmit={handleSubmit} noValidate>
        <div className="field">
          <label className="field__label" htmlFor="placement">
            Placement <span className="field__req" aria-hidden="true">*</span>
          </label>
          <PlacementSelect
            value={placement?.value}
            selectedLabel={placement?.label}
            onSelect={(opt) => { setPlacement(opt); setTouched(true); }}
            invalid={touched && Boolean(placementError)}
          />
          {touched && placementError && <p className="field__error" role="alert">{placementError}</p>}
        </div>

        <div className="form__grid">
          <div className="field">
            <label className="field__label" htmlFor="month">Month</label>
            <select id="month" className="field__input" value={month} onChange={(e) => setMonth(e.target.value)}>
              {MONTHS.map((m) => (
                <option key={m.value} value={m.value}>{m.label}</option>
              ))}
            </select>
          </div>
          <div className="field">
            <label className="field__label" htmlFor="year">Year</label>
            <select id="year" className="field__input" value={year} onChange={(e) => setYear(e.target.value)}>
              {recentYears(6).map((y) => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <button type="submit" className="btn btn--primary" disabled={!isValid || busy} aria-busy={busy}>
            {busy && <Spinner size={16} inline label="Computing" />}
            Compute
          </button>
        </div>
      </form>
    </Modal>
  );
}
