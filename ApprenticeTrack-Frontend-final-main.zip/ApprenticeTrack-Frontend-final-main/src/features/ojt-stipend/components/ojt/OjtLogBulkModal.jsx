// Bulk OJT log entry for back-filling past dates. The trainee adds several rows
// (date / tasks / hours) and submits them in one request via POST /api/ojt-logs/bulk.

import { useMemo, useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import {
  HOURS_MAX,
  HOURS_MIN,
  TASKS_MAX_LENGTH,
  TASKS_MIN_LENGTH,
} from '../../constants/ojtLog';

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function emptyRow() {
  return { logDate: '', tasksPerformed: '', hoursWorked: '' };
}

function rowErrors(row) {
  const e = {};
  if (!row.logDate) e.logDate = 'Date is required';
  else if (row.logDate > todayISO()) e.logDate = 'Date cannot be in the future';

  const tasks = row.tasksPerformed.trim();
  if (!tasks) e.tasksPerformed = 'Describe the tasks performed';
  else if (tasks.length < TASKS_MIN_LENGTH) e.tasksPerformed = `At least ${TASKS_MIN_LENGTH} characters`;
  else if (row.tasksPerformed.length > TASKS_MAX_LENGTH) e.tasksPerformed = `Maximum ${TASKS_MAX_LENGTH} characters`;

  const h = String(row.hoursWorked).trim();
  if (h === '') e.hoursWorked = 'Required';
  else if (Number.isNaN(Number(h))) e.hoursWorked = 'Enter a number';
  else if (Number(h) < HOURS_MIN || Number(h) > HOURS_MAX) e.hoursWorked = `${HOURS_MIN}–${HOURS_MAX}`;
  return e;
}

export default function OjtLogBulkModal({ placementID, traineeID, onClose, onSubmit }) {
  const [rows, setRows] = useState(() => [emptyRow(), emptyRow()]);
  const [showErrors, setShowErrors] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const errorsByRow = useMemo(() => rows.map(rowErrors), [rows]);
  const duplicateDates = useMemo(() => {
    const seen = new Set();
    const dupes = new Set();
    rows.forEach((r) => {
      if (r.logDate) {
        if (seen.has(r.logDate)) dupes.add(r.logDate);
        seen.add(r.logDate);
      }
    });
    return dupes;
  }, [rows]);

  const isValid =
    rows.length > 0 &&
    errorsByRow.every((e) => Object.keys(e).length === 0) &&
    duplicateDates.size === 0;

  const setRow = (i, field, value) =>
    setRows((rs) => rs.map((r, idx) => (idx === i ? { ...r, [field]: value } : r)));
  const addRow = () => setRows((rs) => [...rs, emptyRow()]);
  const removeRow = (i) => setRows((rs) => (rs.length > 1 ? rs.filter((_, idx) => idx !== i) : rs));

  async function handleSubmit(e) {
    e.preventDefault();
    setShowErrors(true);
    if (!isValid) return;
    const logs = rows.map((r) => ({
      logDate: r.logDate,
      tasksPerformed: r.tasksPerformed.trim(),
      hoursWorked: Number(r.hoursWorked),
      placementID,
      traineeID,
    }));
    setSubmitting(true);
    try {
      await onSubmit(logs);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="Add Past OJT Logs (bulk)" onClose={onClose} size="md">
      <form className="form" onSubmit={handleSubmit} noValidate>
        <p className="page__subtitle">
          Add one row per day. Useful for back-filling logs for past dates you missed.
        </p>

        {rows.map((row, i) => {
          const e = showErrors ? errorsByRow[i] : {};
          const dup = row.logDate && duplicateDates.has(row.logDate);
          return (
            <div key={i} className="bulk-log-row">
              <div className="bulk-log-row__head">
                <strong>Log {i + 1}</strong>
                {rows.length > 1 && (
                  <button
                    type="button"
                    className="btn btn--danger-ghost btn--sm"
                    onClick={() => removeRow(i)}
                    aria-label={`Remove log ${i + 1}`}
                  >
                    Remove
                  </button>
                )}
              </div>
              <div className="form__grid">
                <div className="field">
                  <label className="field__label field__label--sm">
                    Date <span className="field__req" aria-hidden="true">*</span>
                  </label>
                  <input
                    type="date"
                    className="field__input"
                    value={row.logDate}
                    max={todayISO()}
                    onChange={(ev) => setRow(i, 'logDate', ev.target.value)}
                    aria-invalid={Boolean(e.logDate) || Boolean(dup)}
                  />
                  {e.logDate && <p className="field__error" role="alert">{e.logDate}</p>}
                  {!e.logDate && dup && (
                    <p className="field__error" role="alert">Duplicate date in this batch</p>
                  )}
                </div>
                <div className="field">
                  <label className="field__label field__label--sm">
                    Hours <span className="field__req" aria-hidden="true">*</span>
                  </label>
                  <input
                    type="number"
                    className="field__input"
                    min={HOURS_MIN}
                    max={HOURS_MAX}
                    step="0.5"
                    value={row.hoursWorked}
                    onChange={(ev) => setRow(i, 'hoursWorked', ev.target.value)}
                    aria-invalid={Boolean(e.hoursWorked)}
                  />
                  {e.hoursWorked && <p className="field__error" role="alert">{e.hoursWorked}</p>}
                </div>
              </div>
              <div className="field">
                <label className="field__label field__label--sm">
                  Tasks Performed <span className="field__req" aria-hidden="true">*</span>
                </label>
                <textarea
                  className="field__input"
                  rows={2}
                  maxLength={TASKS_MAX_LENGTH}
                  value={row.tasksPerformed}
                  onChange={(ev) => setRow(i, 'tasksPerformed', ev.target.value)}
                  aria-invalid={Boolean(e.tasksPerformed)}
                />
                {e.tasksPerformed && <p className="field__error" role="alert">{e.tasksPerformed}</p>}
              </div>
            </div>
          );
        })}

        <button type="button" className="btn btn--secondary btn--sm" onClick={addRow}>
          + Add another day
        </button>

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={submitting}>
            Cancel
          </button>
          <button type="submit" className="btn btn--primary" disabled={!isValid || submitting} aria-busy={submitting}>
            {submitting && <Spinner size={16} inline label="Submitting" />}
            Submit {rows.length} log{rows.length === 1 ? '' : 's'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
