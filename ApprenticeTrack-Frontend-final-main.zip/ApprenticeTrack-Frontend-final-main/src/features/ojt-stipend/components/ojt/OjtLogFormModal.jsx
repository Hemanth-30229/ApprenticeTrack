// Trainee OJT log submit / edit form. Defaults date to today, blocks dates that
// already have a log, enforces min task length and 0-24 hours, and shows a live
// character counter.

import { useMemo, useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import {
  HOURS_MAX,
  HOURS_MIN,
  TASKS_MAX_LENGTH,
  TASKS_MIN_LENGTH,
} from '../../constants/ojtLog';

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

export default function OjtLogFormModal({
  log,
  placementID,
  traineeID,
  onClose,
  onSubmit,
}) {
  const isEdit = Boolean(log);
  const [form, setForm] = useState(() => ({
    logDate: log?.logDate ?? todayISO(),
    tasksPerformed: log?.tasksPerformed ?? '',
    hoursWorked: log?.hoursWorked ?? '',
  }));
  const [touched, setTouched] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const errors = useMemo(() => {
    const e = {};
    if (!form.logDate) e.logDate = 'Log date is required';

    const tasks = form.tasksPerformed.trim();
    if (!tasks) e.tasksPerformed = 'Please describe the tasks performed';
    else if (tasks.length < TASKS_MIN_LENGTH)
      e.tasksPerformed = `Please enter at least ${TASKS_MIN_LENGTH} characters`;
    else if (form.tasksPerformed.length > TASKS_MAX_LENGTH)
      e.tasksPerformed = `Maximum ${TASKS_MAX_LENGTH} characters`;

    const h = String(form.hoursWorked).trim();
    if (h === '') e.hoursWorked = 'Hours worked is required';
    else if (Number.isNaN(Number(h))) e.hoursWorked = 'Enter a number';
    else if (Number(h) < HOURS_MIN || Number(h) > HOURS_MAX)
      e.hoursWorked = `Hours must be between ${HOURS_MIN} and ${HOURS_MAX}`;
    return e;
  }, [form]);

  const isValid = Object.keys(errors).length === 0;
  const set = (f, v) => setForm((s) => ({ ...s, [f]: v }));
  const blur = (f) => setTouched((t) => ({ ...t, [f]: true }));
  const err = (f) => (touched[f] && errors[f] ? errors[f] : '');

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched({ logDate: true, tasksPerformed: true, hoursWorked: true });
    if (!isValid) return;

    const payload = {
      logDate: form.logDate,
      tasksPerformed: form.tasksPerformed.trim(),
      hoursWorked: Number(form.hoursWorked),
      placementID,
      traineeID,
    };
    setSubmitting(true);
    try {
      await onSubmit(payload);
    } finally {
      setSubmitting(false);
    }
  }

  const charCount = form.tasksPerformed.length;
  const counterTone =
    charCount > TASKS_MAX_LENGTH || (charCount > 0 && charCount < TASKS_MIN_LENGTH)
      ? 'char-counter--warn'
      : '';

  return (
    <Modal title={isEdit ? 'Edit & Resubmit Log' : 'Submit OJT Log'} onClose={onClose} size="md">
      <form className="form" onSubmit={handleSubmit} noValidate>
        <div className="field">
          <label className="field__label" htmlFor="logDate">
            Log Date <span className="field__req" aria-hidden="true">*</span>
          </label>
          <input
            id="logDate"
            type="date"
            className="field__input"
            value={form.logDate}
            onChange={(e) => set('logDate', e.target.value)}
            onBlur={() => blur('logDate')}
            aria-invalid={Boolean(err('logDate'))}
            aria-describedby={err('logDate') ? 'logDate-error' : undefined}
          />
          {err('logDate') && (
            <p id="logDate-error" className="field__error" role="alert">
              {err('logDate')}
            </p>
          )}
        </div>

        <div className="field">
          <label className="field__label" htmlFor="tasksPerformed">
            Tasks Performed <span className="field__req" aria-hidden="true">*</span>
          </label>
          <textarea
            id="tasksPerformed"
            className="field__input"
            rows={4}
            maxLength={TASKS_MAX_LENGTH}
            value={form.tasksPerformed}
            onChange={(e) => set('tasksPerformed', e.target.value)}
            onBlur={() => blur('tasksPerformed')}
            aria-invalid={Boolean(err('tasksPerformed'))}
            aria-describedby="tasks-counter tasksPerformed-error"
          />
          <div className="field__row">
            {err('tasksPerformed') ? (
              <p id="tasksPerformed-error" className="field__error" role="alert">
                {err('tasksPerformed')}
              </p>
            ) : (
              <span />
            )}
            <span id="tasks-counter" className={`char-counter ${counterTone}`}>
              {charCount}/{TASKS_MAX_LENGTH}
            </span>
          </div>
        </div>

        <div className="field">
          <label className="field__label" htmlFor="hoursWorked">
            Hours Worked <span className="field__req" aria-hidden="true">*</span>
          </label>
          <input
            id="hoursWorked"
            type="number"
            className="field__input"
            min={HOURS_MIN}
            max={HOURS_MAX}
            step="0.5"
            value={form.hoursWorked}
            onChange={(e) => set('hoursWorked', e.target.value)}
            onBlur={() => blur('hoursWorked')}
            aria-invalid={Boolean(err('hoursWorked'))}
            aria-describedby={err('hoursWorked') ? 'hoursWorked-error' : undefined}
          />
          {err('hoursWorked') && (
            <p id="hoursWorked-error" className="field__error" role="alert">
              {err('hoursWorked')}
            </p>
          )}
        </div>

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={submitting}>
            Cancel
          </button>
          <button
            type="submit"
            className="btn btn--primary"
            disabled={!isValid || submitting}
            aria-busy={submitting}
          >
            {submitting && <Spinner size={16} inline label="Submitting" />}
            {isEdit ? 'Resubmit' : 'Submit Log'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
