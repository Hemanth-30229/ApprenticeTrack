// Attendance summary enums, tones, and helpers.
//
// Matches the AP-19 OJTAttendanceSummary status lifecycle in ojt-stipend-service:
// a summary is "Computed" on creation and transitions to "Approved" by an admin.

export const ATTENDANCE_STATUSES = ['Computed', 'Approved'];

export const ATTENDANCE_STATUS_TONE = {
  Computed: 'info', // blue
  Approved: 'success', // green
};

export const MONTHS = [
  { value: 1, label: 'January' },
  { value: 2, label: 'February' },
  { value: 3, label: 'March' },
  { value: 4, label: 'April' },
  { value: 5, label: 'May' },
  { value: 6, label: 'June' },
  { value: 7, label: 'July' },
  { value: 8, label: 'August' },
  { value: 9, label: 'September' },
  { value: 10, label: 'October' },
  { value: 11, label: 'November' },
  { value: 12, label: 'December' },
];

export function monthLabel(m) {
  return MONTHS.find((x) => x.value === Number(m))?.label || m;
}

// Stipend eligibility threshold — mirrors backend stipend.eligibility-threshold-percent (default 80).
export const ELIGIBILITY_THRESHOLD = 80;

// Colour band for the attendance progress bar (green >=80, yellow 60-79, red <60).
export function attendanceTone(percent) {
  const p = Number(percent);
  if (p >= 80) return 'success';
  if (p >= 60) return 'warning';
  return 'danger';
}

export function recentYears(count = 4) {
  const now = new Date().getFullYear();
  return Array.from({ length: count }, (_, i) => now - i);
}
