// OJT log enums, badge tones, and validation bounds.

export const OJT_LOG_STATUSES = ['Submitted', 'SupervisorConfirmed', 'Rejected'];

export const OJT_LOG_STATUS_TONE = {
  Submitted: 'pending', // yellow
  SupervisorConfirmed: 'success', // green
  Rejected: 'danger', // red
};

export const TASKS_MIN_LENGTH = 10;
export const TASKS_MAX_LENGTH = 1000; // DB column cap
export const HOURS_MIN = 0;
export const HOURS_MAX = 24;
