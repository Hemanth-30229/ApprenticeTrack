// Stipend disbursement enums + tones.

export const STIPEND_STATUSES = ['Pending', 'Approved', 'Disbursed', 'Withheld'];

export const STIPEND_STATUS_TONE = {
  Pending: 'pending', // yellow
  Approved: 'info', // blue
  Disbursed: 'success', // green
  Withheld: 'danger', // red
};

// Eligibility threshold — mirrors backend stipend.eligibility-threshold-percent (default 80).
export const ELIGIBILITY_THRESHOLD = 80;

// Attendance colour: green >= 80, red < 80 (per AC).
export function stipendAttendanceTone(percent) {
  return Number(percent) >= ELIGIBILITY_THRESHOLD ? 'success' : 'danger';
}
