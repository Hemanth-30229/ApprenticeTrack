// Attendance summaries (admin/stipend-admin): list monthly attendance per placement,
// compute a new summary (ComputeAttendanceModal), and view details. Attendance % is
// derived on the backend from confirmed OJT logs vs. the course's required OJT days.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import ComputeAttendanceModal from '../components/attendance/ComputeAttendanceModal';
import AttendanceDetailModal from '../components/attendance/AttendanceDetailModal';
import { useToast } from '../../../shared/toast/ToastContext';
import {
  approveAttendance,
  bulkApproveAttendance,
  computeAttendance,
  listAttendanceSummaries,
  recomputeAttendance,
} from '../api/attendance';
import {
  ATTENDANCE_STATUSES,
  ATTENDANCE_STATUS_TONE,
  attendanceTone,
  MONTHS,
  monthLabel,
  recentYears,
} from '../constants/attendance';
import { exportToCsv } from '../../../shared/utils/csv';

const PAGE_SIZE = 10;

export default function AttendanceListPage() {
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);

  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [month, setMonth] = useState('');
  const [year, setYear] = useState('');
  const [eligible, setEligible] = useState(''); // '', 'true', 'false'
  const [status, setStatus] = useState('');

  const [selected, setSelected] = useState(new Set());
  const [computeOpen, setComputeOpen] = useState(false);
  const [detail, setDetail] = useState(null);
  const [rowBusy, setRowBusy] = useState(null);
  const [bulkBusy, setBulkBusy] = useState(false);

  const debounceRef = useRef(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await listAttendanceSummaries({
        traineeID: search || undefined,
        month: month || undefined,
        year: year || undefined,
        status: status || undefined,
        stipendEligible: eligible === '' ? undefined : eligible === 'true',
        page,
        size: PAGE_SIZE,
        sort: 'year,desc',
      });
      setRows(data.content || []);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
      setSelected(new Set());
    } catch {
      setError('Could not load attendance summaries. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [search, month, year, status, eligible, page]);

  useEffect(() => {
    load();
  }, [load]);

  function onSearchChange(value) {
    setSearchInput(value);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setPage(0);
      setSearch(value.trim());
    }, 400);
  }

  const computedRows = useMemo(() => rows.filter((r) => r.status === 'Computed'), [rows]);
  const allSelected = computedRows.length > 0 && selected.size === computedRows.length;

  function toggle(id) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }
  function toggleAll() {
    setSelected(allSelected ? new Set() : new Set(computedRows.map((r) => r.summaryID)));
  }

  async function handleCompute(payload) {
    try {
      await computeAttendance(payload);
      toast.success(`Attendance computed for ${monthLabel(payload.month)} ${payload.year}.`);
      setComputeOpen(false);
      load();
    } catch (err) {
      toast.error(
        err?.response?.status === 409
          ? 'Already computed for this placement/month — use Recompute on that row to refresh it.'
          : err?.response?.data?.message || 'Failed to compute attendance.'
      );
      throw err;
    }
  }

  async function handleApprove(summary) {
    setRowBusy(summary.summaryID);
    try {
      await approveAttendance(summary.summaryID);
      toast.success('Attendance record approved.');
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to approve record.');
    } finally {
      setRowBusy(null);
    }
  }

  async function handleRecompute(summary) {
    setRowBusy(summary.summaryID);
    try {
      const updated = await recomputeAttendance(summary.summaryID);
      toast.success(`Recomputed: ${updated.daysAttended}/${updated.workingDays} day(s), ${updated.attendancePercent}%.`);
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to recompute record.');
    } finally {
      setRowBusy(null);
    }
  }

  async function handleBulkApprove() {
    const ids = Array.from(selected);
    if (ids.length === 0) return;
    setBulkBusy(true);
    try {
      const res = await bulkApproveAttendance(ids);
      const approved = res.approved?.length ?? ids.length;
      const failed = res.failed?.length ?? 0;
      toast[failed === 0 ? 'success' : 'info'](
        failed === 0 ? `${approved} record(s) approved.` : `${approved} approved, ${failed} failed.`
      );
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Bulk approval failed.');
    } finally {
      setBulkBusy(false);
    }
  }

  function handleExport() {
    if (rows.length === 0) {
      toast.info('Nothing to export.');
      return;
    }
    exportToCsv(
      `attendance-${year || 'all'}-${month || 'all'}`,
      [
        { key: 'traineeName', label: 'Trainee Name', format: (v, r) => v || `#${r.traineeID}` },
        { key: 'month', label: 'Month', format: (v) => monthLabel(v) },
        { key: 'year', label: 'Year' },
        { key: 'workingDays', label: 'Working Days' },
        { key: 'daysAttended', label: 'Days Attended' },
        { key: 'attendancePercent', label: 'Attendance %' },
        { key: 'stipendEligible', label: 'Stipend Eligible', format: (v) => (v ? 'Yes' : 'No') },
        { key: 'status', label: 'Status' },
      ],
      rows
    );
    toast.success('Attendance exported to CSV.');
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Attendance Summaries</h1>
            <p className="page__subtitle">Review monthly OJT attendance and approve for stipend processing.</p>
          </div>
          <div className="entry-actions">
            <button type="button" className="btn btn--secondary" onClick={handleExport}>Export CSV</button>
            <button type="button" className="btn btn--secondary" onClick={() => setComputeOpen(true)}>Compute Attendance</button>
            <button
              type="button"
              className="btn btn--primary"
              onClick={handleBulkApprove}
              disabled={selected.size === 0 || bulkBusy}
              aria-busy={bulkBusy}
            >
              {bulkBusy && <Spinner size={16} inline label="Approving" />}
              Approve Selected ({selected.size})
            </button>
          </div>
        </div>

        <div className="toolbar">
          <div className="toolbar__search">
            <label htmlFor="attendance-search" className="sr-only">Filter by trainee ID</label>
            <input
              id="attendance-search"
              type="search"
              inputMode="numeric"
              className="field__input"
              placeholder="Filter by trainee ID…"
              value={searchInput}
              onChange={(e) => onSearchChange(e.target.value)}
            />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="month-filter" className="field__label field__label--sm">Month</label>
            <select id="month-filter" className="field__input" value={month} onChange={(e) => { setMonth(e.target.value); setPage(0); }}>
              <option value="">All months</option>
              {MONTHS.map((m) => <option key={m.value} value={m.value}>{m.label}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="year-filter" className="field__label field__label--sm">Year</label>
            <select id="year-filter" className="field__input" value={year} onChange={(e) => { setYear(e.target.value); setPage(0); }}>
              <option value="">All years</option>
              {recentYears(6).map((y) => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="eligible-filter" className="field__label field__label--sm">Stipend Eligible</label>
            <select id="eligible-filter" className="field__input" value={eligible} onChange={(e) => { setEligible(e.target.value); setPage(0); }}>
              <option value="">All</option>
              <option value="true">Yes</option>
              <option value="false">No</option>
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="field__label field__label--sm">Status</label>
            <select id="status-filter" className="field__input" value={status} onChange={(e) => { setStatus(e.target.value); setPage(0); }}>
              <option value="">All statuses</option>
              {ATTENDANCE_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col" className="table__check-col">
                  <input type="checkbox" aria-label="Select all computed records" checked={allSelected} onChange={toggleAll} disabled={computedRows.length === 0} />
                </th>
                <th scope="col">Trainee Name</th>
                <th scope="col">Month/Year</th>
                <th scope="col">Working Days</th>
                <th scope="col">Days Attended</th>
                <th scope="col">Attendance %</th>
                <th scope="col">Stipend Eligible</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={9} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
              ) : error ? (
                <tr>
                  <td colSpan={9} className="table__state table__state--error">
                    {error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button>
                  </td>
                </tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan={9} className="table__state">No attendance records found.</td></tr>
              ) : (
                rows.map((r) => {
                  const isComputed = r.status === 'Computed';
                  const pct = Number(r.attendancePercent) || 0;
                  return (
                    <tr key={r.summaryID}>
                      <td data-label="Select" className="table__check-col">
                        <input type="checkbox" aria-label={`Select ${r.traineeName}`} checked={selected.has(r.summaryID)} onChange={() => toggle(r.summaryID)} disabled={!isComputed} />
                      </td>
                      <td data-label="Trainee Name">
                        <button type="button" className="link-button" onClick={() => setDetail(r)}>
                          {r.traineeName || `Trainee #${r.traineeID}`}
                        </button>
                      </td>
                      <td data-label="Month/Year">{monthLabel(r.month)} {r.year}</td>
                      <td data-label="Working Days">{r.workingDays ?? '—'}</td>
                      <td data-label="Days Attended">{r.daysAttended ?? '—'}</td>
                      <td data-label="Attendance %">
                        <div className="attn-bar" title={`${pct}%`}>
                          <div className={`attn-bar__fill attn-bar__fill--${attendanceTone(pct)}`} style={{ width: `${Math.min(100, pct)}%` }} />
                          <span className="attn-bar__label">{pct}%</span>
                        </div>
                      </td>
                      <td data-label="Stipend Eligible">
                        {r.stipendEligible ? (
                          <span className="icon-yes" aria-label="Eligible">✓</span>
                        ) : (
                          <span className="icon-no" aria-label="Not eligible">✗</span>
                        )}
                      </td>
                      <td data-label="Status">
                        <StatusBadge status={r.status} tone={ATTENDANCE_STATUS_TONE[r.status] || 'neutral'} />
                      </td>
                      <td data-label="Actions" className="table__actions">
                        <button type="button" className="btn btn--secondary btn--sm" onClick={() => setDetail(r)}>View</button>
                        {isComputed && (
                          <>
                            <button type="button" className="btn btn--secondary btn--sm" onClick={() => handleRecompute(r)} disabled={rowBusy === r.summaryID} title="Re-count confirmed OJT logs for this month">
                              {rowBusy === r.summaryID ? 'Working…' : 'Recompute'}
                            </button>
                            <button type="button" className="btn btn--secondary btn--sm" onClick={() => handleApprove(r)} disabled={rowBusy === r.summaryID}>
                              Approve
                            </button>
                          </>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <span className="pagination__info">
            {pageInfo.totalElements > 0 ? `${pageInfo.totalElements} total` : ' '}
          </span>
          <div className="pagination__controls">
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={loading || page === 0}>← Previous</button>
            <span className="pagination__page">Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}</span>
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => p + 1)} disabled={loading || page + 1 >= pageInfo.totalPages}>Next →</button>
          </div>
        </div>
      </main>

      {computeOpen && <ComputeAttendanceModal onClose={() => setComputeOpen(false)} onCompute={handleCompute} />}
      {detail && <AttendanceDetailModal summary={detail} onClose={() => setDetail(null)} />}
    </div>
  );
}
