import { useCallback, useEffect, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import EmployerCompanyBar from '../../placement/components/employers/EmployerCompanyBar';
import { useEmployer } from '../../placement/hooks/useEmployer';
import { listPlacements } from '../../placement/api/placements';
import { listOjtLogs } from '../api/ojtLogs';
import { apiErrorMessage } from '../../../shared/api/errors';
import { attendanceTone, MONTHS, monthLabel, recentYears } from '../constants/attendance';

export default function EmployerAttendancePage() {
  const { employers, employerId, setEmployerId, companyName, loaded } = useEmployer();

  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    if (!employerId) { setRows([]); setLoading(false); return; }
    setLoading(true);
    setError('');
    try {
      const page = await listPlacements({ employerID: employerId, size: 100, sort: 'placementDate,desc' });
      const placements = page.content || [];
      const results = await Promise.all(
        placements.map(async (p) => {
          const base = { placementID: p.placementID, trainee: p.traineeName || `Trainee #${p.traineeID}` };
          try {
            const logsPage = await listOjtLogs({ placementId: p.placementID, size: 200, sort: 'logDate,asc' });
            const monthLogs = (logsPage.content || []).filter((l) => {
              if (!l.logDate) return false;
              const d = new Date(l.logDate);
              return d.getMonth() + 1 === Number(month) && d.getFullYear() === Number(year);
            });
            const total = monthLogs.length;
            const confirmed = monthLogs.filter((l) => l.status === 'SupervisorConfirmed').length;
            const pending = monthLogs.filter((l) => l.status === 'Submitted').length;
            const rejected = monthLogs.filter((l) => l.status === 'Rejected').length;
            const pct = total ? Math.round((confirmed / total) * 100) : 0;
            return { ...base, total, confirmed, pending, rejected, pct };
          } catch {
            return { ...base, total: 0, confirmed: 0, pending: 0, rejected: 0, pct: 0 };
          }
        })
      );
      setRows(results);
    } catch (err) {
      setError(apiErrorMessage(err, 'Could not load the attendance summary.'));
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [employerId, month, year]);

  useEffect(() => { load(); }, [load]);

  const noEmployers = loaded && employers.length === 0;

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Attendance Summary</h1>
            <p className="page__subtitle">Monthly OJT attendance for your apprentices.</p>
          </div>
        </div>

        {noEmployers ? (
          <div className="empty-state"><p>No active employer records exist. Ask an administrator to register your company.</p></div>
        ) : (
          <>
            <EmployerCompanyBar employers={employers} employerId={employerId} setEmployerId={setEmployerId} companyName={companyName} />

            {employerId && (
              <div className="toolbar">
                <div className="toolbar__filter">
                  <label htmlFor="month" className="field__label field__label--sm">Month</label>
                  <select id="month" className="field__input" value={month} onChange={(e) => setMonth(e.target.value)}>
                    {MONTHS.map((m) => <option key={m.value} value={m.value}>{m.label}</option>)}
                  </select>
                </div>
                <div className="toolbar__filter">
                  <label htmlFor="year" className="field__label field__label--sm">Year</label>
                  <select id="year" className="field__input" value={year} onChange={(e) => setYear(e.target.value)}>
                    {recentYears(6).map((y) => <option key={y} value={y}>{y}</option>)}
                  </select>
                </div>
              </div>
            )}

            {!employerId ? (
              <div className="empty-state"><p>Select your company to view attendance.</p></div>
            ) : (
              <>
                <p className="page__note">
                  {monthLabel(month)} {year} · attendance derived from submitted/confirmed OJT logs.
                </p>
                <div className="table-wrap">
                  <table className="table">
                    <thead>
                      <tr>
                        <th scope="col">Trainee</th>
                        <th scope="col">Logs</th>
                        <th scope="col">Confirmed</th>
                        <th scope="col">Pending</th>
                        <th scope="col">Rejected</th>
                        <th scope="col">Attendance %</th>
                      </tr>
                    </thead>
                    <tbody>
                      {loading ? (
                        <tr><td colSpan={6} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
                      ) : error ? (
                        <tr><td colSpan={6} className="table__state table__state--error">{error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button></td></tr>
                      ) : rows.length === 0 ? (
                        <tr><td colSpan={6} className="table__state">No apprentices placed with your company yet.</td></tr>
                      ) : (
                        rows.map((r) => (
                          <tr key={r.placementID}>
                            <td data-label="Trainee">{r.trainee}</td>
                            <td data-label="Logs">{r.total}</td>
                            <td data-label="Confirmed">{r.confirmed}</td>
                            <td data-label="Pending">{r.pending}</td>
                            <td data-label="Rejected">{r.rejected}</td>
                            <td data-label="Attendance %">
                              <span className={`pct pct--${attendanceTone(r.pct)}`}>{r.total ? `${r.pct}%` : '—'}</span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </>
        )}
      </main>
    </div>
  );
}
