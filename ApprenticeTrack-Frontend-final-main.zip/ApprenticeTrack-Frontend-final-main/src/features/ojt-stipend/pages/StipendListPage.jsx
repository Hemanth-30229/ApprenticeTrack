// Stipend disbursements (stipend-admin): list disbursements, calculate a new one
// (CalculateStipendModal, gated by attendance eligibility), and view details.
// List-page pattern (see PlacementListPage). Employer/placement names come from
// the placement service.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import ConfirmDialog from '../../../shared/ui/ConfirmDialog';
import CalculateStipendModal from '../components/stipend/CalculateStipendModal';
import { useToast } from '../../../shared/toast/ToastContext';
import {
  approveStipend,
  bulkApproveStipends,
  calculateStipend,
  disburseStipend,
  listStipends,
} from '../api/stipend';
import { getPlacement } from '../../placement/api/placements';
import { listEmployers } from '../../placement/api/employers';
import {
  ELIGIBILITY_THRESHOLD,
  STIPEND_STATUSES,
  STIPEND_STATUS_TONE,
  stipendAttendanceTone,
} from '../constants/stipend';
import { MONTHS, monthLabel, recentYears } from '../constants/attendance';
import { formatCurrency } from '../../../shared/format';
import { exportToCsv } from '../../../shared/utils/csv';

const PAGE_SIZE = 10;

export default function StipendListPage() {
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);

  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [month, setMonth] = useState('');
  const [year, setYear] = useState('');
  const [status, setStatus] = useState('');
  const [employerFilter, setEmployerFilter] = useState('');

  const [employers, setEmployers] = useState([]);
  const [resolved, setResolved] = useState({}); // placementID -> { traineeName, employerName, employerID }
  const resolvedRef = useRef({});

  const [selected, setSelected] = useState(new Set());
  const [calcOpen, setCalcOpen] = useState(false);
  const [action, setAction] = useState(null); // { kind, target? }
  const [busy, setBusy] = useState(false);

  const debounceRef = useRef(null);

  useEffect(() => {
    listEmployers({ page: 0, size: 500 })
      .then((p) => setEmployers(p.content || []))
      .catch(() => {});
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await listStipends({
        month: month || undefined,
        year: year || undefined,
        status: status || undefined,
        page,
        size: PAGE_SIZE,
        sort: 'disbursementID,desc',
      });
      const content = data.content || [];
      setRows(content);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
      setSelected(new Set());

      // Resolve trainee/employer names via placements (cached).
      const missing = [...new Set(content.map((r) => r.placementID))].filter(
        (id) => !(id in resolvedRef.current)
      );
      if (missing.length) {
        await Promise.all(
          missing.map(async (id) => {
            try {
              const p = await getPlacement(id);
              resolvedRef.current[id] = {
                traineeName: p.traineeName,
                employerName: p.employerName,
                employerID: p.employerID,
              };
            } catch {
              resolvedRef.current[id] = {};
            }
          })
        );
        setResolved({ ...resolvedRef.current });
      }
    } catch {
      setError('Could not load stipend records. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [month, year, status, page]);

  useEffect(() => {
    load();
  }, [load]);

  function onSearchChange(value) {
    setSearchInput(value);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => setSearch(value.trim().toLowerCase()), 300);
  }

  // Client-side name search + employer filter (record lacks those fields).
  const visibleRows = useMemo(
    () =>
      rows.filter((r) => {
        const info = resolved[r.placementID] || {};
        if (employerFilter && String(info.employerID) !== String(employerFilter)) return false;
        if (search && !(info.traineeName || '').toLowerCase().includes(search)) return false;
        return true;
      }),
    [rows, resolved, employerFilter, search]
  );

  const selPending = useMemo(
    () => visibleRows.filter((r) => selected.has(r.disbursementID) && r.status === 'Pending'),
    [visibleRows, selected]
  );
  const selApproved = useMemo(
    () => visibleRows.filter((r) => selected.has(r.disbursementID) && r.status === 'Approved'),
    [visibleRows, selected]
  );

  function toggle(id) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  async function runAction() {
    setBusy(true);
    try {
      if (action.kind === 'approve') {
        await approveStipend(action.target.disbursementID);
        toast.success('Stipend approved.');
      } else if (action.kind === 'disburse') {
        await disburseStipend(action.target.disbursementID);
        toast.success('Stipend marked as disbursed.');
      } else if (action.kind === 'bulk-approve') {
        const ids = selPending.map((r) => r.disbursementID);
        const res = await bulkApproveStipends(ids);
        const ok = res.approved?.length ?? ids.length;
        const failed = res.failed?.length ?? 0;
        toast[failed === 0 ? 'success' : 'info'](
          failed === 0 ? `${ok} stipend(s) approved.` : `${ok} approved, ${failed} failed.`
        );
      } else if (action.kind === 'bulk-disburse') {
        // No bulk-disburse endpoint — disburse each selected Approved record.
        const ids = selApproved.map((r) => r.disbursementID);
        const results = await Promise.allSettled(ids.map((id) => disburseStipend(id)));
        const ok = results.filter((r) => r.status === 'fulfilled').length;
        const failed = results.length - ok;
        toast[failed === 0 ? 'success' : 'info'](
          failed === 0 ? `${ok} stipend(s) disbursed.` : `${ok} disbursed, ${failed} failed.`
        );
      }
      setAction(null);
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Action failed. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  async function handleCalculate(payload) {
    try {
      await calculateStipend(payload);
      toast.success(`Stipend calculated for ${monthLabel(payload.month)} ${payload.year}.`);
      setCalcOpen(false);
      load();
    } catch (err) {
      const status409 = err?.response?.status === 409;
      toast.error(
        err?.response?.data?.message ||
          (status409 ? 'A stipend already exists for this placement/month.' : 'Failed to calculate stipend.')
      );
      throw err;
    }
  }

  function handleExport() {
    if (visibleRows.length === 0) {
      toast.info('Nothing to export.');
      return;
    }
    exportToCsv(
      `stipends-${year || 'all'}-${month || 'all'}`,
      [
        { key: 'placementID', label: 'Trainee Name', format: (v) => resolved[v]?.traineeName || '' },
        { key: 'placementID', label: 'Employer', format: (v) => resolved[v]?.employerName || '' },
        { key: 'month', label: 'Month', format: (v) => monthLabel(v) },
        { key: 'year', label: 'Year' },
        { key: 'attendancePercent', label: 'Attendance %' },
        { key: 'stipendAmount', label: 'Stipend Amount' },
        { key: 'status', label: 'Status' },
      ],
      visibleRows
    );
    toast.success('Stipends exported to CSV.');
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Stipends</h1>
            <p className="page__subtitle">Calculate, approve, and disburse monthly stipends.</p>
          </div>
          <div className="entry-actions">
            <button type="button" className="btn btn--secondary" onClick={handleExport}>Export CSV</button>
            <button type="button" className="btn btn--secondary" onClick={() => setCalcOpen(true)}>Calculate Stipends</button>
            <button
              type="button"
              className="btn btn--secondary"
              onClick={() => setAction({ kind: 'bulk-approve' })}
              disabled={selPending.length === 0}
            >
              Approve Selected ({selPending.length})
            </button>
            <button
              type="button"
              className="btn btn--primary"
              onClick={() => setAction({ kind: 'bulk-disburse' })}
              disabled={selApproved.length === 0}
            >
              Disburse Selected ({selApproved.length})
            </button>
          </div>
        </div>

        <div className="toolbar">
          <div className="toolbar__search">
            <label htmlFor="stipend-search" className="sr-only">Search by trainee name</label>
            <input id="stipend-search" type="search" className="field__input" placeholder="Search by trainee name…" value={searchInput} onChange={(e) => onSearchChange(e.target.value)} />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="month-filter" className="field__label field__label--sm">Month</label>
            <select id="month-filter" className="field__input" value={month} onChange={(e) => { setMonth(e.target.value); setPage(0); }}>
              <option value="">All months</option>
              {MONTHS.map((m) => <option key={m.value} value={m.value}>{m.label}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="year-filter" className="field__label field__label--sm">Year</label>
            <select id="year-filter" className="field__input" value={year} onChange={(e) => { setYear(e.target.value); setPage(0); }}>
              <option value="">All years</option>
              {recentYears(6).map((y) => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="field__label field__label--sm">Status</label>
            <select id="status-filter" className="field__input" value={status} onChange={(e) => { setStatus(e.target.value); setPage(0); }}>
              <option value="">All statuses</option>
              {STIPEND_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="employer-filter" className="field__label field__label--sm">Employer</label>
            <select id="employer-filter" className="field__input" value={employerFilter} onChange={(e) => setEmployerFilter(e.target.value)}>
              <option value="">All employers</option>
              {employers.map((emp) => <option key={emp.employerID} value={emp.employerID}>{emp.companyName}</option>)}
            </select>
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col" className="table__check-col"><span className="sr-only">Select</span></th>
                <th scope="col">Trainee Name</th>
                <th scope="col">Employer</th>
                <th scope="col">Month/Year</th>
                <th scope="col">Attendance %</th>
                <th scope="col">Stipend Amount</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={8} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
              ) : error ? (
                <tr>
                  <td colSpan={8} className="table__state table__state--error">
                    {error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button>
                  </td>
                </tr>
              ) : visibleRows.length === 0 ? (
                <tr><td colSpan={8} className="table__state">No stipend records found.</td></tr>
              ) : (
                visibleRows.map((r) => {
                  const info = resolved[r.placementID] || {};
                  const pct = Number(r.attendancePercent) || 0;
                  const selectable = r.status === 'Pending' || r.status === 'Approved';
                  return (
                    <tr key={r.disbursementID}>
                      <td data-label="Select" className="table__check-col">
                        <input type="checkbox" aria-label={`Select stipend #${r.disbursementID}`} checked={selected.has(r.disbursementID)} onChange={() => toggle(r.disbursementID)} disabled={!selectable} />
                      </td>
                      <td data-label="Trainee Name">{info.traineeName || `Trainee #${r.traineeID}`}</td>
                      <td data-label="Employer">{info.employerName || '—'}</td>
                      <td data-label="Month/Year">{monthLabel(r.month)} {r.year}</td>
                      <td data-label="Attendance %">
                        <span className={`pct pct--${stipendAttendanceTone(pct)}`}>{pct}%</span>
                      </td>
                      <td data-label="Stipend Amount">{formatCurrency(r.stipendAmount)}</td>
                      <td data-label="Status">
                        <StatusBadge status={r.status} tone={STIPEND_STATUS_TONE[r.status] || 'neutral'} />
                        {r.status === 'Withheld' && (
                          <span
                            className="withheld-flag"
                            title={`Low attendance (${pct}% < ${ELIGIBILITY_THRESHOLD}%)`}
                            aria-label={`Withheld: low attendance ${pct} percent`}
                          >
                            {' '}⚠️
                          </span>
                        )}
                      </td>
                      <td data-label="Actions" className="table__actions">
                        {r.status === 'Pending' && (
                          <button type="button" className="btn btn--secondary btn--sm" onClick={() => setAction({ kind: 'approve', target: r })}>
                            Approve
                          </button>
                        )}
                        {r.status === 'Approved' && (
                          <button type="button" className="btn btn--secondary btn--sm" onClick={() => setAction({ kind: 'disburse', target: r })}>
                            Mark Disbursed
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <span className="pagination__info">{pageInfo.totalElements > 0 ? `${pageInfo.totalElements} total` : ' '}</span>
          <div className="pagination__controls">
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={loading || page === 0}>← Previous</button>
            <span className="pagination__page">Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}</span>
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => p + 1)} disabled={loading || page + 1 >= pageInfo.totalPages}>Next →</button>
          </div>
        </div>
      </main>

      {calcOpen && <CalculateStipendModal onClose={() => setCalcOpen(false)} onCalculate={handleCalculate} />}

      {action && (
        <ConfirmDialog
          title={confirmTitle(action)}
          message={confirmMessage(action, selPending.length, selApproved.length)}
          confirmLabel={confirmLabel(action)}
          tone="primary"
          busy={busy}
          onConfirm={runAction}
          onCancel={() => (busy ? null : setAction(null))}
        />
      )}
    </div>
  );
}

function confirmTitle(action) {
  return {
    approve: 'Approve stipend?',
    disburse: 'Mark as disbursed?',
    'bulk-approve': 'Approve selected stipends?',
    'bulk-disburse': 'Disburse selected stipends?',
  }[action.kind];
}
function confirmLabel(action) {
  return {
    approve: 'Approve',
    disburse: 'Mark Disbursed',
    'bulk-approve': 'Approve',
    'bulk-disburse': 'Disburse',
  }[action.kind];
}
function confirmMessage(action, pendingCount, approvedCount) {
  switch (action.kind) {
    case 'approve':
      return 'Approve this stipend for disbursement?';
    case 'disburse':
      return 'Mark this stipend as disbursed? This records the payment.';
    case 'bulk-approve':
      return `Approve ${pendingCount} pending stipend(s)?`;
    case 'bulk-disburse':
      return `Mark ${approvedCount} approved stipend(s) as disbursed?`;
    default:
      return '';
  }
}
