import { useCallback, useEffect, useMemo, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import RejectReasonModal from '../components/ojt/RejectReasonModal';
import { useToast } from '../../../shared/toast/ToastContext';
import {
  approveOjtLog,
  bulkApproveOjtLogs,
  listOjtLogs,
  rejectOjtLog,
} from '../api/ojtLogs';
import { OJT_LOG_STATUSES, OJT_LOG_STATUS_TONE } from '../constants/ojtLog';
import { formatDate } from '../../../shared/format';

const PAGE_SIZE = 10;

function truncate(text, n = 90) {
  if (!text) return '—';
  return text.length > n ? `${text.slice(0, n)}…` : text;
}

export default function SupervisorOjtLogPage() {
  const toast = useToast();

  const [logs, setLogs] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);
  const [status, setStatus] = useState('Submitted');

  const [selected, setSelected] = useState(new Set());
  const [rowBusy, setRowBusy] = useState(null); // logID currently approving
  const [bulkBusy, setBulkBusy] = useState(false);
  const [rejecting, setRejecting] = useState(null); // log being rejected

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await listOjtLogs({
        status: status || undefined,
        page,
        size: PAGE_SIZE,
        sort: 'logDate,desc',
      });
      setLogs(data.content || []);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
      setSelected(new Set());
    } catch {
      setError('Could not load OJT logs. Please try again.');
      setLogs([]);
    } finally {
      setLoading(false);
    }
  }, [status, page]);

  useEffect(() => {
    load();
  }, [load]);

  const submittedLogs = useMemo(() => logs.filter((l) => l.status === 'Submitted'), [logs]);
  const allSelected = submittedLogs.length > 0 && selected.size === submittedLogs.length;

  function toggle(logID) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(logID)) next.delete(logID);
      else next.add(logID);
      return next;
    });
  }
  function toggleAll() {
    setSelected(allSelected ? new Set() : new Set(submittedLogs.map((l) => l.logID)));
  }

  async function handleApprove(log) {
    setRowBusy(log.logID);
    try {
      await approveOjtLog(log.logID);
      toast.success(`Log dated ${log.logDate} approved.`);
      load();
    } catch (err) {
      toast.error(approveErrorMessage(err));
    } finally {
      setRowBusy(null);
    }
  }

  async function handleReject(reason) {
    const log = rejecting;
    try {
      await rejectOjtLog(log.logID, reason);
      toast.success(`Log dated ${log.logDate} rejected.`);
      setRejecting(null);
      load();
    } catch (err) {
      toast.error(approveErrorMessage(err));
      throw err;
    }
  }

  async function handleBulkApprove() {
    const logIDs = Array.from(selected);
    if (logIDs.length === 0) return;
    setBulkBusy(true);
    try {
      const res = await bulkApproveOjtLogs(logIDs);
      const approved = res.approved?.length ?? 0;
      const failed = res.failed?.length ?? 0;
      if (failed === 0) {
        toast.success(`${approved} log(s) approved.`);
      } else {
        toast.info(`${approved} approved, ${failed} could not be approved.`);
      }
      load();
    } catch (err) {
      toast.error(approveErrorMessage(err));
    } finally {
      setBulkBusy(false);
    }
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">OJT Log Approvals</h1>
            <p className="page__subtitle">
              Review and approve or reject on-the-job training logs.
            </p>
          </div>
          <button
            type="button"
            className="btn btn--primary"
            onClick={handleBulkApprove}
            disabled={selected.size === 0 || bulkBusy}
            aria-busy={bulkBusy}
          >
            {bulkBusy && <Spinner size={16} inline label="Approving" />}
            Approve Selected ({selected.size})
          </button>
        </div>

        <div className="toolbar">
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="field__label field__label--sm">
              Status
            </label>
            <select
              id="status-filter"
              className="field__input"
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                setPage(0);
              }}
            >
              {OJT_LOG_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
              <option value="">All statuses</option>
            </select>
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col" className="table__check-col">
                  <input
                    type="checkbox"
                    aria-label="Select all submitted logs"
                    checked={allSelected}
                    onChange={toggleAll}
                    disabled={submittedLogs.length === 0}
                  />
                </th>
                <th scope="col">Log Date</th>
                <th scope="col">Trainee</th>
                <th scope="col">Tasks Performed</th>
                <th scope="col">Hours</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={7} className="table__state">
                    <Spinner size={22} label="Loading logs" /> Loading…
                  </td>
                </tr>
              ) : error ? (
                <tr>
                  <td colSpan={7} className="table__state table__state--error">
                    {error}{' '}
                    <button type="button" className="btn btn--secondary btn--sm" onClick={load}>
                      Retry
                    </button>
                  </td>
                </tr>
              ) : logs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="table__state">
                    No logs to review.
                  </td>
                </tr>
              ) : (
                logs.map((log) => {
                  const isSubmitted = log.status === 'Submitted';
                  return (
                    <tr key={log.logID}>
                      <td data-label="Select" className="table__check-col">
                        <input
                          type="checkbox"
                          aria-label={`Select log dated ${log.logDate}`}
                          checked={selected.has(log.logID)}
                          onChange={() => toggle(log.logID)}
                          disabled={!isSubmitted}
                        />
                      </td>
                      <td data-label="Log Date">{formatDate(log.logDate)}</td>
                      <td data-label="Trainee">#{log.traineeID}</td>
                      <td data-label="Tasks Performed">
                        <span title={log.tasksPerformed}>{truncate(log.tasksPerformed)}</span>
                      </td>
                      <td data-label="Hours">{log.hoursWorked ?? '—'}</td>
                      <td data-label="Status">
                        <StatusBadge
                          status={log.status}
                          tone={OJT_LOG_STATUS_TONE[log.status] || 'neutral'}
                        />
                      </td>
                      <td data-label="Actions" className="table__actions">
                        {isSubmitted ? (
                          <>
                            <button
                              type="button"
                              className="btn btn--secondary btn--sm"
                              onClick={() => handleApprove(log)}
                              disabled={rowBusy === log.logID}
                            >
                              {rowBusy === log.logID ? 'Approving…' : 'Approve'}
                            </button>
                            <button
                              type="button"
                              className="btn btn--danger-ghost btn--sm"
                              onClick={() => setRejecting(log)}
                            >
                              Reject
                            </button>
                          </>
                        ) : (
                          <span className="text-muted">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <span className="pagination__info">
            {pageInfo.totalElements > 0 ? `${pageInfo.totalElements} total` : ' '}
          </span>
          <div className="pagination__controls">
            <button
              type="button"
              className="btn btn--secondary btn--sm"
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={loading || page === 0}
            >
              ← Previous
            </button>
            <span className="pagination__page">
              Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}
            </span>
            <button
              type="button"
              className="btn btn--secondary btn--sm"
              onClick={() => setPage((p) => p + 1)}
              disabled={loading || page + 1 >= pageInfo.totalPages}
            >
              Next →
            </button>
          </div>
        </div>
      </main>

      {rejecting && (
        <RejectReasonModal
          log={rejecting}
          onClose={() => setRejecting(null)}
          onConfirm={handleReject}
        />
      )}
    </div>
  );
}

function approveErrorMessage(err) {
  const status = err?.response?.status;
  if (status === 403 || status === 401) {
    return 'You are not the supervisor linked to this placement.';
  }
  return err?.response?.data?.message || 'Action failed. Please try again.';
}
