// Trainee-facing: my OJT (on-the-job training) daily logs. Resolves my trainee
// profile + active placement, lists my logs, and lets me submit one (OjtLogFormModal)
// or back-fill several past dates at once (OjtLogBulkModal).
import { useCallback, useEffect, useMemo, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import OjtLogFormModal from '../components/ojt/OjtLogFormModal';
import OjtLogBulkModal from '../components/ojt/OjtLogBulkModal';
import { useToast } from '../../../shared/toast/ToastContext';
import { useAuth } from '../../../shared/auth/AuthContext';
import { bulkCreateOjtLogs, createOjtLog, listOjtLogs, updateOjtLog } from '../api/ojtLogs';
import { apiErrorMessage } from '../../../shared/api/errors';
import { getTraineeByUser } from '../../training/api/trainees';
import { getActivePlacementForTrainee } from '../../placement/api/placements';
import { OJT_LOG_STATUSES, OJT_LOG_STATUS_TONE } from '../constants/ojtLog';
import { formatDate } from '../../../shared/format';

const PAGE_SIZE = 20;

function truncate(text, n = 90) {
  if (!text) return '—';
  return text.length > n ? `${text.slice(0, n)}…` : text;
}

export default function TraineeOjtLogPage() {
  const { user } = useAuth();
  const toast = useToast();

  // Bootstrapping: resolve trainee profile + active placement.
  const [boot, setBoot] = useState({ loading: true, error: '', trainee: null, placement: null });

  const [logs, setLogs] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);

  // Filters (status is server-side; date range is client-side per AC).
  const [status, setStatus] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [bulkOpen, setBulkOpen] = useState(false);

  const placementId = boot.placement?.placementID;
  const traineeId = boot.trainee?.traineeID;

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const trainee = await getTraineeByUser(user.userID);
        const placement = await getActivePlacementForTrainee(trainee.traineeID);
        if (alive) setBoot({ loading: false, error: '', trainee, placement });
      } catch (err) {
        if (!alive) return;
        const msg =
          err?.response?.status === 404
            ? 'No trainee profile is linked to your account yet.'
            : 'Could not load your placement details.';
        setBoot({ loading: false, error: msg, trainee: null, placement: null });
      }
    })();
    return () => {
      alive = false;
    };
  }, [user.userID]);

  const load = useCallback(async () => {
    if (!placementId) return;
    setLoading(true);
    setError('');
    try {
      const data = await listOjtLogs({
        placementId,
        status: status || undefined,
        page,
        size: PAGE_SIZE,
        sort: 'logDate,desc',
      });
      setLogs(data.content || []);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
    } catch {
      setError('Could not load your OJT logs. Please try again.');
      setLogs([]);
    } finally {
      setLoading(false);
    }
  }, [placementId, status, page]);

  useEffect(() => {
    load();
  }, [load]);

  // Client-side date-range filter (backend has no date params).
  const visibleLogs = useMemo(() => {
    return logs.filter((l) => {
      if (fromDate && l.logDate < fromDate) return false;
      if (toDate && l.logDate > toDate) return false;
      return true;
    });
  }, [logs, fromDate, toDate]);

  function openSubmit() {
    setEditing(null);
    setFormOpen(true);
  }
  function openEdit(log) {
    setEditing(log);
    setFormOpen(true);
  }

  async function handleSubmit(payload) {
    try {
      if (editing) {
        await updateOjtLog(editing.logID, payload);
        toast.success('Log resubmitted successfully.');
      } else {
        await createOjtLog(payload);
        toast.success('OJT log submitted successfully.');
      }
      setFormOpen(false);
      setEditing(null);
      if (!editing && page !== 0) setPage(0);
      else load();
    } catch (err) {
      // Toast only; the form stays open (page closes it only on success). No
      // rethrow — that surfaced as an "uncaught (in promise)" error.
      toast.error(apiErrorMessage(err, editing ? 'Failed to resubmit log.' : 'Failed to submit log.'));
    }
  }

  async function handleBulkSubmit(logs) {
    try {
      const created = await bulkCreateOjtLogs(logs);
      toast.success(`${created.length} OJT log${created.length === 1 ? '' : 's'} submitted.`);
      setBulkOpen(false);
      if (page !== 0) setPage(0);
      else load();
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Failed to submit logs.'));
    }
  }

  if (boot.loading) {
    return (
      <div className="dash">
        <main className="page">
          <div className="table__state">
            <Spinner size={24} label="Loading" /> Loading your placement…
          </div>
        </main>
      </div>
    );
  }

  if (boot.error || !boot.placement) {
    return (
      <div className="dash">
        <main className="page">
          <div className="page__heading">
            <div>
              <h1 className="page__title">OJT Logs</h1>
            </div>
          </div>
          <div className="empty-state">
            <p>{boot.error || 'You have no active placement, so OJT logging is unavailable.'}</p>
            <p className="empty-state__hint">
              Contact your placement officer once you have an active apprenticeship.
            </p>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">My OJT Logs</h1>
            <p className="page__subtitle">
              Submit and track your daily on-the-job training logs.
            </p>
          </div>
          <div className="page__heading-actions">
            <button type="button" className="btn btn--secondary" onClick={() => setBulkOpen(true)}>
              + Bulk Add (past dates)
            </button>
            <button type="button" className="btn btn--primary" onClick={openSubmit}>
              + Submit Log
            </button>
          </div>
        </div>

        <div className="toolbar">
          <div className="toolbar__filter">
            <label htmlFor="from-date" className="field__label field__label--sm">
              From
            </label>
            <input
              id="from-date"
              type="date"
              className="field__input"
              value={fromDate}
              max={toDate || undefined}
              onChange={(e) => setFromDate(e.target.value)}
            />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="to-date" className="field__label field__label--sm">
              To
            </label>
            <input
              id="to-date"
              type="date"
              className="field__input"
              value={toDate}
              min={fromDate || undefined}
              onChange={(e) => setToDate(e.target.value)}
            />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="field__label field__label--sm">
              Status
            </label>
            <select
              id="status-filter"
              className="field__input"
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                setPage(0);
              }}
            >
              <option value="">All statuses</option>
              {OJT_LOG_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Log Date</th>
                <th scope="col">Tasks Performed</th>
                <th scope="col">Hours</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={5} className="table__state">
                    <Spinner size={22} label="Loading logs" /> Loading…
                  </td>
                </tr>
              ) : error ? (
                <tr>
                  <td colSpan={5} className="table__state table__state--error">
                    {error}{' '}
                    <button type="button" className="btn btn--secondary btn--sm" onClick={load}>
                      Retry
                    </button>
                  </td>
                </tr>
              ) : visibleLogs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="table__state">
                    No logs found.
                  </td>
                </tr>
              ) : (
                visibleLogs.map((log) => (
                  <tr key={log.logID}>
                    <td data-label="Log Date">{formatDate(log.logDate)}</td>
                    <td data-label="Tasks Performed">
                      <span title={log.tasksPerformed}>{truncate(log.tasksPerformed)}</span>
                      {log.status === 'Rejected' && log.rejectionReason && (
                        <p className="reject-reason">
                          <strong>Rejected:</strong> {log.rejectionReason}
                        </p>
                      )}
                    </td>
                    <td data-label="Hours">{log.hoursWorked ?? '—'}</td>
                    <td data-label="Status">
                      <StatusBadge
                        status={log.status}
                        tone={OJT_LOG_STATUS_TONE[log.status] || 'neutral'}
                      />
                    </td>
                    <td data-label="Actions" className="table__actions">
                      {log.status === 'Rejected' ? (
                        <button
                          type="button"
                          className="btn btn--secondary btn--sm"
                          onClick={() => openEdit(log)}
                        >
                          Edit &amp; Resubmit
                        </button>
                      ) : (
                        <span className="text-muted">—</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {(fromDate || toDate) && (
          <p className="page__note">
            Date filter is applied within the current page of results.
          </p>
        )}

        <div className="pagination">
          <span className="pagination__info">
            {pageInfo.totalElements > 0 ? `${pageInfo.totalElements} total logs` : ' '}
          </span>
          <div className="pagination__controls">
            <button
              type="button"
              className="btn btn--secondary btn--sm"
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={loading || page === 0}
            >
              ← Previous
            </button>
            <span className="pagination__page">
              Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}
            </span>
            <button
              type="button"
              className="btn btn--secondary btn--sm"
              onClick={() => setPage((p) => p + 1)}
              disabled={loading || page + 1 >= pageInfo.totalPages}
            >
              Next →
            </button>
          </div>
        </div>
      </main>

      {formOpen && (
        <OjtLogFormModal
          log={editing}
          placementID={placementId}
          traineeID={traineeId}
          onClose={() => {
            setFormOpen(false);
            setEditing(null);
          }}
          onSubmit={handleSubmit}
        />
      )}

      {bulkOpen && (
        <OjtLogBulkModal
          placementID={placementId}
          traineeID={traineeId}
          onClose={() => setBulkOpen(false)}
          onSubmit={handleBulkSubmit}
        />
      )}
    </div>
  );
}
