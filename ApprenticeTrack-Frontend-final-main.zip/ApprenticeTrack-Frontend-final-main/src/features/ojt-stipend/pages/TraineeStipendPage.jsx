// Trainee Stipend History — the signed-in trainee's own monthly stipend
// disbursements. Read-only view over AP-23 (/api/stipend-disbursements,
// filtered by the trainee's own traineeID). Mirrors TraineeResultsPage:
// resolve the trainee profile from the user, then load their records.

import { useCallback, useEffect, useMemo, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import { useAuth } from '../../../shared/auth/AuthContext';
import { getTraineeByUser } from '../../training/api/trainees';
import { listStipends } from '../api/stipend';
import {
  ELIGIBILITY_THRESHOLD,
  STIPEND_STATUS_TONE,
  stipendAttendanceTone,
} from '../constants/stipend';
import { monthLabel } from '../constants/attendance';
import { formatCurrency } from '../../../shared/format';

export default function TraineeStipendPage() {
  const { user } = useAuth();

  const [boot, setBoot] = useState({ loading: true, error: '', traineeID: null });
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const trainee = await getTraineeByUser(user.userID);
        if (alive) setBoot({ loading: false, error: '', traineeID: trainee.traineeID });
      } catch (err) {
        if (alive)
          setBoot({
            loading: false,
            error:
              err?.response?.status === 404
                ? 'No trainee profile is linked to your account yet.'
                : 'Could not load your profile.',
            traineeID: null,
          });
      }
    })();
    return () => {
      alive = false;
    };
  }, [user.userID]);

  const load = useCallback(async () => {
    if (!boot.traineeID) return;
    setLoading(true);
    setError('');
    try {
      const data = await listStipends({
        traineeID: boot.traineeID,
        page: 0,
        size: 50,
        sort: 'disbursementID,desc',
      });
      setRows(data.content || []);
    } catch {
      setError('Could not load your stipend history. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [boot.traineeID]);

  useEffect(() => {
    load();
  }, [load]);

  // Total actually paid out (Disbursed rows only).
  const totalPaid = useMemo(
    () =>
      rows
        .filter((r) => r.status === 'Disbursed')
        .reduce((sum, r) => sum + (Number(r.stipendAmount) || 0), 0),
    [rows]
  );

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Stipend History</h1>
            <p className="page__subtitle">Track your monthly stipend disbursements and payment status.</p>
          </div>
          {rows.length > 0 && (
            <div className="entry-actions">
              <span className="page__note">Total disbursed: <strong>{formatCurrency(totalPaid)}</strong></span>
            </div>
          )}
        </div>

        {boot.loading ? (
          <div className="table__state"><Spinner size={24} label="Loading" /> Loading…</div>
        ) : boot.error ? (
          <div className="empty-state"><p>{boot.error}</p></div>
        ) : (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">Month/Year</th>
                  <th scope="col">Attendance %</th>
                  <th scope="col">Stipend Amount</th>
                  <th scope="col">Status</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={4} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
                ) : error ? (
                  <tr>
                    <td colSpan={4} className="table__state table__state--error">
                      {error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button>
                    </td>
                  </tr>
                ) : rows.length === 0 ? (
                  <tr><td colSpan={4} className="table__state">You have no stipend records yet.</td></tr>
                ) : (
                  rows.map((r) => {
                    const pct = Number(r.attendancePercent) || 0;
                    return (
                      <tr key={r.disbursementID}>
                        <td data-label="Month/Year">{monthLabel(r.month)} {r.year}</td>
                        <td data-label="Attendance %">
                          <span className={`pct pct--${stipendAttendanceTone(pct)}`}>{pct}%</span>
                        </td>
                        <td data-label="Stipend Amount">{formatCurrency(r.stipendAmount)}</td>
                        <td data-label="Status">
                          <StatusBadge status={r.status} tone={STIPEND_STATUS_TONE[r.status] || 'neutral'} />
                          {r.status === 'Withheld' && (
                            <span
                              className="withheld-flag"
                              title={`Low attendance (${pct}% < ${ELIGIBILITY_THRESHOLD}%)`}
                              aria-label={`Withheld: low attendance ${pct} percent`}
                            >
                              {' '}⚠️
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}

        {!boot.error && rows.length > 0 && (
          <p className="page__note">
            Amounts marked <strong>Disbursed</strong> have been paid; <strong>Withheld</strong> means attendance fell
            below {ELIGIBILITY_THRESHOLD}% for that month.
          </p>
        )}
      </main>
    </div>
  );
}
