import api from '../../../shared/api/client';

export function listEmployers({
  companyName,
  status,
  industrySector,
  page = 0,
  size = 10,
  sort = 'companyName,asc',
} = {}) {
  const params = { page, size, sort };
  if (companyName) params.companyName = companyName;
  if (status) params.status = status;
  if (industrySector) params.industrySector = industrySector;
  return api.get('/api/employers', { params }).then((r) => r.data);
}

export function getEmployer(id) {
  return api.get(`/api/employers/${id}`).then((r) => r.data);
}

export function createEmployer(body) {
  return api.post('/api/employers', body).then((r) => r.data);
}

export function updateEmployer(id, body) {
  return api.put(`/api/employers/${id}`, body).then((r) => r.data);
}

export function updateEmployerStatus(id, status) {
  return api.patch(`/api/employers/${id}/status`, { status }).then((r) => r.data);
}
