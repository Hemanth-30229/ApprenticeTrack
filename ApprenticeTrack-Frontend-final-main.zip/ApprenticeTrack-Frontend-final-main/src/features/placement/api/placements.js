import api from '../../../shared/api/client';

export function listPlacements({
  traineeID,
  employerID,
  vacancyID,
  status,
  page = 0,
  size = 10,
  sort = 'placementDate,desc',
} = {}) {
  const params = { page, size, sort };
  if (traineeID) params.traineeID = traineeID;
  if (employerID) params.employerID = employerID;
  if (vacancyID) params.vacancyID = vacancyID;
  if (status) params.status = status;
  return api.get('/api/placements', { params }).then((r) => r.data);
}

export function getPlacement(id) {
  return api.get(`/api/placements/${id}`).then((r) => r.data);
}

export function createPlacement(body) {
  return api.post('/api/placements', body).then((r) => r.data);
}

export function updatePlacementStatus(id, status) {
  return api.put(`/api/placements/${id}/status`, { status }).then((r) => r.data);
}

export function getActivePlacementForTrainee(traineeID) {
  return listPlacements({ traineeID, status: 'Active', page: 0, size: 1 }).then(
    (page) => (page.content && page.content[0]) || null
  );
}
