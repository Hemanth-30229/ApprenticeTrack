import api from '../../../shared/api/client';

export function listVacancies({
  employerID,
  tradeRequired,
  status,
  page = 0,
  size = 10,
  sort = 'postedDate,desc',
} = {}) {
  const params = { page, size, sort };
  if (employerID) params.employerID = employerID;
  if (tradeRequired) params.tradeRequired = tradeRequired;
  if (status) params.status = status;
  return api.get('/api/vacancies', { params }).then((r) => r.data);
}

export function getVacancy(id) {
  return api.get(`/api/vacancies/${id}`).then((r) => r.data);
}

export function createVacancy(body) {
  return api.post('/api/vacancies', body).then((r) => r.data);
}

export function updateVacancy(id, body) {
  return api.put(`/api/vacancies/${id}`, body).then((r) => r.data);
}
