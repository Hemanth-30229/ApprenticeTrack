export default function EmployerCompanyBar({ employers, employerId, setEmployerId, companyName }) {
  if (employers.length <= 1 && employerId) {
    return companyName ? (
      <p className="page__note">Showing data for <strong>{companyName}</strong>.</p>
    ) : null;
  }
  return (
    <div className="toolbar">
      <div className="toolbar__filter">
        <label htmlFor="company" className="field__label field__label--sm">Company</label>
        <select id="company" className="field__input" value={employerId} onChange={(e) => setEmployerId(e.target.value)}>
          <option value="">Select your company…</option>
          {employers.map((e) => (
            <option key={e.employerID} value={e.employerID}>{e.companyName}</option>
          ))}
        </select>
      </div>
    </div>
  );
}
