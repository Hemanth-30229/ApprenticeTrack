import { useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import { COMMON_INDUSTRY_SECTORS } from '../../constants/employer';

function emptyForm() {
  return {
    companyName: '',
    industrySector: '',
    address: '',
    contactPerson: '',
    apprenticeshipCapacity: '',
  };
}

function fromEmployer(e) {
  return {
    companyName: e.companyName ?? '',
    industrySector: e.industrySector ?? '',
    address: e.address ?? '',
    contactPerson: e.contactPerson ?? '',
    apprenticeshipCapacity: e.apprenticeshipCapacity ?? '',
  };
}

function validate(form) {
  const e = {};
  if (!form.companyName.trim()) e.companyName = 'Company name is required';
  if (!form.industrySector.trim()) e.industrySector = 'Industry sector is required';
  if (!form.address.trim()) e.address = 'Address is required';
  if (!form.contactPerson.trim()) e.contactPerson = 'Contact person is required';
  if (!String(form.apprenticeshipCapacity).trim()) e.apprenticeshipCapacity = 'Capacity is required';
  return e;
}

export default function EmployerFormModal({ employer, onClose, onSubmit }) {
  const isEdit = Boolean(employer);
  const [form, setForm] = useState(() => (isEdit ? fromEmployer(employer) : emptyForm()));
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const set = (f, v) => setForm((s) => ({ ...s, [f]: v }));

  async function handleSubmit(e) {
    e.preventDefault();

    const found = validate(form);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    const payload = {
      companyName: form.companyName.trim(),
      industrySector: form.industrySector.trim(),
      address: form.address.trim(),
      contactPerson: form.contactPerson.trim(),
      apprenticeshipCapacity: Number(form.apprenticeshipCapacity),
    };

    setSubmitting(true);
    try {
      await onSubmit(payload);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title={isEdit ? 'Edit Employer' : 'Register Employer'} onClose={onClose} size="lg">
      <form className="form" onSubmit={handleSubmit}>
        <div className="form__grid">
          <Field label="Company Name" error={errors.companyName}>
            <input
              type="text"
              className="field__input"
              value={form.companyName}
              onChange={(e) => set('companyName', e.target.value)}
            />
          </Field>

          <Field label="Industry Sector" error={errors.industrySector}>
            <input
              type="text"
              className="field__input"
              list="industry-sectors"
              value={form.industrySector}
              onChange={(e) => set('industrySector', e.target.value)}
            />
            <datalist id="industry-sectors">
              {COMMON_INDUSTRY_SECTORS.map((s) => (
                <option key={s} value={s} />
              ))}
            </datalist>
          </Field>

          <Field label="Contact Person" error={errors.contactPerson}>
            <input
              type="text"
              className="field__input"
              value={form.contactPerson}
              onChange={(e) => set('contactPerson', e.target.value)}
            />
          </Field>

          <Field label="Apprenticeship Capacity" error={errors.apprenticeshipCapacity}>
            <input
              type="number"
              min="1"
              className="field__input"
              value={form.apprenticeshipCapacity}
              onChange={(e) => set('apprenticeshipCapacity', e.target.value)}
            />
          </Field>

          <Field label="Address" error={errors.address} full>
            <textarea
              className="field__input"
              rows={2}
              value={form.address}
              onChange={(e) => set('address', e.target.value)}
            />
          </Field>
        </div>

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={submitting}>
            Cancel
          </button>
          <button type="submit" className="btn btn--primary" disabled={submitting}>
            {submitting && <Spinner size={16} inline label="Saving" />}
            {isEdit ? 'Save Changes' : 'Register Employer'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

function Field({ label, error, full, children }) {
  return (
    <div className={`field ${full ? 'field--full' : ''}`}>
      <label className="field__label">{label}</label>
      {children}
      {error && <p className="field__error" role="alert">{error}</p>}
    </div>
  );
}
