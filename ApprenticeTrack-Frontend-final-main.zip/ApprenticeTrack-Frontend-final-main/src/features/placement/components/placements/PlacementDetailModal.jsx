import { useEffect, useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import StatusBadge from '../../../../shared/ui/StatusBadge';
import { getTrainee } from '../../../training/api/trainees';
import { getEmployer } from '../../api/employers';
import { getVacancy } from '../../api/vacancies';
import { PLACEMENT_STATUS_TONE } from '../../constants/placement';
import { formatDate } from '../../../../shared/format';

export default function PlacementDetailModal({ placement, onClose }) {
  const [data, setData] = useState({ trainee: null, employer: null, vacancy: null });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const [trainee, employer, vacancy] = await Promise.all([
        getTrainee(placement.traineeID).catch(() => null),
        getEmployer(placement.employerID).catch(() => null),
        getVacancy(placement.vacancyID).catch(() => null),
      ]);
      setData({ trainee, employer, vacancy });
      setLoading(false);
    }
    load();
  }, [placement]);

  const { trainee, employer, vacancy } = data;

  return (
    <Modal title={`Placement #${placement.placementID}`} onClose={onClose} size="lg">
      {loading ? (
        <p className="widget__empty">
          <Spinner size={18} inline label="Loading" /> Loading details…
        </p>
      ) : (
        <>
          <div className="detail-columns">
            <section>
              <h3 className="detail-section-title">Trainee</h3>
              <dl className="detail-grid detail-grid--single">
                <Row label="Name" value={placement.traineeName || trainee?.name} />
                <Row label="Phone" value={trainee?.phone} />
                <Row label="Education" value={trainee?.educationLevel} />
                <Row label="Status" value={trainee?.status} />
              </dl>
            </section>

            <section>
              <h3 className="detail-section-title">Employer</h3>
              <dl className="detail-grid detail-grid--single">
                <Row label="Company" value={placement.employerName || employer?.companyName} />
                <Row label="Sector" value={employer?.industrySector} />
                <Row label="Trade" value={vacancy?.tradeRequired} />
                <Row label="Contact" value={employer?.contactPerson} />
              </dl>
            </section>

            <section>
              <h3 className="detail-section-title">Supervisor</h3>
              <dl className="detail-grid detail-grid--single">
                <Row label="Name" value={placement.supervisorName} />
                <Row label="Phone" value={placement.supervisorPhone} />
              </dl>
            </section>
          </div>

          <h3 className="detail-section-title">Timeline</h3>
          <ol className="timeline">
            <li className="timeline__item">
              <span className="timeline__dot" />
              <div>
                <span className="timeline__title">Placed</span>
                <span className="timeline__meta">{formatDate(placement.placementDate)}</span>
              </div>
            </li>
            <li className="timeline__item">
              <span className={`timeline__dot timeline__dot--${PLACEMENT_STATUS_TONE[placement.status] || 'neutral'}`} />
              <div>
                <span className="timeline__title">
                  Current status <StatusBadge status={placement.status} tone={PLACEMENT_STATUS_TONE[placement.status] || 'neutral'} />
                </span>
                <span className="timeline__meta">
                  {placement.status === 'Active' ? 'Ongoing' : placement.status}
                </span>
              </div>
            </li>
          </ol>

          <div className="modal__actions">
            <button type="button" className="btn btn--secondary" onClick={onClose}>
              Close
            </button>
          </div>
        </>
      )}
    </Modal>
  );
}

function Row({ label, value }) {
  return (
    <div className="detail-grid__row">
      <dt className="detail-grid__label">{label}</dt>
      <dd className="detail-grid__value">{value ?? '—'}</dd>
    </div>
  );
}
