import { useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import SearchableSelect from '../../../../shared/ui/SearchableSelect';
import { listTrainees } from '../../../training/api/trainees';

async function fetchEligibleTrainees(query) {
  const page = await listTrainees({
    name: query || undefined,
    status: 'Active',
    page: 0,
    size: 10,
    sort: 'name,asc',
  });
  return (page.content || []).map((t) => ({
    value: t.traineeID,
    label: `${t.name} (#${t.traineeID})`,
    name: t.name,
  }));
}

export default function PlacementFormModal({ vacancies, initialVacancyId, onClose, onSubmit }) {
  const [traineeID, setTraineeID] = useState(null);
  const [traineeName, setTraineeName] = useState('');
  const [vacancyID, setVacancyID] = useState(initialVacancyId ? String(initialVacancyId) : '');
  const [supervisorName, setSupervisorName] = useState('');
  const [supervisorPhone, setSupervisorPhone] = useState('');
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const selectedVacancy = vacancies.find((v) => String(v.vacancyID) === String(vacancyID));

  function validate() {
    const e = {};
    if (!traineeID) e.trainee = 'Please select a trainee';
    if (!vacancyID) e.vacancy = 'Please select a vacancy';
    if (!supervisorName.trim()) e.supervisorName = 'Supervisor name is required';
    if (!supervisorPhone.trim()) e.supervisorPhone = 'Supervisor phone is required';
    return e;
  }

  async function handleSubmit(e) {
    e.preventDefault();

    const found = validate();
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setSubmitting(true);
    try {
      await onSubmit({
        traineeID: Number(traineeID),
        vacancyID: Number(vacancyID),
        employerID: selectedVacancy.employerID,
        supervisorName: supervisorName.trim(),
        supervisorPhone: supervisorPhone.trim(),
      });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="New Placement" onClose={onClose} size="md">
      <form className="form" onSubmit={handleSubmit}>
        <div className="field">
          <label className="field__label" htmlFor="trainee">Trainee</label>
          <SearchableSelect
            value={traineeID}
            selectedLabel={traineeName}
            placeholder="Search eligible trainees…"
            fetchOptions={fetchEligibleTrainees}
            invalid={Boolean(errors.trainee)}
            onSelect={(opt) => {
              setTraineeID(opt.value);
              setTraineeName(opt.name);
            }}
          />
          <p className="field__hint">Only Active trainees are eligible for placement.</p>
          {errors.trainee && <p className="field__error" role="alert">{errors.trainee}</p>}
        </div>

        <div className="field">
          <label className="field__label" htmlFor="vacancy">Vacancy</label>
          <select
            id="vacancy"
            className="field__input"
            value={vacancyID}
            onChange={(e) => setVacancyID(e.target.value)}
          >
            <option value="">Select a vacancy…</option>
            {vacancies.map((v) => {
              const filled = v.filledCount ?? 0;
              const isFull = v.status === 'Filled' || v.status === 'Expired' || filled >= v.vacancyCount;
              return (
                <option key={v.vacancyID} value={v.vacancyID} disabled={isFull}>
                  {v.companyName || `Employer #${v.employerID}`} - {v.tradeRequired} ({filled}/
                  {v.vacancyCount} filled){v.status === 'Filled' ? ' — Full' : v.status === 'Expired' ? ' — Expired' : ''}
                </option>
              );
            })}
          </select>
          {errors.vacancy && <p className="field__error" role="alert">{errors.vacancy}</p>}
        </div>

        <div className="form__grid">
          <div className="field">
            <label className="field__label" htmlFor="supervisorName">Supervisor Name</label>
            <input
              id="supervisorName"
              type="text"
              className="field__input"
              value={supervisorName}
              onChange={(e) => setSupervisorName(e.target.value)}
            />
            {errors.supervisorName && <p className="field__error" role="alert">{errors.supervisorName}</p>}
          </div>

          <div className="field">
            <label className="field__label" htmlFor="supervisorPhone">Supervisor Phone</label>
            <input
              id="supervisorPhone"
              type="tel"
              className="field__input"
              value={supervisorPhone}
              onChange={(e) => setSupervisorPhone(e.target.value)}
            />
            {errors.supervisorPhone && <p className="field__error" role="alert">{errors.supervisorPhone}</p>}
          </div>
        </div>

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={submitting}>
            Cancel
          </button>
          <button type="submit" className="btn btn--primary" disabled={submitting}>
            {submitting && <Spinner size={16} inline label="Creating" />}
            Create Placement
          </button>
        </div>
      </form>
    </Modal>
  );
}
