import { useRef } from 'react';
import SearchableSelect from '../../../../shared/ui/SearchableSelect';
import { listPlacements } from '../../api/placements';

function placementLabel(p) {
  const trainee = p.traineeName || `Trainee #${p.traineeID}`;
  const employer = p.employerName || `Employer #${p.employerID}`;
  return `${trainee} — ${employer} (#${p.placementID})`;
}

export default function PlacementSelect({ value, selectedLabel, onSelect, invalid = false }) {
  const cacheRef = useRef(null);

  async function fetchOptions(query) {
    if (!cacheRef.current) {
      const page = await listPlacements({ page: 0, size: 500, sort: 'placementDate,desc' });
      cacheRef.current = (page.content || []).map((p) => ({
        value: p.placementID,
        traineeID: p.traineeID,
        label: placementLabel(p),
        _search: `${p.traineeName || ''} ${p.employerName || ''} ${p.placementID}`.toLowerCase(),
      }));
    }
    const q = query.toLowerCase();
    const matched = q ? cacheRef.current.filter((o) => o._search.includes(q)) : cacheRef.current;
    return matched.slice(0, 50);
  }

  return (
    <SearchableSelect
      value={value}
      selectedLabel={selectedLabel}
      placeholder="Search placement by trainee or employer…"
      fetchOptions={fetchOptions}
      onSelect={onSelect}
      invalid={invalid}
    />
  );
}
