import { useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';

export default function TerminatePlacementModal({ placement, onClose, onConfirm }) {
  const [busy, setBusy] = useState(false);

  async function handleConfirm() {
    setBusy(true);
    try {
      await onConfirm();
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal title="Terminate placement?" onClose={busy ? () => {} : onClose} size="sm">
      <p className="confirm__message">
        Terminate the placement for <strong>{placement.traineeName || `Trainee #${placement.traineeID}`}</strong>?
        This frees up the vacancy slot and cannot be undone.
      </p>
      <div className="modal__actions">
        <button type="button" className="btn btn--secondary" onClick={onClose} disabled={busy}>
          Cancel
        </button>
        <button type="button" className="btn btn--danger" onClick={handleConfirm} disabled={busy}>
          {busy && <Spinner size={16} inline label="Terminating" />}
          Terminate
        </button>
      </div>
    </Modal>
  );
}
