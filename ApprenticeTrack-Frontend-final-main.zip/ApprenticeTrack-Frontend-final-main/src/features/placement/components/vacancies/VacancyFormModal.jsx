import { useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';

function emptyForm() {
  return { tradeRequired: '', vacancyCount: '', stipendOffered: '' };
}
function fromVacancy(v) {
  return {
    tradeRequired: v.tradeRequired ?? '',
    vacancyCount: v.vacancyCount ?? '',
    stipendOffered: v.stipendOffered ?? '',
  };
}

function validate(f) {
  const e = {};
  if (!f.tradeRequired.trim()) e.tradeRequired = 'Trade required is required';
  if (!String(f.vacancyCount).trim()) e.vacancyCount = 'Vacancy count is required';
  if (!String(f.stipendOffered).trim()) e.stipendOffered = 'Stipend is required';
  return e;
}

export default function VacancyFormModal({ vacancy, onClose, onSubmit }) {
  const isEdit = Boolean(vacancy);
  const [form, setForm] = useState(() => (isEdit ? fromVacancy(vacancy) : emptyForm()));
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const set = (f, v) => setForm((s) => ({ ...s, [f]: v }));

  async function handleSubmit(e) {
    e.preventDefault();

    const found = validate(form);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setSubmitting(true);
    try {
      await onSubmit({
        tradeRequired: form.tradeRequired.trim(),
        vacancyCount: Number(form.vacancyCount),
        stipendOffered: Number(form.stipendOffered),
      });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title={isEdit ? 'Edit Vacancy' : 'Post Vacancy'} onClose={onClose} size="md">
      <form className="form" onSubmit={handleSubmit}>
        <div className="form__grid">
          <Field label="Trade Required" error={errors.tradeRequired}>
            <input type="text" className="field__input" value={form.tradeRequired} onChange={(e) => set('tradeRequired', e.target.value)} />
          </Field>
          <Field label="Vacancy Count" error={errors.vacancyCount}>
            <input type="number" min="1" className="field__input" value={form.vacancyCount} onChange={(e) => set('vacancyCount', e.target.value)} />
          </Field>
          <Field label="Stipend Offered (₹/month)" error={errors.stipendOffered}>
            <input type="number" min="0" step="0.01" className="field__input" value={form.stipendOffered} onChange={(e) => set('stipendOffered', e.target.value)} />
          </Field>
        </div>

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={submitting}>Cancel</button>
          <button type="submit" className="btn btn--primary" disabled={submitting}>
            {submitting && <Spinner size={16} inline label="Saving" />}
            {isEdit ? 'Save Changes' : 'Post Vacancy'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

function Field({ label, error, children }) {
  return (
    <div className="field">
      <label className="field__label">{label}</label>
      {children}
      {error && <p className="field__error" role="alert">{error}</p>}
    </div>
  );
}
