export const EMPLOYER_STATUSES = ['Active', 'Suspended', 'Deregistered'];

export const EMPLOYER_STATUS_TONE = {
  Active: 'success', // green
  Suspended: 'warning', // orange
  Deregistered: 'danger', // red
};

export const EMPLOYER_STATUS_TRANSITIONS = {
  Active: [{ to: 'Suspended', label: 'Suspend', tone: 'danger' }],
  Suspended: [
    { to: 'Active', label: 'Reactivate', tone: 'primary' },
    { to: 'Deregistered', label: 'Deregister', tone: 'danger' },
  ],
  Deregistered: [],
};

export const COMMON_INDUSTRY_SECTORS = [
  'Manufacturing',
  'Construction',
  'IT / Software',
  'Automotive',
  'Healthcare',
  'Hospitality',
  'Retail',
  'Electrical',
  'Textiles',
  'Agriculture',
  'Logistics',
  'Other',
];
