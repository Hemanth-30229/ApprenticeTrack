export const PLACEMENT_STATUSES = ['Active', 'Completed', 'Terminated'];

export const PLACEMENT_STATUS_TONE = {
  Active: 'info',
  Completed: 'success',
  Terminated: 'danger',
};

export const PLACEMENT_STATUS_TRANSITIONS = {
  Active: [
    { to: 'Completed', label: 'Complete Placement', tone: 'primary' },
    { to: 'Terminated', label: 'Terminate Placement', tone: 'danger' },
  ],
  Completed: [],
  Terminated: [],
};

export const VACANCY_STATUS_TONE = {
  Open: 'success',
  PartiallyFilled: 'warning',
  Filled: 'info',
  Expired: 'neutral',
};
