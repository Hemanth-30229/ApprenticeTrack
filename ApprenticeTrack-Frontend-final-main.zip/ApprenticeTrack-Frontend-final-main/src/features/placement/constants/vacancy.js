export const VACANCY_STATUS_LABEL = {
  Open: 'Open',
  PartiallyFilled: 'Partially Filled',
  Filled: 'Filled',
  Expired: 'Expired',
};

export const VACANCY_STATUS_TONE = {
  Open: 'success',
  PartiallyFilled: 'warning',
  Filled: 'info',
  Expired: 'neutral',
};
