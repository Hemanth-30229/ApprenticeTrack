import { useEffect, useState } from 'react';
import { useAuth } from '../../../shared/auth/AuthContext';
import { listEmployers } from '../api/employers';

function resolveEmployerId(list, user) {
  const byInstitute = list.find((e) => String(e.employerID) === String(user?.instituteID));
  if (byInstitute) return String(byInstitute.employerID);
  if (user?.name) {
    const name = user.name.trim().toLowerCase();
    const byContact = list.filter((e) => (e.contactPerson || '').trim().toLowerCase() === name);
    if (byContact.length === 1) return String(byContact[0].employerID);
  }
  if (list.length === 1) return String(list[0].employerID);
  return '';
}

export function useEmployer() {
  const { user } = useAuth();
  const [employers, setEmployers] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [employerId, setEmployerId] = useState('');

  useEffect(() => {
    listEmployers({ status: 'Active', size: 500 })
      .then((p) => {
        const list = p.content || [];
        setEmployers(list);
        setEmployerId(resolveEmployerId(list, user));
      })
      .catch(() => setEmployers([]))
      .finally(() => setLoaded(true));
  }, [user]);

  const companyName = employers.find((e) => String(e.employerID) === String(employerId))?.companyName;

  return { employers, employerId, setEmployerId, companyName, loaded };
}
