import { useEffect, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import ConfirmDialog from '../../../shared/ui/ConfirmDialog';
import EmployerFormModal from '../components/employers/EmployerFormModal';
import { useToast } from '../../../shared/toast/ToastContext';
import {
  createEmployer,
  listEmployers,
  updateEmployer,
  updateEmployerStatus,
} from '../api/employers';
import {
  COMMON_INDUSTRY_SECTORS,
  EMPLOYER_STATUSES,
  EMPLOYER_STATUS_TONE,
  EMPLOYER_STATUS_TRANSITIONS,
} from '../constants/employer';

const PAGE_SIZE = 10;

export default function EmployerListPage() {
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ number: 0, totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [sector, setSector] = useState('');
  const [page, setPage] = useState(0);

  const [seenSectors, setSeenSectors] = useState([]);

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [statusChange, setStatusChange] = useState(null); 
  const [statusBusy, setStatusBusy] = useState(false);

  async function load() {
    setLoading(true);
    setError('');
    try {
      const data = await listEmployers({
        companyName: search || undefined,
        status: status || undefined,
        industrySector: sector || undefined,
        page,
        size: PAGE_SIZE,
        sort: 'companyName,asc',
      });
      const content = data.content || [];
      setRows(content);
      setPageInfo({
        number: data.number ?? 0,
        totalPages: data.totalPages ?? 0,
        totalElements: data.totalElements ?? 0,
      });
      setSeenSectors((prev) => {
        const set = new Set(prev);
        content.forEach((e) => e.industrySector && set.add(e.industrySector));
        return Array.from(set);
      });
    } catch {
      setError('Could not load employers. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  // Reload whenever a filter or the page changes.
  useEffect(() => {
    load();
  }, [search, status, sector, page]);

  const sectorOptions = Array.from(new Set([...COMMON_INDUSTRY_SECTORS, ...seenSectors]))
    .sort((a, b) => a.localeCompare(b));

  function openAdd() {
    setEditing(null);
    setFormOpen(true);
  }
  function openEdit(employer) {
    setEditing(employer);
    setFormOpen(true);
  }

  async function handleSubmit(payload) {
    try {
      if (editing) {
        await updateEmployer(editing.employerID, payload);
        toast.success('Employer updated successfully.');
      } else {
        await createEmployer(payload);
        toast.success('Employer registered successfully.');
      }
      setFormOpen(false);
      setEditing(null);
      if (!editing && page !== 0) setPage(0);
      else load();
    } catch (err) {
      toast.error(
        err?.response?.data?.message ||
          (editing ? 'Failed to update employer.' : 'Failed to register employer.')
      );
      throw err;
    }
  }

  async function confirmStatusChange() {
    if (!statusChange) return;
    setStatusBusy(true);
    try {
      await updateEmployerStatus(statusChange.employer.employerID, statusChange.to);
      toast.success(
        `${statusChange.employer.companyName} is now ${statusChange.to}.`
      );
      setStatusChange(null);
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to change status.');
    } finally {
      setStatusBusy(false);
    }
  }

  const from = pageInfo.totalElements === 0 ? 0 : page * PAGE_SIZE + 1;
  const to = Math.min((page + 1) * PAGE_SIZE, pageInfo.totalElements);

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Employers</h1>
            <p className="page__subtitle">
              Register, view, edit and manage employer establishments.
            </p>
          </div>
          <button type="button" className="btn btn--primary" onClick={openAdd}>
            + Register Employer
          </button>
        </div>

        <div className="toolbar">
          <div className="toolbar__search">
            <label htmlFor="employer-search" className="sr-only">
              Search employers by company name
            </label>
            <input
              id="employer-search"
              type="search"
              className="field__input"
              placeholder="Search by company name…"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(0); }}
            />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="sr-only">
              Filter by status
            </label>
            <select
              id="status-filter"
              className="field__input"
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                setPage(0);
              }}
            >
              <option value="">All statuses</option>
              {EMPLOYER_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="sector-filter" className="sr-only">
              Filter by industry sector
            </label>
            <select
              id="sector-filter"
              className="field__input"
              value={sector}
              onChange={(e) => {
                setSector(e.target.value);
                setPage(0);
              }}
            >
              <option value="">All sectors</option>
              {sectorOptions.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Company Name</th>
                <th scope="col">Industry Sector</th>
                <th scope="col">Contact Person</th>
                <th scope="col">Capacity</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={6} className="table__state">
                    <Spinner size={22} label="Loading employers" /> Loading…
                  </td>
                </tr>
              ) : error ? (
                <tr>
                  <td colSpan={6} className="table__state table__state--error">
                    {error}{' '}
                    <button type="button" className="btn btn--secondary btn--sm" onClick={load}>
                      Retry
                    </button>
                  </td>
                </tr>
              ) : rows.length === 0 ? (
                <tr>
                  <td colSpan={6} className="table__state">
                    No employers found.
                  </td>
                </tr>
              ) : (
                rows.map((emp) => (
                  <tr key={emp.employerID}>
                    <td data-label="Company Name">{emp.companyName}</td>
                    <td data-label="Industry Sector">{emp.industrySector}</td>
                    <td data-label="Contact Person">{emp.contactPerson}</td>
                    <td data-label="Capacity">{emp.apprenticeshipCapacity}</td>
                    <td data-label="Status">
                      <StatusBadge
                        status={emp.status}
                        tone={EMPLOYER_STATUS_TONE[emp.status] || 'neutral'}
                      />
                    </td>
                    <td data-label="Actions" className="table__actions">
                      <button
                        type="button"
                        className="btn btn--secondary btn--sm"
                        onClick={() => openEdit(emp)}
                      >
                        Edit
                      </button>
                      {(EMPLOYER_STATUS_TRANSITIONS[emp.status] || []).map((tr) => (
                        <button
                          key={tr.to}
                          type="button"
                          className={`btn btn--sm ${
                            tr.tone === 'danger' ? 'btn--danger-ghost' : 'btn--secondary'
                          }`}
                          onClick={() =>
                            setStatusChange({ employer: emp, to: tr.to, label: tr.label, tone: tr.tone })
                          }
                        >
                          {tr.label}
                        </button>
                      ))}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <span className="pagination__info">
            {pageInfo.totalElements > 0 ? `Showing ${from}–${to} of ${pageInfo.totalElements}` : ' '}
          </span>
          <div className="pagination__controls">
            <button
              type="button"
              className="btn btn--secondary btn--sm"
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={loading || page === 0}
            >
              ← Previous
            </button>
            <span className="pagination__page">
              Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}
            </span>
            <button
              type="button"
              className="btn btn--secondary btn--sm"
              onClick={() => setPage((p) => p + 1)}
              disabled={loading || page + 1 >= pageInfo.totalPages}
            >
              Next →
            </button>
          </div>
        </div>
      </main>

      {formOpen && (
        <EmployerFormModal
          employer={editing}
          onClose={() => {
            setFormOpen(false);
            setEditing(null);
          }}
          onSubmit={handleSubmit}
        />
      )}

      {statusChange && (
        <ConfirmDialog
          title={`${statusChange.label} employer?`}
          message={`Are you sure you want to ${statusChange.label.toLowerCase()} "${statusChange.employer.companyName}"?`}
          confirmLabel={statusChange.label}
          tone={statusChange.tone === 'danger' ? 'danger' : 'primary'}
          busy={statusBusy}
          onConfirm={confirmStatusChange}
          onCancel={() => (statusBusy ? null : setStatusChange(null))}
        />
      )}
    </div>
  );
}
