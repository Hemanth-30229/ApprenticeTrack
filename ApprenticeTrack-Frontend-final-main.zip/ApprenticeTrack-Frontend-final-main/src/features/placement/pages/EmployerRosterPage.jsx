import { useEffect, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import EmployerCompanyBar from '../components/employers/EmployerCompanyBar';
import { useEmployer } from '../hooks/useEmployer';
import { listPlacements } from '../api/placements';
import { listVacancies } from '../api/vacancies';
import { apiErrorMessage } from '../../../shared/api/errors';
import { PLACEMENT_STATUSES, PLACEMENT_STATUS_TONE } from '../constants/placement';
import { formatDate } from '../../../shared/format';

const PAGE_SIZE = 10;

export default function EmployerRosterPage() {
  const { employers, employerId, setEmployerId, companyName, loaded } = useEmployer();

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);
  const [status, setStatus] = useState('');
  const [tradeByVacancy, setTradeByVacancy] = useState({});

  useEffect(() => {
    if (!employerId) return;
    listVacancies({ employerID: employerId, size: 500 })
      .then((p) => {
        const map = {};
        (p.content || []).forEach((v) => { map[v.vacancyID] = v.tradeRequired; });
        setTradeByVacancy(map);
      })
      .catch(() => setTradeByVacancy({}));
  }, [employerId]);

  async function load() {
    if (!employerId) { setRows([]); setLoading(false); return; }
    setLoading(true);
    setError('');
    try {
      const data = await listPlacements({
        employerID: employerId,
        status: status || undefined,
        page,
        size: PAGE_SIZE,
        sort: 'placementDate,desc',
      });
      setRows(data.content || []);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
    } catch (err) {
      setError(apiErrorMessage(err, 'Could not load your trainee roster.'));
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [employerId, status, page]);

  const noEmployers = loaded && employers.length === 0;

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Trainee Roster</h1>
            <p className="page__subtitle">Apprentices placed with your company.</p>
          </div>
        </div>

        {noEmployers ? (
          <div className="empty-state"><p>No active employer records exist. Ask an administrator to register your company.</p></div>
        ) : (
          <>
            <EmployerCompanyBar employers={employers} employerId={employerId} setEmployerId={setEmployerId} companyName={companyName} />

            {employerId && (
              <div className="toolbar">
                <div className="toolbar__filter">
                  <label htmlFor="status-filter" className="field__label field__label--sm">Status</label>
                  <select id="status-filter" className="field__input" value={status} onChange={(e) => { setStatus(e.target.value); setPage(0); }}>
                    <option value="">All statuses</option>
                    {PLACEMENT_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>
            )}

            {!employerId ? (
              <div className="empty-state"><p>Select your company to view its roster.</p></div>
            ) : (
              <>
                <div className="table-wrap">
                  <table className="table">
                    <thead>
                      <tr>
                        <th scope="col">Trainee</th>
                        <th scope="col">Trade</th>
                        <th scope="col">Supervisor</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Placement Date</th>
                        <th scope="col">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {loading ? (
                        <tr><td colSpan={6} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
                      ) : error ? (
                        <tr><td colSpan={6} className="table__state table__state--error">{error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button></td></tr>
                      ) : rows.length === 0 ? (
                        <tr><td colSpan={6} className="table__state">No apprentices placed with your company yet.</td></tr>
                      ) : (
                        rows.map((p) => (
                          <tr key={p.placementID}>
                            <td data-label="Trainee">{p.traineeName || `Trainee #${p.traineeID}`}</td>
                            <td data-label="Trade">{tradeByVacancy[p.vacancyID] || '—'}</td>
                            <td data-label="Supervisor">{p.supervisorName}</td>
                            <td data-label="Phone">{p.supervisorPhone}</td>
                            <td data-label="Placement Date">{formatDate(p.placementDate)}</td>
                            <td data-label="Status"><StatusBadge status={p.status} tone={PLACEMENT_STATUS_TONE[p.status] || 'neutral'} /></td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                <div className="pagination">
                  <span className="pagination__info">{pageInfo.totalElements > 0 ? `${pageInfo.totalElements} total` : ' '}</span>
                  <div className="pagination__controls">
                    <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={loading || page === 0}>← Previous</button>
                    <span className="pagination__page">Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}</span>
                    <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => p + 1)} disabled={loading || page + 1 >= pageInfo.totalPages}>Next →</button>
                  </div>
                </div>
              </>
            )}
          </>
        )}
      </main>
    </div>
  );
}
