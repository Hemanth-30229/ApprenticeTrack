import { useEffect, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import CapacityBar from '../../training/components/batches/CapacityBar';
import VacancyFormModal from '../components/vacancies/VacancyFormModal';
import { useToast } from '../../../shared/toast/ToastContext';
import { useEmployer } from '../hooks/useEmployer';
import { createVacancy, listVacancies, updateVacancy } from '../api/vacancies';
import { apiErrorMessage } from '../../../shared/api/errors';
import { VACANCY_STATUS_LABEL, VACANCY_STATUS_TONE } from '../constants/vacancy';
import { formatCurrency, formatDate } from '../../../shared/format';

const PAGE_SIZE = 10;

export default function EmployerVacancyPage() {
  const toast = useToast();

  const { employers, employerId, setEmployerId, companyName, loaded: employersLoaded } = useEmployer();

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  async function load() {
    if (!employerId) {
      setRows([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError('');
    try {
      const data = await listVacancies({ employerID: employerId, page, size: PAGE_SIZE, sort: 'postedDate,desc' });
      setRows(data.content || []);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
    } catch (err) {
      setError(apiErrorMessage(err, 'Could not load your vacancies.'));
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [employerId, page]);

  async function handleSubmit(payload) {
    try {
      if (editing) {
        await updateVacancy(editing.vacancyID, payload);
        toast.success('Vacancy updated.');
      } else {
        await createVacancy({ employerID: Number(employerId), ...payload });
        toast.success('Vacancy posted.');
      }
      setFormOpen(false);
      setEditing(null);
      if (!editing && page !== 0) setPage(0);
      else load();
    } catch (err) {
      toast.error(apiErrorMessage(err, editing ? 'Failed to update vacancy.' : 'Failed to post vacancy.'));
    }
  }

  const noEmployers = employersLoaded && employers.length === 0;
  const canPost = Boolean(employerId);

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">My Vacancies</h1>
            <p className="page__subtitle">Post apprenticeship vacancies and track how they fill.</p>
          </div>
          <button
            type="button"
            className="btn btn--primary"
            onClick={() => { setEditing(null); setFormOpen(true); }}
            disabled={!canPost}
          >
            + Post Vacancy
          </button>
        </div>

        {noEmployers ? (
          <div className="empty-state">
            <p>No active employer records exist.</p>
            <p className="empty-state__hint">Ask an administrator to register your company (Employers) before posting vacancies.</p>
          </div>
        ) : (
          <>
            <div className="toolbar">
              <div className="toolbar__filter">
                <label htmlFor="company" className="field__label field__label--sm">Company</label>
                <select id="company" className="field__input" value={employerId} onChange={(e) => { setEmployerId(e.target.value); setPage(0); }}>
                  <option value="">Select your company…</option>
                  {employers.map((e) => (
                    <option key={e.employerID} value={e.employerID}>{e.companyName}</option>
                  ))}
                </select>
              </div>
            </div>

            {!employerId ? (
              <div className="empty-state"><p>Select your company above to view and post vacancies.</p></div>
            ) : (
              <>
                {companyName && <p className="page__note">Posting as <strong>{companyName}</strong>.</p>}
                <div className="table-wrap">
                  <table className="table">
                    <thead>
                      <tr>
                        <th scope="col">Trade</th>
                        <th scope="col">Fill</th>
                        <th scope="col">Stipend</th>
                        <th scope="col">Posted</th>
                        <th scope="col">Status</th>
                        <th scope="col" className="table__actions-col">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {loading ? (
                        <tr><td colSpan={6} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
                      ) : error ? (
                        <tr><td colSpan={6} className="table__state table__state--error">{error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button></td></tr>
                      ) : rows.length === 0 ? (
                        <tr><td colSpan={6} className="table__state">No vacancies yet. Post your first one.</td></tr>
                      ) : (
                        rows.map((v) => (
                          <tr key={v.vacancyID}>
                            <td data-label="Trade">{v.tradeRequired}</td>
                            <td data-label="Fill"><CapacityBar enrolled={v.filledCount} capacity={v.vacancyCount} /></td>
                            <td data-label="Stipend">{formatCurrency(v.stipendOffered)}</td>
                            <td data-label="Posted">{formatDate(v.postedDate)}</td>
                            <td data-label="Status"><StatusBadge status={VACANCY_STATUS_LABEL[v.status] || v.status} tone={VACANCY_STATUS_TONE[v.status] || 'neutral'} /></td>
                            <td data-label="Actions" className="table__actions">
                              <button type="button" className="btn btn--secondary btn--sm" onClick={() => { setEditing(v); setFormOpen(true); }}>Edit</button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                <div className="pagination">
                  <span className="pagination__info">{pageInfo.totalElements > 0 ? `${pageInfo.totalElements} total` : ' '}</span>
                  <div className="pagination__controls">
                    <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={loading || page === 0}>← Previous</button>
                    <span className="pagination__page">Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}</span>
                    <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => p + 1)} disabled={loading || page + 1 >= pageInfo.totalPages}>Next →</button>
                  </div>
                </div>
              </>
            )}
          </>
        )}
      </main>

      {formOpen && (
        <VacancyFormModal
          vacancy={editing}
          onClose={() => { setFormOpen(false); setEditing(null); }}
          onSubmit={handleSubmit}
        />
      )}
    </div>
  );
}
