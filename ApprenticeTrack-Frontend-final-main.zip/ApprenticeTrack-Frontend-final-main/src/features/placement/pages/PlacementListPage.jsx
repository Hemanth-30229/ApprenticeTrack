import { useEffect, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import ConfirmDialog from '../../../shared/ui/ConfirmDialog';
import PlacementFormModal from '../components/placements/PlacementFormModal';
import PlacementDetailModal from '../components/placements/PlacementDetailModal';
import TerminatePlacementModal from '../components/placements/TerminatePlacementModal';
import { useToast } from '../../../shared/toast/ToastContext';
import { createPlacement, listPlacements, updatePlacementStatus } from '../api/placements';
import { listVacancies } from '../api/vacancies';
import { listEmployers } from '../api/employers';
import {
  PLACEMENT_STATUSES,
  PLACEMENT_STATUS_TONE,
  PLACEMENT_STATUS_TRANSITIONS,
} from '../constants/placement';
import { formatDate } from '../../../shared/format';

export default function PlacementListPage() {
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [vacancies, setVacancies] = useState([]);
  const [employers, setEmployers] = useState([]);

  const [employerFilter, setEmployerFilter] = useState('');
  const [tradeFilter, setTradeFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const [formOpen, setFormOpen] = useState(false);
  const [detail, setDetail] = useState(null);
  const [completing, setCompleting] = useState(null);
  const [terminating, setTerminating] = useState(null);
  const [busy, setBusy] = useState(false);

  async function loadReference() {
    try {
      const [vacPage, empPage] = await Promise.all([
        listVacancies({ page: 0, size: 500 }),
        listEmployers({ page: 0, size: 500 }),
      ]);
      setVacancies(vacPage.content || []);
      setEmployers(empPage.content || []);
    } catch {
    }
  }

  useEffect(() => {
    loadReference();
  }, []);

  const vacancyById = {};
  vacancies.forEach((v) => { vacancyById[v.vacancyID] = v; });
  const trades = Array.from(new Set(vacancies.map((v) => v.tradeRequired).filter(Boolean)))
    .sort((a, b) => a.localeCompare(b));

  const formVacancies = vacancies.filter((v) => v.status !== 'Expired');

  async function load() {
    setLoading(true);
    setError('');
    try {
      const data = await listPlacements({
        employerID: employerFilter || undefined,
        status: statusFilter || undefined,
        size: 500,
        sort: 'placementDate,desc',
      });
      let content = data.content || [];
      if (tradeFilter) {
        content = content.filter((p) => vacancyById[p.vacancyID]?.tradeRequired === tradeFilter);
      }
      setRows(content);
    } catch {
      setError('Could not load placements. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [employerFilter, statusFilter, tradeFilter, vacancies]);

  async function handleCreate(payload) {
    try {
      await createPlacement(payload);
      toast.success('Placement created successfully.');
      setFormOpen(false);
      loadReference(); // refresh vacancy fill counts
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to create placement.');
      throw err;
    }
  }

  async function doStatus(placement, status, successMsg) {
    setBusy(true);
    try {
      await updatePlacementStatus(placement.placementID, status);
      toast.success(successMsg);
      setCompleting(null);
      setTerminating(null);
      loadReference();
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to update placement status.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Placements</h1>
            <p className="page__subtitle">Match trainees to employer vacancies and track placements.</p>
          </div>
          <button type="button" className="btn btn--primary" onClick={() => setFormOpen(true)}>
            + New Placement
          </button>
        </div>

        <div className="toolbar">
          <div className="toolbar__filter">
            <label htmlFor="employer-filter" className="field__label field__label--sm">Employer</label>
            <select
              id="employer-filter"
              className="field__input"
              value={employerFilter}
              onChange={(e) => setEmployerFilter(e.target.value)}
            >
              <option value="">All employers</option>
              {employers.map((emp) => (
                <option key={emp.employerID} value={emp.employerID}>{emp.companyName}</option>
              ))}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="trade-filter" className="field__label field__label--sm">Trade</label>
            <select
              id="trade-filter"
              className="field__input"
              value={tradeFilter}
              onChange={(e) => setTradeFilter(e.target.value)}
            >
              <option value="">All trades</option>
              {trades.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="field__label field__label--sm">Status</label>
            <select
              id="status-filter"
              className="field__input"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="">All statuses</option>
              {PLACEMENT_STATUSES.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Trainee Name</th>
                <th scope="col">Employer Name</th>
                <th scope="col">Trade</th>
                <th scope="col">Placement Date</th>
                <th scope="col">Supervisor</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
              ) : error ? (
                <tr>
                  <td colSpan={7} className="table__state table__state--error">
                    {error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button>
                  </td>
                </tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan={7} className="table__state">No placements found.</td></tr>
              ) : (
                rows.map((p) => (
                  <tr key={p.placementID}>
                    <td data-label="Trainee Name">
                      <button type="button" className="link-button" onClick={() => setDetail(p)}>
                        {p.traineeName || `Trainee #${p.traineeID}`}
                      </button>
                    </td>
                    <td data-label="Employer Name">{p.employerName || `Employer #${p.employerID}`}</td>
                    <td data-label="Trade">{vacancyById[p.vacancyID]?.tradeRequired || '—'}</td>
                    <td data-label="Placement Date">{formatDate(p.placementDate)}</td>
                    <td data-label="Supervisor">{p.supervisorName}</td>
                    <td data-label="Status">
                      <StatusBadge status={p.status} tone={PLACEMENT_STATUS_TONE[p.status] || 'neutral'} />
                    </td>
                    <td data-label="Actions" className="table__actions">
                     
                      {(PLACEMENT_STATUS_TRANSITIONS[p.status] || []).map((tr) =>
                        tr.to === 'Completed' ? (
                          <button key={tr.to} type="button" className="btn btn--secondary btn--sm" onClick={() => setCompleting(p)}>
                            {tr.label}
                          </button>
                        ) : (
                          <button key={tr.to} type="button" className="btn btn--danger-ghost btn--sm" onClick={() => setTerminating(p)}>
                            {tr.label}
                          </button>
                        )
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </main>

      {formOpen && (
        <PlacementFormModal
          vacancies={formVacancies}
          onClose={() => setFormOpen(false)}
          onSubmit={handleCreate}
        />
      )}

      {detail && <PlacementDetailModal placement={detail} onClose={() => setDetail(null)} />}

      {completing && (
        <ConfirmDialog
          title="Complete placement?"
          message={`Mark the placement for "${completing.traineeName || `Trainee #${completing.traineeID}`}" as Completed?`}
          confirmLabel="Complete Placement"
          tone="primary"
          busy={busy}
          onConfirm={() => doStatus(completing, 'Completed', 'Placement marked as completed.')}
          onCancel={() => (busy ? null : setCompleting(null))}
        />
      )}

      {terminating && (
        <TerminatePlacementModal
          placement={terminating}
          onClose={() => (busy ? null : setTerminating(null))}
          onConfirm={() => doStatus(terminating, 'Terminated', 'Placement terminated.')}
        />
      )}
    </div>
  );
}
