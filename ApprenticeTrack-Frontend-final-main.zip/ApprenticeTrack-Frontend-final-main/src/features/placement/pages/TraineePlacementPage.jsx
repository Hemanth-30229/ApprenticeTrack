import { useCallback, useEffect, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import { useAuth } from '../../../shared/auth/AuthContext';
import { getTraineeByUser } from '../../training/api/trainees';
import { listPlacements } from '../api/placements';
import { getEmployer } from '../api/employers';
import { getVacancy } from '../api/vacancies';
import { PLACEMENT_STATUS_TONE } from '../constants/placement';
import { formatCurrency, formatDate } from '../../../shared/format';

export default function TraineePlacementPage() {
  const { user } = useAuth();

  const [boot, setBoot] = useState({ loading: true, error: '', traineeID: null });
  const [rows, setRows] = useState([]);
  const [details, setDetails] = useState({ employer: null, vacancy: null });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const trainee = await getTraineeByUser(user.userID);
        if (alive) setBoot({ loading: false, error: '', traineeID: trainee.traineeID });
      } catch (err) {
        if (alive)
          setBoot({
            loading: false,
            error:
              err?.response?.status === 404
                ? 'No trainee profile is linked to your account yet.'
                : 'Could not load your profile.',
            traineeID: null,
          });
      }
    })();
    return () => {
      alive = false;
    };
  }, [user.userID]);

  const load = useCallback(async () => {
    if (!boot.traineeID) return;
    setLoading(true);
    setError('');
    try {
      const page = await listPlacements({
        traineeID: boot.traineeID,
        page: 0,
        size: 50,
        sort: 'placementDate,desc',
      });
      const list = page.content || [];
      setRows(list);

      const current = list[0];
      if (current) {
        const [employer, vacancy] = await Promise.all([
          getEmployer(current.employerID).catch(() => null),
          getVacancy(current.vacancyID).catch(() => null),
        ]);
        setDetails({ employer, vacancy });
      } else {
        setDetails({ employer: null, vacancy: null });
      }
    } catch {
      setError('Could not load your placement details. Please try again.');
      setRows([]);
      setDetails({ employer: null, vacancy: null });
    } finally {
      setLoading(false);
    }
  }, [boot.traineeID]);

  useEffect(() => {
    load();
  }, [load]);

  const current = rows[0] || null;
  const { employer, vacancy } = details;
  const past = rows.slice(1);

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">My Placement</h1>
            <p className="page__subtitle">
              The company you have been matched with for your on-the-job training.
            </p>
          </div>
          {current && (
            <div className="entry-actions">
              <StatusBadge
                status={current.status}
                tone={PLACEMENT_STATUS_TONE[current.status] || 'neutral'}
              />
            </div>
          )}
        </div>

        {boot.loading || loading ? (
          <div className="table__state">
            <Spinner size={24} label="Loading" /> Loading…
          </div>
        ) : boot.error ? (
          <div className="empty-state">
            <p>{boot.error}</p>
          </div>
        ) : error ? (
          <div className="empty-state">
            <p>{error}</p>
            <button type="button" className="btn btn--secondary btn--sm" onClick={load}>
              Retry
            </button>
          </div>
        ) : !current ? (
          <div className="empty-state">
            <p>
              You have not been placed with a company yet. Once the placement officer matches
              you with a vacancy, the company details will appear here.
            </p>
          </div>
        ) : (
          <>
            <div className="detail-columns">
              <section>
                <h3 className="detail-section-title">Company</h3>
                <dl className="detail-grid detail-grid--single">
                  <Row label="Company" value={current.employerName || employer?.companyName} />
                  <Row label="Sector" value={employer?.industrySector} />
                  <Row label="Address" value={employer?.address} />
                  <Row label="Contact person" value={employer?.contactPerson} />
                </dl>
              </section>

              <section>
                <h3 className="detail-section-title">Apprenticeship</h3>
                <dl className="detail-grid detail-grid--single">
                  <Row label="Trade" value={vacancy?.tradeRequired} />
                  <Row
                    label="Stipend offered"
                    value={
                      vacancy?.stipendOffered == null
                        ? null
                        : formatCurrency(vacancy.stipendOffered)
                    }
                  />
                  <Row label="Placed on" value={formatDate(current.placementDate)} />
                  <Row label="Status" value={current.status} />
                </dl>
              </section>

              <section>
                <h3 className="detail-section-title">Supervisor</h3>
                <dl className="detail-grid detail-grid--single">
                  <Row label="Name" value={current.supervisorName} />
                  <Row label="Phone" value={current.supervisorPhone} />
                </dl>
              </section>
            </div>

            <h3 className="detail-section-title">Timeline</h3>
            <ol className="timeline">
              <li className="timeline__item">
                <span className="timeline__dot" />
                <div>
                  <span className="timeline__title">
                    Matched with {current.employerName || employer?.companyName || 'employer'}
                  </span>
                  <span className="timeline__meta">{formatDate(current.placementDate)}</span>
                </div>
              </li>
              <li className="timeline__item">
                <span
                  className={`timeline__dot timeline__dot--${
                    PLACEMENT_STATUS_TONE[current.status] || 'neutral'
                  }`}
                />
                <div>
                  <span className="timeline__title">
                    Current status{' '}
                    <StatusBadge
                      status={current.status}
                      tone={PLACEMENT_STATUS_TONE[current.status] || 'neutral'}
                    />
                  </span>
                  <span className="timeline__meta">
                    {current.status === 'Active' ? 'Ongoing' : current.status}
                  </span>
                </div>
              </li>
            </ol>

            {past.length > 0 && (
              <>
                <h3 className="detail-section-title">Previous placements</h3>
                <div className="table-wrap">
                  <table className="table">
                    <thead>
                      <tr>
                        <th scope="col">Company</th>
                        <th scope="col">Supervisor</th>
                        <th scope="col">Placed on</th>
                        <th scope="col">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {past.map((p) => (
                        <tr key={p.placementID}>
                          <td data-label="Company">{p.employerName || '—'}</td>
                          <td data-label="Supervisor">{p.supervisorName || '—'}</td>
                          <td data-label="Placed on">{formatDate(p.placementDate)}</td>
                          <td data-label="Status">
                            <StatusBadge
                              status={p.status}
                              tone={PLACEMENT_STATUS_TONE[p.status] || 'neutral'}
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}

            <p className="page__note">
              Placement details are managed by the placement officer. Contact them if anything
              here looks incorrect.
            </p>
          </>
        )}
      </main>
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="detail-grid__row">
      <dt className="detail-grid__label">{label}</dt>
      <dd className="detail-grid__value">{value ?? '—'}</dd>
    </div>
  );
}
