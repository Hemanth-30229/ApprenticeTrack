import { useEffect, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import CapacityBar from '../../training/components/batches/CapacityBar';
import PlacementFormModal from '../components/placements/PlacementFormModal';
import { useToast } from '../../../shared/toast/ToastContext';
import { listVacancies } from '../api/vacancies';
import { createPlacement } from '../api/placements';
import { VACANCY_STATUS_LABEL, VACANCY_STATUS_TONE } from '../constants/vacancy';
import { formatCurrency, formatDate } from '../../../shared/format';

export default function VacancyBoardPage() {
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [matchVacancy, setMatchVacancy] = useState(null);

  async function load() {
    setLoading(true);
    setError('');
    try {
      const data = await listVacancies({ size: 500, sort: 'postedDate,desc' });
      setRows(data.content || []);
    } catch {
      setError('Could not load vacancies. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleMatch(payload) {
    try {
      await createPlacement(payload);
      toast.success('Trainee matched to vacancy.');
      setMatchVacancy(null);
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to create placement.');
      throw err;
    }
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Vacancy Board</h1>
            <p className="page__subtitle">Browse apprenticeship vacancies and match trainees.</p>
          </div>
        </div>

        {loading ? (
          <div className="table__state"><Spinner size={24} label="Loading" /> Loading vacancies…</div>
        ) : error ? (
          <div className="empty-state"><p>{error}</p><button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button></div>
        ) : rows.length === 0 ? (
          <div className="empty-state"><p>No vacancies found.</p></div>
        ) : (
          <div className="vacancy-board">
            {rows.map((v) => {
              const matchable = v.status === 'Open' || v.status === 'PartiallyFilled';
              return (
                <article key={v.vacancyID} className="vacancy-card">
                  <header className="vacancy-card__head">
                    <div>
                      <h2 className="vacancy-card__trade">{v.tradeRequired}</h2>
                      <p className="vacancy-card__employer">{v.companyName || `Employer #${v.employerID}`}</p>
                    </div>
                    <StatusBadge status={VACANCY_STATUS_LABEL[v.status] || v.status} tone={VACANCY_STATUS_TONE[v.status] || 'neutral'} />
                  </header>

                  <div className="vacancy-card__fill">
                    <CapacityBar enrolled={v.filledCount} capacity={v.vacancyCount} />
                  </div>

                  <dl className="vacancy-card__meta">
                    <div><dt>Stipend</dt><dd>{formatCurrency(v.stipendOffered)}</dd></div>
                    <div><dt>Posted</dt><dd>{formatDate(v.postedDate)}</dd></div>
                  </dl>

                  <button
                    type="button"
                    className="btn btn--primary btn--sm vacancy-card__match"
                    onClick={() => setMatchVacancy(v)}
                    disabled={!matchable}
                    title={matchable ? 'Match a trainee to this vacancy' : 'This vacancy has no open slots'}
                  >
                    Match Trainee
                  </button>
                </article>
              );
            })}
          </div>
        )}
      </main>

      {matchVacancy && (
        <PlacementFormModal
          vacancies={rows}
          initialVacancyId={matchVacancy.vacancyID}
          onClose={() => setMatchVacancy(null)}
          onSubmit={handleMatch}
        />
      )}
    </div>
  );
}
