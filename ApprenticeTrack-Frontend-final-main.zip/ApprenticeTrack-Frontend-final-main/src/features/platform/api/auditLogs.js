// Audit Log API via the gateway. Admin-only (Admin / VocationalAdmin).

import api from '../../../shared/api/client';

export function listAuditLogs({
  userId,
  module,
  action,
  startDate,
  endDate,
  page = 0,
  size = 25,
  sort = 'timestamp,desc',
} = {}) {
  const params = { page, size, sort };
  if (userId) params.userId = userId;
  if (module) params.module = module;
  if (action) params.action = action;
  if (startDate) params.startDate = startDate;
  if (endDate) params.endDate = endDate;
  return api.get('/api/audit-logs', { params }).then((r) => r.data);
}
