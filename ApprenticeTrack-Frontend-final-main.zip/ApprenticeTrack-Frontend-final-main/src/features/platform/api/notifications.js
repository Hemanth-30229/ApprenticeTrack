// Notification API (AP-25) via the gateway. Scoped to the authenticated user.

import api from '../../../shared/api/client';

export function listNotifications({
  category,
  status,
  fromDate,
  toDate,
  page = 0,
  size = 10,
  sort = 'createdDate,desc',
} = {}) {
  const params = { page, size, sort };
  if (category) params.category = category;
  if (status) params.status = status;
  if (fromDate) params.fromDate = fromDate;
  if (toDate) params.toDate = toDate;
  return api.get('/api/notifications', { params }).then((r) => r.data);
}

export function getUnreadCount() {
  return api.get('/api/notifications/unread-count').then((r) => r.data.unreadCount ?? 0);
}

export function markNotificationRead(id) {
  return api.put(`/api/notifications/${id}/read`).then((r) => r.data);
}

export function dismissNotification(id) {
  return api.put(`/api/notifications/${id}/dismiss`).then((r) => r.data);
}

/** PUT /mark-all-read -> { markedRead: number } */
export function markAllNotificationsRead() {
  return api.put('/api/notifications/mark-all-read').then((r) => r.data.markedRead ?? 0);
}
