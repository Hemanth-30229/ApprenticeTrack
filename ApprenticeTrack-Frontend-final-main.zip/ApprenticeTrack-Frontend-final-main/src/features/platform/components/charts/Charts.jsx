// Lightweight, dependency-free SVG chart primitives for dashboard widgets.
// All are accessible (role="img" + aria-label) and inherit color via CSS vars.

const PALETTE = [
  'var(--chart-1)',
  'var(--chart-2)',
  'var(--chart-3)',
  'var(--chart-4)',
  'var(--chart-5)',
];

/** Horizontal progress bar. value/max -> filled fraction. */
export function ProgressBar({ value = 0, max = 100, label }) {
  const pct = max > 0 ? Math.min(100, Math.max(0, (value / max) * 100)) : 0;
  return (
    <div
      className="chart-progress"
      role="img"
      aria-label={label || `${Math.round(pct)} percent`}
    >
      <div className="chart-progress__track">
        <div className="chart-progress__fill" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

/** Semicircular gauge for a 0-100 percentage. */
export function Gauge({ value = 0, label }) {
  const pct = Math.min(100, Math.max(0, value));
  const r = 52;
  const cx = 60;
  const cy = 60;
  const circumference = Math.PI * r; // half circle
  const dash = (pct / 100) * circumference;
  return (
    <svg
      className="chart-gauge"
      viewBox="0 0 120 70"
      role="img"
      aria-label={label || `${Math.round(pct)} percent`}
    >
      <path
        d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
        className="chart-gauge__track"
        fill="none"
      />
      <path
        d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
        className="chart-gauge__value"
        fill="none"
        strokeDasharray={`${dash} ${circumference}`}
      />
      <text x={cx} y={cy - 6} className="chart-gauge__label">
        {Math.round(pct)}%
      </text>
    </svg>
  );
}

/** Donut / pie chart from [{label, value, color?}]. */
export function Donut({ data = [], label }) {
  const total = data.reduce((sum, d) => sum + (Number(d.value) || 0), 0);
  const r = 45;
  const cx = 60;
  const cy = 60;
  const circumference = 2 * Math.PI * r;
  let offset = 0;

  return (
    <svg
      className="chart-donut"
      viewBox="0 0 120 120"
      role="img"
      aria-label={label || 'Distribution chart'}
    >
      <circle cx={cx} cy={cy} r={r} className="chart-donut__track" fill="none" />
      {total > 0 &&
        data.map((d, i) => {
          const fraction = (Number(d.value) || 0) / total;
          const len = fraction * circumference;
          const seg = (
            <circle
              key={d.label}
              cx={cx}
              cy={cy}
              r={r}
              fill="none"
              stroke={d.color || PALETTE[i % PALETTE.length]}
              strokeWidth="14"
              strokeDasharray={`${len} ${circumference - len}`}
              strokeDashoffset={-offset}
              transform={`rotate(-90 ${cx} ${cy})`}
            />
          );
          offset += len;
          return seg;
        })}
    </svg>
  );
}

/** Vertical bar chart from [{label, value, color?}]. */
export function Bars({ data = [], label }) {
  const max = Math.max(1, ...data.map((d) => Number(d.value) || 0));
  return (
    <div className="chart-bars" role="img" aria-label={label || 'Bar chart'}>
      {data.map((d, i) => {
        const h = ((Number(d.value) || 0) / max) * 100;
        return (
          <div className="chart-bars__col" key={d.label}>
            <div className="chart-bars__bar-wrap">
              <span className="chart-bars__value">{d.value}</span>
              <div
                className="chart-bars__bar"
                style={{
                  height: `${h}%`,
                  background: d.color || PALETTE[i % PALETTE.length],
                }}
              />
            </div>
            <span className="chart-bars__label">{d.label}</span>
          </div>
        );
      })}
    </div>
  );
}

/** Simple line / sparkline from an array of numbers. */
export function Sparkline({ points = [], label }) {
  if (points.length < 2) {
    return (
      <div className="chart-empty" role="img" aria-label={label || 'No trend data'}>
        Not enough data to plot a trend yet.
      </div>
    );
  }
  const w = 240;
  const h = 72;
  const max = Math.max(...points);
  const min = Math.min(...points);
  const range = max - min || 1;
  const step = w / (points.length - 1);
  const coords = points.map((p, i) => {
    const x = i * step;
    const y = h - ((p - min) / range) * (h - 8) - 4;
    return [x, y];
  });
  const path = coords
    .map(([x, y], i) => `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`)
    .join(' ');
  const area = `${path} L ${w} ${h} L 0 ${h} Z`;
  return (
    <svg
      className="chart-line"
      viewBox={`0 0 ${w} ${h}`}
      preserveAspectRatio="none"
      role="img"
      aria-label={label || 'Trend line'}
    >
      <path d={area} className="chart-line__area" />
      <path d={path} className="chart-line__stroke" fill="none" />
    </svg>
  );
}
