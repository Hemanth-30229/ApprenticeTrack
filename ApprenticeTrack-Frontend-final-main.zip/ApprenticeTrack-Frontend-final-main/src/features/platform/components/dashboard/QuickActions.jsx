// Role-specific quick action buttons. Targets are Phase-1 placeholders; each
// invokes `onAction` (the dashboard shows a "coming soon" note) until the
// corresponding feature screens are built in later acceptance criteria.

import { Link } from 'react-router-dom';
import { ROLES } from '../../../../shared/auth/roles';

const ACTIONS = {
  [ROLES.TRAINEE]: [
    { key: 'submit-ojt', label: 'Submit OJT Log', to: '/trainee/ojt-logs' },
    { key: 'view-certificates', label: 'View Certificates', to: '/trainee/certificates' },
    { key: 'view-placement', label: 'My Placement', to: '/trainee/placement' },
  ],
  [ROLES.EMPLOYER]: [
    { key: 'review-logs', label: 'Review Pending Logs', to: '/employer/ojt-logs' },
    { key: 'post-vacancy', label: 'Post Vacancy', to: '/employer/vacancies' },
  ],
  [ROLES.ASSESSOR]: [
    { key: 'enter-results', label: 'Enter Results', to: '/assessor/tests' },
    { key: 'view-schedule', label: 'View Schedule', to: '/assessor/tests' },
  ],
  [ROLES.PLACEMENT_OFFICER]: [
    { key: 'match-trainee', label: 'Match Trainee', to: '/placements' },
    { key: 'post-vacancy', label: 'Post Vacancy' },
  ],
  [ROLES.STIPEND_ADMIN]: [
    { key: 'review-approvals', label: 'Review Approvals', to: '/attendance' },
    { key: 'run-disbursement', label: 'Run Disbursement', to: '/stipends' },
  ],
  [ROLES.ADMIN]: [
    { key: 'add-user', label: 'Add User', to: '/users' },
    { key: 'view-audit', label: 'View Audit Logs', to: '/audit-logs' },
  ],
};

export default function QuickActions({ role, onAction }) {
  const actions = ACTIONS[role] || [];
  if (actions.length === 0) return null;
  return (
    <div className="quick-actions" role="group" aria-label="Quick actions">
      {actions.map((a) =>
        a.to ? (
          <Link key={a.key} to={a.to} className="btn btn--primary btn--sm">
            {a.label}
          </Link>
        ) : (
          <button
            key={a.key}
            type="button"
            className="btn btn--primary btn--sm"
            onClick={() => onAction(a.label)}
          >
            {a.label}
          </button>
        )
      )}
    </div>
  );
}
