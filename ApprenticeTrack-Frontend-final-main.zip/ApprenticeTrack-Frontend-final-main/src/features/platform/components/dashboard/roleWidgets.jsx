// Builds the widget grid for each role from AP-10 metrics + supplementary lists.
// Metric names here are the EXACT strings the platform-service dashboard emits.

import { Bars, Donut, Gauge, ProgressBar, Sparkline } from '../charts/Charts';
import {
  BadgeCard,
  Card,
  ChartCard,
  ListCard,
  ProgressCard,
  StatCard,
} from './widgets';
import {
  formatCurrency,
  formatDate,
  formatNumber,
  formatPercent,
  getMetric,
  getValue,
} from '../../../../shared/format';
import { ROLES } from '../../../../shared/auth/roles';

// Rough course-progress % from enrollment status (no explicit % in the API).
const ENROLLMENT_PCT = {
  Enrolled: 20,
  OJTInProgress: 55,
  AssessmentPending: 80,
  Completed: 100,
  Withdrawn: 0,
};

const CERT_TONE = {
  Issued: 'success',
  Revoked: 'danger',
  NotAvailable: 'neutral',
};

function trendOf(metrics, name) {
  return getMetric(metrics, name)?.trend;
}

export function buildWidgets({ role, metrics, extras, extrasLoading }) {
  switch (role) {
    case ROLES.TRAINEE:
      return traineeWidgets(metrics);
    case ROLES.EMPLOYER:
      return employerWidgets(metrics, extras, extrasLoading);
    case ROLES.ASSESSOR:
      return assessorWidgets(metrics, extras, extrasLoading);
    case ROLES.PLACEMENT_OFFICER:
      return placementOfficerWidgets(metrics, extras, extrasLoading);
    case ROLES.STIPEND_ADMIN:
      return stipendAdminWidgets(metrics);
    case ROLES.ADMIN:
      return adminWidgets(metrics, extras, extrasLoading);
    default:
      return [];
  }
}

function traineeWidgets(metrics) {
  const enrollment = getValue(metrics, 'activeEnrollment', {}) || {};
  const status = enrollment.status || 'None';
  const coursePct = ENROLLMENT_PCT[status] ?? 0;
  const stipend = getValue(metrics, 'stipendHistory', {}) || {};
  const certStatus = getValue(metrics, 'certificateStatus', 'NotAvailable');

  return [
    <ProgressCard
      key="course"
      title="Course Progress"
      trend={trendOf(metrics, 'activeEnrollment')}
      chart={<ProgressBar value={coursePct} max={100} label={`${coursePct}% complete`} />}
      caption={status === 'None' ? 'No active enrollment' : `Status: ${status}`}
    />,
    <StatCard
      key="ojt"
      title="OJT Log Status"
      trend={trendOf(metrics, 'pendingOjtLogs')}
      value={formatNumber(getValue(metrics, 'pendingOjtLogs', 0))}
      caption="Logs awaiting supervisor confirmation"
    />,
    <StatCard
      key="stipend"
      title="Stipend History"
      trend={trendOf(metrics, 'stipendHistory')}
      value={formatCurrency(stipend.totalDisbursed ?? 0)}
      caption={`${formatNumber(stipend.disbursementCount ?? 0)} disbursements · monthly chart soon`}
    />,
    <BadgeCard
      key="cert"
      title="Certificate Status"
      status={certStatus}
      tone={CERT_TONE[certStatus] || 'neutral'}
      caption="Trade certification"
    />,
  ];
}

function employerWidgets(metrics, extras, extrasLoading) {
  const vac = getValue(metrics, 'vacancySummary', { open: 0, filled: 0 }) || {};
  return [
    <StatCard
      key="apprentices"
      title="Active Apprentices"
      trend={trendOf(metrics, 'activeApprentices')}
      value={formatNumber(getValue(metrics, 'activeApprentices', 0))}
    />,
    <StatCard
      key="pending"
      title="Pending OJT Confirmations"
      trend={trendOf(metrics, 'pendingOjtLogConfirmations')}
      value={formatNumber(getValue(metrics, 'pendingOjtLogConfirmations', 0))}
    />,
    <ChartCard
      key="vacancy"
      title="Vacancy Summary"
      trend={trendOf(metrics, 'vacancySummary')}
      chart={
        <Bars
          label="Open versus filled vacancies"
          data={[
            { label: 'Open', value: Number(vac.open) || 0, color: 'var(--chart-1)' },
            { label: 'Filled', value: Number(vac.filled) || 0, color: 'var(--chart-2)' },
          ]}
        />
      }
    />,
    <ListCard
      key="placements"
      title="Recent Placements"
      size="md"
      loading={extrasLoading}
      items={extras.recentPlacements}
      empty="No placements yet."
      renderItem={(p) => (
        <li key={p.placementID} className="feed-item">
          <span className="feed-item__main">{p.traineeName || `Trainee #${p.traineeID}`}</span>
          <span className="feed-item__meta">
            {p.employerName ? `${p.employerName} · ` : ''}
            {formatDate(p.placementDate)}
          </span>
        </li>
      )}
    />,
  ];
}

function assessorWidgets(metrics, extras, extrasLoading) {
  return [
    <ListCard
      key="upcoming"
      title="Upcoming Tests (next 7 days)"
      size="md"
      loading={extrasLoading}
      items={extras.upcomingTests}
      empty="No tests scheduled in the next 7 days."
      renderItem={(t) => (
        <li key={t.testID} className="feed-item">
          <span className="feed-item__main">
            {t.courseName || `Course #${t.courseID}`}
            {t.batchCode ? ` · ${t.batchCode}` : ''}
          </span>
          <span className="feed-item__meta">{formatDate(t.testDate)}</span>
        </li>
      )}
    />,
    <StatCard
      key="pending"
      title="Pending Results"
      trend={trendOf(metrics, 'pendingResultEntries')}
      value={formatNumber(getValue(metrics, 'pendingResultEntries', 0))}
      action={{ label: 'Enter Results', to: '/assessor/tests' }}
    />,
    <StatCard
      key="completed"
      title="Completed Assessments"
      trend={trendOf(metrics, 'completedAssessmentsThisMonth')}
      value={formatNumber(getValue(metrics, 'completedAssessmentsThisMonth', 0))}
      caption="this month"
    />,
  ];
}

function placementOfficerWidgets(metrics, extras, extrasLoading) {
  const rate = Number(getValue(metrics, 'placementRate', 0)) || 0;
  return [
    <ChartCard
      key="rate"
      title="Placement Rate"
      trend={trendOf(metrics, 'placementRate')}
      chart={<Gauge value={rate} label={`Placement rate ${formatPercent(rate)}`} />}
      caption={formatPercent(rate)}
    />,
    <StatCard
      key="unmatched"
      title="Unmatched Trainees"
      trend={trendOf(metrics, 'unmatchedTrainees')}
      value={formatNumber(getValue(metrics, 'unmatchedTrainees', 0))}
    />,
    <StatCard
      key="open"
      title="Open Vacancies"
      trend={trendOf(metrics, 'openVacancies')}
      value={formatNumber(getValue(metrics, 'openVacancies', 0))}
    />,
    <ListCard
      key="timeline"
      title="Recent Placements"
      size="md"
      loading={extrasLoading}
      items={extras.recentPlacements}
      empty="No recent placements."
      renderItem={(p) => (
        <li key={p.placementID} className="feed-item feed-item--timeline">
          <span className="feed-item__main">{p.traineeName || `Trainee #${p.traineeID}`}</span>
          <span className="feed-item__meta">
            {p.employerName ? `${p.employerName} · ` : ''}
            {formatDate(p.placementDate)}
          </span>
        </li>
      )}
    />,
  ];
}

function stipendAdminWidgets(metrics) {
  const compliance = Number(getValue(metrics, 'attendanceComplianceRate', 0)) || 0;
  return [
    <StatCard
      key="approvals"
      title="Pending Approvals"
      trend={trendOf(metrics, 'pendingStipendApprovals')}
      value={formatNumber(getValue(metrics, 'pendingStipendApprovals', 0))}
      action={{ label: 'Review', to: '/attendance' }}
    />,
    <StatCard
      key="disbursed"
      title="Monthly Disbursement"
      trend={trendOf(metrics, 'totalDisbursedThisMonth')}
      value={formatCurrency(getValue(metrics, 'totalDisbursedThisMonth', 0))}
      caption="this month"
    />,
    <StatCard
      key="withheld"
      title="Withheld"
      trend={trendOf(metrics, 'withheldCount')}
      value={formatNumber(getValue(metrics, 'withheldCount', 0))}
    />,
    <ChartCard
      key="compliance"
      title="Attendance Compliance"
      trend={trendOf(metrics, 'attendanceComplianceRate')}
      chart={
        <Donut
          label={`Attendance compliance ${formatPercent(compliance)}`}
          data={[
            { label: 'Compliant', value: compliance, color: 'var(--chart-2)' },
            { label: 'Non-compliant', value: Math.max(0, 100 - compliance), color: 'var(--chart-4)' },
          ]}
        />
      }
      legend={
        <>
          <li><span className="dot" style={{ background: 'var(--chart-2)' }} />Compliant {formatPercent(compliance)}</li>
          <li><span className="dot" style={{ background: 'var(--chart-4)' }} />Non-compliant {formatPercent(100 - compliance)}</li>
        </>
      }
    />,
  ];
}

function adminWidgets(metrics, extras, extrasLoading) {
  const placementRate = Number(getValue(metrics, 'overallPlacementRate', 0)) || 0;
  const vac = getValue(metrics, 'vacancySummary', { open: 0, filled: 0 }) || {};

  return [
    <Card key="overview" title="System Overview" size="md">
      <div className="widget__triple">
        <div>
          <p className="widget__stat widget__stat--md">{formatNumber(getValue(metrics, 'totalActiveTrainees', 0))}</p>
          <p className="widget__stat-label">Trainees</p>
        </div>
        <div>
          <p className="widget__stat widget__stat--md">{formatNumber(getValue(metrics, 'totalActiveEmployers', 0))}</p>
          <p className="widget__stat-label">Employers</p>
        </div>
        <div>
          <p className="widget__stat widget__stat--md">{formatNumber(getValue(metrics, 'totalActiveBatches', 0))}</p>
          <p className="widget__stat-label">Active Batches</p>
        </div>
      </div>
    </Card>,
    <ChartCard
      key="placement-trend"
      title="Placement Rate"
      trend={trendOf(metrics, 'overallPlacementRate')}
      chart={<Sparkline points={[]} label="Placement rate trend" />}
      caption={`Current: ${formatPercent(placementRate)} · trend needs time-series data`}
    />,
    <ChartCard
      key="vacancy"
      title="Vacancy Summary"
      trend={trendOf(metrics, 'vacancySummary')}
      chart={
        <Bars
          label="Open versus filled vacancies"
          data={[
            { label: 'Open', value: Number(vac.open) || 0, color: 'var(--chart-1)' },
            { label: 'Filled', value: Number(vac.filled) || 0, color: 'var(--chart-2)' },
          ]}
        />
      }
    />,
    <ListCard
      key="activity"
      title="Recent Activity"
      size="md"
      loading={extrasLoading}
      items={extras.recentActivity}
      empty="No recent activity."
      renderItem={(a) => (
        <li key={a.auditID} className="feed-item">
          <span className="feed-item__main">
            {a.action}
            {a.module ? ` · ${a.module}` : ''}
          </span>
          <span className="feed-item__meta">
            User #{a.userID} · {formatDate(a.timestamp)}
          </span>
        </li>
      )}
    />,
  ];
}
