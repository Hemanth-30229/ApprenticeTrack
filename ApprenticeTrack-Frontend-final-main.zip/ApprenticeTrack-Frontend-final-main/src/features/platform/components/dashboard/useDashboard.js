// Dashboard data hooks.
//
// useDashboard   -> the AP-10 metrics list, with 5-minute auto-refresh + manual
//                   refresh, loading/error state, and last-updated timestamp.
// useDashboardExtras -> supplementary list/feed/timeline data that AP-10 does
//                   not provide, fetched per role from the relevant endpoints.

import { useEffect, useState } from 'react';
import api from '../../../../shared/api/client';
import { ROLES } from '../../../../shared/auth/roles';

const REFRESH_MS = 5 * 60 * 1000; // 5 minutes

export function useDashboard(user) {
  const [metrics, setMetrics] = useState([]);
  const [meta, setMeta] = useState(null); // { role, generatedAt, cached }
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');
  const [lastUpdated, setLastUpdated] = useState(null);

  async function load({ silent = false } = {}) {
    if (silent) setRefreshing(true);
    else setLoading(true);
    setError('');
    try {
      // employerID is only meaningful for the Employer role.
      const params =
        user?.role === ROLES.EMPLOYER && user?.instituteID
          ? { employerID: user.instituteID }
          : undefined;
      const { data } = await api.get('/api/dashboard', { params });
      setMetrics(data.metrics || []);
      setMeta({ role: data.role, generatedAt: data.generatedAt, cached: data.cached });
      setLastUpdated(new Date());
    } catch (err) {
      setError(
        err?.response?.status === 503
          ? 'The dashboard service is temporarily unavailable.'
          : 'Could not load your dashboard. Please try again.'
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  // Initial load + 5-minute auto-refresh.
  useEffect(() => {
    load();
    const id = setInterval(() => load({ silent: true }), REFRESH_MS);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  return {
    metrics,
    meta,
    loading,
    refreshing,
    error,
    lastUpdated,
    refresh: () => load({ silent: true }),
  };
}

// --- Supplementary lists (not covered by AP-10) ----------------------------

function isoDaysFromNow(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

export function useDashboardExtras(user) {
  const [data, setData] = useState({});
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const role = user?.role;
    const next = {};
    try {
      if (role === ROLES.EMPLOYER && user?.instituteID) {
        const { data: page } = await api.get('/api/placements', {
          params: { employerID: user.instituteID, page: 0, size: 5, sort: 'placementDate,desc' },
        });
        next.recentPlacements = page.content || [];
      } else if (role === ROLES.PLACEMENT_OFFICER) {
        const { data: page } = await api.get('/api/placements', {
          params: { page: 0, size: 6, sort: 'placementDate,desc' },
        });
        next.recentPlacements = page.content || [];
      } else if (role === ROLES.ASSESSOR) {
        const { data: page } = await api.get('/api/trade-tests', {
          params: {
            assessorID: user.userID,
            status: 'Scheduled',
            fromDate: isoDaysFromNow(0),
            toDate: isoDaysFromNow(7),
            page: 0,
            size: 6,
            sort: 'testDate,asc',
          },
        });
        next.upcomingTests = page.content || [];
      } else if (role === ROLES.ADMIN) {
        const { data: page } = await api.get('/api/audit-logs', {
          params: { page: 0, size: 5, sort: 'timestamp,desc' },
        });
        next.recentActivity = page.content || [];
      }
    } catch {
      // Supplementary data is best-effort; widgets fall back to empty states.
    } finally {
      setData(next);
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  return { extras: data, extrasLoading: loading };
}
