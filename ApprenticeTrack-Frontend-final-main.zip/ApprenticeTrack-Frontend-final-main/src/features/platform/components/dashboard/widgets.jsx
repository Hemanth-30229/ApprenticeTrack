// Dashboard widget cards. Each card shows a title, an optional trend indicator
// with a "vs previous period" comparison line, and role-specific content.

import { Link } from 'react-router-dom';
import { trendInfo } from '../../../../shared/format';

/** Base card shell used by every widget. */
export function Card({ title, trend, action, size = 'sm', children, footnote }) {
  const t = trend ? trendInfo(trend) : null;
  return (
    <section className={`widget widget--${size}`} aria-label={title}>
      <header className="widget__head">
        <h3 className="widget__title">{title}</h3>
        {t && (
          <span
            className={`widget__trend widget__trend--${t.dir}`}
            title={`Trend: ${t.label} vs previous period`}
          >
            <span aria-hidden="true">{t.arrow}</span>
            <span className="sr-only">{t.label} versus previous period</span>
          </span>
        )}
      </header>

      <div className="widget__body">{children}</div>

      <footer className="widget__foot">
        {footnote && <span className="widget__foot-note">{footnote}</span>}
        {action &&
          (action.to ? (
            <Link className="widget__action" to={action.to}>
              {action.label}
            </Link>
          ) : (
            <button
              type="button"
              className="widget__action"
              onClick={action.onClick}
            >
              {action.label}
            </button>
          ))}
      </footer>
    </section>
  );
}

/** A single big number with a comparison caption. */
export function StatCard({ title, value, trend, caption = 'vs previous period', action }) {
  return (
    <Card title={title} trend={trend} action={action} footnote={caption}>
      <p className="widget__stat">{value}</p>
    </Card>
  );
}

/** Progress bar card with a "x / y" caption. */
export function ProgressCard({ title, chart, caption, trend, action }) {
  return (
    <Card title={title} trend={trend} action={action} footnote={caption}>
      {chart}
    </Card>
  );
}

/** Generic chart card (gauge/donut/bars/line) with optional legend. */
export function ChartCard({ title, chart, legend, trend, action, size = 'sm', caption }) {
  return (
    <Card title={title} trend={trend} action={action} size={size} footnote={caption}>
      <div className="widget__chart">{chart}</div>
      {legend && <ul className="widget__legend">{legend}</ul>}
    </Card>
  );
}

/** Status badge card (e.g. certificate status). */
export function BadgeCard({ title, status, tone = 'neutral', caption, action }) {
  return (
    <Card title={title} action={action} footnote={caption}>
      <span className={`badge badge--${tone}`}>{status}</span>
    </Card>
  );
}

/** List / feed / timeline card. Renders items via a render function. */
export function ListCard({ title, items, renderItem, empty, action, size = 'md', loading }) {
  return (
    <Card title={title} action={action} size={size}>
      {loading ? (
        <ul className="widget__list">
          {[0, 1, 2].map((i) => (
            <li key={i} className="skeleton skeleton--line" />
          ))}
        </ul>
      ) : items && items.length > 0 ? (
        <ul className="widget__list">{items.map(renderItem)}</ul>
      ) : (
        <p className="widget__empty">{empty || 'Nothing to show yet.'}</p>
      )}
    </Card>
  );
}

/** Loading skeleton placeholder for a widget. */
export function SkeletonCard({ size = 'sm' }) {
  return (
    <section className={`widget widget--${size}`} aria-hidden="true">
      <div className="skeleton skeleton--title" />
      <div className="skeleton skeleton--block" />
      <div className="skeleton skeleton--line" />
    </section>
  );
}
