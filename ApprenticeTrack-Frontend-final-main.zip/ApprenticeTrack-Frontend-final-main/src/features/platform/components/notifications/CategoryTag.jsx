// Colour-coded notification category tag.

export default function CategoryTag({ category }) {
  return <span className={`cat cat--${String(category).toLowerCase()}`}>{category}</span>;
}
