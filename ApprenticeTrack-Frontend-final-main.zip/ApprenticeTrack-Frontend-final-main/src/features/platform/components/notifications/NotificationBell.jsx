// Notification bell with unread badge + dropdown of the latest 10 notifications.

import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../../../shared/auth/AuthContext';
import { useNotifications } from './NotificationContext';
import CategoryTag from './CategoryTag';
import Spinner from '../../../../shared/Spinner';
import {
  dismissNotification,
  listNotifications,
  markAllNotificationsRead,
  markNotificationRead,
} from '../../api/notifications';
import { categoryRoute } from '../../constants/notification';
import { timeAgo } from '../../../../shared/utils/timeAgo';

export default function NotificationBell() {
  const { user } = useAuth();
  const { unreadCount, refreshUnread } = useNotifications();
  const navigate = useNavigate();

  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const rootRef = useRef(null);

  useEffect(() => {
    function onDocClick(e) {
      if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, []);

  async function loadRecent() {
    setLoading(true);
    try {
      const data = await listNotifications({ page: 0, size: 10, sort: 'createdDate,desc' });
      // Hide dismissed from the quick panel.
      setItems((data.content || []).filter((n) => n.status !== 'Dismissed'));
    } catch {
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  function toggle() {
    const next = !open;
    setOpen(next);
    if (next) loadRecent();
  }

  async function handleClick(n) {
    setOpen(false);
    try {
      if (n.status === 'Unread') {
        await markNotificationRead(n.notificationID);
        refreshUnread();
      }
    } catch {
      /* navigation still proceeds */
    }
    navigate(categoryRoute(n.category, user?.role));
  }

  async function handleDismiss(e, n) {
    e.stopPropagation();
    try {
      await dismissNotification(n.notificationID);
      setItems((list) => list.filter((x) => x.notificationID !== n.notificationID));
      refreshUnread();
    } catch {
      /* ignore */
    }
  }

  async function handleMarkAll() {
    try {
      await markAllNotificationsRead();
      setItems((list) => list.map((n) => (n.status === 'Unread' ? { ...n, status: 'Read' } : n)));
      refreshUnread();
    } catch {
      /* ignore */
    }
  }

  return (
    <div className="bell" ref={rootRef}>
      <button
        type="button"
        className="bell__button"
        aria-label={`Notifications${unreadCount ? `, ${unreadCount} unread` : ''}`}
        aria-expanded={open}
        onClick={toggle}
      >
        <span aria-hidden="true">🔔</span>
        {unreadCount > 0 && <span className="bell__badge">{unreadCount > 99 ? '99+' : unreadCount}</span>}
      </button>

      {open && (
        <div className="bell__panel" role="dialog" aria-label="Notifications">
          <div className="bell__panel-head">
            <span>Notifications</span>
            <button type="button" className="bell__link" onClick={handleMarkAll} disabled={unreadCount === 0}>
              Mark all as read
            </button>
          </div>

          <div className="bell__list">
            {loading ? (
              <div className="bell__empty"><Spinner size={18} inline label="Loading" /> Loading…</div>
            ) : items.length === 0 ? (
              <div className="bell__empty">You&apos;re all caught up.</div>
            ) : (
              items.map((n) => (
                <button
                  key={n.notificationID}
                  type="button"
                  className={`notif ${n.status === 'Unread' ? 'notif--unread' : ''}`}
                  onClick={() => handleClick(n)}
                >
                  {n.status === 'Unread' && <span className="notif__dot" aria-hidden="true" />}
                  <span className="notif__body">
                    <span className="notif__message">{n.message}</span>
                    <span className="notif__meta">
                      <CategoryTag category={n.category} />
                      <span className="notif__time">{timeAgo(n.createdDate)}</span>
                    </span>
                  </span>
                  <span
                    className="notif__dismiss"
                    role="button"
                    tabIndex={0}
                    aria-label="Dismiss notification"
                    onClick={(e) => handleDismiss(e, n)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') handleDismiss(e, n);
                    }}
                  >
                    ×
                  </span>
                </button>
              ))
            )}
          </div>

          <button
            type="button"
            className="bell__viewall"
            onClick={() => {
              setOpen(false);
              navigate('/notifications');
            }}
          >
            View all
          </button>
        </div>
      )}
    </div>
  );
}
