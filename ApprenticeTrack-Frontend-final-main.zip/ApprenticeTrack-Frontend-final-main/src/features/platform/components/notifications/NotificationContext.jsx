// Polls the unread-notification count for the badge (default 30s, configurable
// via VITE_NOTIFICATION_POLL_MS). Provides the count + a refresh trigger so
// read/dismiss/mark-all actions can update the badge immediately.

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { useAuth } from '../../../../shared/auth/AuthContext';
import { getUnreadCount } from '../../api/notifications';
import { NOTIFICATION_POLL_MS } from '../../constants/notification';

const NotificationContext = createContext(null);

export function NotificationProvider({ children }) {
  const { isAuthenticated } = useAuth();
  const [unreadCount, setUnreadCount] = useState(0);

  const refreshUnread = useCallback(async () => {
    if (!isAuthenticated) return;
    try {
      setUnreadCount(await getUnreadCount());
    } catch {
      /* ignore transient errors; next poll retries */
    }
  }, [isAuthenticated]);

  useEffect(() => {
    if (!isAuthenticated) {
      setUnreadCount(0);
      return undefined;
    }
    refreshUnread();
    const id = setInterval(refreshUnread, NOTIFICATION_POLL_MS);
    return () => clearInterval(id);
  }, [isAuthenticated, refreshUnread]);

  const value = useMemo(
    () => ({ unreadCount, refreshUnread, setUnreadCount }),
    [unreadCount, refreshUnread]
  );

  return <NotificationContext.Provider value={value}>{children}</NotificationContext.Provider>;
}

export function useNotifications() {
  const ctx = useContext(NotificationContext);
  if (!ctx) throw new Error('useNotifications must be used within a NotificationProvider');
  return ctx;
}
