// Audit log modules + page-size options.

export const AUDIT_MODULES = [
  'Enrollment',
  'Placement',
  'OJT',
  'Assessment',
  'Stipend',
  'Certification',
];

export const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];

export function formatDateTime(value) {
  if (!value) return '—';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}
