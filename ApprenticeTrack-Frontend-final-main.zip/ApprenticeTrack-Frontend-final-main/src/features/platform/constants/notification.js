// Notification categories/statuses, category->route mapping, and helpers.

import { homePathForRole, ROLES } from '../../../shared/auth/roles';

export const NOTIFICATION_CATEGORIES = [
  'Enrollment',
  'Placement',
  'OJT',
  'Assessment',
  'Stipend',
  'Certification',
];

export const NOTIFICATION_STATUSES = ['Unread', 'Read', 'Dismissed'];

// Poll interval for the unread-count badge (configurable; default 30s).
export const NOTIFICATION_POLL_MS =
  Number(import.meta.env.VITE_NOTIFICATION_POLL_MS) || 30000;

// Category -> relevant page per role. The notification carries no entity ID, so
// we can only route to the category's list page for the current role, not a
// specific record. Falls back to the role's dashboard.
const CATEGORY_ROUTE = {
  [ROLES.TRAINEE]: {
    OJT: '/trainee/ojt-logs',
    Assessment: '/trainee/results',
    Certification: '/trainee/certificates',
  },
  [ROLES.ADMIN]: {
    Enrollment: '/enrollments',
    Assessment: '/results',
    Certification: '/certificates',
    Placement: '/employers',
  },
  [ROLES.EMPLOYER]: {
    OJT: '/employer/ojt-logs',
  },
  [ROLES.ASSESSOR]: {
    Assessment: '/assessor/tests',
  },
  [ROLES.PLACEMENT_OFFICER]: {
    Placement: '/placements',
  },
  [ROLES.STIPEND_ADMIN]: {
    Stipend: '/stipends',
    OJT: '/attendance',
  },
};

export function categoryRoute(category, role) {
  return CATEGORY_ROUTE[role]?.[category] || homePathForRole(role);
}
