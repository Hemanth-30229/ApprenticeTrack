// Audit log viewer (admin): searchable, filterable, paginated list of system audit
// entries with CSV export. List-page pattern (see PlacementListPage for the reference).
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import CategoryTag from '../components/notifications/CategoryTag';
import { useToast } from '../../../shared/toast/ToastContext';
import { listAuditLogs } from '../api/auditLogs';
import { AUDIT_MODULES, formatDateTime, PAGE_SIZE_OPTIONS } from '../constants/audit';
import { exportToCsv } from '../../../shared/utils/csv';

export default function AuditLogPage() {
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [exporting, setExporting] = useState(false);

  const [page, setPage] = useState(0);
  const [size, setSize] = useState(25);
  const [sort, setSort] = useState({ field: 'timestamp', dir: 'desc' });

  // Server-side filters
  const [userId, setUserId] = useState('');
  const [module, setModule] = useState('');
  const [action, setAction] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Client-side quick search
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const debounceRef = useRef(null);

  const sortParam = `${sort.field},${sort.dir}`;

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await listAuditLogs({
        userId: userId || undefined,
        module: module || undefined,
        action: action || undefined,
        startDate: startDate || undefined,
        endDate: endDate || undefined,
        page,
        size,
        sort: sortParam,
      });
      setRows(data.content || []);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
    } catch (err) {
      setError(
        err?.response?.status === 403
          ? 'You do not have permission to view audit logs.'
          : 'Could not load audit logs. Please try again.'
      );
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [userId, module, action, startDate, endDate, page, size, sortParam]);

  useEffect(() => {
    load();
  }, [load]);

  function onSearchChange(value) {
    setSearchInput(value);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => setSearch(value.trim().toLowerCase()), 300);
  }

  // Client-side quick search across the loaded page.
  const visibleRows = useMemo(() => {
    if (!search) return rows;
    return rows.filter((r) =>
      [r.action, r.module, r.details, r.userID, r.ipAddress]
        .map((v) => String(v ?? '').toLowerCase())
        .some((s) => s.includes(search))
    );
  }, [rows, search]);

  function toggleSort(field) {
    setPage(0);
    setSort((prev) =>
      prev.field === field
        ? { field, dir: prev.dir === 'asc' ? 'desc' : 'asc' }
        : { field, dir: 'asc' }
    );
  }

  function resetFilters() {
    setUserId('');
    setModule('');
    setAction('');
    setStartDate('');
    setEndDate('');
    setSearchInput('');
    setSearch('');
    setPage(0);
  }

  async function handleExport() {
    setExporting(true);
    try {
      // Export the filtered set (up to 1000 rows), not just the current page.
      const data = await listAuditLogs({
        userId: userId || undefined,
        module: module || undefined,
        action: action || undefined,
        startDate: startDate || undefined,
        endDate: endDate || undefined,
        page: 0,
        size: 1000,
        sort: sortParam,
      });
      const content = data.content || [];
      if (content.length === 0) {
        toast.info('No audit logs to export.');
        return;
      }
      exportToCsv(
        'audit-logs',
        [
          { key: 'auditID', label: 'Audit ID' },
          { key: 'timestamp', label: 'Timestamp', format: (v) => formatDateTime(v) },
          { key: 'userID', label: 'User ID' },
          { key: 'module', label: 'Module' },
          { key: 'action', label: 'Action' },
          { key: 'ipAddress', label: 'IP Address' },
          { key: 'details', label: 'Details' },
        ],
        content
      );
      toast.success(`Exported ${content.length} audit log(s).`);
    } catch {
      toast.error('Failed to export audit logs.');
    } finally {
      setExporting(false);
    }
  }

  const from = pageInfo.totalElements === 0 ? 0 : page * size + 1;
  const to = Math.min((page + 1) * size, pageInfo.totalElements);

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Audit Logs</h1>
            <p className="page__subtitle">Review system-wide audit trails.</p>
          </div>
          <button type="button" className="btn btn--secondary" onClick={handleExport} disabled={exporting} aria-busy={exporting}>
            {exporting && <Spinner size={16} inline label="Exporting" />}
            Export CSV
          </button>
        </div>

        <div className="toolbar">
          <div className="toolbar__search">
            <label htmlFor="audit-search" className="sr-only">Search audit logs</label>
            <input id="audit-search" type="search" className="field__input" placeholder="Search action, details, IP…" value={searchInput} onChange={(e) => onSearchChange(e.target.value)} />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="user-filter" className="field__label field__label--sm">User ID</label>
            <input id="user-filter" type="number" className="field__input" placeholder="e.g. 42" value={userId} onChange={(e) => { setUserId(e.target.value); setPage(0); }} />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="module-filter" className="field__label field__label--sm">Module</label>
            <select id="module-filter" className="field__input" value={module} onChange={(e) => { setModule(e.target.value); setPage(0); }}>
              <option value="">All modules</option>
              {AUDIT_MODULES.map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="action-filter" className="field__label field__label--sm">Action</label>
            <input id="action-filter" type="text" className="field__input" placeholder="e.g. CREATE" value={action} onChange={(e) => { setAction(e.target.value); setPage(0); }} />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="start-date" className="field__label field__label--sm">From</label>
            <input id="start-date" type="date" className="field__input" value={startDate} max={endDate || undefined} onChange={(e) => { setStartDate(e.target.value); setPage(0); }} />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="end-date" className="field__label field__label--sm">To</label>
            <input id="end-date" type="date" className="field__input" value={endDate} min={startDate || undefined} onChange={(e) => { setEndDate(e.target.value); setPage(0); }} />
          </div>
          <div className="toolbar__filter toolbar__filter--reset">
            <button type="button" className="btn btn--secondary" onClick={resetFilters}>Reset</button>
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <SortHeader label="Timestamp" field="timestamp" sort={sort} onSort={toggleSort} />
                <SortHeader label="User" field="userID" sort={sort} onSort={toggleSort} />
                <SortHeader label="Module" field="module" sort={sort} onSort={toggleSort} />
                <SortHeader label="Action" field="action" sort={sort} onSort={toggleSort} />
                <th scope="col">Details</th>
                <th scope="col">IP Address</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
              ) : error ? (
                <tr>
                  <td colSpan={6} className="table__state table__state--error">
                    {error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button>
                  </td>
                </tr>
              ) : visibleRows.length === 0 ? (
                <tr><td colSpan={6} className="table__state">No audit logs found.</td></tr>
              ) : (
                visibleRows.map((r) => (
                  <tr key={r.auditID}>
                    <td data-label="Timestamp">{formatDateTime(r.timestamp)}</td>
                    <td data-label="User">#{r.userID}</td>
                    <td data-label="Module">
                      {AUDIT_MODULES.includes(r.module) ? <CategoryTag category={r.module} /> : r.module}
                    </td>
                    <td data-label="Action">{r.action}</td>
                    <td data-label="Details" className="audit-details" title={r.details}>{r.details || '—'}</td>
                    <td data-label="IP Address">{r.ipAddress || '—'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <div className="pagination__left">
            <span className="pagination__info">
              {pageInfo.totalElements > 0 ? `Showing ${from}–${to} of ${pageInfo.totalElements}` : ' '}
            </span>
            <label className="page-size">
              <span>Rows:</span>
              <select
                className="field__input"
                value={size}
                onChange={(e) => { setSize(Number(e.target.value)); setPage(0); }}
              >
                {PAGE_SIZE_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </label>
          </div>
          <div className="pagination__controls">
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={loading || page === 0}>← Previous</button>
            <span className="pagination__page">Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}</span>
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => p + 1)} disabled={loading || page + 1 >= pageInfo.totalPages}>Next →</button>
          </div>
        </div>
      </main>
    </div>
  );
}

function SortHeader({ label, field, sort, onSort }) {
  const active = sort.field === field;
  const ariaSort = active ? (sort.dir === 'asc' ? 'ascending' : 'descending') : 'none';
  return (
    <th scope="col" aria-sort={ariaSort}>
      <button type="button" className="sort-header" onClick={() => onSort(field)}>
        {label}
        <span className="sort-header__arrow" aria-hidden="true">
          {active ? (sort.dir === 'asc' ? '▲' : '▼') : '↕'}
        </span>
      </button>
    </th>
  );
}
