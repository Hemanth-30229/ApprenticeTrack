import { useState } from 'react';
import { useAuth } from '../../../shared/auth/AuthContext';
import { ROLE_DASHBOARD_LABEL } from '../../../shared/auth/roles';
import Spinner from '../../../shared/Spinner';
import QuickActions from '../components/dashboard/QuickActions';
import { SkeletonCard } from '../components/dashboard/widgets';
import { buildWidgets } from '../components/dashboard/roleWidgets';
import { useDashboard, useDashboardExtras } from '../components/dashboard/useDashboard';
import '../components/dashboard/dashboard.css';

function formatTime(date) {
  if (!date) return '';
  return date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
}

export default function DashboardPage() {
  const { user } = useAuth();
  const { metrics, loading, refreshing, error, lastUpdated, refresh } = useDashboard(user);
  const { extras, extrasLoading } = useDashboardExtras(user);
  const [notice, setNotice] = useState('');

  const title = ROLE_DASHBOARD_LABEL[user?.role] || 'Dashboard';

  function handleQuickAction(label) {
    setNotice(`“${label}” is coming soon.`);
  }

  const widgets = buildWidgets({
    role: user?.role,
    metrics,
    extras,
    extrasLoading,
  });

  return (
    <div className="dash">

      <main className="dash__main" id="main-content">
        <div className="dash__heading">
          <div>
            <h1 className="dash__title">{title}</h1>
            <p className="dash__subtitle">
              Welcome back{user?.name ? `, ${user.name}` : ''}. Here’s your overview.
            </p>
          </div>
          <div className="dash__controls">
            <span className="dash__updated" aria-live="polite">
              {refreshing ? (
                <>
                  <Spinner size={14} inline label="Refreshing" /> Refreshing…
                </>
              ) : lastUpdated ? (
                `Updated ${formatTime(lastUpdated)}`
              ) : (
                ''
              )}
            </span>
            <button
              type="button"
              className="btn btn--secondary btn--sm"
              onClick={refresh}
              disabled={loading || refreshing}
            >
              ↻ Refresh
            </button>
          </div>
        </div>

        <QuickActions role={user?.role} onAction={handleQuickAction} />

        {notice && (
          <div className="dash__notice" role="status">
            <span>{notice}</span>
            <button
              type="button"
              className="dash__notice-close"
              aria-label="Dismiss"
              onClick={() => setNotice('')}
            >
              ×
            </button>
          </div>
        )}

        {error && (
          <div className="dash__error" role="alert">
            <span>{error}</span>
            <button type="button" className="btn btn--secondary btn--sm" onClick={refresh}>
              Retry
            </button>
          </div>
        )}

        <div className="dash__grid">
          {loading
            ? [0, 1, 2, 3, 4].map((i) => <SkeletonCard key={i} />)
            : widgets}
        </div>

        <p className="dash__autorefresh-note">
          This dashboard refreshes automatically every 5 minutes.
        </p>
      </main>
    </div>
  );
}
