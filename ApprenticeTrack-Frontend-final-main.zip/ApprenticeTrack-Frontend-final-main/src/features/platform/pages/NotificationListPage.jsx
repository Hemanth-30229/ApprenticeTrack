import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import CategoryTag from '../components/notifications/CategoryTag';
import { useAuth } from '../../../shared/auth/AuthContext';
import { useNotifications } from '../components/notifications/NotificationContext';
import { useToast } from '../../../shared/toast/ToastContext';
import {
  dismissNotification,
  listNotifications,
  markAllNotificationsRead,
  markNotificationRead,
} from '../api/notifications';
import {
  categoryRoute,
  NOTIFICATION_CATEGORIES,
  NOTIFICATION_STATUSES,
} from '../constants/notification';
import { formatDate } from '../../../shared/format';
import { timeAgo } from '../../../shared/utils/timeAgo';

const PAGE_SIZE = 15;

const STATUS_TONE = { Unread: 'info', Read: 'neutral', Dismissed: 'warning' };

export default function NotificationListPage() {
  const { user } = useAuth();
  const { unreadCount, refreshUnread } = useNotifications();
  const toast = useToast();
  const navigate = useNavigate();

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);

  const [category, setCategory] = useState('');
  const [status, setStatus] = useState('');
  const [showDismissed, setShowDismissed] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await listNotifications({
        category: category || undefined,
        status: status || undefined,
        page,
        size: PAGE_SIZE,
        sort: 'createdDate,desc',
      });
      setRows(data.content || []);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
    } catch {
      setError('Could not load notifications. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [category, status, page]);

  useEffect(() => {
    load();
  }, [load]);

  const visibleRows = useMemo(() => {
    if (showDismissed || status === 'Dismissed') return rows;
    return rows.filter((n) => n.status !== 'Dismissed');
  }, [rows, showDismissed, status]);

  async function handleRowClick(n) {
    try {
      if (n.status === 'Unread') {
        await markNotificationRead(n.notificationID);
        refreshUnread();
      }
    } catch {
      /* still navigate */
    }
    navigate(categoryRoute(n.category, user?.role));
  }

  async function handleDismiss(e, n) {
    e.stopPropagation();
    try {
      await dismissNotification(n.notificationID);
      toast.success('Notification dismissed.');
      refreshUnread();
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to dismiss notification.');
    }
  }

  async function handleMarkAll() {
    try {
      const count = await markAllNotificationsRead();
      toast.success(count > 0 ? `${count} notification(s) marked as read.` : 'No unread notifications.');
      refreshUnread();
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to mark all as read.');
    }
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Notifications</h1>
            <p className="page__subtitle">View and manage your alerts across all categories.</p>
          </div>
          <button type="button" className="btn btn--primary" onClick={handleMarkAll} disabled={unreadCount === 0}>
            Mark All as Read
          </button>
        </div>

        <div className="toolbar">
          <div className="toolbar__filter">
            <label htmlFor="category-filter" className="field__label field__label--sm">Category</label>
            <select id="category-filter" className="field__input" value={category} onChange={(e) => { setCategory(e.target.value); setPage(0); }}>
              <option value="">All categories</option>
              {NOTIFICATION_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="field__label field__label--sm">Status</label>
            <select id="status-filter" className="field__input" value={status} onChange={(e) => { setStatus(e.target.value); setPage(0); }}>
              <option value="">All statuses</option>
              {NOTIFICATION_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <label className="toggle">
            <input type="checkbox" checked={showDismissed} onChange={(e) => setShowDismissed(e.target.checked)} />
            <span>Show dismissed</span>
          </label>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Message</th>
                <th scope="col">Category</th>
                <th scope="col">Status</th>
                <th scope="col">Created</th>
                <th scope="col" className="table__actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={5} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
              ) : error ? (
                <tr>
                  <td colSpan={5} className="table__state table__state--error">
                    {error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button>
                  </td>
                </tr>
              ) : visibleRows.length === 0 ? (
                <tr><td colSpan={5} className="table__state">You have no notifications.</td></tr>
              ) : (
                visibleRows.map((n) => (
                  <tr
                    key={n.notificationID}
                    className={`notif-row ${n.status === 'Unread' ? 'notif-row--unread' : ''}`}
                    onClick={() => handleRowClick(n)}
                  >
                    <td data-label="Message">{n.message}</td>
                    <td data-label="Category"><CategoryTag category={n.category} /></td>
                    <td data-label="Status">
                      <StatusBadge status={n.status} tone={STATUS_TONE[n.status] || 'neutral'} />
                    </td>
                    <td data-label="Created" title={formatDate(n.createdDate)}>{timeAgo(n.createdDate)}</td>
                    <td data-label="Actions" className="table__actions">
                      {n.status !== 'Dismissed' && (
                        <button
                          type="button"
                          className="btn btn--danger-ghost btn--sm"
                          aria-label="Dismiss notification"
                          onClick={(e) => handleDismiss(e, n)}
                        >
                          × Dismiss
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <span className="pagination__info">{pageInfo.totalElements > 0 ? `${pageInfo.totalElements} total` : ' '}</span>
          <div className="pagination__controls">
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={loading || page === 0}>← Previous</button>
            <span className="pagination__page">Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}</span>
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => p + 1)} disabled={loading || page + 1 >= pageInfo.totalPages}>Next →</button>
          </div>
        </div>
      </main>
    </div>
  );
}
