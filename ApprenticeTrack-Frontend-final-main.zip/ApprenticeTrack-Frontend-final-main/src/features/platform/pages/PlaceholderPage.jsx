// Generic "coming soon" page for sidebar items whose screens aren't built yet.

import { useSearchParams } from 'react-router-dom';

export default function PlaceholderPage() {
  const [params] = useSearchParams();
  const feature = params.get('feature') || 'This feature';

  return (
    <div className="page">
      <div className="empty-state">
        <h1 className="page__title">{feature}</h1>
        <p className="empty-state__hint">This screen is coming soon.</p>
      </div>
    </div>
  );
}
