// ---------------------------------------------------------------------------
// Batch API (training-service)
// ---------------------------------------------------------------------------
// A batch is a scheduled run of a course that trainees enrol into. These
// functions manage batches (list / view / create / edit / status / delete).
// ---------------------------------------------------------------------------

import api from '../../../shared/api/client';

export function listBatches({
  courseID,
  status,
  fromDate,
  toDate,
  page = 0,
  size = 500,
  sort = 'startDate,asc',
} = {}) {
  const params = { page, size, sort };
  if (courseID) params.courseID = courseID;
  if (status) params.status = status;
  if (fromDate) params.fromDate = fromDate;
  if (toDate) params.toDate = toDate;
  return api.get('/api/batches', { params }).then((r) => r.data);
}

/** body: { courseID, batchCode, startDate, endDate, trainerID, venueID, capacity } */
export function createBatch(body) {
  return api.post('/api/batches', body).then((r) => r.data);
}

export function updateBatch(id, body) {
  return api.put(`/api/batches/${id}`, body).then((r) => r.data);
}

/** PATCH status. body { status } */
export function updateBatchStatus(id, status) {
  return api.patch(`/api/batches/${id}/status`, { status }).then((r) => r.data);
}

export function deleteBatch(id) {
  return api.delete(`/api/batches/${id}`).then((r) => r.data);
}
