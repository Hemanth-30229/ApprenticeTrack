// ---------------------------------------------------------------------------
// Trade Course API (training-service)
// ---------------------------------------------------------------------------
// A course defines a trade programme and its week split (classroom + OJT weeks).
// These functions manage the course catalogue (list / view / create / edit / delete).
// ---------------------------------------------------------------------------

import api from '../../../shared/api/client';

export function listCourses({
  sector,
  qualificationLevel,
  status = 'Active',
  page = 0,
  size = 200,
  sort = 'courseName,asc',
} = {}) {
  const params = { page, size, sort };
  if (sector) params.sector = sector;
  if (qualificationLevel) params.qualificationLevel = qualificationLevel;
  if (status) params.status = status;
  return api.get('/api/trade-courses', { params }).then((r) => r.data);
}

export function getCourse(id) {
  return api.get(`/api/trade-courses/${id}`).then((r) => r.data);
}

/** body: { courseName, tradeCode, sector, durationWeeks, classroomWeeks, ojtWeeks, qualificationLevel } */
export function createCourse(body) {
  return api.post('/api/trade-courses', body).then((r) => r.data);
}

export function updateCourse(id, body) {
  return api.put(`/api/trade-courses/${id}`, body).then((r) => r.data);
}

export function deleteCourse(id) {
  return api.delete(`/api/trade-courses/${id}`).then((r) => r.data);
}
