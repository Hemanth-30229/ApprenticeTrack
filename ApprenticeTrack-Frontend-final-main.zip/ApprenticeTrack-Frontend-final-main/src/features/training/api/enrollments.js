// ---------------------------------------------------------------------------
// Enrollment API (training-service)
// ---------------------------------------------------------------------------
// An enrollment links a trainee to a course + batch and tracks their status
// (Enrolled -> OJTInProgress -> AssessmentPending -> Completed). These functions
// list/create enrollments, change status, and read a batch's roster.
// ---------------------------------------------------------------------------

import api from '../../../shared/api/client';

/** List enrollments. The response includes traineeName + courseName per row. */
export function listEnrollments({ traineeID, courseID, batchID, status, page = 0, size = 100, sort = 'enrollmentDate,desc' } = {}) {
  const params = { page, size, sort };
  if (traineeID) params.traineeID = traineeID;
  if (courseID) params.courseID = courseID;
  if (batchID) params.batchID = batchID;
  if (status) params.status = status;
  return api.get('/api/enrollments', { params }).then((r) => r.data);
}

/** body: { traineeID, courseID, batchID, enrollmentDate } */
export function createEnrollment(body) {
  return api.post('/api/enrollments', body).then((r) => r.data);
}

/** PUT status. body { status } */
export function updateEnrollmentStatus(id, status) {
  return api.put(`/api/enrollments/${id}/status`, { status }).then((r) => r.data);
}

/** Roster (traineeID + name) for a batch, derived from its enrollments. */
export function getBatchRoster(batchID) {
  return listEnrollments({ batchID, size: 200 }).then((page) =>
    (page.content || []).map((e) => ({ traineeID: e.traineeID, name: e.traineeName }))
  );
}
