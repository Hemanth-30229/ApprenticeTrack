// ---------------------------------------------------------------------------
// Trainee API (training-service)
// ---------------------------------------------------------------------------
// A "trainee" is an apprentice's profile. These functions manage that profile
// (list / view / look-up-by-login-user / create / edit / delete). `api` is the
// shared axios instance (adds the auth token, points at the gateway).
// ---------------------------------------------------------------------------

import api from '../../../shared/api/client';

/** Paginated, filterable list. Returns a Spring Page. */
export function listTrainees({ name, status, page = 0, size = 10, sort = 'name,asc' } = {}) {
  const params = { page, size, sort };
  if (name) params.name = name;
  if (status) params.status = status;
  return api.get('/api/trainees', { params }).then((r) => r.data);
}

export function getTrainee(id) {
  return api.get(`/api/trainees/${id}`).then((r) => r.data);
}

/** Resolve the trainee profile for a given auth userId (404 if none). */
export function getTraineeByUser(userId) {
  return api.get(`/api/trainees/by-user/${userId}`).then((r) => r.data);
}

/**
 * Create a trainee.
 * body: { userID, name, dateOfBirth, gender, educationLevel, address, phone,
 *         emergencyContact: { name, phone } }
 */
export function createTrainee(body) {
  return api.post('/api/trainees', body).then((r) => r.data);
}

/**
 * Update a trainee. The API only accepts these fields:
 * body: { name, address, phone, educationLevel, emergencyContact: { name, phone } }
 */
export function updateTrainee(id, body) {
  return api.put(`/api/trainees/${id}`, body).then((r) => r.data);
}

export function deleteTrainee(id) {
  return api.delete(`/api/trainees/${id}`).then((r) => r.data);
}
