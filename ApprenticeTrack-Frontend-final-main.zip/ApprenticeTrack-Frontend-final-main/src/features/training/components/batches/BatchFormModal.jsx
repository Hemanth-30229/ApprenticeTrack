// Create / edit a training batch. On edit, a status change is applied via the
// separate PATCH /status endpoint (create always starts as Upcoming server-side).

import { cloneElement, isValidElement, useMemo, useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import { BATCH_STATUS_NEXT } from '../../constants/batch';

function isPosInt(v) {
  return /^\d+$/.test(String(v).trim()) && Number(v) > 0;
}

function emptyForm() {
  return { batchCode: '', courseID: '', startDate: '', endDate: '', trainerID: '', venueID: '', capacity: '' };
}
function fromBatch(b) {
  return {
    batchCode: b.batchCode ?? '',
    courseID: b.courseID ?? '',
    startDate: b.startDate ?? '',
    endDate: b.endDate ?? '',
    trainerID: b.trainerID ?? '',
    venueID: b.venueID ?? '',
    capacity: b.capacity ?? '',
    status: b.status ?? 'Upcoming',
  };
}

export default function BatchFormModal({ batch, courses, onClose, onSubmit }) {
  const isEdit = Boolean(batch);
  const [form, setForm] = useState(() => (isEdit ? fromBatch(batch) : emptyForm()));
  const [touched, setTouched] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const errors = useMemo(() => {
    const e = {};
    if (!form.batchCode.trim()) e.batchCode = 'Batch code is required';
    if (!form.courseID) e.courseID = 'Course is required';
    if (!form.startDate) e.startDate = 'Start date is required';
    if (!form.endDate) e.endDate = 'End date is required';
    else if (form.startDate && form.endDate <= form.startDate) e.endDate = 'End date must be after start date';
    if (!isPosInt(form.trainerID)) e.trainerID = 'Enter a valid trainer ID';
    if (!isPosInt(form.venueID)) e.venueID = 'Enter a valid venue ID';
    if (!isPosInt(form.capacity)) e.capacity = 'Capacity must be greater than 0';
    return e;
  }, [form, isEdit]);

  const isValid = Object.keys(errors).length === 0;
  const set = (f, v) => setForm((s) => ({ ...s, [f]: v }));
  const blur = (f) => setTouched((t) => ({ ...t, [f]: true }));
  const err = (f) => (touched[f] && errors[f] ? errors[f] : '');

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched(Object.keys(form).reduce((a, k) => ({ ...a, [k]: true }), {}));
    if (!isValid) return;
    setSubmitting(true);
    try {
      const payload = {
        batchCode: form.batchCode.trim(),
        courseID: Number(form.courseID),
        startDate: form.startDate,
        endDate: form.endDate,
        trainerID: Number(form.trainerID),
        venueID: Number(form.venueID),
        capacity: Number(form.capacity),
      };
      // In edit mode, include the (possibly changed) status so the page can PATCH it.
      await onSubmit(payload, isEdit ? form.status : undefined);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title={isEdit ? 'Edit Batch' : 'New Batch'} onClose={onClose} size="lg">
      <form className="form" onSubmit={handleSubmit} noValidate>
        <div className="form__grid">
          <Field label="Batch Code" error={err('batchCode')} required>
            <input className="field__input" value={form.batchCode} onChange={(e) => set('batchCode', e.target.value)} onBlur={() => blur('batchCode')} aria-invalid={Boolean(err('batchCode'))} />
          </Field>
          <Field label="Course" error={err('courseID')} required>
            <select className="field__input" value={form.courseID} onChange={(e) => set('courseID', e.target.value)} onBlur={() => blur('courseID')} disabled={isEdit} aria-invalid={Boolean(err('courseID'))}>
              <option value="">Select a course…</option>
              {courses.map((c) => <option key={c.courseID} value={c.courseID}>{c.courseName} ({c.tradeCode})</option>)}
            </select>
          </Field>
          <Field label="Start Date" error={err('startDate')} required>
            <input type="date" className="field__input" value={form.startDate} onChange={(e) => set('startDate', e.target.value)} onBlur={() => blur('startDate')} aria-invalid={Boolean(err('startDate'))} />
          </Field>
          <Field label="End Date" error={err('endDate')} required>
            <input type="date" className="field__input" value={form.endDate} min={form.startDate || undefined} onChange={(e) => set('endDate', e.target.value)} onBlur={() => blur('endDate')} aria-invalid={Boolean(err('endDate'))} />
          </Field>
          <Field label="Trainer ID" error={err('trainerID')} required>
            <input type="number" min="1" className="field__input" value={form.trainerID} onChange={(e) => set('trainerID', e.target.value)} onBlur={() => blur('trainerID')} aria-invalid={Boolean(err('trainerID'))} />
          </Field>
          <Field label="Venue ID" error={err('venueID')} required>
            <input type="number" min="1" className="field__input" value={form.venueID} onChange={(e) => set('venueID', e.target.value)} onBlur={() => blur('venueID')} aria-invalid={Boolean(err('venueID'))} />
          </Field>
          <Field label="Capacity" error={err('capacity')} required>
            <input type="number" min="1" className="field__input" value={form.capacity} onChange={(e) => set('capacity', e.target.value)} onBlur={() => blur('capacity')} aria-invalid={Boolean(err('capacity'))} />
          </Field>
          {isEdit && (() => {
            // Backend allows only Upcoming → Active → Completed (one-way). Offer the
            // current status (keep) plus its single legal next step; lock terminal.
            const current = batch?.status ?? 'Upcoming';
            const next = BATCH_STATUS_NEXT[current];
            return (
              <Field label="Status">
                {next ? (
                  <select className="field__input" value={form.status} onChange={(e) => set('status', e.target.value)}>
                    <option value={current}>{current} (no change)</option>
                    <option value={next}>Advance to {next}</option>
                  </select>
                ) : (
                  <input className="field__input" value={current} disabled readOnly />
                )}
              </Field>
            );
          })()}
        </div>

        {!isEdit && <p className="form__note">New batches start with status “Upcoming”.</p>}

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={submitting}>Cancel</button>
          <button type="submit" className="btn btn--primary" disabled={!isValid || submitting} aria-busy={submitting}>
            {submitting && <Spinner size={16} inline label="Saving" />}
            {isEdit ? 'Save Changes' : 'Create Batch'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

function Field({ label, error, required, children }) {
  const id = label.replace(/[^a-z0-9]+/gi, '-').toLowerCase();
  return (
    <div className="field">
      <label className="field__label" htmlFor={id}>
        {label}
        {required && <span className="field__req" aria-hidden="true"> *</span>}
      </label>
      {isValidElement(children)
        ? cloneElement(children, { id, 'aria-describedby': error ? `${id}-error` : undefined })
        : children}
      {error && <p id={`${id}-error`} className="field__error" role="alert">{error}</p>}
    </div>
  );
}
