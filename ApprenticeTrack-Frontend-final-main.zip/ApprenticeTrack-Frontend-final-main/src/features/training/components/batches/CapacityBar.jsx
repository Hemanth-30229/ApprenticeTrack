// Capacity utilisation indicator: enrolled vs. capacity.

import { capacityTone } from '../../constants/batch';

export default function CapacityBar({ enrolled = 0, capacity = 0 }) {
  const filled = Number(enrolled) || 0;
  const cap = Number(capacity) || 0;
  const pct = cap > 0 ? Math.min(100, (filled / cap) * 100) : 0;
  const tone = capacityTone(filled, cap);

  return (
    <div className="capacity" role="img" aria-label={`${filled} of ${cap} enrolled`}>
      <div className="capacity__track">
        <div className={`capacity__fill capacity__fill--${tone}`} style={{ width: `${pct}%` }} />
      </div>
      <span className="capacity__label">{filled}/{cap}</span>
    </div>
  );
}
