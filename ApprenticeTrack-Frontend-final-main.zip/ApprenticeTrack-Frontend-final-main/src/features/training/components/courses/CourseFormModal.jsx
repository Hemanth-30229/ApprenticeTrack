// Create / edit a trade course with client-side validation.
// Validates that classroom + OJT weeks add up to the total duration.

import { cloneElement, isValidElement, useMemo, useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import DurationBar from './DurationBar';
import { COURSE_QUALIFICATION_LEVELS, COURSE_STATUSES } from '../../constants/course';
import { COMMON_INDUSTRY_SECTORS } from '../../../placement/constants/employer';

function emptyForm() {
  return {
    courseName: '',
    tradeCode: '',
    sector: '',
    qualificationLevel: '',
    durationWeeks: '',
    classroomWeeks: '',
    ojtWeeks: '',
    videoLink: '',
    status: 'Active',
  };
}

function fromCourse(c) {
  return {
    courseName: c.courseName ?? '',
    tradeCode: c.tradeCode ?? '',
    sector: c.sector ?? '',
    qualificationLevel: c.qualificationLevel ?? '',
    durationWeeks: c.durationWeeks ?? '',
    classroomWeeks: c.classroomWeeks ?? '',
    ojtWeeks: c.ojtWeeks ?? '',
    videoLink: c.videoLink ?? '',
    status: c.status ?? 'Active',
  };
}

function intField(value) {
  return /^\d+$/.test(String(value).trim());
}

function validate(f) {
  const e = {};
  if (!f.courseName.trim()) e.courseName = 'Course name is required';
  if (!f.tradeCode.trim()) e.tradeCode = 'Trade code is required';
  if (!f.sector.trim()) e.sector = 'Sector is required';
  if (!f.qualificationLevel) e.qualificationLevel = 'Qualification level is required';

  if (!intField(f.durationWeeks) || Number(f.durationWeeks) < 1)
    e.durationWeeks = 'Enter a whole number of weeks (min 1)';
  if (!intField(f.classroomWeeks)) e.classroomWeeks = 'Enter a whole number';
  if (!intField(f.ojtWeeks)) e.ojtWeeks = 'Enter a whole number';

  if (!e.durationWeeks && !e.classroomWeeks && !e.ojtWeeks) {
    const sum = Number(f.classroomWeeks) + Number(f.ojtWeeks);
    if (sum !== Number(f.durationWeeks))
      e.ojtWeeks = `Classroom + OJT (${sum}) must equal total duration (${f.durationWeeks})`;
  }
  if (f.videoLink.trim() && !/^https?:\/\//i.test(f.videoLink.trim()))
    e.videoLink = 'Enter a full URL starting with http:// or https://';
  return e;
}

export default function CourseFormModal({ course, onClose, onSubmit }) {
  const isEdit = Boolean(course);
  const [form, setForm] = useState(() => (isEdit ? fromCourse(course) : emptyForm()));
  const [touched, setTouched] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const errors = useMemo(() => validate(form), [form]);
  const isValid = Object.keys(errors).length === 0;
  const set = (f, v) => setForm((s) => ({ ...s, [f]: v }));
  const blur = (f) => setTouched((t) => ({ ...t, [f]: true }));
  const err = (f) => (touched[f] && errors[f] ? errors[f] : '');

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched(Object.keys(form).reduce((a, k) => ({ ...a, [k]: true }), {}));
    if (!isValid) return;
    setSubmitting(true);
    try {
      const payload = {
        courseName: form.courseName.trim(),
        tradeCode: form.tradeCode.trim(),
        sector: form.sector.trim(),
        qualificationLevel: form.qualificationLevel,
        durationWeeks: Number(form.durationWeeks),
        classroomWeeks: Number(form.classroomWeeks),
        ojtWeeks: Number(form.ojtWeeks),
        videoLink: form.videoLink.trim() || null,
      };
      // The update contract (TradeCourseUpdateRequestDTO) requires status;
      // the create contract does not accept it. Only send it on edit.
      if (isEdit) payload.status = form.status;
      await onSubmit(payload);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title={isEdit ? 'Edit Trade Course' : 'New Trade Course'} onClose={onClose} size="lg">
      <form className="form" onSubmit={handleSubmit} noValidate>
        <div className="form__grid">
          <Field label="Course Name" error={err('courseName')} required>
            <input type="text" className="field__input" value={form.courseName} onChange={(e) => set('courseName', e.target.value)} onBlur={() => blur('courseName')} aria-invalid={Boolean(err('courseName'))} />
          </Field>
          <Field label="Trade Code" error={err('tradeCode')} required>
            <input type="text" className="field__input" value={form.tradeCode} onChange={(e) => set('tradeCode', e.target.value)} onBlur={() => blur('tradeCode')} aria-invalid={Boolean(err('tradeCode'))} />
          </Field>
          <Field label="Sector" error={err('sector')} required>
            <input type="text" className="field__input" list="course-sectors" value={form.sector} onChange={(e) => set('sector', e.target.value)} onBlur={() => blur('sector')} aria-invalid={Boolean(err('sector'))} />
            <datalist id="course-sectors">
              {COMMON_INDUSTRY_SECTORS.map((s) => <option key={s} value={s} />)}
            </datalist>
          </Field>
          <Field label="Qualification Level" error={err('qualificationLevel')} required>
            <select className="field__input" value={form.qualificationLevel} onChange={(e) => set('qualificationLevel', e.target.value)} onBlur={() => blur('qualificationLevel')} aria-invalid={Boolean(err('qualificationLevel'))}>
              <option value="">Select…</option>
              {COURSE_QUALIFICATION_LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
          </Field>
          <Field label="Total Duration (weeks)" error={err('durationWeeks')} required>
            <input type="number" min="1" className="field__input" value={form.durationWeeks} onChange={(e) => set('durationWeeks', e.target.value)} onBlur={() => blur('durationWeeks')} aria-invalid={Boolean(err('durationWeeks'))} />
          </Field>
          <Field label="Classroom (weeks)" error={err('classroomWeeks')} required>
            <input type="number" min="0" className="field__input" value={form.classroomWeeks} onChange={(e) => set('classroomWeeks', e.target.value)} onBlur={() => blur('classroomWeeks')} aria-invalid={Boolean(err('classroomWeeks'))} />
          </Field>
          <Field label="OJT (weeks)" error={err('ojtWeeks')} required>
            <input type="number" min="0" className="field__input" value={form.ojtWeeks} onChange={(e) => set('ojtWeeks', e.target.value)} onBlur={() => blur('ojtWeeks')} aria-invalid={Boolean(err('ojtWeeks'))} />
          </Field>
        </div>

        <div className="field">
          <label className="field__label" htmlFor="video-link">Video Link (optional)</label>
          <input
            id="video-link"
            type="url"
            className="field__input"
            placeholder="https://www.youtube.com/watch?v=…"
            value={form.videoLink}
            onChange={(e) => set('videoLink', e.target.value)}
            onBlur={() => blur('videoLink')}
            aria-invalid={Boolean(err('videoLink'))}
          />
          {err('videoLink') && <p className="field__error" role="alert">{err('videoLink')}</p>}
          <p className="field__hint">Learning video shown to enrolled trainees (YouTube or a direct video URL).</p>
        </div>

        {isEdit && (
          <div className="field">
            <label className="field__label" htmlFor="course-status">Status</label>
            <select
              id="course-status"
              className="field__input"
              value={form.status}
              onChange={(e) => set('status', e.target.value)}
            >
              {COURSE_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
            <p className="field__hint">Discontinued courses stay on record but can no longer take new enrolments.</p>
          </div>
        )}

        <div className="field field--full">
          <span className="field__label">Duration Breakdown</span>
          <DurationBar
            classroomWeeks={form.classroomWeeks}
            ojtWeeks={form.ojtWeeks}
            durationWeeks={form.durationWeeks}
          />
        </div>

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={submitting}>Cancel</button>
          <button type="submit" className="btn btn--primary" disabled={!isValid || submitting} aria-busy={submitting}>
            {submitting && <Spinner size={16} inline label="Saving" />}
            {isEdit ? 'Save Changes' : 'Create Course'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

function Field({ label, error, required, children }) {
  const id = label.replace(/[^a-z0-9]+/gi, '-').toLowerCase();
  return (
    <div className="field">
      <label className="field__label" htmlFor={id}>
        {label}
        {required && <span className="field__req" aria-hidden="true"> *</span>}
      </label>
      {isValidElement(children)
        ? cloneElement(children, { id, 'aria-describedby': error ? `${id}-error` : undefined })
        : children}
      {error && <p id={`${id}-error`} className="field__error" role="alert">{error}</p>}
    </div>
  );
}
