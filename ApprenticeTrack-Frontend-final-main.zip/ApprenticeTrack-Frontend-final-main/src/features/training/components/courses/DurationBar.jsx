// Visual breakdown of a course's duration: classroom vs OJT weeks.

export default function DurationBar({ classroomWeeks = 0, ojtWeeks = 0, durationWeeks }) {
  const classroom = Number(classroomWeeks) || 0;
  const ojt = Number(ojtWeeks) || 0;
  const total = classroom + ojt || Number(durationWeeks) || 0;

  if (total === 0) {
    return <span className="text-muted duration-bar__empty">—</span>;
  }

  const classroomPct = (classroom / total) * 100;
  const ojtPct = (ojt / total) * 100;

  return (
    <div
      className="duration-bar"
      role="img"
      aria-label={`Duration: ${classroom} classroom weeks, ${ojt} OJT weeks`}
    >
      <div className="duration-bar__track">
        {classroom > 0 && (
          <div className="duration-bar__seg duration-bar__seg--classroom" style={{ width: `${classroomPct}%` }} />
        )}
        {ojt > 0 && (
          <div className="duration-bar__seg duration-bar__seg--ojt" style={{ width: `${ojtPct}%` }} />
        )}
      </div>
      <div className="duration-bar__legend">
        <span><span className="dot dot--classroom" /> Classroom {classroom}w</span>
        <span><span className="dot dot--ojt" /> OJT {ojt}w</span>
      </div>
    </div>
  );
}
