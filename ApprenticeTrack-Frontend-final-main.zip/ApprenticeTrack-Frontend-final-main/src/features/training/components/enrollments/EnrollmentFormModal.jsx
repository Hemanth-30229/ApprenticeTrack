// New enrollment form: searchable trainee, course dropdown, capacity-aware
// batch dropdown (filtered by course), editable enrollment date, and a
// read-only auto-calculated expected completion date.

import { useMemo, useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import SearchableSelect from '../../../../shared/ui/SearchableSelect';
import { listTrainees } from '../../api/trainees';
import { formatDate } from '../../../../shared/format';

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function addWeeks(isoDate, weeks) {
  if (!isoDate || !weeks) return '';
  const d = new Date(isoDate);
  if (Number.isNaN(d.getTime())) return '';
  d.setDate(d.getDate() + weeks * 7);
  return d.toISOString().slice(0, 10);
}

async function fetchTrainees(query) {
  const page = await listTrainees({ name: query || undefined, page: 0, size: 10, sort: 'name,asc' });
  return (page.content || []).map((t) => ({
    value: t.traineeID,
    label: `${t.name} (#${t.traineeID})`,
    name: t.name,
  }));
}

export default function EnrollmentFormModal({ courses, batches, onClose, onSubmit }) {
  const [traineeID, setTraineeID] = useState(null);
  const [traineeName, setTraineeName] = useState('');
  const [courseID, setCourseID] = useState('');
  const [batchID, setBatchID] = useState('');
  const [enrollmentDate, setEnrollmentDate] = useState(todayISO());
  const [touched, setTouched] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const course = courses.find((c) => String(c.courseID) === String(courseID));
  const batchOptions = useMemo(
    () => batches.filter((b) => String(b.courseID) === String(courseID)),
    [batches, courseID]
  );

  const expectedCompletion = useMemo(
    () => addWeeks(enrollmentDate, course?.durationWeeks),
    [enrollmentDate, course]
  );

  const errors = {
    trainee: traineeID ? '' : 'Please select a trainee',
    course: courseID ? '' : 'Please select a course',
    batch: batchID ? '' : 'Please select a batch',
    enrollmentDate: enrollmentDate ? '' : 'Enrollment date is required',
  };
  const isValid = Object.values(errors).every((e) => !e);
  const err = (f) => (touched[f] && errors[f] ? errors[f] : '');

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched({ trainee: true, course: true, batch: true, enrollmentDate: true });
    if (!isValid) return;
    setSubmitting(true);
    try {
      await onSubmit({
        traineeID: Number(traineeID),
        courseID: Number(courseID),
        batchID: Number(batchID),
        enrollmentDate,
      });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="New Enrollment" onClose={onClose} size="md">
      <form className="form" onSubmit={handleSubmit} noValidate>
        <div className="field">
          <label className="field__label" htmlFor="trainee">
            Trainee <span className="field__req" aria-hidden="true">*</span>
          </label>
          <SearchableSelect
            value={traineeID}
            selectedLabel={traineeName}
            placeholder="Search trainees by name…"
            fetchOptions={fetchTrainees}
            invalid={Boolean(err('trainee'))}
            onSelect={(opt) => {
              setTraineeID(opt.value);
              setTraineeName(opt.name);
              setTouched((t) => ({ ...t, trainee: true }));
            }}
          />
          {err('trainee') && <p className="field__error" role="alert">{err('trainee')}</p>}
        </div>

        <div className="field">
          <label className="field__label" htmlFor="course">
            Course <span className="field__req" aria-hidden="true">*</span>
          </label>
          <select
            id="course"
            className="field__input"
            value={courseID}
            onChange={(e) => {
              setCourseID(e.target.value);
              setBatchID(''); // reset batch when course changes
              setTouched((t) => ({ ...t, course: true }));
            }}
            aria-invalid={Boolean(err('course'))}
          >
            <option value="">Select a course…</option>
            {courses.map((c) => (
              <option key={c.courseID} value={c.courseID}>
                {c.courseName} ({c.tradeCode})
              </option>
            ))}
          </select>
          {err('course') && <p className="field__error" role="alert">{err('course')}</p>}
        </div>

        <div className="field">
          <label className="field__label" htmlFor="batch">
            Batch <span className="field__req" aria-hidden="true">*</span>
          </label>
          <select
            id="batch"
            className="field__input"
            value={batchID}
            disabled={!courseID}
            onChange={(e) => {
              setBatchID(e.target.value);
              setTouched((t) => ({ ...t, batch: true }));
            }}
            aria-invalid={Boolean(err('batch'))}
          >
            <option value="">
              {courseID ? 'Select a batch…' : 'Select a course first'}
            </option>
            {batchOptions.map((b) => {
              const enrolled = b.enrolledTraineeCount ?? 0;
              const full = enrolled >= b.capacity;
              return (
                <option key={b.batchID} value={b.batchID} disabled={full}>
                  {b.batchCode} ({enrolled}/{b.capacity} filled){full ? ' — Full' : ''}
                </option>
              );
            })}
          </select>
          {courseID && batchOptions.length === 0 && (
            <p className="field__hint">No batches exist for this course yet.</p>
          )}
          {err('batch') && <p className="field__error" role="alert">{err('batch')}</p>}
        </div>

        <div className="form__grid">
          <div className="field">
            <label className="field__label" htmlFor="enrollmentDate">
              Enrollment Date <span className="field__req" aria-hidden="true">*</span>
            </label>
            <input
              id="enrollmentDate"
              type="date"
              className="field__input"
              value={enrollmentDate}
              onChange={(e) => setEnrollmentDate(e.target.value)}
              aria-invalid={Boolean(err('enrollmentDate'))}
            />
            {err('enrollmentDate') && (
              <p className="field__error" role="alert">{err('enrollmentDate')}</p>
            )}
          </div>

          <div className="field">
            <label className="field__label" htmlFor="expectedCompletion">
              Expected Completion
            </label>
            <input
              id="expectedCompletion"
              type="text"
              className="field__input"
              value={expectedCompletion ? formatDate(expectedCompletion) : '—'}
              readOnly
              aria-readonly="true"
            />
            <p className="field__hint">
              {course
                ? `Auto-calculated from course duration (${course.durationWeeks} weeks).`
                : 'Select a course to calculate.'}
            </p>
          </div>
        </div>

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={submitting}>
            Cancel
          </button>
          <button type="submit" className="btn btn--primary" disabled={!isValid || submitting} aria-busy={submitting}>
            {submitting && <Spinner size={16} inline label="Enrolling" />}
            Create Enrollment
          </button>
        </div>
      </form>
    </Modal>
  );
}
