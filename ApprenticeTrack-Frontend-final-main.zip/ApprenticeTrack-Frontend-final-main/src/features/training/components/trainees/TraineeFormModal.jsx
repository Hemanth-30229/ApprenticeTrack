// Create / edit trainee form in a modal, with client-side validation.
//
// Create mode collects BOTH the login account (email + password, role=Trainee)
// and the trainee profile. The page creates the User account first, then the
// Trainee linked to it — so a new trainee can immediately log in. Edit mode only
// sends the fields the API's PUT accepts (name, address, phone, educationLevel,
// emergencyContact); DOB, gender and status are read-only after creation.

import { cloneElement, isValidElement, useMemo, useState } from 'react';
import Modal from '../../../../shared/ui/Modal';
import Spinner from '../../../../shared/Spinner';
import { PHONE_RE, TRAINEE_GENDERS } from '../../constants/trainee';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const EDUCATION_SUGGESTIONS = [
  '10th Pass',
  '12th Pass',
  'ITI',
  'Diploma',
  'Graduate',
  'Post Graduate',
];

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function emptyForm() {
  return {
    email: '',
    password: '',
    instituteID: '',
    name: '',
    dateOfBirth: '',
    gender: '',
    educationLevel: '',
    address: '',
    phone: '',
    emergencyName: '',
    emergencyPhone: '',
  };
}

function fromTrainee(t) {
  return {
    userID: t.userID ?? '',
    name: t.name ?? '',
    dateOfBirth: t.dateOfBirth ?? '',
    gender: t.gender ?? '',
    educationLevel: t.educationLevel ?? '',
    address: t.address ?? '',
    phone: t.phone ?? '',
    emergencyName: t.emergencyContact?.name ?? '',
    emergencyPhone: t.emergencyContact?.phone ?? '',
  };
}

function validate(form, isEdit) {
  const e = {};
  if (!isEdit) {
    if (!form.email.trim()) e.email = 'Email is required';
    else if (!EMAIL_RE.test(form.email.trim())) e.email = 'Enter a valid email address';
    if (!form.password) e.password = 'Password is required';
    else if (form.password.length < 8) e.password = 'Password must be at least 8 characters';
    if (String(form.instituteID).trim() === '') e.instituteID = 'Institute ID is required';
    else if (!/^\d+$/.test(String(form.instituteID).trim())) e.instituteID = 'Institute ID must be a number';
    if (!form.dateOfBirth) e.dateOfBirth = 'Date of birth is required';
    else if (form.dateOfBirth >= todayISO()) e.dateOfBirth = 'Date of birth must be in the past';
    if (!form.gender) e.gender = 'Gender is required';
  }
  if (!form.name.trim()) e.name = 'Name is required';
  if (!form.educationLevel.trim()) e.educationLevel = 'Education level is required';
  if (!form.address.trim()) e.address = 'Address is required';
  if (!form.phone.trim()) e.phone = 'Phone is required';
  else if (!PHONE_RE.test(form.phone.trim())) e.phone = 'Enter a valid 10-digit mobile number';
  if (!form.emergencyName.trim()) e.emergencyName = 'Emergency contact name is required';
  if (!form.emergencyPhone.trim()) e.emergencyPhone = 'Emergency contact phone is required';
  else if (!PHONE_RE.test(form.emergencyPhone.trim()))
    e.emergencyPhone = 'Enter a valid 10-digit mobile number';
  return e;
}

export default function TraineeFormModal({ trainee, onClose, onSubmit }) {
  const isEdit = Boolean(trainee);
  const [form, setForm] = useState(() => (isEdit ? fromTrainee(trainee) : emptyForm()));
  const [touched, setTouched] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const errors = useMemo(() => validate(form, isEdit), [form, isEdit]);
  const isValid = Object.keys(errors).length === 0;

  function set(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }
  function blur(field) {
    setTouched((t) => ({ ...t, [field]: true }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched(
      Object.keys(form).reduce((acc, k) => ({ ...acc, [k]: true }), {})
    );
    if (!isValid) return;

    const emergencyContact = {
      name: form.emergencyName.trim(),
      phone: form.emergencyPhone.trim(),
    };

    const payload = isEdit
      ? {
          name: form.name.trim(),
          address: form.address.trim(),
          phone: form.phone.trim(),
          educationLevel: form.educationLevel.trim(),
          emergencyContact,
        }
      : {
          // account (used by the page to create the login User first)
          email: form.email.trim(),
          password: form.password,
          instituteID: Number(form.instituteID),
          // trainee profile
          name: form.name.trim(),
          dateOfBirth: form.dateOfBirth,
          gender: form.gender,
          educationLevel: form.educationLevel.trim(),
          address: form.address.trim(),
          phone: form.phone.trim(),
          emergencyContact,
        };

    setSubmitting(true);
    try {
      await onSubmit(payload);
    } finally {
      setSubmitting(false);
    }
  }

  const err = (field) => (touched[field] && errors[field] ? errors[field] : '');

  return (
    <Modal title={isEdit ? 'Edit Trainee' : 'Add Trainee'} onClose={onClose} size="lg">
      <form className="form" onSubmit={handleSubmit} noValidate>
        {!isEdit && (
          <p className="form__note form__note--top">
            Creating a trainee also creates their login account. They sign in with the
            email and password set below.
          </p>
        )}
        <div className="form__grid">
          {!isEdit && (
            <>
              <Field label="Email" error={err('email')} required>
                <input
                  type="email"
                  autoComplete="off"
                  className="field__input"
                  value={form.email}
                  onChange={(e) => set('email', e.target.value)}
                  onBlur={() => blur('email')}
                  aria-invalid={Boolean(err('email'))}
                />
              </Field>
              <Field label="Password" error={err('password')} required>
                <input
                  type="password"
                  autoComplete="new-password"
                  className="field__input"
                  value={form.password}
                  onChange={(e) => set('password', e.target.value)}
                  onBlur={() => blur('password')}
                  aria-invalid={Boolean(err('password'))}
                />
              </Field>
              <Field label="Institute ID" error={err('instituteID')} required>
                <input
                  type="number"
                  min="1"
                  className="field__input"
                  value={form.instituteID}
                  onChange={(e) => set('instituteID', e.target.value)}
                  onBlur={() => blur('instituteID')}
                  aria-invalid={Boolean(err('instituteID'))}
                />
              </Field>
            </>
          )}

          <Field label="Name" error={err('name')} required>
            <input
              type="text"
              className="field__input"
              value={form.name}
              onChange={(e) => set('name', e.target.value)}
              onBlur={() => blur('name')}
              aria-invalid={Boolean(err('name'))}
            />
          </Field>

          <Field label="Date of Birth" error={err('dateOfBirth')} required>
            <input
              type="date"
              className="field__input"
              max={todayISO()}
              value={form.dateOfBirth}
              onChange={(e) => set('dateOfBirth', e.target.value)}
              onBlur={() => blur('dateOfBirth')}
              disabled={isEdit}
              aria-invalid={Boolean(err('dateOfBirth'))}
            />
          </Field>

          <Field label="Gender" error={err('gender')} required>
            <select
              className="field__input"
              value={form.gender}
              onChange={(e) => set('gender', e.target.value)}
              onBlur={() => blur('gender')}
              disabled={isEdit}
              aria-invalid={Boolean(err('gender'))}
            >
              <option value="">Select…</option>
              {TRAINEE_GENDERS.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          </Field>

          <Field label="Education Level" error={err('educationLevel')} required>
            <input
              type="text"
              className="field__input"
              list="education-levels"
              value={form.educationLevel}
              onChange={(e) => set('educationLevel', e.target.value)}
              onBlur={() => blur('educationLevel')}
              aria-invalid={Boolean(err('educationLevel'))}
            />
            <datalist id="education-levels">
              {EDUCATION_SUGGESTIONS.map((x) => (
                <option key={x} value={x} />
              ))}
            </datalist>
          </Field>

          <Field label="Phone" error={err('phone')} required>
            <input
              type="tel"
              className="field__input"
              value={form.phone}
              onChange={(e) => set('phone', e.target.value)}
              onBlur={() => blur('phone')}
              aria-invalid={Boolean(err('phone'))}
            />
          </Field>

          <Field label="Address" error={err('address')} required full>
            <textarea
              className="field__input"
              rows={2}
              value={form.address}
              onChange={(e) => set('address', e.target.value)}
              onBlur={() => blur('address')}
              aria-invalid={Boolean(err('address'))}
            />
          </Field>

          <Field label="Emergency Contact Name" error={err('emergencyName')} required>
            <input
              type="text"
              className="field__input"
              value={form.emergencyName}
              onChange={(e) => set('emergencyName', e.target.value)}
              onBlur={() => blur('emergencyName')}
              aria-invalid={Boolean(err('emergencyName'))}
            />
          </Field>

          <Field label="Emergency Contact Phone" error={err('emergencyPhone')} required>
            <input
              type="tel"
              className="field__input"
              value={form.emergencyPhone}
              onChange={(e) => set('emergencyPhone', e.target.value)}
              onBlur={() => blur('emergencyPhone')}
              aria-invalid={Boolean(err('emergencyPhone'))}
            />
          </Field>
        </div>

        {isEdit && (
          <p className="form__note">
            Date of birth and gender cannot be changed after creation.
          </p>
        )}

        <div className="modal__actions">
          <button type="button" className="btn btn--secondary" onClick={onClose} disabled={submitting}>
            Cancel
          </button>
          <button
            type="submit"
            className="btn btn--primary"
            disabled={!isValid || submitting}
            aria-busy={submitting}
          >
            {submitting && <Spinner size={16} inline label="Saving" />}
            {isEdit ? 'Save Changes' : 'Create Trainee'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

function Field({ label, error, required, full, children }) {
  const id = label.replace(/\s+/g, '-').toLowerCase();
  return (
    <div className={`field ${full ? 'field--full' : ''}`}>
      <label className="field__label" htmlFor={id}>
        {label}
        {required && <span className="field__req" aria-hidden="true"> *</span>}
      </label>
      {/* clone to attach id/aria-describedby */}
      {inject(children, id, error)}
      {error && (
        <p id={`${id}-error`} className="field__error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

// Attach id + aria-describedby to the single form control child.
function inject(child, id, error) {
  if (!isValidElement(child)) return child;
  return cloneElement(child, {
    id,
    'aria-describedby': error ? `${id}-error` : undefined,
  });
}
