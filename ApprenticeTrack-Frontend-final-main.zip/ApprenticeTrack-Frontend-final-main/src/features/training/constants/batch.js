// Training batch enums + tones.

export const BATCH_STATUSES = ['Upcoming', 'Active', 'Completed'];

// Backend enforces a one-way lifecycle: Upcoming → Active → Completed. This maps
// each status to its only legal next status (null = terminal, no change allowed).
export const BATCH_STATUS_NEXT = {
  Upcoming: 'Active',
  Active: 'Completed',
  Completed: null,
};

export const BATCH_STATUS_TONE = {
  Upcoming: 'info', // blue
  Active: 'success', // green
  Completed: 'neutral', // grey
};

// Capacity utilisation colour bands.
export function capacityTone(enrolled, capacity) {
  if (!capacity || capacity <= 0) return 'neutral';
  const pct = (enrolled / capacity) * 100;
  if (pct >= 100) return 'danger';
  if (pct >= 80) return 'warning';
  return 'success';
}
