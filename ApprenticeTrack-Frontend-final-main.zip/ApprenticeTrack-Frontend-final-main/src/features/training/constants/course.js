// Trade course + competency unit enums and tones.

export const COURSE_QUALIFICATION_LEVELS = ['Level1', 'Level2', 'Level3', 'Level4'];

export const COURSE_STATUSES = ['Active', 'Discontinued'];
export const COURSE_STATUS_TONE = {
  Active: 'success',
  Discontinued: 'neutral',
};
