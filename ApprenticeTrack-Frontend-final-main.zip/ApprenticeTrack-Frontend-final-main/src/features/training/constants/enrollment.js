// Course enrollment enums, tones, and status transitions.

export const ENROLLMENT_STATUSES = [
  'Enrolled',
  'OJTInProgress',
  'AssessmentPending',
  'Completed',
  'Withdrawn',
];

export const ENROLLMENT_STATUS_LABEL = {
  Enrolled: 'Enrolled',
  OJTInProgress: 'OJT In Progress',
  AssessmentPending: 'Assessment Pending',
  Completed: 'Completed',
  Withdrawn: 'Withdrawn',
};

export const ENROLLMENT_STATUS_TONE = {
  Enrolled: 'info',
  OJTInProgress: 'warning',
  AssessmentPending: 'pending',
  Completed: 'success',
  Withdrawn: 'neutral',
};

// Forward flow + withdraw from any active state. Backend validates transitions;
// invalid ones surface as an error toast.
export const ENROLLMENT_STATUS_TRANSITIONS = {
  Enrolled: [
    { to: 'OJTInProgress', label: 'Start OJT', tone: 'primary' },
    { to: 'Withdrawn', label: 'Withdraw', tone: 'danger' },
  ],
  OJTInProgress: [
    { to: 'AssessmentPending', label: 'Mark Assessment Pending', tone: 'primary' },
    { to: 'Withdrawn', label: 'Withdraw', tone: 'danger' },
  ],
  AssessmentPending: [
    { to: 'Completed', label: 'Complete', tone: 'primary' },
    { to: 'Withdrawn', label: 'Withdraw', tone: 'danger' },
  ],
  Completed: [],
  Withdrawn: [],
};
