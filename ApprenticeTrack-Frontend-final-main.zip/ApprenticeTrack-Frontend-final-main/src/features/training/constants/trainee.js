// Trainee enums (exact case-sensitive backend values) + status badge tones.

export const TRAINEE_STATUSES = ['Active', 'Placed', 'Completed', 'Dropout'];
export const TRAINEE_GENDERS = ['Male', 'Female', 'Other'];

// Status badge colour mapping (per acceptance criteria).
export const TRAINEE_STATUS_TONE = {
  Active: 'success', // green
  Placed: 'info', // blue
  Completed: 'neutral', // grey
  Dropout: 'danger', // red
};

// Phone: 10-digit Indian mobile.
export const PHONE_RE = /^[6-9]\d{9}$/;
