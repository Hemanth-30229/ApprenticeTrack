// Batches list (admin). List-page pattern (see PlacementListPage for the annotated
// reference). A batch belongs to a course; CapacityBar shows how full it is.
import { useCallback, useEffect, useMemo, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import ConfirmDialog from '../../../shared/ui/ConfirmDialog';
import CapacityBar from '../components/batches/CapacityBar';
import BatchFormModal from '../components/batches/BatchFormModal';
import { useToast } from '../../../shared/toast/ToastContext';
import {
  createBatch,
  deleteBatch,
  listBatches,
  updateBatch,
  updateBatchStatus,
} from '../api/batches';
import { listCourses } from '../api/courses';
import { apiErrorMessage } from '../../../shared/api/errors';
import { BATCH_STATUSES, BATCH_STATUS_TONE } from '../constants/batch';
import { formatDate } from '../../../shared/format';

const PAGE_SIZE = 10;

export default function BatchListPage() {
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);

  const [courses, setCourses] = useState([]);
  const [courseFilter, setCourseFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [removing, setRemoving] = useState(null);
  const [removeBusy, setRemoveBusy] = useState(false);

  useEffect(() => {
    listCourses({ status: undefined, size: 200 })
      .then((p) => setCourses(p.content || []))
      .catch(() => {});
  }, []);

  const courseName = useMemo(() => {
    const map = {};
    courses.forEach((c) => { map[c.courseID] = c.courseName; });
    return map;
  }, [courses]);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await listBatches({
        courseID: courseFilter || undefined,
        status: statusFilter || undefined,
        fromDate: fromDate || undefined,
        toDate: toDate || undefined,
        page,
        size: PAGE_SIZE,
        sort: 'startDate,asc',
      });
      setRows(data.content || []);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
    } catch {
      setError('Could not load batches. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [courseFilter, statusFilter, fromDate, toDate, page]);

  useEffect(() => {
    load();
  }, [load]);

  async function handleSubmit(payload, newStatus) {
    try {
      if (editing) {
        await updateBatch(editing.batchID, payload);
        if (newStatus && newStatus !== editing.status) {
          await updateBatchStatus(editing.batchID, newStatus);
        }
        toast.success('Batch updated successfully.');
      } else {
        await createBatch(payload);
        toast.success('Batch created successfully.');
      }
      setFormOpen(false);
      setEditing(null);
      if (!editing && page !== 0) setPage(0);
      else load();
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Failed to save batch.'));
      throw err;
    }
  }

  async function handleRemove() {
    setRemoveBusy(true);
    try {
      await deleteBatch(removing.batchID);
      toast.success(`Batch "${removing.batchCode}" deleted.`);
      setRemoving(null);
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to delete batch.');
    } finally {
      setRemoveBusy(false);
    }
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Batches</h1>
            <p className="page__subtitle">Manage training batches and cohort assignments.</p>
          </div>
          <button type="button" className="btn btn--primary" onClick={() => { setEditing(null); setFormOpen(true); }}>
            + New Batch
          </button>
        </div>

        <div className="toolbar">
          <div className="toolbar__filter">
            <label htmlFor="course-filter" className="field__label field__label--sm">Course</label>
            <select id="course-filter" className="field__input" value={courseFilter} onChange={(e) => { setCourseFilter(e.target.value); setPage(0); }}>
              <option value="">All courses</option>
              {courses.map((c) => <option key={c.courseID} value={c.courseID}>{c.courseName}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="field__label field__label--sm">Status</label>
            <select id="status-filter" className="field__input" value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setPage(0); }}>
              <option value="">All statuses</option>
              {BATCH_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="from-date" className="field__label field__label--sm">From</label>
            <input id="from-date" type="date" className="field__input" value={fromDate} max={toDate || undefined} onChange={(e) => { setFromDate(e.target.value); setPage(0); }} />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="to-date" className="field__label field__label--sm">To</label>
            <input id="to-date" type="date" className="field__input" value={toDate} min={fromDate || undefined} onChange={(e) => { setToDate(e.target.value); setPage(0); }} />
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Batch Code</th>
                <th scope="col">Course</th>
                <th scope="col">Start</th>
                <th scope="col">End</th>
                <th scope="col">Capacity</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
              ) : error ? (
                <tr>
                  <td colSpan={7} className="table__state table__state--error">
                    {error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button>
                  </td>
                </tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan={7} className="table__state">No batches found.</td></tr>
              ) : (
                rows.map((b) => (
                  <tr key={b.batchID}>
                    <td data-label="Batch Code">{b.batchCode}</td>
                    <td data-label="Course">{courseName[b.courseID] || `Course #${b.courseID}`}</td>
                    <td data-label="Start">{formatDate(b.startDate)}</td>
                    <td data-label="End">{formatDate(b.endDate)}</td>
                    <td data-label="Capacity"><CapacityBar enrolled={b.enrolledTraineeCount} capacity={b.capacity} /></td>
                    <td data-label="Status"><StatusBadge status={b.status} tone={BATCH_STATUS_TONE[b.status] || 'neutral'} /></td>
                    <td data-label="Actions" className="table__actions">
                      <button type="button" className="btn btn--secondary btn--sm" onClick={() => { setEditing(b); setFormOpen(true); }}>Edit</button>
                      <button type="button" className="btn btn--danger-ghost btn--sm" onClick={() => setRemoving(b)}>Delete</button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <span className="pagination__info">{pageInfo.totalElements > 0 ? `${pageInfo.totalElements} total` : ' '}</span>
          <div className="pagination__controls">
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={loading || page === 0}>← Previous</button>
            <span className="pagination__page">Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}</span>
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => p + 1)} disabled={loading || page + 1 >= pageInfo.totalPages}>Next →</button>
          </div>
        </div>
      </main>

      {formOpen && (
        <BatchFormModal
          batch={editing}
          courses={courses}
          onClose={() => { setFormOpen(false); setEditing(null); }}
          onSubmit={handleSubmit}
        />
      )}


      {removing && (
        <ConfirmDialog
          title="Delete batch?"
          message={`Delete batch "${removing.batchCode}"? This cannot be undone.`}
          confirmLabel="Delete"
          busy={removeBusy}
          onConfirm={handleRemove}
          onCancel={() => (removeBusy ? null : setRemoving(null))}
        />
      )}
    </div>
  );
}
