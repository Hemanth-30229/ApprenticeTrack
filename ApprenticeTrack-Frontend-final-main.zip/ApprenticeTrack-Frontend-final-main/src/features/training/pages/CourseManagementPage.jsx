// Course management (admin). List-page pattern (see PlacementListPage for the
// annotated reference). Courses carry the duration split: classroom + OJT weeks.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import ConfirmDialog from '../../../shared/ui/ConfirmDialog';
import DurationBar from '../components/courses/DurationBar';
import CourseFormModal from '../components/courses/CourseFormModal';
import { useToast } from '../../../shared/toast/ToastContext';
import { createCourse, deleteCourse, listCourses, updateCourse } from '../api/courses';
import { COMMON_INDUSTRY_SECTORS } from '../../placement/constants/employer';
import {
  COURSE_QUALIFICATION_LEVELS,
  COURSE_STATUSES,
  COURSE_STATUS_TONE,
} from '../constants/course';

const PAGE_SIZE = 10;

export default function CourseManagementPage() {
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);

  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [sector, setSector] = useState('');
  const [level, setLevel] = useState('');
  const [status, setStatus] = useState('');
  const [seenSectors, setSeenSectors] = useState([]);

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [removing, setRemoving] = useState(null);
  const [removeBusy, setRemoveBusy] = useState(false);

  const debounceRef = useRef(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      // status omitted returns all; we pass a value only when filtering.
      const data = await listCourses({
        sector: sector || undefined,
        qualificationLevel: level || undefined,
        status: status || '',
        page,
        size: PAGE_SIZE,
        sort: 'courseName,asc',
      });
      const content = data.content || [];
      setRows(content);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
      setSeenSectors((prev) => {
        const s = new Set(prev);
        content.forEach((c) => c.sector && s.add(c.sector));
        return Array.from(s);
      });
    } catch {
      setError('Could not load courses. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [sector, level, status, page]);

  useEffect(() => {
    load();
  }, [load]);

  const sectorOptions = useMemo(() => {
    const s = new Set([...COMMON_INDUSTRY_SECTORS, ...seenSectors]);
    return Array.from(s).sort((a, b) => a.localeCompare(b));
  }, [seenSectors]);

  // Client-side search on course name / trade code (no name param server-side).
  const visibleRows = useMemo(() => {
    if (!search) return rows;
    return rows.filter(
      (c) =>
        (c.courseName || '').toLowerCase().includes(search) ||
        (c.tradeCode || '').toLowerCase().includes(search)
    );
  }, [rows, search]);

  function onSearchChange(value) {
    setSearchInput(value);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => setSearch(value.trim().toLowerCase()), 300);
  }

  async function handleSubmit(payload) {
    try {
      if (editing) {
        await updateCourse(editing.courseID, payload);
        toast.success('Course updated successfully.');
      } else {
        await createCourse(payload);
        toast.success('Course created successfully.');
      }
      setFormOpen(false);
      setEditing(null);
      if (!editing && page !== 0) setPage(0);
      else load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to save course.');
      throw err;
    }
  }

  async function handleRemove() {
    setRemoveBusy(true);
    try {
      await deleteCourse(removing.courseID);
      toast.success(`Course "${removing.courseName}" deleted.`);
      setRemoving(null);
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to delete course.');
    } finally {
      setRemoveBusy(false);
    }
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Courses &amp; Curriculum</h1>
            <p className="page__subtitle">Manage trade courses and their competency frameworks.</p>
          </div>
          <button type="button" className="btn btn--primary" onClick={() => { setEditing(null); setFormOpen(true); }}>
            + New Course
          </button>
        </div>

        <div className="toolbar">
          <div className="toolbar__search">
            <label htmlFor="course-search" className="sr-only">Search courses</label>
            <input id="course-search" type="search" className="field__input" placeholder="Search name or trade code…" value={searchInput} onChange={(e) => onSearchChange(e.target.value)} />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="sector-filter" className="field__label field__label--sm">Sector</label>
            <select id="sector-filter" className="field__input" value={sector} onChange={(e) => { setSector(e.target.value); setPage(0); }}>
              <option value="">All sectors</option>
              {sectorOptions.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="level-filter" className="field__label field__label--sm">Qualification</label>
            <select id="level-filter" className="field__input" value={level} onChange={(e) => { setLevel(e.target.value); setPage(0); }}>
              <option value="">All levels</option>
              {COURSE_QUALIFICATION_LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="field__label field__label--sm">Status</label>
            <select id="status-filter" className="field__input" value={status} onChange={(e) => { setStatus(e.target.value); setPage(0); }}>
              <option value="">All statuses</option>
              {COURSE_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Course Name</th>
                <th scope="col">Trade Code</th>
                <th scope="col">Sector</th>
                <th scope="col">Level</th>
                <th scope="col">Duration</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
              ) : error ? (
                <tr>
                  <td colSpan={7} className="table__state table__state--error">
                    {error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button>
                  </td>
                </tr>
              ) : visibleRows.length === 0 ? (
                <tr><td colSpan={7} className="table__state">No courses found.</td></tr>
              ) : (
                visibleRows.map((c) => (
                  <tr key={c.courseID}>
                    <td data-label="Course Name">{c.courseName}</td>
                    <td data-label="Trade Code">{c.tradeCode}</td>
                    <td data-label="Sector">{c.sector}</td>
                    <td data-label="Level">{c.qualificationLevel}</td>
                    <td data-label="Duration"><DurationBar classroomWeeks={c.classroomWeeks} ojtWeeks={c.ojtWeeks} durationWeeks={c.durationWeeks} /></td>
                    <td data-label="Status"><StatusBadge status={c.status} tone={COURSE_STATUS_TONE[c.status] || 'neutral'} /></td>
                    <td data-label="Actions" className="table__actions">
                      <button type="button" className="btn btn--secondary btn--sm" onClick={() => { setEditing(c); setFormOpen(true); }}>Edit</button>
                      <button type="button" className="btn btn--danger-ghost btn--sm" onClick={() => setRemoving(c)}>Delete</button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <span className="pagination__info">{pageInfo.totalElements > 0 ? `${pageInfo.totalElements} total` : ' '}</span>
          <div className="pagination__controls">
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={loading || page === 0}>← Previous</button>
            <span className="pagination__page">Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}</span>
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => p + 1)} disabled={loading || page + 1 >= pageInfo.totalPages}>Next →</button>
          </div>
        </div>
      </main>

      {formOpen && (
        <CourseFormModal
          course={editing}
          onClose={() => { setFormOpen(false); setEditing(null); }}
          onSubmit={handleSubmit}
        />
      )}

      {removing && (
        <ConfirmDialog
          title="Delete course?"
          message={`Delete "${removing.courseName}" and its competency framework? This cannot be undone.`}
          confirmLabel="Delete"
          busy={removeBusy}
          onConfirm={handleRemove}
          onCancel={() => (removeBusy ? null : setRemoving(null))}
        />
      )}
    </div>
  );
}
