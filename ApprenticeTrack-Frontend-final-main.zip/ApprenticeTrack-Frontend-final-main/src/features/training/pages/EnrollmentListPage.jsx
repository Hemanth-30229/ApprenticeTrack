// Enrollments list (admin). List-page pattern (see PlacementListPage for the
// annotated reference). An enrollment links a trainee to a course + batch; the
// row actions move it through its status lifecycle.
import { useCallback, useEffect, useMemo, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import ConfirmDialog from '../../../shared/ui/ConfirmDialog';
import EnrollmentFormModal from '../components/enrollments/EnrollmentFormModal';
import { useToast } from '../../../shared/toast/ToastContext';
import {
  createEnrollment,
  listEnrollments,
  updateEnrollmentStatus,
} from '../api/enrollments';
import { listCourses } from '../api/courses';
import { listBatches } from '../api/batches';
import {
  ENROLLMENT_STATUSES,
  ENROLLMENT_STATUS_LABEL,
  ENROLLMENT_STATUS_TONE,
  ENROLLMENT_STATUS_TRANSITIONS,
} from '../constants/enrollment';
import { formatDate } from '../../../shared/format';

const PAGE_SIZE = 10;

export default function EnrollmentListPage() {
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);

  // Reference data for filters, batch-code lookup, and the form.
  const [courses, setCourses] = useState([]);
  const [batches, setBatches] = useState([]);

  const [courseFilter, setCourseFilter] = useState('');
  const [batchFilter, setBatchFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const [formOpen, setFormOpen] = useState(false);
  const [statusChange, setStatusChange] = useState(null); // { enrollment, to, label, tone }
  const [statusBusy, setStatusBusy] = useState(false);

  // Load reference data once.
  useEffect(() => {
    (async () => {
      try {
        const [coursePage, batchPage] = await Promise.all([listCourses(), listBatches()]);
        setCourses(coursePage.content || []);
        setBatches(batchPage.content || []);
      } catch {
        /* filters degrade gracefully if reference data fails */
      }
    })();
  }, []);

  const batchCodeById = useMemo(() => {
    const map = {};
    batches.forEach((b) => {
      map[b.batchID] = b.batchCode;
    });
    return map;
  }, [batches]);

  const courseNameById = useMemo(() => {
    const map = {};
    courses.forEach((c) => {
      map[c.courseID] = c.courseName;
    });
    return map;
  }, [courses]);

  // Batch filter options, narrowed to the selected course.
  const batchFilterOptions = useMemo(
    () =>
      courseFilter
        ? batches.filter((b) => String(b.courseID) === String(courseFilter))
        : batches,
    [batches, courseFilter]
  );

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await listEnrollments({
        courseID: courseFilter || undefined,
        batchID: batchFilter || undefined,
        status: statusFilter || undefined,
        page,
        size: PAGE_SIZE,
        sort: 'enrollmentDate,desc',
      });
      setRows(data.content || []);
      setPageInfo({ totalPages: data.totalPages ?? 0, totalElements: data.totalElements ?? 0 });
    } catch {
      setError('Could not load enrollments. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [courseFilter, batchFilter, statusFilter, page]);

  useEffect(() => {
    load();
  }, [load]);

  async function reloadBatches() {
    // Refresh capacity counts after an enrollment is created.
    try {
      const batchPage = await listBatches();
      setBatches(batchPage.content || []);
    } catch {
      /* ignore */
    }
  }

  async function handleCreate(payload) {
    try {
      await createEnrollment(payload);
      toast.success('Trainee enrolled successfully.');
      setFormOpen(false);
      reloadBatches();
      if (page !== 0) setPage(0);
      else load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to create enrollment.');
      throw err;
    }
  }

  async function confirmStatusChange() {
    if (!statusChange) return;
    setStatusBusy(true);
    try {
      await updateEnrollmentStatus(statusChange.enrollment.enrollmentID, statusChange.to);
      toast.success(
        `${statusChange.enrollment.traineeName || 'Enrollment'} → ${ENROLLMENT_STATUS_LABEL[statusChange.to]}.`
      );
      setStatusChange(null);
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to change status.');
    } finally {
      setStatusBusy(false);
    }
  }

  const from = pageInfo.totalElements === 0 ? 0 : page * PAGE_SIZE + 1;
  const to = Math.min((page + 1) * PAGE_SIZE, pageInfo.totalElements);

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Enrollments</h1>
            <p className="page__subtitle">Enroll trainees into course batches and track progress.</p>
          </div>
          <button type="button" className="btn btn--primary" onClick={() => setFormOpen(true)}>
            + New Enrollment
          </button>
        </div>

        <div className="toolbar">
          <div className="toolbar__filter">
            <label htmlFor="course-filter" className="field__label field__label--sm">Course</label>
            <select
              id="course-filter"
              className="field__input"
              value={courseFilter}
              onChange={(e) => {
                setCourseFilter(e.target.value);
                setBatchFilter('');
                setPage(0);
              }}
            >
              <option value="">All courses</option>
              {courses.map((c) => (
                <option key={c.courseID} value={c.courseID}>{c.courseName}</option>
              ))}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="batch-filter" className="field__label field__label--sm">Batch</label>
            <select
              id="batch-filter"
              className="field__input"
              value={batchFilter}
              onChange={(e) => {
                setBatchFilter(e.target.value);
                setPage(0);
              }}
            >
              <option value="">All batches</option>
              {batchFilterOptions.map((b) => (
                <option key={b.batchID} value={b.batchID}>{b.batchCode}</option>
              ))}
            </select>
          </div>
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="field__label field__label--sm">Status</label>
            <select
              id="status-filter"
              className="field__input"
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setPage(0);
              }}
            >
              <option value="">All statuses</option>
              {ENROLLMENT_STATUSES.map((s) => (
                <option key={s} value={s}>{ENROLLMENT_STATUS_LABEL[s]}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Trainee Name</th>
                <th scope="col">Course Name</th>
                <th scope="col">Batch Code</th>
                <th scope="col">Enrolled</th>
                <th scope="col">Expected Completion</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="table__state"><Spinner size={22} label="Loading" /> Loading…</td></tr>
              ) : error ? (
                <tr>
                  <td colSpan={7} className="table__state table__state--error">
                    {error} <button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button>
                  </td>
                </tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan={7} className="table__state">No enrollments found.</td></tr>
              ) : (
                rows.map((en) => (
                  <tr key={en.enrollmentID}>
                    <td data-label="Trainee Name">{en.traineeName || `Trainee #${en.traineeID}`}</td>
                    <td data-label="Course Name">{en.courseName || courseNameById[en.courseID] || `Course #${en.courseID}`}</td>
                    <td data-label="Batch Code">{batchCodeById[en.batchID] || `Batch #${en.batchID}`}</td>
                    <td data-label="Enrolled">{formatDate(en.enrollmentDate)}</td>
                    <td data-label="Expected Completion">{formatDate(en.expectedCompletionDate)}</td>
                    <td data-label="Status">
                      <StatusBadge
                        status={ENROLLMENT_STATUS_LABEL[en.status] || en.status}
                        tone={ENROLLMENT_STATUS_TONE[en.status] || 'neutral'}
                      />
                    </td>
                    <td data-label="Actions" className="table__actions">
                      {(ENROLLMENT_STATUS_TRANSITIONS[en.status] || []).length === 0 ? (
                        <span className="text-muted">—</span>
                      ) : (
                        (ENROLLMENT_STATUS_TRANSITIONS[en.status] || []).map((tr) => (
                          <button
                            key={tr.to}
                            type="button"
                            className={`btn btn--sm ${tr.tone === 'danger' ? 'btn--danger-ghost' : 'btn--secondary'}`}
                            onClick={() =>
                              setStatusChange({ enrollment: en, to: tr.to, label: tr.label, tone: tr.tone })
                            }
                          >
                            {tr.label}
                          </button>
                        ))
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <span className="pagination__info">
            {pageInfo.totalElements > 0 ? `Showing ${from}–${to} of ${pageInfo.totalElements}` : ' '}
          </span>
          <div className="pagination__controls">
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={loading || page === 0}>← Previous</button>
            <span className="pagination__page">Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}</span>
            <button type="button" className="btn btn--secondary btn--sm" onClick={() => setPage((p) => p + 1)} disabled={loading || page + 1 >= pageInfo.totalPages}>Next →</button>
          </div>
        </div>
      </main>

      {formOpen && (
        <EnrollmentFormModal
          courses={courses}
          batches={batches}
          onClose={() => setFormOpen(false)}
          onSubmit={handleCreate}
        />
      )}

      {statusChange && (
        <ConfirmDialog
          title={`${statusChange.label}?`}
          message={`Change status of "${statusChange.enrollment.traineeName || `Trainee #${statusChange.enrollment.traineeID}`}" to ${ENROLLMENT_STATUS_LABEL[statusChange.to]}?`}
          confirmLabel={statusChange.label}
          tone={statusChange.tone === 'danger' ? 'danger' : 'primary'}
          busy={statusBusy}
          onConfirm={confirmStatusChange}
          onCancel={() => (statusBusy ? null : setStatusChange(null))}
        />
      )}
    </div>
  );
}
