// Trainee-facing: the learning content for one course (video + details) with a
// "mark classroom complete" action stored locally (setCourseCompleted). Reads the
// course via getCourse; resolveVideo turns a stored link into an embeddable URL.
import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import Spinner from '../../../shared/Spinner';
import { useAuth } from '../../../shared/auth/AuthContext';
import { useToast } from '../../../shared/toast/ToastContext';
import { getCourse } from '../api/courses';
import { apiErrorMessage } from '../../../shared/api/errors';
import { resolveVideo } from '../../../shared/utils/video';
import { isCourseCompleted, setCourseCompleted } from '../../../shared/utils/courseProgress';

export default function TraineeCourseContentPage() {
  const { courseId } = useParams();
  const { user } = useAuth();
  const toast = useToast();

  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [completed, setCompleted] = useState(() => isCourseCompleted(user?.userID, courseId));

  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      setError('');
      try {
        const c = await getCourse(courseId);
        if (alive) setCourse(c);
      } catch (err) {
        if (alive) setError(apiErrorMessage(err, 'Could not load this course.'));
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => { alive = false; };
  }, [courseId]);

  function toggleComplete() {
    const next = !completed;
    setCourseCompleted(user?.userID, courseId, next);
    setCompleted(next);
    toast.success(next ? 'Marked as completed. Progress updated.' : 'Marked as not completed.');
  }

  const video = resolveVideo(course?.videoLink);
  const progress = completed ? 100 : 0;

  return (
    <div className="dash">
      <main className="page">
        <Link to="/trainee/courses" className="back-link">← Back to My Courses</Link>

        {loading ? (
          <div className="table__state"><Spinner size={24} label="Loading" /> Loading course…</div>
        ) : error || !course ? (
          <div className="empty-state"><p>{error || 'Course not found.'}</p></div>
        ) : (
          <>
            <div className="page__heading">
              <div>
                <h1 className="page__title">{course.courseName}</h1>
                <p className="page__subtitle">{course.tradeCode} · {course.qualificationLevel}</p>
              </div>
            </div>

            {/* Content progress */}
            <div className="content-progress">
              <div className="content-progress__head">
                <span>Content progress</span>
                <strong>{progress}%</strong>
              </div>
              <div className="chart-progress__track">
                <div className="chart-progress__fill" style={{ width: `${progress}%` }} />
              </div>
            </div>

            {/* Video */}
            <section className="course-video">
              {video.kind === 'youtube' ? (
                <div className="course-video__frame">
                  <iframe
                    src={video.src}
                    title={`${course.courseName} video`}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>
              ) : video.kind === 'file' ? (
                <div className="course-video__frame">
                  {/* eslint-disable-next-line jsx-a11y/media-has-caption */}
                  <video src={video.src} controls />
                </div>
              ) : video.kind === 'link' ? (
                <p className="widget__empty">
                  <a href={video.src} target="_blank" rel="noreferrer" className="login__link">Open course video ↗</a>
                </p>
              ) : (
                <p className="widget__empty">No learning video has been added for this course yet.</p>
              )}
            </section>

            <div className="course-content__actions">
              <button
                type="button"
                className={completed ? 'btn btn--secondary' : 'btn btn--primary'}
                onClick={toggleComplete}
              >
                {completed ? '✓ Completed — mark as not done' : 'Mark as Completed'}
              </button>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
