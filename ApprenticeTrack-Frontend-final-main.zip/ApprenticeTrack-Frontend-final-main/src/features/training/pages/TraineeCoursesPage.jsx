// Trainee-facing: the courses I'm enrolled in. Resolves my trainee profile from
// my login (getTraineeByUser), lists my enrollments, and links into each course's
// content. `isCourseCompleted` is a small local-storage helper for the "done" mark.
import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import { useAuth } from '../../../shared/auth/AuthContext';
import { getTraineeByUser } from '../api/trainees';
import { listEnrollments } from '../api/enrollments';
import { ENROLLMENT_STATUS_LABEL, ENROLLMENT_STATUS_TONE } from '../constants/enrollment';
import { formatDate } from '../../../shared/format';
import { apiErrorMessage } from '../../../shared/api/errors';
import { isCourseCompleted } from '../../../shared/utils/courseProgress';

export default function TraineeCoursesPage() {
  const { user } = useAuth();

  const [boot, setBoot] = useState({ loading: true, error: '', traineeID: null });
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const trainee = await getTraineeByUser(user.userID);
        if (alive) setBoot({ loading: false, error: '', traineeID: trainee.traineeID });
      } catch (err) {
        if (alive)
          setBoot({
            loading: false,
            error:
              err?.response?.status === 404
                ? 'No trainee profile is linked to your account yet. Ask your administrator to create your trainee profile.'
                : 'Could not load your profile.',
            traineeID: null,
          });
      }
    })();
    return () => { alive = false; };
  }, [user.userID]);

  const load = useCallback(async () => {
    if (!boot.traineeID) return;
    setLoading(true);
    setError('');
    try {
      const data = await listEnrollments({ traineeID: boot.traineeID, size: 50, sort: 'enrollmentDate,desc' });
      setRows(data.content || []);
    } catch (err) {
      setError(apiErrorMessage(err, 'Could not load your courses.'));
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [boot.traineeID]);

  useEffect(() => { load(); }, [load]);

  if (boot.loading) {
    return (
      <div className="dash"><main className="page"><div className="table__state"><Spinner size={24} label="Loading" /> Loading…</div></main></div>
    );
  }

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">My Courses</h1>
            <p className="page__subtitle">Courses you are enrolled in.</p>
          </div>
        </div>

        {boot.error ? (
          <div className="empty-state"><p>{boot.error}</p></div>
        ) : loading ? (
          <div className="table__state"><Spinner size={22} label="Loading" /> Loading your courses…</div>
        ) : error ? (
          <div className="empty-state"><p>{error}</p><button type="button" className="btn btn--secondary btn--sm" onClick={load}>Retry</button></div>
        ) : rows.length === 0 ? (
          <div className="empty-state">
            <p>You are not enrolled in any course yet.</p>
            <p className="empty-state__hint">Your administrator enrols you into a course batch; it will appear here.</p>
          </div>
        ) : (
          <div className="result-grid">
            {rows.map((en) => (
              <div key={en.enrollmentID} className="cert-item">
                <div className="cert-item__body">
                  <span className="cert-item__kicker">Course</span>
                  <h2 className="cert-item__course">{en.courseName || `Course #${en.courseID}`}</h2>
                  <dl className="cert-item__meta">
                    <div><dt>Batch</dt><dd>#{en.batchID}</dd></div>
                    <div><dt>Enrolled</dt><dd>{formatDate(en.enrollmentDate)}</dd></div>
                    <div><dt>Expected completion</dt><dd>{formatDate(en.expectedCompletionDate)}</dd></div>
                    {en.ojtStartDate && <div><dt>OJT start</dt><dd>{formatDate(en.ojtStartDate)}</dd></div>}
                  </dl>
                </div>
                <div className="cert-item__meta" style={{ marginTop: '0.5rem' }}>
                  <div>
                    <dt>Content</dt>
                    <dd>
                      {isCourseCompleted(user.userID, en.courseID)
                        ? <span className="badge badge--success">Completed</span>
                        : <span className="badge badge--neutral">Not started</span>}
                    </dd>
                  </div>
                </div>
                <div className="cert-item__foot">
                  <StatusBadge status={ENROLLMENT_STATUS_LABEL[en.status] || en.status} tone={ENROLLMENT_STATUS_TONE[en.status] || 'neutral'} />
                  <Link to={`/trainee/courses/${en.courseID}`} className="btn btn--primary btn--sm">Open Course</Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
