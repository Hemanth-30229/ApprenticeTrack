// Trainees directory (admin). Standard list-page pattern — see
// features/placement/pages/PlacementListPage.jsx for the annotated reference.
// Creating a trainee also creates their login account (createUser from identity).
import { useCallback, useEffect, useRef, useState } from 'react';
import Spinner from '../../../shared/Spinner';
import StatusBadge from '../../../shared/ui/StatusBadge';
import ConfirmDialog from '../../../shared/ui/ConfirmDialog';
import TraineeFormModal from '../components/trainees/TraineeFormModal';
import { useToast } from '../../../shared/toast/ToastContext';
import {
  createTrainee,
  deleteTrainee,
  listTrainees,
  updateTrainee,
} from '../api/trainees';
import { createUser } from '../../identity/api/users';
import { TRAINEE_STATUSES, TRAINEE_STATUS_TONE } from '../constants/trainee';
import { formatDate } from '../../../shared/format';
import './TraineeListPage.css';

const PAGE_SIZE = 10;

export default function TraineeListPage() {
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ number: 0, totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters / paging
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(0);

  // Modals
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [confirm, setConfirm] = useState(null); // trainee to delete
  const [deleting, setDeleting] = useState(false);

  const debounceRef = useRef(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await listTrainees({
        name: search || undefined,
        status: status || undefined,
        page,
        size: PAGE_SIZE,
        sort: 'name,asc',
      });
      setRows(data.content || []);
      setPageInfo({
        number: data.number ?? 0,
        totalPages: data.totalPages ?? 0,
        totalElements: data.totalElements ?? 0,
      });
    } catch {
      setError('Could not load trainees. Please try again.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [search, status, page]);

  useEffect(() => {
    load();
  }, [load]);

  // Debounce the search box -> resets to first page.
  function onSearchChange(value) {
    setSearchInput(value);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setPage(0);
      setSearch(value.trim());
    }, 400);
  }

  function onStatusChange(value) {
    setStatus(value);
    setPage(0);
  }

  function openAdd() {
    setEditing(null);
    setFormOpen(true);
  }
  function openEdit(trainee) {
    setEditing(trainee);
    setFormOpen(true);
  }

  async function handleSubmit(payload) {
    if (editing) {
      try {
        await updateTrainee(editing.traineeID, payload);
        toast.success('Trainee updated successfully.');
        setFormOpen(false);
        setEditing(null);
        load();
      } catch (err) {
        toast.error(err?.response?.data?.message || 'Failed to update trainee.');
        throw err;
      }
      return;
    }

    // Create: first the login account (User, role=Trainee), then the profile.
    let user;
    try {
      user = await createUser({
        name: payload.name,
        role: 'Trainee',
        email: payload.email,
        password: payload.password,
        phone: payload.phone,
        instituteID: payload.instituteID,
      });
    } catch (err) {
      const status = err?.response?.status;
      if (status === 409) toast.error('An account with this email already exists.');
      else if (status === 401 || status === 403) toast.error('You are not authorised to create users.');
      else toast.error(err?.response?.data?.message || 'Failed to create the login account.');
      throw err; // keep the form open
    }

    try {
      await createTrainee({
        userID: user.userID,
        name: payload.name,
        dateOfBirth: payload.dateOfBirth,
        gender: payload.gender,
        educationLevel: payload.educationLevel,
        address: payload.address,
        phone: payload.phone,
        emergencyContact: payload.emergencyContact,
      });
      toast.success(`Trainee created. They can log in with ${payload.email}.`);
      setFormOpen(false);
      setEditing(null);
      if (page !== 0) setPage(0);
      else load();
    } catch (err) {
      // Account was created but the profile failed — surface clearly.
      toast.error(
        `Login account created (ID ${user.userID}), but the trainee profile failed: ${
          err?.response?.data?.message || 'please retry from Users.'
        }`
      );
      throw err;
    }
  }

  async function handleDelete() {
    if (!confirm) return;
    setDeleting(true);
    try {
      await deleteTrainee(confirm.traineeID);
      toast.success(`Trainee "${confirm.name}" removed.`);
      setConfirm(null);
      // If we removed the last row on a page, step back a page.
      if (rows.length === 1 && page > 0) setPage((p) => p - 1);
      else load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to remove trainee.');
    } finally {
      setDeleting(false);
    }
  }

  const from = pageInfo.totalElements === 0 ? 0 : page * PAGE_SIZE + 1;
  const to = Math.min((page + 1) * PAGE_SIZE, pageInfo.totalElements);

  return (
    <div className="dash">
      <main className="page">
        <div className="page__heading">
          <div>
            <h1 className="page__title">Trainees</h1>
            <p className="page__subtitle">View, create, edit and search trainee profiles.</p>
          </div>
          <button type="button" className="btn btn--primary" onClick={openAdd}>
            + Add Trainee
          </button>
        </div>

        <div className="toolbar">
          <div className="toolbar__search">
            <label htmlFor="trainee-search" className="sr-only">
              Search trainees by name
            </label>
            <input
              id="trainee-search"
              type="search"
              className="field__input"
              placeholder="Search by name…"
              value={searchInput}
              onChange={(e) => onSearchChange(e.target.value)}
            />
          </div>
          <div className="toolbar__filter">
            <label htmlFor="status-filter" className="sr-only">
              Filter by status
            </label>
            <select
              id="status-filter"
              className="field__input"
              value={status}
              onChange={(e) => onStatusChange(e.target.value)}
            >
              <option value="">All statuses</option>
              {TRAINEE_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Name</th>
                <th scope="col">Date of Birth</th>
                <th scope="col">Gender</th>
                <th scope="col">Education Level</th>
                <th scope="col">Status</th>
                <th scope="col" className="table__actions-col">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={6} className="table__state">
                    <Spinner size={22} label="Loading trainees" /> Loading…
                  </td>
                </tr>
              ) : error ? (
                <tr>
                  <td colSpan={6} className="table__state table__state--error">
                    {error}{' '}
                    <button type="button" className="btn btn--secondary btn--sm" onClick={load}>
                      Retry
                    </button>
                  </td>
                </tr>
              ) : rows.length === 0 ? (
                <tr>
                  <td colSpan={6} className="table__state">
                    No trainees found.
                  </td>
                </tr>
              ) : (
                rows.map((t) => (
                  <tr key={t.traineeID}>
                    <td data-label="Name">{t.name}</td>
                    <td data-label="Date of Birth">{formatDate(t.dateOfBirth)}</td>
                    <td data-label="Gender">{t.gender}</td>
                    <td data-label="Education Level">{t.educationLevel}</td>
                    <td data-label="Status">
                      <StatusBadge
                        status={t.status}
                        tone={TRAINEE_STATUS_TONE[t.status] || 'neutral'}
                      />
                    </td>
                    <td data-label="Actions" className="table__actions">
                      <button
                        type="button"
                        className="btn btn--secondary btn--sm"
                        onClick={() => openEdit(t)}
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        className="btn btn--danger-ghost btn--sm"
                        onClick={() => setConfirm(t)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <span className="pagination__info">
            {pageInfo.totalElements > 0
              ? `Showing ${from}–${to} of ${pageInfo.totalElements}`
              : ' '}
          </span>
          <div className="pagination__controls">
            <button
              type="button"
              className="btn btn--secondary btn--sm"
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={loading || page === 0}
            >
              ← Previous
            </button>
            <span className="pagination__page">
              Page {pageInfo.totalPages === 0 ? 0 : page + 1} of {pageInfo.totalPages}
            </span>
            <button
              type="button"
              className="btn btn--secondary btn--sm"
              onClick={() => setPage((p) => p + 1)}
              disabled={loading || page + 1 >= pageInfo.totalPages}
            >
              Next →
            </button>
          </div>
        </div>
      </main>

      {formOpen && (
        <TraineeFormModal
          trainee={editing}
          onClose={() => {
            setFormOpen(false);
            setEditing(null);
          }}
          onSubmit={handleSubmit}
        />
      )}

      {confirm && (
        <ConfirmDialog
          title="Remove trainee?"
          message={`Are you sure you want to remove "${confirm.name}"? This action cannot be undone.`}
          confirmLabel="Remove"
          busy={deleting}
          onConfirm={handleDelete}
          onCancel={() => (deleting ? null : setConfirm(null))}
        />
      )}
    </div>
  );
}
