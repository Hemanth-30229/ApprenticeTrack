import { useEffect } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from './auth/AuthContext';
import { homePathForRole } from './auth/roles';
import { useToast } from './toast/ToastContext';
import Spinner from './Spinner';

export default function ProtectedRoute({ allow }) {
  const { isAuthenticated, user, loading } = useAuth();

  if (loading) {
    return (
      <div className="page-center">
        <Spinner size={32} label="Checking your session" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (user.mustChangePassword) {
    return <Navigate to="/change-password" replace />;
  }

  if (allow && !allow.includes(user.role)) {
    return <AccessDenied to={homePathForRole(user.role)} />;
  }

  return <Outlet />;
}

function AccessDenied({ to }) {
  const toast = useToast();
  useEffect(() => {
    toast.error('Access denied');
  }, []);
  return <Navigate to={to} replace />;
}
