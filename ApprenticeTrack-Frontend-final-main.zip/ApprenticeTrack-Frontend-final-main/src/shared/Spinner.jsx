// Accessible loading spinner. `label` is announced to screen readers.

export default function Spinner({ size = 20, label = 'Loading', inline = false }) {
  return (
    <span
      className={inline ? 'spinner spinner--inline' : 'spinner'}
      role="status"
      aria-live="polite"
      style={{ '--spinner-size': `${size}px` }}
    >
      <span className="spinner__ring" aria-hidden="true" />
      <span className="sr-only">{label}</span>
    </span>
  );
}
