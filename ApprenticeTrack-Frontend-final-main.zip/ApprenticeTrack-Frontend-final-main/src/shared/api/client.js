// Axios instance pointed at the API Gateway.
// - Attaches the JWT bearer token to every request.
// - On a 401 (token missing/expired), logs the user out via a handler that
//   AuthContext wires up to redirect back to the login screen.

import axios from 'axios';
import { tokenStorage } from '../auth/tokenStorage';

const baseURL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:2004';

const api = axios.create({
  baseURL,
  headers: { 'Content-Type': 'application/json' },
});

// AuthContext registers a callback here so we can redirect on logout without
// creating a circular import between the client and the context.
let onAuthFailure = () => {};
export function setOnAuthFailure(cb) {
  onAuthFailure = cb;
}

// Attach the bearer token to every request (unless the caller opts out).
api.interceptors.request.use((config) => {
  const token = tokenStorage.getAccess();
  if (token && !config.skipAuth) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// If a logged-in request comes back 401 Unauthorized, clear the session and log
// out. Public auth calls (login/register) handle their own errors, so skip them.
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const isAuthEndpoint = error.config?.url?.includes('/api/auth/');
    if (error.response?.status === 401 && !isAuthEndpoint) {
      tokenStorage.clear();
      onAuthFailure();
    }
    return Promise.reject(error);
  }
);

export default api;
