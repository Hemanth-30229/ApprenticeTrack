// Extracts a human-readable message from an Axios error, handling the common
// Spring error-body shapes: { message }, { fieldErrors: {field: msg} },
// and { errors: [{ field, defaultMessage }] }.

export function apiErrorMessage(err, fallback = 'Something went wrong. Please try again.') {
  const data = err?.response?.data;
  if (!data) return fallback;
  if (typeof data === 'string') return data;
  if (typeof data.message === 'string' && data.message.trim()) return data.message;
  if (data.fieldErrors && typeof data.fieldErrors === 'object') {
    const msgs = Object.values(data.fieldErrors).filter(Boolean);
    if (msgs.length) return msgs.join(' · ');
  }
  if (Array.isArray(data.errors)) {
    const msgs = data.errors.map((e) => e.defaultMessage || e.message).filter(Boolean);
    if (msgs.length) return msgs.join(' · ');
  }
  return fallback;
}
