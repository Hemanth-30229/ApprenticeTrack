import { createContext, useContext, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api, { setOnAuthFailure } from '../api/client';
import { tokenStorage } from './tokenStorage';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const navigate = useNavigate();
  const [user, setUser] = useState(() => tokenStorage.getUser());

  useEffect(() => {
    setOnAuthFailure(() => {
      setUser(null);
      navigate('/login', { replace: true });
    });
  }, [navigate]);

  async function login(email, password) {
    const { data } = await api.post(
      '/api/auth/login',
      { email, password },
      { skipAuth: true }
    );
    const profile = {
      userID: data.userID,
      name: data.name,
      role: data.role,
      instituteID: data.instituteID,
      mustChangePassword: Boolean(data.mustChangePassword),
    };
    tokenStorage.setSession({ accessToken: data.accessToken, user: profile });
    setUser(profile);
    return profile;
  }

  function logout() {
    tokenStorage.clear();
    setUser(null);
    navigate('/login', { replace: true });
  }
  
  function clearPasswordChangeRequirement() {
    setUser((prev) => {
      if (!prev) return prev;
      const next = { ...prev, mustChangePassword: false };
      tokenStorage.setUser(next);
      return next;
    });
  }

  const value = {
    user,
    isAuthenticated: Boolean(user),
    loading: false,
    login,
    logout,
    clearPasswordChangeRequirement,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}
