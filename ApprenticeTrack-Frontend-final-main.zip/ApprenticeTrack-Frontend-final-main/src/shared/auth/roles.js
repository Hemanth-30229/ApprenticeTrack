export const ROLES = {
  TRAINEE: 'Trainee',
  EMPLOYER: 'Employer',
  ASSESSOR: 'Assessor',
  PLACEMENT_OFFICER: 'PlacementOfficer',
  STIPEND_ADMIN: 'StipendAdmin',
  ADMIN: 'Admin',
};

const ROLE_HOME = {
  Trainee: '/trainee',
  Employer: '/employer',
  Assessor: '/assessor',
  PlacementOfficer: '/placement',
  StipendAdmin: '/stipend',
  Admin: '/admin',
};

export const ROLE_DASHBOARD_LABEL = {
  Trainee: 'Trainee Portal',
  Employer: 'Employer Console',
  Assessor: 'Assessor Workbench',
  PlacementOfficer: 'Placement Officer Console',
  StipendAdmin: 'Stipend Admin Dashboard',
  Admin: 'Admin Console',
};

export function homePathForRole(role) {
  return ROLE_HOME[role] || '/login';
}
