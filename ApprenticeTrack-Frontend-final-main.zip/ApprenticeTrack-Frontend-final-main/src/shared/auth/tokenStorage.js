// Secure-storage wrapper for auth tokens and the current user profile.
//
// NOTE on "httpOnly cookie or secure storage": the backend returns the JWT in
// the JSON response body (it does not Set-Cookie an httpOnly cookie), so a true
// httpOnly cookie is not possible without a backend change. We therefore use
// browser storage as the "secure storage" option. localStorage is used so the
// session survives a full page reload; swap to sessionStorage if you prefer the
// session to end when the tab closes. Centralising access here means there is a
// single place to harden later (e.g. move to httpOnly cookies via a BFF).

const ACCESS_KEY = 'apt.accessToken';
const USER_KEY = 'apt.user';

const store = window.localStorage;

export const tokenStorage = {
  getAccess() {
    return store.getItem(ACCESS_KEY);
  },
  setAccess(token) {
    if (token) store.setItem(ACCESS_KEY, token);
  },
  getUser() {
    const raw = store.getItem(USER_KEY);
    try {
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  },
  setUser(user) {
    if (user) store.setItem(USER_KEY, JSON.stringify(user));
  },
  setSession({ accessToken, user }) {
    this.setAccess(accessToken);
    this.setUser(user);
  },
  clear() {
    store.removeItem(ACCESS_KEY);
    store.removeItem(USER_KEY);
  },
};
