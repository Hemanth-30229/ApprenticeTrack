// Formatting + metric helpers shared by dashboard widgets.

const inr = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
});
const num = new Intl.NumberFormat('en-IN');

export function formatNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) ? num.format(n) : String(value ?? '—');
}

export function formatCurrency(value) {
  const n = Number(value);
  return Number.isFinite(n) ? inr.format(n) : '—';
}

export function formatPercent(value, digits = 1) {
  const n = Number(value);
  return Number.isFinite(n) ? `${n.toFixed(digits)}%` : '—';
}

export function formatDate(value) {
  if (!value) return '—';
  const d = new Date(value);
  return Number.isNaN(d.getTime())
    ? String(value)
    : d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

/** Pull a metric object out of the flat metrics list by exact name. */
export function getMetric(metrics, name) {
  return (metrics || []).find((m) => m.name === name);
}

/** Get a metric's raw value (may be a scalar or an object). */
export function getValue(metrics, name, fallback = null) {
  const m = getMetric(metrics, name);
  return m == null || m.value === undefined ? fallback : m.value;
}

// Backend TrendIndicator (up|down|stable) -> arrow, label, direction.
const TREND = {
  up: { arrow: '↑', label: 'Up', dir: 'up' },
  down: { arrow: '↓', label: 'Down', dir: 'down' },
  stable: { arrow: '→', label: 'Stable', dir: 'stable' },
};

export function trendInfo(trend) {
  return TREND[trend] || TREND.stable;
}
