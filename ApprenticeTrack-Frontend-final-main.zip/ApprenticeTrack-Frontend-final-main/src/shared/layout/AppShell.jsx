import { useEffect, useState } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { homePathForRole } from '../auth/roles';
import Sidebar from './Sidebar';
import UserMenu from './UserMenu';
import Breadcrumbs from './Breadcrumbs';
import NotificationBell from '../../features/platform/components/notifications/NotificationBell';
import './shell.css';

export default function AppShell() {
  const { isAuthenticated, user } = useAuth();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  if (!isAuthenticated) return <Outlet />;

  const shellClass = `app-shell ${collapsed ? 'is-collapsed' : ''} ${mobileOpen ? 'is-mobile-open' : ''}`;

  return (
    <div className={shellClass}>
      <header className="app-topbar">
        <button
          type="button"
          className="app-topbar__hamburger"
          aria-label="Toggle navigation menu"
          aria-expanded={mobileOpen}
          onClick={() => setMobileOpen((o) => !o)}
        >
          ☰
        </button>
        <Link to={homePathForRole(user?.role)} className="app-topbar__brand">
          <span className="app-topbar__mark" aria-hidden="true">AT</span>
          <span className="app-topbar__name">ApprenticeTrack</span>
        </Link>

        <div className="app-topbar__spacer" />

        <NotificationBell />
        <UserMenu />
      </header>

      <button
        type="button"
        className="app-backdrop"
        aria-label="Close navigation menu"
        tabIndex={mobileOpen ? 0 : -1}
        onClick={() => setMobileOpen(false)}
      />

      <aside className="app-sidebar" aria-label="Sidebar">
        <Sidebar collapsed={collapsed} onNavigate={() => setMobileOpen(false)} />
        <button
          type="button"
          className="app-sidebar__collapse"
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          onClick={() => setCollapsed((c) => !c)}
        >
          <span aria-hidden="true">{collapsed ? '»' : '«'}</span>
          <span className="app-sidebar__label">Collapse</span>
        </button>
      </aside>

      <main className="app-shell__main" id="main-content">
        <Breadcrumbs />
        <div className="app-shell__content">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
