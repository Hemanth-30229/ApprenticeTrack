// Breadcrumb trail below the top bar (e.g. Dashboard > Trade Tests > Results).

import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { buildBreadcrumbs } from './navConfig';

export default function Breadcrumbs() {
  const { user } = useAuth();
  const { pathname } = useLocation();
  const crumbs = buildBreadcrumbs(pathname, user?.role);

  return (
    <nav className="breadcrumbs" aria-label="Breadcrumb">
      <ol className="breadcrumbs__list">
        {crumbs.map((c, i) => {
          const last = i === crumbs.length - 1;
          return (
            <li key={`${c.to}-${i}`} className="breadcrumbs__item">
              {last ? (
                <span aria-current="page">{c.label}</span>
              ) : (
                <>
                  <Link to={c.to}>{c.label}</Link>
                  <span className="breadcrumbs__sep" aria-hidden="true">›</span>
                </>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
