// Collapsible role-based sidebar navigation.

import { NavLink } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { navItemsForRole } from './navConfig';

export default function Sidebar({ collapsed, onNavigate }) {
  const { user } = useAuth();
  const items = navItemsForRole(user?.role);

  return (
    <nav className="app-sidebar__nav" aria-label="Primary">
      <ul className="app-sidebar__list">
        {items.map((item, i) => (
          <li key={`${item.to}-${i}`}>
            <NavLink
              to={item.to}
              end={item.end}
              className={({ isActive }) => `app-sidebar__link ${isActive ? 'is-active' : ''}`}
              title={collapsed ? item.label : undefined}
              onClick={onNavigate}
            >
              <span className="app-sidebar__icon" aria-hidden="true">{item.icon}</span>
              <span className="app-sidebar__label">{item.label}</span>
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}
