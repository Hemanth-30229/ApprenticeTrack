// Role-based sidebar navigation + breadcrumb labels.
//
// Items follow the AC's per-role menus, mapped to real routes where a page
// exists and to the /soon placeholder where the feature isn't built yet. Extra
// existing pages are appended so nothing built becomes unreachable.

import { homePathForRole, ROLES } from '../auth/roles';

const NAV = {
  [ROLES.TRAINEE]: [
    { label: 'Dashboard', to: '/trainee', icon: '🏠', end: true },
    { label: 'My Courses', to: '/trainee/courses', icon: '📚' },
    { label: 'My Placement', to: '/trainee/placement', icon: '🏢' },
    { label: 'OJT Logs', to: '/trainee/ojt-logs', icon: '📝' },
    { label: 'Trade Tests', to: '/trainee/tests', icon: '🧪' },
    { label: 'My Results', to: '/trainee/results', icon: '🎓' },
    { label: 'Stipend History', to: '/trainee/stipends', icon: '💰' },
    { label: 'Certificates', to: '/trainee/certificates', icon: '📜' },
  ],
  [ROLES.EMPLOYER]: [
    { label: 'Dashboard', to: '/employer', icon: '🏠', end: true },
    { label: 'Vacancies', to: '/employer/vacancies', icon: '📢' },
    { label: 'Trainee Roster', to: '/employer/roster', icon: '👥' },
    { label: 'OJT Confirmations', to: '/employer/ojt-logs', icon: '✅' },
    { label: 'Attendance Summary', to: '/employer/attendance-summary', icon: '📅' },
  ],
  [ROLES.ASSESSOR]: [
    { label: 'Dashboard', to: '/assessor', icon: '🏠', end: true },
    { label: 'Trade Tests', to: '/assessor/tests', icon: '🧪' },
    { label: 'Results Entry', to: '/assessor/tests', icon: '📝' },
    { label: 'Reassessment Tracker', to: '/assessor/reassessments', icon: '🔁' },
  ],
  [ROLES.PLACEMENT_OFFICER]: [
    { label: 'Dashboard', to: '/placement', icon: '🏠', end: true },
    { label: 'Vacancy Board', to: '/vacancies', icon: '📢' },
    { label: 'Matching Panel', to: '/placements', icon: '🤝' },
    { label: 'Placement Tracker', to: '/placements', icon: '📈' },
    { label: 'Batches', to: '/batches', icon: '👥' },
  ],
  [ROLES.STIPEND_ADMIN]: [
    { label: 'Dashboard', to: '/stipend', icon: '🏠', end: true },
    { label: 'Attendance Review', to: '/attendance', icon: '📅' },
    { label: 'Stipend Computation', to: '/stipends', icon: '🧮' },
    { label: 'Disbursement Queue', to: '/stipends', icon: '💸' },
  ],
  [ROLES.ADMIN]: [
    { label: 'Dashboard', to: '/admin', icon: '🏠', end: true },
    { label: 'Courses', to: '/courses', icon: '📚' },
    { label: 'Batches', to: '/batches', icon: '👥' },
    { label: 'Trainees', to: '/trainees', icon: '🎓' },
    { label: 'Enrollments', to: '/enrollments', icon: '🗂️' },
    { label: 'Employers', to: '/employers', icon: '🏢' },
    { label: 'Vacancies', to: '/vacancies', icon: '📢' },
    { label: 'Results', to: '/results', icon: '📋' },
    { label: 'Certificates', to: '/certificates', icon: '📜' },
    { label: 'Audit Logs', to: '/audit-logs', icon: '🔎' },
    { label: 'Assessors', to: '/assessors', icon: '🧑‍🏫' },
    { label: 'Users', to: '/users', icon: '👤' },
  ],
};

export function navItemsForRole(role) {
  return NAV[role] || [{ label: 'Dashboard', to: homePathForRole(role), icon: '🏠', end: true }];
}

// --- Breadcrumbs -----------------------------------------------------------

// Static path -> breadcrumb label (excluding the leading Dashboard crumb).
const PAGE_LABELS = {
  '/trainee/ojt-logs': 'OJT Logs',
  '/trainee/placement': 'My Placement',
  '/trainee/results': 'My Results',
  '/trainee/tests': 'My Trade Tests',
  '/trainee/stipends': 'Stipend History',
  '/trainee/certificates': 'My Certificates',
  '/employer/ojt-logs': 'OJT Confirmations',
  '/assessor/tests': 'Trade Tests',
  '/assessor/reassessments': 'Reassessment Tracker',
  '/placements': 'Placements',
  '/vacancies': 'Vacancy Board',
  '/batches': 'Batches',
  '/attendance': 'Attendance Review',
  '/stipends': 'Stipends',
  '/courses': 'Courses & Curriculum',
  '/trainees': 'Trainees',
  '/enrollments': 'Enrollments',
  '/employers': 'Employers',
  '/results': 'Results',
  '/certificates': 'Certificates',
  '/audit-logs': 'Audit Logs',
  '/notifications': 'Notifications',
  '/profile': 'My Profile',
  '/soon': 'Coming Soon',
};

export function buildBreadcrumbs(pathname, role) {
  const home = homePathForRole(role);
  const crumbs = [{ label: 'Dashboard', to: home }];

  if (pathname === home || pathname === '/') return crumbs;

  // Assessment entry: /assessor/tests/{id} -> Trade Tests > Results
  const entryMatch = /^\/assessor\/tests\/[^/]+$/.test(pathname);
  if (entryMatch) {
    crumbs.push({ label: 'Trade Tests', to: '/assessor/tests' });
    crumbs.push({ label: 'Results', to: pathname });
    return crumbs;
  }

  // Question paper: /assessor/tests/{id}/questions -> Trade Tests > Question Paper
  if (/^\/assessor\/tests\/[^/]+\/questions$/.test(pathname)) {
    crumbs.push({ label: 'Trade Tests', to: '/assessor/tests' });
    crumbs.push({ label: 'Question Paper', to: pathname });
    return crumbs;
  }

  // Trainee test attempt: /trainee/tests/{id} -> My Trade Tests > Write Test
  if (/^\/trainee\/tests\/[^/]+$/.test(pathname)) {
    crumbs.push({ label: 'My Trade Tests', to: '/trainee/tests' });
    crumbs.push({ label: 'Write Test', to: pathname });
    return crumbs;
  }

  const label = PAGE_LABELS[pathname];
  if (label) crumbs.push({ label, to: pathname });
  return crumbs;
}
