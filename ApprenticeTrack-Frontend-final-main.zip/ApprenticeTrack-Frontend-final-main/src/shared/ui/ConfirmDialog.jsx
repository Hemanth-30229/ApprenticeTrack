// Confirmation dialog built on Modal. Used before destructive actions.

import Modal from './Modal';
import Spinner from '../Spinner';

export default function ConfirmDialog({
  title = 'Are you sure?',
  message,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  tone = 'danger',
  busy = false,
  onConfirm,
  onCancel,
}) {
  return (
    <Modal title={title} onClose={busy ? () => {} : onCancel} size="sm">
      <p className="confirm__message">{message}</p>
      <div className="modal__actions">
        <button
          type="button"
          className="btn btn--secondary"
          onClick={onCancel}
          disabled={busy}
        >
          {cancelLabel}
        </button>
        <button
          type="button"
          className={`btn ${tone === 'danger' ? 'btn--danger' : 'btn--primary'}`}
          onClick={onConfirm}
          disabled={busy}
          aria-busy={busy}
        >
          {busy && <Spinner size={16} inline label="Working" />}
          {confirmLabel}
        </button>
      </div>
    </Modal>
  );
}
