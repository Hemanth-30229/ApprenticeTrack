// Async searchable single-select. `fetchOptions(query)` returns
// [{ value, label }]. Debounced; basic keyboard + click support.

import { useEffect, useId, useRef, useState } from 'react';

export default function SearchableSelect({
  value,
  selectedLabel,
  placeholder = 'Search…',
  fetchOptions,
  onSelect,
  disabled = false,
  invalid = false,
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState(-1);
  const rootRef = useRef(null);
  const debounceRef = useRef(null);
  const listId = useId();

  // Close on outside click.
  useEffect(() => {
    function onDocClick(e) {
      if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, []);

  // Debounced fetch when open + query changes.
  useEffect(() => {
    if (!open) return;
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(async () => {
      setLoading(true);
      try {
        const opts = await fetchOptions(query.trim());
        setOptions(opts);
        setActive(opts.length ? 0 : -1);
      } catch {
        setOptions([]);
      } finally {
        setLoading(false);
      }
    }, 300);
    return () => clearTimeout(debounceRef.current);
  }, [open, query, fetchOptions]);

  function choose(opt) {
    onSelect(opt);
    setOpen(false);
    setQuery('');
  }

  function onKeyDown(e) {
    if (!open && (e.key === 'ArrowDown' || e.key === 'Enter')) {
      setOpen(true);
      return;
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActive((a) => Math.min(options.length - 1, a + 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActive((a) => Math.max(0, a - 1));
    } else if (e.key === 'Enter' && active >= 0 && options[active]) {
      e.preventDefault();
      choose(options[active]);
    } else if (e.key === 'Escape') {
      setOpen(false);
    }
  }

  return (
    <div className="search-select" ref={rootRef}>
      <input
        type="text"
        className={`field__input ${invalid ? 'cell-input--error' : ''}`}
        placeholder={value ? selectedLabel : placeholder}
        value={open ? query : value ? selectedLabel : ''}
        disabled={disabled}
        onFocus={() => setOpen(true)}
        onChange={(e) => {
          setQuery(e.target.value);
          setOpen(true);
        }}
        onKeyDown={onKeyDown}
        role="combobox"
        aria-expanded={open}
        aria-controls={listId}
        aria-autocomplete="list"
      />
      {open && (
        <ul className="search-select__list" id={listId} role="listbox">
          {loading ? (
            <li className="search-select__empty">Searching…</li>
          ) : options.length === 0 ? (
            <li className="search-select__empty">No matches</li>
          ) : (
            options.map((opt, i) => (
              <li
                key={opt.value}
                role="option"
                aria-selected={i === active}
                className={`search-select__option ${i === active ? 'is-active' : ''}`}
                onMouseEnter={() => setActive(i)}
                onMouseDown={(e) => {
                  e.preventDefault();
                  choose(opt);
                }}
              >
                {opt.label}
              </li>
            ))
          )}
        </ul>
      )}
    </div>
  );
}
