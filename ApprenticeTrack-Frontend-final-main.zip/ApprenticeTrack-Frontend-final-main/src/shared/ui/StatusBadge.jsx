// Small colour-coded status pill. `tone` is one of success|info|neutral|danger|warning.

export default function StatusBadge({ status, tone = 'neutral' }) {
  return <span className={`badge badge--${tone}`}>{status}</span>;
}
