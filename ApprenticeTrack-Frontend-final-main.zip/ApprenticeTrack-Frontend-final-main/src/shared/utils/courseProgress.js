// Per-user course content completion, persisted client-side.
//
// NOTE: The backend has no lesson/content-completion tracking, so "mark as
// completed" is stored in localStorage (per user + course). It survives reloads
// on this device but is not synced server-side or across devices. When a backend
// completion API exists, swap these three functions to call it.

const key = (userId, courseId) => `apt.course-complete.${userId}.${courseId}`;

export function isCourseCompleted(userId, courseId) {
  if (userId == null || courseId == null) return false;
  return localStorage.getItem(key(userId, courseId)) === '1';
}

export function setCourseCompleted(userId, courseId, done) {
  if (userId == null || courseId == null) return;
  if (done) localStorage.setItem(key(userId, courseId), '1');
  else localStorage.removeItem(key(userId, courseId));
}
