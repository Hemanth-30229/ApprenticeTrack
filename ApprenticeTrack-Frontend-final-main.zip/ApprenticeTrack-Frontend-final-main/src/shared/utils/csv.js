// Client-side CSV export. Opens in Excel/Sheets.
// columns: [{ key, label, format? }]. rows: array of objects.

function escapeCell(value) {
  const s = value == null ? '' : String(value);
  // Quote if it contains comma, quote, or newline; double up embedded quotes.
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function exportToCsv(filename, columns, rows) {
  const header = columns.map((c) => escapeCell(c.label)).join(',');
  const body = rows
    .map((row) =>
      columns
        .map((c) => escapeCell(c.format ? c.format(row[c.key], row) : row[c.key]))
        .join(',')
    )
    .join('\n');
  const csv = `${header}\n${body}`;

  // BOM so Excel detects UTF-8.
  const blob = new Blob(['﻿', csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename.endsWith('.csv') ? filename : `${filename}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
