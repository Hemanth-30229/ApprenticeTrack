// Save a Blob to the user's device as a download.

export function saveBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/** Pull filename from a Content-Disposition header, else fall back. */
export function filenameFromResponse(response, fallback) {
  const cd = response?.headers?.['content-disposition'] || '';
  const match = /filename="?([^"]+)"?/.exec(cd);
  return match ? match[1] : fallback;
}
