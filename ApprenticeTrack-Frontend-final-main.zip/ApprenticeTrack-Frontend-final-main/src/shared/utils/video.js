// Turn a course video URL into something embeddable.
// - YouTube watch/share/shorts -> embed iframe URL
// - direct video files (.mp4/.webm/.ogg) -> native <video>
// - anything else -> external link

export function resolveVideo(url) {
  if (!url) return { kind: 'none' };
  const u = url.trim();

  const yt = u.match(
    /(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{6,})/
  );
  if (yt) return { kind: 'youtube', src: `https://www.youtube.com/embed/${yt[1]}` };

  if (/\.(mp4|webm|ogg)(\?.*)?$/i.test(u)) return { kind: 'file', src: u };

  return { kind: 'link', src: u };
}
